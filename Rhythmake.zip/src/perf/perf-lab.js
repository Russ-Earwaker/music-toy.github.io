// src/perf/perf-lab.js
// Perf Lab: generates stress scenes + runs scripted benchmarks + copies JSON results.

import { setParticleQualityLock } from '../baseMusicToy/index.js';
import { start as startTransport, stop as stopTransport, isRunning } from '../audio-core.js';
import { initBoardAnchor } from '../board-anchor.js';
import { getCommittedState } from '../zoom/ZoomCoordinator.js';
import { runBenchmark } from './PerfHarness.js';
import { makePanZoomScript, makePanZoomCommitSpamScript, makeOverviewSpamScript, makeOverviewOnceScript, makeDrawgridRandomiseOnceScript } from './PerfScripts.js';
import { buildParticleWorstCase } from './StressSceneParticles.js';
import { buildChainedLoopgridStress } from './StressSceneChains.js';
import { overviewMode } from '../overview-mode.js';
import { evaluateAuthoringIntensityHandoffTrace, parseBeatSwarmTraceRecords } from '../beat-swarm/beat-swarm-authoring-intensity-audit.js';

// Global perf toggles consumed by shared particle code.
// Keep it simple: one object, easy to inspect in console.
try {
  window.__PERF_PARTICLES = window.__PERF_PARTICLES || {
    skipUpdate: false,
    skipDraw: false,
    budgetMul: 1,
    freezeUnfocusedDuringGesture: false,
    logFreeze: false,
  };
} catch {}

// ---------------------------------------------------------------------------
// Disable noisy debug traces during perf runs
//
// Perf Lab measures frame cost; verbose DG/FG traces distort results.
// You can re-enable any of these from the console for targeted debugging.
try {
  window.__DG_REFRESH_SIZE_TRACE = false;
  window.__DG_REFRESH_TRACE = false;
  window.__DG_GHOST_TRACE = false;
  window.__DG_LAYER_DEBUG = false;
  window.__TUTORIAL_STREAM_DEBUG = false;
} catch {}

// ---------------------------------------------------------------------------
// Perf trace buffering (avoid console.log during perf runs)
//
// Some debug traces (DG/FG DPR + canvas size snapshots) are extremely expensive if they
// hit console.log during heavy RAF. Instead, we buffer them in memory and attach a
// small snapshot to each perf result bundle.
try {
  const MAX = 3000;
  window.__PERF_TRACE_BUFFER = window.__PERF_TRACE_BUFFER || { events: [], max: MAX };
  window.__PERF_TRACE_KEEP_BUFFER = window.__PERF_TRACE_KEEP_BUFFER || false;
  window.__PERF_TRACE_TO_CONSOLE = window.__PERF_TRACE_TO_CONSOLE || false; // opt-in
  window.__PERF_TRACE_CLEAR = function __PERF_TRACE_CLEAR() {
    try {
      const b = window.__PERF_TRACE_BUFFER;
      if (b && Array.isArray(b.events)) b.events.length = 0;
    } catch {}
  };
  window.__PERF_TRACE_PUSH = function __PERF_TRACE_PUSH(kind, payload) {
    try {
      const b = window.__PERF_TRACE_BUFFER;
      if (!b || !Array.isArray(b.events)) return;
      const evt = {
        t: (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now(),
        kind: String(kind || ''),
        payload: payload || null,
      };
      b.events.push(evt);
      const max = Number.isFinite(b.max) ? b.max : MAX;
      if (b.events.length > max) b.events.splice(0, b.events.length - max);
    } catch {}
  };
  window.__PERF_TRACE_SNAPSHOT = function __PERF_TRACE_SNAPSHOT(limit = 200) {
    try {
      const b = window.__PERF_TRACE_BUFFER;
      const ev = (b && Array.isArray(b.events)) ? b.events : [];
      const n = Number.isFinite(limit) ? Math.max(0, Math.floor(limit)) : 200;
      const slice = n > 0 ? ev.slice(Math.max(0, ev.length - n)) : [];
      return { total: ev.length, tail: slice };
    } catch {
      return { total: 0, tail: [] };
    }
  };
} catch {}

// ---------------------------------------------------------------------------
// Trace summary helpers (PASS/FAIL signals for current focus)
//
// We intentionally avoid console logging during perf. Instead, we scan the buffered trace at the end
// of an auto-run and attach a compact summary to the bundle meta.
function computePerfTraceSummary() {
  try {
    const b = window.__PERF_TRACE_BUFFER;
    const ev = (b && Array.isArray(b.events)) ? b.events : [];
    let fgMinPressure = 1;
    let fgSawPressure = false;
    let fgSamples = 0;

    // Resize churn signals (if enabled)
    let dgSkipNotReady = 0;

    for (const e of ev) {
      if (!e || !e.kind) continue;
      if (e.kind === 'FG.dpr' && e.payload) {
        fgSamples++;
        const pm = Number(e.payload.pressureMul);
        if (Number.isFinite(pm)) {
          fgMinPressure = Math.min(fgMinPressure, pm);
          if (pm < 0.999) fgSawPressure = true;
        }
      }
      if (e.kind === 'DG.size-trace' && e.payload && e.payload.event === 'drawGrid:skip-not-ready') {
        dgSkipNotReady++;
      }
    }

    return {
      fg: {
        samples: fgSamples,
        minPressureMul: Number.isFinite(fgMinPressure) ? fgMinPressure : 1,
        sawPressure: !!fgSawPressure,
      },
      dg: {
        skipNotReadyCount: dgSkipNotReady,
      },
      traceEventCount: ev.length,
    };
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Auto-run queues
//
// Goal: keep the footer workflow stable:
//   1) Generic baseline (mixed → lots of DrawGrid → lots of Simple Rhythm)
//   2) Current Focus (changes as we iterate)
//   3) Focus Micro (short, high-signal, usually trace-enabled)
//
// Edit these arrays to change what the footer buttons run.

const AUTO_GENERIC_QUEUE = [
  'traceOff',
  'dgTierAutoOn',
  'dgForceTierAuto',
  'dgAdaptiveOff',
  // Mixed
  'buildP6',
  'runP6a',
  // Lots of DrawGrid
  'buildP3',
  'runP3f',
  // Lots of Simple Rhythm
  'buildP4',
  'runP4b',
];

// Current focus for this cycle:
//   - Single-batch DrawGrid focus triad on one shared scene build:
//     baseline -> overlays isolated -> baseline repeat
//   - Designed to replace "run Auto Generic multiple times" for this focus check.
//
// IMPORTANT:
// Keep this queue SHORT so it never *feels* like it's looping.
// If you want deep A/B sweeps, add them to AUTO_FOCUS_MICRO_QUEUE instead.
const AUTO_FOCUS_QUEUE = [
  // Keep focus apples-to-apples (trace off during perf measurement).
  'traceOff',
  'dgTierAutoOn',
  'dgForceTierAuto',
  'dgAdaptiveOn',

  // Build/warm once, then run all focus variants back-to-back.
  'buildP3',
  'warmupFirstAppearance',
  'warmupSettle',
  'runP3fShort',
  'warmupSettle',
  'runP3fNoOverlaysShort',
  'warmupSettle',
  // End with baseline repeat to reveal immediate drift/noise in same batch.
  'runP3fShort2',

  // Cleanup: return to default for subsequent manual runs.
  'dgAdaptiveOn',
  'dgForceTierAuto',
];

// Validation focus: same intent as AUTO_FOCUS_QUEUE but with more toys (stronger pressure signal).
// Use this to confirm pressure-DPR actually engages on stronger machines.
const AUTO_FOCUS_HEAVY_QUEUE = [
  'traceDprOn',

  // Build once (heavier than P3Focus)
  'buildP3FocusHeavy',
  'warmupFirstAppearance',
  'warmupSettle',

  // Same focus variants back-to-back on the same scene
  'runP3fFocusShort',
  'warmupSettle',
  // Repeat baseline once to spot run-to-run noise.
  'runP3fFocusShort2',
  'warmupSettle',
  'runP3fNoOverlaysFocusShort',
  'warmupSettle',
  'runP3fNoParticlesFocusShort',

  'traceDprOff',
  'traceOff',
];

// Focus Micro: short, high-signal runs (quickly verifies LOD, overlays, etc).
// Intended to be run frequently while iterating.
const AUTO_MICRO_QUEUE = [
  'traceDprOn',
  'buildP3Focus',
  'warmupFirstAppearance',
  'warmupSettle',
  'runP3fFocusShort',
  'warmupSettle',
  'runP3fNoParticlesFocusShort',
  'traceDprOff',
  'traceOff',
];

// Most diagnostic micro-run for the current focus.
// Usually trace ON + shortest script we have.
const AUTO_FOCUS_MICRO_QUEUE = [
  // IMPORTANT: micro should be apples-to-apples (trace adds overhead and noise).
  'traceOff',
  'buildP3Lite',
  // Warmup: reduce variance from "first time on screen" (canvas alloc / decode / first raster).
  'warmupFirstAppearance',
  'warmupSettle',
  // Baseline x2 (stability check)
  'runP3fShort',
  'runP3fShort2',

  // Overlays isolated x2
  'buildP3Lite',
  'warmupFirstAppearance',
  'warmupSettle',
  'runP3fNoOverlaysShort',
  'runP3fNoOverlaysShort2',

  // Particles isolated x2
  'buildP3Lite',
  'warmupFirstAppearance',
  'warmupSettle',
  'runP3fNoParticlesShort',
  'runP3fNoParticlesShort2',
];

// Zoom spike probe:
// - Same DrawGrid scene/warmup as focus runs
// - Adds commit-spam zoom variants (anchor ON/OFF) with short durations
//   to expose tail spikes tied to zoom commit/reflow paths.
const AUTO_ZOOM_SPIKE_QUEUE = [
  'traceOff',
  'dgTierAutoOn',
  'dgForceTierAuto',
  'dgAdaptiveOn',
  'buildP3',
  'warmupFirstAppearance',
  'warmupSettle',
  'runP3fShort',
  'warmupSettle',
  'runP3lShort',
  'warmupSettle',
  'runP3l2Short',
  'warmupSettle',
  'runP3fShort2',
  'dgAdaptiveOn',
  'dgForceTierAuto',
];

const AUTO_BEAT_SWARM_GENERIC_QUEUE = [
  'traceOff',
  'buildBS0',
  'runBS0s1',
  'runBS0s2',
  'runBS0s3',
  'runBS0s4',
  'runBS0s5',
];

const PERF_MUSIC_REPEAT_UI_KEY = 'perfLab:musicRepeatUi';

function ensureUI() {
  let ov = document.getElementById('perf-lab-overlay');
  if (ov) return ov;

  ov = document.createElement('div');
  ov.id = 'perf-lab-overlay';
  ov.className = 'perf-lab-overlay';

  // --- Build button lists (sorted) -----------------------------------------
  function btn(act, text, cls = '') {
    return `<button type="button" class="perf-lab-btn ${cls}" data-act="${act}">${text}</button>`;
  }

  function section(title, buttonsHtml) {
    return `
      <div class="perf-lab-section">
        <div class="perf-lab-section-title">${title}</div>
        <div class="perf-lab-section-buttons">${buttonsHtml}</div>
      </div>
    `;
  }

  function sortByLabel(arr) {
    return arr.slice().sort((a, b) => String(a.label).localeCompare(String(b.label)));
  }

  function loadMusicRepeatUiState() {
    try {
      const raw = localStorage.getItem(PERF_MUSIC_REPEAT_UI_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      return parsed && typeof parsed === 'object' ? parsed : null;
    } catch {
      return null;
    }
  }

  function saveMusicRepeatUiState(state = null) {
    try {
      const next = state && typeof state === 'object' ? state : null;
      if (!next) {
        localStorage.removeItem(PERF_MUSIC_REPEAT_UI_KEY);
        return;
      }
      localStorage.setItem(PERF_MUSIC_REPEAT_UI_KEY, JSON.stringify({
        enemyType: String(next.enemyType || 'drawsnake').trim().toLowerCase() || 'drawsnake',
        behavior: String(next.behavior || 'none').trim().toLowerCase() || 'none',
        groupCount: Math.max(1, Math.trunc(Number(next.groupCount) || 8)),
        speedScale: Math.max(0.25, Math.min(4, Number(next.speedScale) || 1)),
      }));
    } catch {}
  }

  const P2 = {
    title: 'P2 ? Particles',
    build: btn('buildP2', 'Build P2: Particle Worst-Case', 'primary'),
    runs: sortByLabel([
      { act: 'runP2a', label: 'Run P2a: Static (30s)' },
      { act: 'runP2b', label: 'Run P2b: Pan/Zoom (30s)' },
      { act: 'runP2c', label: 'Run P2c: Overview (30s)' },
    ]),
  };

  const P3 = {
    title: 'P3 ? DrawGrid',
    build:
      btn('buildP3Focus',      'Build P3Focus: DrawGrid (Tiny)', 'primary') +
      btn('buildP3FocusHeavy', 'Build P3FocusHeavy: DrawGrid (Heavy)', 'primary') +
      btn('buildP3Lite',       'Build P3Lite: DrawGrid (Fast)') +
      btn('buildP3',           'Build P3: DrawGrid Worst-Case'),
    runs: sortByLabel([
      { act: 'runP3f',  label: 'Run P3f: Playing Pan/Zoom + Random Notes (Anchor ON)' },
      { act: 'runP3fPlayheadSeparateOff', label: 'Run P3f: Playhead Separate OFF' },
      { act: 'runP3fPlayheadSeparateOn', label: 'Run P3f: Playhead Separate ON' },
      { act: 'runP3fMixedSomeEmpty', label: 'Run P3f: Playing Pan/Zoom (Mostly Full + Some Empty)' },
      { act: 'runP3fNoGrid', label: 'Run P3f: Playing Pan/Zoom + Random Notes (No Grid)' },
      { act: 'runP3fNoParticles', label: 'Run P3f: Playing Pan/Zoom + Random Notes (No Particles)' },
      { act: 'runP3fNoOverlays', label: 'Run P3f: Playing Pan/Zoom + Random Notes (No Overlays)' },
      { act: 'runP3fNoOverlayStrokes', label: 'Run P3f: Playing Pan/Zoom + Random Notes (No Overlay Strokes)' },
      { act: 'runP3fNoOverlayCore', label: 'Run P3f: Playing Pan/Zoom + Random Notes (No Overlay Core)' },
      { act: 'runP3fParticleProfile', label: 'Run P3f: Playing Pan/Zoom + Random Notes (Particle Profile)' }
    ]),
  };

  const P4 = {
    title: 'P4 ? Chained Simple Rhythm (Loopgrid)',
    build: [
      btn('buildP4',  'Build P4: Chained Simple Rhythm (Random)', 'primary'),
      btn('buildP4h', 'Build P4H: Chained SR (Heavy Play)', 'primary'),
    ].join(''),
    runs: sortByLabel([
      { act: 'runP4a',  label: 'Run P4a: Playing Static (30s)' },
      { act: 'runP4b',  label: 'Run P4b: Playing Pan/Zoom (30s)' },
      { act: 'runP4c',  label: 'Run P4c: Playing Static (No Particle Draw)' },
      { act: 'runP4d',  label: 'Run P4d: Playing Static (No Particle Update+Draw)' },
      { act: 'runP4e',  label: 'Run P4e: Pan/Zoom (Toy Draw ?2)' },
      { act: 'runP4f',  label: 'Run P4f: Pan/Zoom (Freeze Unfocused)' },
      { act: 'runP4g',  label: 'Run P4g: Pan/Zoom (Unfocused ?2)' },
      { act: 'runP4h2', label: 'Run P4h2: Pan/Zoom (Unfocused ?4)' },
      { act: 'runP4i',  label: 'Run P4i: Pan/Zoom (Unfocused Pulse-Only)' },
      { act: 'runP4j',  label: 'Run P4j: Pan/Zoom (Unfocused Step-Only)' },
      { act: 'runP4k',  label: 'Run P4k: Playing Pan/Zoom (No zoom-tick relayout)' },
      { act: 'runP4m',  label: 'Run P4m: Pan/Zoom (No Loopgrid Visuals)' },
      { act: 'runP4n',  label: 'Run P4n: Pan/Zoom (No Chains/Dots/Overlays)' },
      { act: 'runP4o',  label: 'Run P4o: Playing Pan/Zoom (No Pulses)' },
      { act: 'runP4p',  label: 'Run P4p: Playing Pan/Zoom (Audio+Step Only)' },
      { act: 'runP4q',  label: 'Run P4q: Playing Pan/Zoom (No Chains)' },
      { act: 'runP4r',  label: 'Run P4r: Playing Pan/Zoom (No Tap Dots)' },
      { act: 'runP4s',  label: 'Run P4s: Playing Pan/Zoom (No Overlays)' },
      { act: 'runP4t',  label: 'Run P4t: Playing Pan/Zoom (No Loopgrid Render)' },
      { act: 'runP4u',  label: 'Run P4u: Playing Pan/Zoom (Gesture Render ?2)' },
      { act: 'runP4v',  label: 'Run P4v: Playing Pan/Zoom (Gesture Render ?4)' },
      { act: 'runP4w',  label: 'Run P4w: Playing Pan/Zoom (Gesture ?4 + No Tap Dots)' },
      { act: 'runP4x',  label: 'Run P4x: Pan/Zoom (Gesture ?4 + No Tap Dots + Chain Cache)' },
    ]),
  };

  

  const P5 = {
    title: 'P5 - Mixed Draw + Simple Rhythm',
    build: btn('buildP5', 'Build P5: Mixed Draw + SR', 'primary'),
    runs: sortByLabel([
      { act: 'runP5a', label: 'Run P5a: Playing Pan/Zoom (Random Notes)' },
      { act: 'runP5b', label: 'Run P5b: Pan/Zoom (Gesture Draw 1/2)' },
      { act: 'runP5c', label: 'Run P5c: Pan/Zoom (Gesture Fields 1/2)' },
    ]),
  };

  const P6 = {
    title: 'P6 - Avg Mix (4 SR Chains + 4 Draw)',
    build: btn('buildP6', 'Build P6: Avg Mix', 'primary'),
    runs: sortByLabel([
      { act: 'runP6a', label: 'Run P6a: Playing Pan/Zoom (Random Notes)' },
      { act: 'runP6b', label: 'Run P6b: Playing Static (Random Notes)' },
      { act: 'runP6c', label: 'Run P6c: Playing Extreme Zoom (Random Notes)' },
      { act: 'runP6d', label: 'Run P6d: Extreme Zoom (Gesture Mod 1/4)' },
      { act: 'runP6e', label: 'Run P6e: Extreme Zoom + Zoom Profiling' },
      { act: 'runP6eNoPaint', label: 'Run P6e: Extreme Zoom + No Paint' },
      { act: 'runP6ePaintOnly', label: 'Run P6e: Extreme Zoom + Paint Only' },
      { act: 'runP6eNoDom', label: 'Run P6e: Extreme Zoom + No DOM Updates' },
    ]),
  };

  const P7 = {
    title: 'P7 - Mixed Chains (4x Draw + 4x SR)',
    build: btn('buildP7', 'Build P7: Mixed Chains', 'primary'),
    runs: sortByLabel([
      { act: 'runP7a', label: 'Run P7a: Playing Pan/Zoom (All Toys Active)' },
      { act: 'runP7b', label: 'Run P7b: Playing Pan/Zoom (Some Toys Empty)' },
    ]),
  };

  const BS0 = {
    title: 'BS0 - Beat Swarm (Default Empty Scene)',
    build: btn('buildBS0', 'Build BS0: Beat Swarm Default Scene', 'primary'),
    runs: sortByLabel([
      { act: 'runBS0s1', label: 'Run BS0 S1: Static Fire (1 Stage)' },
      { act: 'runBS0s2', label: 'Run BS0 S2: Static Fire (2 Stages)' },
      { act: 'runBS0s3', label: 'Run BS0 S3: Static Fire (3 Stages)' },
      { act: 'runBS0s4', label: 'Run BS0 S4: Static Fire (4 Stages)' },
      { act: 'runBS0s5', label: 'Run BS0 S5: Static Fire (5 Stages)' },
    ]),
  };

  const ENEMY_SANDBOX = {
    title: 'Enemy Sandbox',
    controls: `<div class="perf-lab-enemy-sandbox-controls is-pinned">
          <select class="perf-lab-select" data-enemy-sandbox-kind aria-label="Enemy class">
            <option value="basic_small">Basic small</option>
            <option value="basic_large">Basic large</option>
            <option value="elite_formation">Elite formation</option>
            <option value="rock">Rock (native)</option>
            <option value="spawner">Spawner (native)</option>
            <option value="drawsnake">Snake (native, 1 max)</option>
          </select>
          <select class="perf-lab-select" data-enemy-sandbox-ability aria-label="Enemy ability">
            <optgroup label="Projectile">
              <option value="projectile_straight">Straight projectile</option>
              <option value="projectile_spread">Spread projectile</option>
              <option value="projectile_burst">Burst projectile</option>
              <option value="homing_single">Homing projectile</option>
              <option value="homing_swarm">Homing swarm</option>
            </optgroup>
            <optgroup label="Laser">
              <option value="laser_sweep">Sweep laser</option>
              <option value="laser_radial">Radial laser</option>
              <option value="laser_tracking">Tracking laser</option>
              <option value="laser_beam_thin">Arena beam thin</option>
              <option value="laser_beam_thick">Arena beam thick</option>
            </optgroup>
            <optgroup label="Area and movement">
              <option value="local_explosion">Local explosion</option>
              <option value="wind_push">Wind push</option>
              <option value="arena_safe_circle">Safe circle</option>
              <option value="arena_danger_hex">Danger hex</option>
              <option value="charge_direct">Direct charge</option>
              <option value="charge_intercept">Intercept charge</option>
            </optgroup>
            <optgroup label="Support">
              <option value="support_shield_pair">Shield pair</option>
              <option value="support_shield_field">Shield field</option>
            </optgroup>
          </select>
          <select class="perf-lab-select" data-enemy-sandbox-count aria-label="Enemy count">
            <option value="1">1 enemy</option>
            <option value="2">2 enemies</option>
            <option value="3" selected>3 enemies</option>
            <option value="4">4 enemies</option>
            <option value="6">6 enemies</option>
            <option value="8">8 enemies</option>
          </select>
          ${btn('enemySandboxSpawn', 'Spawn / Replace', 'primary')}
          ${btn('enemySandboxClear', 'Clear / Exit Sandbox')}
        </div>`,
  };

  const MUSIC_LAB = {
    title: 'Music Lab - Beat Swarm Diagnostics',
    controls: [
      `<div class="perf-lab-music-current">
        <div class="perf-lab-controlsTitle">Current Work</div>
        ${btn('musicLabRunArrangementIntensityRampDebug', 'Run Arrangement Intensity Ramp (1x115s)', 'primary')}
        ${btn('musicLabRunFullScoreArrangementDebug', 'Run Full Score + Arrangements (1x75s)', 'primary')}
        ${btn('musicLabRunDirectorFormationIntensityFlow', 'Run Production Onboarding Flow (1x300s)', 'primary')}
        ${btn('musicLabRunOnboardingCompositionAudit', 'Run Autopilot Composition Audit (1x240s)', 'primary')}
        ${btn('musicLabRunEnemyArchitectureDebug', 'Run Enemy Lane + Movement Lab (1x70s)', 'primary')}
      </div>`,
      `<details class="perf-lab-music-group">
        <summary>Session and Export</summary>
        <div class="perf-lab-music-group-body">
          ${btn('musicLabEnable', 'Enable Music Lab')}${btn('musicLabDisable', 'Disable Music Lab')}
          ${btn('musicLabReset', 'Reset Session', 'primary')}${btn('musicLabSnapshot', 'Show Snapshot')}
          ${btn('musicLabExport', 'Export JSON')}${btn('musicLabSaveResources', 'Save to resources')}${btn('musicLabDownload', 'Download JSON')}
        </div>
      </details>`,
    ].join(''),
  };

  const tests = [...P3.runs, ...P7.runs, ...BS0.runs];
  if (!window.__PERF_LAB_TESTS_LOGGED) {
    window.__PERF_LAB_TESTS_LOGGED = true;
    try { console.log('[perf-lab] tests:', tests.map(t => t.label)); } catch {}
  }

  const toolsHtml = section(
    'Tools',
    [
      btn('auto', 'Run Auto (Demon Hunt: traceOff → traceOn)'),
      btn('autoFast', 'Auto: Fast Loop (P3f A/B + NoParticles + P4b)'),
      btn('autoPauseDom', 'Auto: Pause DOM-in-RAF Probe'),
      btn('autoQuickTraceP3f', 'Auto: Quick Trace P3f (Short)'),
      btn('autoGenericAdaptiveCompare', 'Auto: Generic (Compare DG Adaptive DPR)'),
    ].join('')
  );

  const sectionsHtml = [
    section(P3.title, `${P3.build}${P3.runs.map(r => btn(r.act, r.label)).join('')}`),
    section(P7.title, `${P7.build}`),
    section(BS0.title, `${BS0.build}${BS0.runs.map(r => btn(r.act, r.label)).join('')}`),
    toolsHtml,
  ].join('');
  const musicHtml = [
    section(ENEMY_SANDBOX.title, ENEMY_SANDBOX.controls),
    section(MUSIC_LAB.title, MUSIC_LAB.controls),
  ].join('');

  ov.innerHTML = `
    <div class="perf-lab-panel">
      <div class="perf-lab-header">
        <div>
          <div class="perf-lab-title">Perf Lab</div>
          <div class="perf-lab-sub">Repeatable stress tests</div>
        </div>
        <div class="perf-lab-header-right">
          <button class="perf-lab-btn" data-act="close">?</button>
        </div>
      </div>

      <div class="perf-lab-body perf-lab-split">
        <div class="perf-lab-left">
          <div class="perf-lab-tabs">
            <button class="perf-lab-tab is-active" data-tab="controls">Controls</button>
            <button class="perf-lab-tab" data-tab="music">Music</button>
            <button class="perf-lab-tab" data-tab="tests">Tests</button>
            <button class="perf-lab-tab" data-tab="harmony">Harmony</button>
          </div>

          <div class="perf-lab-tabpage is-active" data-tabpage="controls">
            <div class="perf-lab-controlsPanel">
              <div class="perf-lab-controlsGroup">
                <div class="perf-lab-controlsTitle">Quality Lab</div>
                <label class="perf-lab-toggle">Target FPS
                  <select class="perf-lab-select" data-qlab="targetFps">
                    <option value="0">Off</option>
                    <option value="60">60</option>
                    <option value="30">30</option>
                    <option value="20">20</option>
                    <option value="15">15</option>
                    <option value="10">10</option>
                    <option value="5">5</option>
                  </select>
                </label>
                <label class="perf-lab-toggle">CPU burn
                  <select class="perf-lab-select" data-qlab="cpuBurnMs">
                    <option value="0">0ms</option>
                    <option value="2">2ms</option>
                    <option value="5">5ms</option>
                    <option value="10">10ms</option>
                    <option value="15">15ms</option>
                    <option value="20">20ms</option>
                  </select>
                </label>
                <label class="perf-lab-toggle">Quality
                  <select class="perf-lab-select" data-qlab="forceScale">
                    <option value="">Auto</option>
                    <option value="1">High (1.0)</option>
                    <option value="0.7">Med (0.7)</option>
                    <option value="0.45">Low (0.45)</option>
                  </select>
                </label>
                <label class="perf-lab-toggle">DrawGrid tier
                  <select class="perf-lab-select" data-qlab="dgForceTier">
                    <option value="">Auto</option>
                    <option value="3">3 (Full)</option>
                    <option value="2">2 (Light)</option>
                    <option value="1">1 (Medium)</option>
                    <option value="0">0 (Low)</option>
                    <option value="-1">-1 (Emergency)</option>
                  </select>
                </label>
                <label class="perf-lab-toggle">LoopGrid tier
                  <select class="perf-lab-select" data-qlab="lgForceTier">
                    <option value="">Auto</option>
                    <option value="0">0 (Full)</option>
                    <option value="1">1 (High)</option>
                    <option value="2">2 (Med)</option>
                    <option value="3">3 (Low)</option>
                    <option value="4">4 (Ultra)</option>
                  </select>
                </label>
                <div class="perf-lab-row perf-lab-qlab-buttons">
                  <button class="perf-lab-btn perf-lab-btn-mini" data-act="qualityApply">Apply</button>
                </div>
              </div>
            </div>
          </div>

          <div class="perf-lab-tabpage" data-tabpage="tests">
            <div class="perf-lab-tests" id="perf-lab-tests">
              <div class="perf-lab-controlsPanel" style="margin-bottom:10px;">
                <div class="perf-lab-controlsGroup">
                  <div class="perf-lab-controlsTitle">Perf toggles</div>
                  <div class="perf-lab-row perf-lab-toggles">
                    <label class="perf-lab-toggle"><input type="checkbox" data-tog="skipUpdate" /> Skip particle update</label>
                    <label class="perf-lab-toggle"><input type="checkbox" data-tog="skipDraw" /> Skip particle draw</label>
                    <label class="perf-lab-toggle">Budget
                      <select class="perf-lab-select" data-tog="budgetMul">
                        <option value="1">100%</option><option value="0.5">50%</option><option value="0.25">25%</option><option value="0.1">10%</option>
                      </select>
                    </label>
                    <label class="perf-lab-toggle"><input type="checkbox" data-tog="freezeUnfocusedDuringGesture" checked /> Freeze unfocused</label>
                    <label class="perf-lab-toggle"><input type="checkbox" data-perf="freezeChainUi" /> Freeze chain UI</label>
                    <label class="perf-lab-toggle"><input type="checkbox" data-perf="traceMarks" /> Trace marks</label>
                    <label class="perf-lab-toggle"><input type="checkbox" data-perf="traceCanvasResize" /> Trace canvas resize</label>
                    <label class="perf-lab-toggle"><input type="checkbox" data-perf="traceDomInRaf" /> Trace DOM-in-RAF</label>
                  </div>
                </div>
              </div>
              ${sectionsHtml}
            </div>
          </div>

          <div class="perf-lab-tabpage" data-tabpage="music">
            <div class="perf-lab-tests" id="perf-lab-music">
              ${musicHtml}
            </div>
          </div>


          <div class="perf-lab-tabpage" data-tabpage="harmony">
            <iframe class="perf-lab-harmony-frame" title="Harmony Lab" allow="autoplay"></iframe>
          </div>

          <div class="perf-lab-lastresult">
            <div class="perf-lab-output-title">Last Result</div>
            <pre class="perf-lab-output perf-lab-output-small" id="perf-lab-output"></pre>
          </div>
          <div class="perf-lab-row perf-lab-footer">
            <button class="perf-lab-btn" data-act="autoGeneric">Run-Auto (Generic)</button>
            <button class="perf-lab-btn" data-act="autoBeatSwarmGeneric">Auto: Beat Swarm (Generic)</button>
            <button class="perf-lab-btn" data-act="autoFocus">Auto: Current Focus</button>
            <button class="perf-lab-btn" data-act="autoZoomSpike">Auto: Zoom Spike Probe</button>
            <button class="perf-lab-btn" data-act="autoFocusHeavy">Auto: Focus Validation (Heavy)</button>
            <button class="perf-lab-btn" data-act="autoMicro">Auto: Focus Micro (Best)</button>
            <div class="perf-lab-status" id="perf-lab-status">Idle</div>
          </div>
        </div>
          <pre class="perf-lab-output" id="perf-lab-output"></pre>
        </div>
      </div>
    </div>
  `;

  // --- one-time CSS injection for split layout ------------------------------
  if (!document.getElementById('perf-lab-style')) {
    const style = document.createElement('style');
    style.id = 'perf-lab-style';
    style.textContent = `
      .perf-lab-overlay{
        position:fixed;
        right:12px;
        bottom:12px;
        left:auto;
        top:auto;
        transform:none;
        z-index:99999;
        max-width:calc(100vw - 24px);
        max-height:calc(100vh - 24px);
      }
      .perf-lab-panel{
        width:min(490px, calc(100vw - 24px));
      }
            .perf-lab-split{
        display:block;
        height: min(78vh, 720px);
      }
      .perf-lab-left{
        display:flex;
        flex-direction:column;
        min-height:0;
      }
      .perf-lab-overlay.is-harmony .perf-lab-panel{width:min(960px, calc(100vw - 24px));}
      .perf-lab-overlay.is-harmony .perf-lab-lastresult,
      .perf-lab-overlay.is-harmony .perf-lab-footer{display:none;}
      .perf-lab-harmony-frame{display:block;width:100%;height:min(70vh, 650px);border:0;border-radius:10px;}
      .perf-lab-tabs{
        display:flex;
        gap:8px;
        margin:0 0 8px;
      }
      .perf-lab-tab{
        appearance:none;
        border:1px solid rgba(255,255,255,0.14);
        background:rgba(255,255,255,0.06);
        color:inherit;
        border-radius:10px;
        padding:7px 10px;
        font-size:12px;
        line-height:1;
        cursor:pointer;
        user-select:none;
      }
      .perf-lab-tab.is-active{
        background:rgba(255,255,255,0.14);
        border-color:rgba(255,255,255,0.24);
      }
      .perf-lab-tabpage{
        display:none;
        min-height:0;
      }
      .perf-lab-tabpage.is-active{
        display:block;
        min-height:0;
      }      .perf-lab-tests{
        flex:1;
        min-height:0;
        overflow:auto;
        padding-right:6px;
        border-top:1px solid rgba(255,255,255,0.08);
      }
      .perf-lab-output-title{
        font-size:12px;
        opacity:0.75;
        margin:4px 0 8px;
      }
      .perf-lab-output{
        flex:1;
        min-height:0;
        overflow:auto;
        max-height:100%;
      }
      .perf-lab-lastresult{
        border-top:1px solid rgba(255,255,255,0.08);
        margin-top:10px;
        padding-top:10px;
        min-height:0;
      }
      .perf-lab-output-small{
        max-height:120px;
      }      .perf-lab-section{ padding:10px 0; }
      .perf-lab-section-title{
        font-weight:600;
        font-size:12px;
        opacity:0.85;
        margin:0 0 8px;
      }
      .perf-lab-section-buttons{
        display:flex;
        flex-wrap:wrap;
        gap:8px;
      }
      .perf-lab-footer{
        margin-top:10px;
        border-top:1px solid rgba(255,255,255,0.08);
        padding-top:10px;
      }
      .perf-lab-header-right{
        display:flex;
        align-items:flex-start;
        gap:10px;
      }
      .perf-lab-btn-mini{
        padding:6px 10px;
        font-size:12px;
        line-height:1;
      }
      button.perf-lab-btn.is-active{
        background:rgba(255,255,255,0.16);
        border-color:rgba(255,255,255,0.28);
      }
      .perf-lab-controlsPanel{
        background:rgba(20,20,20,0.85);
        border:1px solid rgba(255,255,255,0.12);
        border-radius:10px;
        padding:10px;
        box-shadow:0 10px 40px rgba(0,0,0,0.35);
      }      .perf-lab-controlsGroup{
        padding:6px 0;
      }
      .perf-lab-controlsGroup + .perf-lab-controlsGroup{
        border-top:1px solid rgba(255,255,255,0.08);
        margin-top:8px;
        padding-top:10px;
      }
      .perf-lab-controlsTitle{
        font-size:12px;
        font-weight:600;
        opacity:0.85;
        margin:0 0 8px;
      }
      .perf-lab-music-current,
      .perf-lab-music-group{
        flex:1 0 100%;
        min-width:0;
      }
      .perf-lab-music-current{
        padding:10px;
        border:1px solid rgba(126,205,255,0.34);
        border-radius:6px;
        background:rgba(86,155,208,0.1);
      }
      .perf-lab-enemy-sandbox-controls{
        display:grid;
        grid-template-columns:minmax(120px,1fr) minmax(160px,1.4fr) minmax(90px,.7fr);
        gap:8px;
        width:100%;
        margin:0;
      }
      .perf-lab-enemy-sandbox-controls.is-pinned{
        padding:10px;
        border:1px solid rgba(255,255,255,0.12);
        background:rgba(255,255,255,0.035);
      }
      .perf-lab-enemy-sandbox-controls .perf-lab-select{
        min-width:0;
        width:100%;
      }
      .perf-lab-enemy-sandbox-controls .perf-lab-btn{
        margin:0;
      }
      @media (max-width:720px){
        .perf-lab-enemy-sandbox-controls{
          grid-template-columns:minmax(0,1fr);
        }
      }
      .perf-lab-music-group{
        border-top:1px solid rgba(255,255,255,0.1);
        padding-top:8px;
      }
      .perf-lab-music-group summary{
        cursor:pointer;
        font-size:12px;
        font-weight:600;
        opacity:0.82;
        padding:4px 0;
      }
      .perf-lab-music-group-body{
        display:flex;
        flex-wrap:wrap;
        gap:8px;
        padding:8px 0 2px;
      }
      .perf-lab-qlab-buttons{
        gap:8px;
        margin-top:8px;
      }
    `;
    document.head.appendChild(style);
  }
  // Initialise toggle UI from current global state (so defaults match what you see)
  try {
    const st = (window.__PERF_PARTICLES = window.__PERF_PARTICLES || {});
    ov.querySelectorAll('[data-tog]').forEach((el) => {
      const key = el.getAttribute('data-tog');
      if (!key) return;
      const v = st[key];
      if (el.tagName === 'INPUT' && el.type === 'checkbox') el.checked = !!v;
      if (el.tagName === 'SELECT') {
        const val = Number.isFinite(v) ? v : el.value;
        el.value = String(Number(val));
      }
    });
    ov.querySelectorAll('[data-perf]').forEach((el) => {
      const key = el.getAttribute('data-perf');
      if (!key) return;
      const trace = (window.__PERF_TRACE || {});
      const v =
        (key === 'traceMarks') ? window.__PERF_TRACE_MARKS :
        (key === 'freezeChainUi') ? window.__PERF_DISABLE_CHAIN_UI :
        (key === 'traceCanvasResize') ? !!trace.traceCanvasResize :
        (key === 'traceDomInRaf') ? !!trace.traceDomInRaf :
        null;
      if (el.tagName === 'INPUT' && el.type === 'checkbox') el.checked = !!v;
    });
  } catch {}
  // Quality Lab defaults
  try {
    const qlab = (window.__QUALITY_LAB = window.__QUALITY_LAB || {});
    if (!('targetFps' in qlab)) qlab.targetFps = 0;
    if (!('cpuBurnMs' in qlab)) qlab.cpuBurnMs = 0;
    if (!('forceScale' in qlab)) qlab.forceScale = null;
    if (!('dgForceTier' in qlab)) qlab.dgForceTier = (typeof window !== 'undefined' ? (window.__DG_FORCE_TIER ?? null) : null);
    if (!('lgForceTier' in qlab)) qlab.lgForceTier = (typeof window !== 'undefined' ? (window.__LG_FORCE_TIER ?? null) : null);
    // Legacy mirror (handy for console poking)
    if (typeof window.__QUALITY_FORCE_SCALE !== 'number') window.__QUALITY_FORCE_SCALE = null;
  } catch {}


  // Pending settings (only committed on Apply)
  const __pending = {
    qlab: null,
    particles: null,
    perf: null,
  };
  try {
    __pending.qlab = { ...(window.__QUALITY_LAB || {}) };
    if (!('dgForceTier' in __pending.qlab)) __pending.qlab.dgForceTier = (typeof window !== 'undefined' ? (window.__DG_FORCE_TIER ?? null) : null);
    if (!('lgForceTier' in __pending.qlab)) __pending.qlab.lgForceTier = (typeof window !== 'undefined' ? (window.__LG_FORCE_TIER ?? null) : null);
    __pending.particles = { ...(window.__PERF_PARTICLES || {}) };
    __pending.perf = {
      traceMarks: !!window.__PERF_TRACE_MARKS,
      freezeChainUi: !!window.__PERF_DISABLE_CHAIN_UI,
      traceCanvasResize: !!(window.__PERF_TRACE && window.__PERF_TRACE.traceCanvasResize),
      traceDomInRaf: !!(window.__PERF_TRACE && window.__PERF_TRACE.traceDomInRaf),
    };
  } catch {
    __pending.qlab = { targetFps: 0, cpuBurnMs: 0, forceScale: null, dgForceTier: null, lgForceTier: null };
    __pending.particles = {};
    __pending.perf = { traceMarks: false, freezeChainUi: false, traceCanvasResize: false, traceDomInRaf: false };
  }

  function syncUiFromPending() {
    try {
      // Quality Lab controls
      ov.querySelectorAll('[data-qlab]').forEach((el) => {
        const k = el.getAttribute('data-qlab');
        if (!k) return;
        if (k === 'forceScale') {
          const v = (typeof __pending.qlab.forceScale === 'number' && isFinite(__pending.qlab.forceScale))
            ? String(__pending.qlab.forceScale) : '';
          if (el.tagName === 'SELECT') el.value = v;
          return;
        }
        if (k === 'dgForceTier') {
          const v = __pending.qlab.dgForceTier;
          if (el.tagName === 'SELECT') el.value = (v == null) ? '' : String(v);
          return;
        }
        if (k === 'lgForceTier') {
          const v = __pending.qlab.lgForceTier;
          if (el.tagName === 'SELECT') el.value = (v == null) ? '' : String(v);
          return;
        }
        const v = __pending.qlab[k];
        if (el.tagName === 'SELECT') el.value = String(Number(v) || 0);
      });

      // Particle toggles
      ov.querySelectorAll('[data-tog]').forEach((el) => {
        const key = el.getAttribute('data-tog');
        if (!key) return;
        const v = __pending.particles[key];
        if (el.tagName === 'INPUT' && el.type === 'checkbox') el.checked = !!v;
        if (el.tagName === 'SELECT') {
          const val = Number.isFinite(v) ? v : el.value;
          el.value = String(Number(val));
        }
      });

      // Perf toggles
      ov.querySelectorAll('[data-perf]').forEach((el) => {
        const key = el.getAttribute('data-perf');
        if (!key) return;
        const v =
          (key === 'traceMarks') ? __pending.perf.traceMarks :
          (key === 'freezeChainUi') ? __pending.perf.freezeChainUi :
          (key === 'traceCanvasResize') ? __pending.perf.traceCanvasResize :
          (key === 'traceDomInRaf') ? __pending.perf.traceDomInRaf :
          null;
        if (el.tagName === 'INPUT' && el.type === 'checkbox') el.checked = !!v;
      });
    } catch {}
  }

  function __applyDrawgridForceTier(forceTier) {
    try {
      window.__DG_FORCE_TIER = (forceTier == null) ? null : forceTier;
    } catch {}

    try {
      const panels = document.querySelectorAll('.toy-panel');
      for (const p of panels) {
        const fn = p && p.__dgSetQualityTier;
        if (typeof fn !== 'function') continue;
        if (forceTier == null) {
          try { delete p.__dgQualityTier; } catch {}
          try { delete p.__dgQualityTierReason; } catch {}
          try { delete p.__dgQualityTierSetMs; } catch {}
        } else {
          fn(forceTier, 'perflab');
        }
      }
    } catch {}
  }

  function __applyLoopgridForceTier(forceTier) {
    // LoopGrid currently reads the global override (window.__LG_FORCE_TIER) inside the toy code.
    // We also *optionally* push to panels if we ever add a panel hook later.
    try {
      window.__LG_FORCE_TIER = (forceTier == null) ? null : forceTier;
    } catch {}

    try {
      const panels = document.querySelectorAll('.toy-panel');
      for (const p of panels) {
        const fn = p && p.__lgSetQualityTier;
        if (typeof fn !== 'function') continue;
        if (forceTier == null) {
          try { delete p.__lgQualityTier; } catch {}
          try { delete p.__lgQualityTierReason; } catch {}
          try { delete p.__lgQualityTierSetMs; } catch {}
        } else {
          fn(forceTier, 'perflab');
        }
      }
    } catch {}
  }

  function applyPendingToGlobals() {
    try {
      window.__QUALITY_LAB = window.__QUALITY_LAB || {};
      const qlab = window.__QUALITY_LAB;
      qlab.targetFps = Math.max(0, Number(__pending.qlab.targetFps) || 0);
      qlab.cpuBurnMs = Math.max(0, Number(__pending.qlab.cpuBurnMs) || 0);
      qlab.forceScale = (typeof __pending.qlab.forceScale === 'number' && isFinite(__pending.qlab.forceScale)) ? __pending.qlab.forceScale : null;
      qlab.dgForceTier = (__pending.qlab.dgForceTier == null) ? null : (__pending.qlab.dgForceTier | 0);
      qlab.lgForceTier = (__pending.qlab.lgForceTier == null) ? null : (__pending.qlab.lgForceTier | 0);
      window.__QUALITY_FORCE_SCALE = (typeof qlab.forceScale === 'number') ? qlab.forceScale : null;
      try {
        const t = (qlab.dgForceTier == null) ? null : (qlab.dgForceTier | 0);
        __applyDrawgridForceTier(t);
      } catch {}
      try {
        const t = (qlab.lgForceTier == null) ? null : (qlab.lgForceTier | 0);
        __applyLoopgridForceTier(t);
      } catch {}

      window.__PERF_PARTICLES = window.__PERF_PARTICLES || {};
      Object.assign(window.__PERF_PARTICLES, __pending.particles || {});

      window.__PERF_TRACE = window.__PERF_TRACE || {};
      window.__PERF_TRACE_MARKS = !!__pending.perf.traceMarks;
      window.__PERF_DISABLE_CHAIN_UI = !!__pending.perf.freezeChainUi;
      window.__PERF_TRACE.traceCanvasResize = !!__pending.perf.traceCanvasResize;
      window.__PERF_TRACE.traceDomInRaf = !!__pending.perf.traceDomInRaf;

      console.log('[PerfLab] APPLY', { qlab: { ...qlab }, particles: { ...window.__PERF_PARTICLES }, perf: { ...__pending.perf } });
    } catch {}
  }

  // Start UI by reflecting the pending state (not necessarily the globals)
  try { syncUiFromPending(); } catch {}
  try { setCycleBtnVisual(); } catch {}
  try { setShowStateBtnVisual(); } catch {}
  try {
    const storedMusicRepeatUi = loadMusicRepeatUiState();
    if (storedMusicRepeatUi) {
      const typeEl = ov.querySelector('[data-music-spawn-type]');
      const behaviorEl = ov.querySelector('[data-music-spawn-behavior]');
      const countEl = ov.querySelector('[data-music-group-count]');
      const speedEl = ov.querySelector('[data-music-speed-scale]');
      if (typeEl instanceof HTMLSelectElement) typeEl.value = String(storedMusicRepeatUi.enemyType || 'drawsnake');
      if (behaviorEl instanceof HTMLSelectElement) behaviorEl.value = String(storedMusicRepeatUi.behavior || 'none');
      if (countEl instanceof HTMLSelectElement) countEl.value = String(Math.max(1, Math.trunc(Number(storedMusicRepeatUi.groupCount) || 8)));
      if (speedEl instanceof HTMLSelectElement) speedEl.value = String(Math.max(0.25, Math.min(4, Number(storedMusicRepeatUi.speedScale) || 1)));
    }
  } catch {}
  // Keep UI checkboxes/selects in sync with global perf state.
  // (Used by Trace Demon buttons and safe to call anytime.)
  function syncUiFromState() {
    try {
      const st = (window.__PERF_PARTICLES = window.__PERF_PARTICLES || {});
      ov.querySelectorAll('[data-tog]').forEach((el) => {
        const key = el.getAttribute('data-tog');
        if (!key) return;
        const v = st[key];
        if (el.tagName === 'INPUT' && el.type === 'checkbox') el.checked = !!v;
        if (el.tagName === 'SELECT') {
          const val = Number.isFinite(v) ? v : el.value;
          el.value = String(Number(val));
        }
      });

      const trace = (window.__PERF_TRACE || {});
      ov.querySelectorAll('[data-perf]').forEach((el) => {
        const key = el.getAttribute('data-perf');
        if (!key) return;
        const v =
          (key === 'traceMarks') ? window.__PERF_TRACE_MARKS :
          (key === 'freezeChainUi') ? window.__PERF_DISABLE_CHAIN_UI :
          (key === 'traceCanvasResize') ? !!trace.traceCanvasResize :
          (key === 'traceDomInRaf') ? !!trace.traceDomInRaf :
          null;
        if (el.tagName === 'INPUT' && el.type === 'checkbox') el.checked = !!v;
      });
      // Quality Lab controls (FPS throttle + forced quality scale)
      const qlab = (window.__QUALITY_LAB = window.__QUALITY_LAB || {});
      ov.querySelectorAll('[data-qlab]').forEach((el) => {
        const k = el.getAttribute('data-qlab');
        if (!k) return;
        if (k === 'forceScale') {
          // forceScale: null | number (empty string => auto)
          const v = (typeof qlab.forceScale === 'number' && isFinite(qlab.forceScale)) ? String(qlab.forceScale) : '';
          if (el.tagName === 'SELECT') el.value = v;
          return;
        }
        if (k === 'dgForceTier') {
          const v = qlab.dgForceTier;
          if (el.tagName === 'SELECT') el.value = (v == null) ? '' : String(v);
          return;
        }
        if (k === 'lgForceTier') {
          const v = qlab.lgForceTier;
          if (el.tagName === 'SELECT') el.value = (v == null) ? '' : String(v);
          return;
        }
        const v = qlab[k];
        if (el.tagName === 'SELECT') el.value = String(Number(v) || 0);
      });
    } catch {}
  }

  function getMusicLabApi() {
    const api = window.__beatSwarmMusicLab;
    if (!api || typeof api !== 'object') return null;
    if (typeof api.exportSession !== 'function') return null;
    return api;
  }

  function getMusicLabDebugState() {
    const api = getMusicLabApi();
    if (!api) return { available: false };
    let snap = null;
    try {
      snap = (typeof api.getSessionSnapshot === 'function') ? api.getSessionSnapshot() : null;
    } catch {}
    const events = Array.isArray(snap?.events) ? snap.events : [];
    const paletteChanges = Array.isArray(snap?.paletteChanges) ? snap.paletteChanges : [];
    const pacingChanges = Array.isArray(snap?.pacingChanges) ? snap.pacingChanges : [];
    const executedCount = events.filter((e) => String(e?.phase || '') === 'executed').length;
    return {
      available: true,
      sessionId: String(snap?.sessionId || ''),
      startedAtIso: String(snap?.startedAtIso || ''),
      eventCount: events.length,
      executedCount,
      paletteChangeCount: paletteChanges.length,
      pacingChangeCount: pacingChanges.length,
      metricsCheckpoints: Array.isArray(snap?.metricsHistory) ? snap.metricsHistory.length : 0,
    };
  }

  function delayMs(ms = 0) {
    return new Promise((resolve) => {
      try {
        setTimeout(resolve, Math.max(0, Number(ms) || 0));
      } catch {
        resolve();
      }
    });
  }

  async function runTimedMusicRepeatDebug({
    enemyType = 'drawsnake',
    behavior = 'none',
    groupCount = 8,
    speedScale = 1,
    persistent = true,
    durationMs = 20000,
  } = {}) {
    const api = getMusicLabApi();
    if (!api || typeof api.setEnabled !== 'function' || typeof api.reset !== 'function' || typeof api.exportSession !== 'function') {
      return { ok: false, reason: 'music_lab_api_unavailable' };
    }
    const safeDurationMs = Math.max(3000, Math.trunc(Number(durationMs) || 20000));
    const safeEnemyType = String(enemyType || 'drawsnake').trim().toLowerCase() || 'drawsnake';
    const safeBehavior = String(behavior || 'none').trim().toLowerCase() || 'none';
    const safeGroupCount = Math.max(1, Math.trunc(Number(groupCount) || 8));
    const safeSpeedScale = Math.max(0.25, Math.min(4, Number(speedScale) || 1));
    try {
      api.setEnabled(true);
      api.reset('perf-lab-timed-repeat');
    } catch (err) {
      return { ok: false, reason: 'music_lab_reset_failed', error: String(err && err.message || err) };
    }
    const startResult = await startPerfMusicRepeatSpawn(safeEnemyType, {
      persistent,
      behavior: safeBehavior,
      groupCount: safeGroupCount,
      speedScale: safeSpeedScale,
    });
    if (!startResult?.ok) return startResult || { ok: false, reason: 'repeat_start_failed' };
    await delayMs(safeDurationMs);
    stopPerfMusicRepeatSpawn();
    await delayMs(120);
    const fileName = [
      'resources-debug-music-repeat',
      safeEnemyType,
      safeBehavior || 'none',
      `${safeDurationMs}ms`,
      new Date().toISOString().replace(/[:.]/g, '-'),
    ].join('-') + '.json';
    let payload = null;
    try {
      payload = api.exportSession();
    } catch (err) {
      return {
        ok: false,
        reason: 'music_lab_export_failed',
        error: String(err && err.message || err),
        fileName,
      };
    }
    const cfg = await resolveResultsConfig();
    const debugOutputUrl = resolveDebugOutputPostUrl(cfg);
    const saved = await postDebugOutputFile({
      fileName,
      text: JSON.stringify(payload, null, 2),
      meta: {
        source: 'perf-lab-timed-repeat-debug',
        enemyType: safeEnemyType,
        behavior: safeBehavior,
        durationMs: safeDurationMs,
        groupCount: safeGroupCount,
        speedScale: safeSpeedScale,
      },
    }, debugOutputUrl);
    return {
      ok: saved,
      saved,
      debugOutputUrl,
      fileName,
      durationMs: safeDurationMs,
      enemyType: safeEnemyType,
      behavior: safeBehavior,
      groupCount: safeGroupCount,
      speedScale: safeSpeedScale,
      ...getMusicLabDebugState(),
    };
  }

  async function saveMusicLabSessionToResources({
    runId = 'musicLabAutoSave',
    label = 'music-lab-session',
    notes = '',
    iterationIndex = 1,
    iterationCount = 1,
  } = {}) {
    const api = getMusicLabApi();
    if (!api || typeof api.exportSession !== 'function') {
      return { ok: false, reason: 'music_lab_api_unavailable' };
    }
    const payload = api.exportSession();
    const cfg = await resolveResultsConfig();
    const postUrl = resolveLabPostUrl(cfg, 'music');
    if (!postUrl) {
      return { ok: false, reason: 'no_post_url' };
    }
    const bundle = buildResultsBundle([
      {
        label: String(label || 'music-lab-session'),
        runId: String(runId || 'musicLabAutoSave'),
        createdAt: new Date().toISOString(),
        musicLab: payload,
      },
    ], {
      runId: String(runId || 'musicLabAutoSave'),
      notes: String(notes || ''),
      runMode: 'auto',
      scenarioName: String(label || 'music-lab-session'),
      testCategory: 'music-lab-session',
      iterationIndex: Math.max(1, Math.trunc(Number(iterationIndex) || 1)),
      iterationCount: Math.max(1, Math.trunc(Number(iterationCount) || 1)),
      labType: 'music',
      kind: 'music-lab',
    });
    const ok = await postResultsBundle(bundle, postUrl, { allowLegacyPerfFallback: true });
    return {
      ok: !!ok,
      reason: ok ? '' : 'post_failed',
      postUrl,
      sessionId: String(payload?.sessionId || ''),
      events: Array.isArray(payload?.eventTimeline) ? payload.eventTimeline.length : 0,
    };
  }

  ov.addEventListener('click', async (e) => {
    // Tabs (Controls / Music / Tests / Harmony)
    const tabBtn = e.target && e.target.closest ? e.target.closest('button[data-tab]') : null;
    if (tabBtn) {
      try { e.preventDefault(); } catch {}
      try { e.stopPropagation(); } catch {}
      try {
        const tab = String(tabBtn.getAttribute('data-tab') || 'controls');
        ov.classList.toggle('is-harmony', tab === 'harmony');
        const frame = ov.querySelector('.perf-lab-harmony-frame');
        if (tab === 'harmony' && !frame.hasAttribute('src')) {
          frame.src = new URL('../../harmony-lab/?debug=1', import.meta.url).href;
        } else if (tab !== 'harmony') pauseHarmonyLab(ov);
        ov.querySelectorAll('.perf-lab-tab').forEach((b) => b.classList.toggle('is-active', b === tabBtn));
        ov.querySelectorAll('.perf-lab-tabpage').forEach((p) => {
          const key = String(p.getAttribute('data-tabpage') || '');
          p.classList.toggle('is-active', key === tab);
        });
      } catch {}
      return;
    }

    const btn = e.target && e.target.closest ? e.target.closest('button[data-act]') : null;
    if (!btn) return;
    try { e.preventDefault(); } catch {}
    try { e.stopPropagation(); } catch {}
    const act = btn.getAttribute('data-act');
    if (act === 'close') hide();

    if (act === 'enemySandboxSpawn') {
      const kind = String(ov.querySelector('[data-enemy-sandbox-kind]')?.value || 'basic_small').trim().toLowerCase();
      const abilityId = String(ov.querySelector('[data-enemy-sandbox-ability]')?.value || 'projectile_straight').trim().toLowerCase();
      const count = Math.max(1, Math.min(8, Math.trunc(Number(ov.querySelector('[data-enemy-sandbox-count]')?.value) || 1)));
      let modeApi = window.BeatSwarmMode;
      if (!modeApi?.isActive?.()) {
        const rebuilt = await buildBS0();
        if (!rebuilt) {
          setStatus('Enemy sandbox failed: Beat Swarm setup unavailable');
          return;
        }
        try { stopTransport(); } catch {}
        await waitForPerfLabMs(120);
        try { startTransport(); } catch {}
        await waitForTransportRunning(2200);
        await prepareBS0StaticStage(1, 1);
        modeApi = window.BeatSwarmMode;
      } else if (!isRunning()) {
        try { startTransport(); } catch {}
        await waitForTransportRunning(2200);
      }
      if (typeof modeApi?.startEnemySandboxTest !== 'function') {
        setStatus('Enemy sandbox failed: refresh required');
        return;
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      try { modeApi.setPlayerInfiniteHealth?.(true); } catch {}
      const result = modeApi.startEnemySandboxTest({ kind, abilityId, count });
      setStatus(result?.active
        ? `Enemy sandbox: ${kind}, ${result.abilityId || abilityId}, ${result.aliveEnemyIds?.length || 0} active`
        : 'Enemy sandbox failed to spawn');
      setOutput(result);
      return;
    }
    if (act === 'enemySandboxClear') {
      const result = window.BeatSwarmMode?.stopEnemySandboxTest?.() || { active: false };
      setStatus('Enemy sandbox cleared; normal spawning restored');
      setOutput(result);
      return;
    }

    if (act === 'musicEnemyRepeatStart') {
      const typeEl = ov.querySelector('[data-music-spawn-type]');
      const behaviorEl = ov.querySelector('[data-music-spawn-behavior]');
      const countEl = ov.querySelector('[data-music-group-count]');
      const speedEl = ov.querySelector('[data-music-speed-scale]');
      const persistentEl = ov.querySelector('[data-music-repeat-persistent]');
      const enemyType = String(typeEl?.value || 'drawsnake').trim().toLowerCase() || 'drawsnake';
      const behavior = String(behaviorEl?.value || 'none').trim().toLowerCase() || 'none';
      const groupCount = Math.max(1, Math.trunc(Number(countEl?.value) || 8));
      const speedScale = Math.max(0.25, Math.min(4, Number(speedEl?.value) || 1));
      const persistent = persistentEl ? persistentEl.checked !== false : true;
      saveMusicRepeatUiState({ enemyType, behavior, groupCount, speedScale });
      const result = await startPerfMusicRepeatSpawn(enemyType, { persistent, behavior, groupCount, speedScale });
      setStatus(result.ok ? `Music repeat spawn running: ${enemyType} (${behavior})` : 'Music repeat spawn failed');
      setOutput(result);
      return;
    }
    if (act === 'musicEnemyRepeatTimedDebug') {
      const typeEl = ov.querySelector('[data-music-spawn-type]');
      const behaviorEl = ov.querySelector('[data-music-spawn-behavior]');
      const countEl = ov.querySelector('[data-music-group-count]');
      const speedEl = ov.querySelector('[data-music-speed-scale]');
      const persistentEl = ov.querySelector('[data-music-repeat-persistent]');
      const enemyType = String(typeEl?.value || 'drawsnake').trim().toLowerCase() || 'drawsnake';
      const behavior = String(behaviorEl?.value || 'none').trim().toLowerCase() || 'none';
      const groupCount = Math.max(1, Math.trunc(Number(countEl?.value) || 8));
      const speedScale = Math.max(0.25, Math.min(4, Number(speedEl?.value) || 1));
      const persistent = persistentEl ? persistentEl.checked !== false : true;
      saveMusicRepeatUiState({ enemyType, behavior, groupCount, speedScale });
      setStatus(`Timed debug run active: ${enemyType} (${behavior})`);
      setOutput({
        ok: true,
        running: true,
        durationMs: 20000,
        enemyType,
        behavior,
        groupCount,
        speedScale,
      });
      const result = await runTimedMusicRepeatDebug({
        enemyType,
        behavior,
        groupCount,
        speedScale,
        persistent,
        durationMs: 20000,
      });
      setStatus(result.ok ? `Timed debug run exported: ${result.fileName}` : 'Timed debug run failed');
      setOutput(result);
      return;
    }
    if (act === 'musicEnemyRepeatStop') {
      stopPerfMusicRepeatSpawn();
      setStatus('Music repeat spawn stopped');
      setOutput({ ok: true, stopped: true });
      return;
    }

    if (act === 'qualityApply') {
      try {
        applyPendingToGlobals();
        // After apply, mirror pending from globals again (keeps us deterministic if other code changed them).
        __pending.qlab = { ...(window.__QUALITY_LAB || {}) };
        __pending.particles = { ...(window.__PERF_PARTICLES || {}) };
        __pending.perf = {
          traceMarks: !!window.__PERF_TRACE_MARKS,
          freezeChainUi: !!window.__PERF_DISABLE_CHAIN_UI,
          traceCanvasResize: !!(window.__PERF_TRACE && window.__PERF_TRACE.traceCanvasResize),
          traceDomInRaf: !!(window.__PERF_TRACE && window.__PERF_TRACE.traceDomInRaf),
        };
        syncUiFromPending();
        setCycleBtnVisual();
        setShowStateBtnVisual();
      } catch {}

      // --------------------------------------------------------------
      // DrawGrid test harness:
      // If user sets a target FPS, we also provide an override signal
      // that DrawGrid can use for LOD decisions (playhead/particles/etc).
      // This avoids relying on the app's measured FPS (often rAF-based).
      // --------------------------------------------------------------
      try {
        const tf = Number(window.__QUALITY_LAB?.targetFps || 0);
        window.__DG_FPS_TEST_OVERRIDE = (tf > 0) ? tf : 0;
      } catch {}
    }
    if (act === 'buildP2') buildP2();
    if (act === 'buildP2d') await buildP2d();
    if (act === 'runP2a') await runP2a();
    if (act === 'runP2b') await runP2b();
    if (act === 'runP2c') await runP2c();
    if (act === 'runP2d') await runP2d();
    if (act === 'runP2e') await runP2e();
    if (act === 'runP2f') await runP2f();
    if (act === 'runP2g') await runP2g();
    if (act === 'runP2h') await runP2h();
    if (act === 'runP2i') await runP2i();
    if (act === 'runP2j') await runP2j();
    if (act === 'runP2k') await runP2k();
    if (act === 'runP2l') await runP2l();
    if (act === 'runP2m') await runP2m();
    if (act === 'runP2n') await runP2n();
    if (act === 'runP2o') await runP2o();
    if (act === 'runP2p') await runP2p();
    if (act === 'runP2q') await runP2q();
    if (act === 'runP2r') await runP2r();
    if (act === 'runP2s') await runP2s();
    if (act === 'runP2t') await runP2t();
    if (act === 'runP2u') await runP2u();
    if (act === 'runP2v') await runP2v();
    if (act === 'runP2w') await runP2w();
    if (act === 'runP2x') await runP2x();
    if (act === 'runP2y') await runP2y();
    if (act === 'runP2z') await runP2z();
    if (act === 'buildBS0') await buildBS0();
    if (act === 'runBS0a') await runBS0a();
    if (act === 'runBS0b') await runBS0b();
    if (act === 'runBS0s1') await runBS0s1();
    if (act === 'runBS0s2') await runBS0s2();
    if (act === 'runBS0s3') await runBS0s3();
    if (act === 'runBS0s4') await runBS0s4();
    if (act === 'runBS0s5') await runBS0s5();
    if (act === 'musicLabEnable') {
      const api = getMusicLabApi();
      if (!api || typeof api.setEnabled !== 'function') {
        setStatus('Music Lab API unavailable (enter Beat Swarm first)');
        return;
      }
      try {
        api.setEnabled(true);
        setStatus('Music Lab enabled');
        setOutput(getMusicLabDebugState());
      } catch (err) {
        setStatus('Music Lab enable failed');
        setOutput({ ok: false, error: String(err && err.message || err) });
      }
      return;
    }
    if (act === 'musicLabDisable') {
      const api = getMusicLabApi();
      if (!api || typeof api.setEnabled !== 'function') {
        setStatus('Music Lab API unavailable (enter Beat Swarm first)');
        return;
      }
      try {
        api.setEnabled(false);
        setStatus('Music Lab disabled');
        setOutput(getMusicLabDebugState());
      } catch (err) {
        setStatus('Music Lab disable failed');
        setOutput({ ok: false, error: String(err && err.message || err) });
      }
      return;
    }
    if (act === 'musicLabReset') {
      const api = getMusicLabApi();
      if (!api || typeof api.reset !== 'function') {
        setStatus('Music Lab API unavailable (enter Beat Swarm first)');
        return;
      }
      try {
        const snap = api.reset('perf-lab');
        setStatus('Music Lab session reset');
        setOutput({
          ok: true,
          sessionId: String(snap?.sessionId || ''),
          startedAtIso: String(snap?.startedAtIso || ''),
        });
      } catch (err) {
        setStatus('Music Lab reset failed');
        setOutput({ ok: false, error: String(err && err.message || err) });
      }
      return;
    }
    if (act === 'musicLabRunBS0S3Arrangement5m') {
      await runBS0s3MusicLabArrangement5m();
      return;
    }
    if (act === 'musicLabRunBS0S3CompositionFlow4m') {
      await runBS0s3MusicLabCompositionFlow4m();
      return;
    }
    if (act === 'musicLabRunBS0S3CompositionPacing4m') {
      await runBS0s3MusicLabCompositionPacingFlow4m();
      return;
    }
    if (act === 'musicLabRunBS0S3TapOrbFoundationDebug') {
      await runBS0s3MusicLabTapOrbFoundationDebug75s();
      return;
    }
    if (act === 'musicLabRunGunnerCombatDebug') {
      await runGunnerCombatProfilesDebug();
      return;
    }
    if (act === 'musicLabRunSeekerCombatDebug') {
      await runSeekerCombatProfilesDebug();
      return;
    }
    if (act === 'musicLabRunLaserSpinnerCombatDebug') {
      await runLaserSpinnerCombatProfilesDebug();
      return;
    }
    if (act === 'musicLabRunShapeCasterCombatDebug') {
      await runShapeCasterCombatProfilesDebug();
      return;
    }
    if (act === 'musicLabRunChargerCombatDebug') {
      await runChargerCombatProfilesDebug();
      return;
    }
    if (act === 'musicLabRunConductorCombatDebug') {
      await runConductorCombatProfilesDebug();
      return;
    }
    if (act === 'musicLabRunShapeCasterGunnerCombinationDebug') {
      await runShapeCasterGunnerCombinationDebug();
      return;
    }
    if (act === 'musicLabRunShapeCasterSeekerCombinationDebug') {
      await runShapeCasterSeekerCombinationDebug();
      return;
    }
    if (act === 'musicLabRunLaserVariantsDebug') {
      await runLaserVariantsDebug();
      return;
    }
    if (act === 'musicLabRunSymmetricLaserGroupDebug') {
      await runSymmetricLaserGroupDebug();
      return;
    }
    if (act === 'musicLabRunTrackedLaserMotifsDebug') {
      await runTrackedLaserMotifsDebug();
      return;
    }
    if (act === 'musicLabRunGunnerPercussionFormationDebug') {
      await runGunnerPercussionFormationDebug();
      return;
    }
    if (act === 'musicLabRunDualMusicalFormationDebug') {
      await runDualMusicalFormationDebug();
      return;
    }
    if (act === 'musicLabRunLeadResponseFormationDebug') {
      await runLeadResponseFormationDebug();
      return;
    }
    if (act === 'musicLabRunAccentSubdivisionFormationDebug') {
      await runAccentSubdivisionFormationDebug();
      return;
    }
    if (act === 'musicLabRunFullScoreArrangementDebug') {
      await runFullScoreArrangementDebug();
      return;
    }
    if (act === 'musicLabRunArrangementIntensityRampDebug') {
      await runArrangementIntensityRampDebug();
      return;
    }
    if (act === 'musicLabRunDirectorFormationIntensityFlow') {
      await runDirectorFormationIntensityFlowDebug();
      return;
    }
    if (act === 'musicLabRunAuthoringIntensityHandoff') {
      await runAuthoringIntensityHandoffDebug();
      return;
    }
    if (act === 'musicLabRunEnemyArchitectureDebug') {
      await runEnemyArchitectureDebug();
      return;
    }
    if (act === 'musicLabRunOnboardingCompositionAudit') {
      await runOnboardingCompositionAuditDebug();
      return;
    }
    if (act === 'musicLabRunBS0S3AccentRewriteDebug') {
      await runBS0s3MusicLabAccentRewriteDebug90s();
      return;
    }
    if (act === 'musicLabRunBS0S3MusicMissileRewriteDebug') {
      await runBS0s3MusicLabMusicMissileRewriteDebug120s();
      return;
    }
    if (act === 'musicLabRunBS0S3PinballBouncerRewriteDebug') {
      await runBS0s3MusicLabPinballBouncerRewriteDebug120s();
      return;
    }
    if (act === 'musicLabRunBS0S3MusicMissileBassRewriteDebug') {
      await runBS0s3MusicLabMusicMissileRewriteDebug120s({
        themeId: 'bassDrive',
        laneId: 'foundation_lane',
        expectedInstrument: 'BASS TONE 3',
        durationMs: 360000,
        followupEvents: [
          { interaction: 'music_missile', themeId: 'accentRhythm', laneId: 'secondary_loop_lane' },
          { interaction: 'tap_orb', themeId: 'bassDrive', laneId: 'foundation_lane' },
          { interaction: 'tap_orb', themeId: 'accentRhythm', laneId: 'secondary_loop_lane' },
        ],
      });
      return;
    }
    if (act === 'weaponGateLabOpen') {
      if (window.__WeaponGateLab?.open) {
        window.__WeaponGateLab.open();
        setStatus('Weapon Gate Onboarding Lab opened');
      } else {
        setStatus('Weapon Gate Lab unavailable; hard refresh and try again');
      }
      return;
    }
    if (act === 'weaponGateBeatSwarmStart') {
      const api = getBeatSwarmApi();
      if (!api) {
        setStatus('Beat Swarm API unavailable; hard refresh and try again');
        return;
      }
      try { api.exit?.(); } catch {}
      try { api.enter?.({ weaponGateIntro: true }); } catch {}
      try { if (!isRunning()) startTransport(); } catch {}
      setStatus('Beat Swarm gate start launched');
      return;
    }
    if (act === 'musicLabRunBS0S3GateToLeadGatesDebug') {
      await runBS0s3MusicLabGateToLeadGatesDebug120s();
      return;
    }
    if (act === 'musicLabRunBS0S3GateToLeadBallDebug') {
      await runBS0s3MusicLabGateToLeadBallDebug60s();
      return;
    }
    if (act === 'musicLabRunBS0S3GateStartTapOrbDebug') {
      await runBS0s3MusicLabGateStartTapOrbHandoffDebug150s();
      return;
    }
    if (act === 'musicLabRunBS0S3IntensityRamp150s') {
      await runBS0s3MusicLabIntensityRamp150s();
      return;
    }
    if (act === 'musicLabRunBS0S3IntensityRampDebug150s') {
      await runBS0s3MusicLabIntensityRampDebug150s();
      return;
    }
    if (act.startsWith('musicLabRunBS0S3Listen')) {
      const sectionByAction = {
        musicLabRunBS0S3ListenSilent: 'silent',
        musicLabRunBS0S3ListenLow: 'low',
        musicLabRunBS0S3ListenMedium: 'medium',
        musicLabRunBS0S3ListenBuild: 'build',
        musicLabRunBS0S3ListenPeak: 'peak',
        musicLabRunBS0S3ListenRelease: 'release',
        musicLabRunBS0S3ListenReleaseOnly: 'release_only',
        musicLabRunBS0S3ListenSettle: 'settle',
      };
      await runBS0s3MusicLabIntensityListenSection(sectionByAction[act] || 'low');
      return;
    }
    if (act === 'musicLabSnapshot') {
      const state = getMusicLabDebugState();
      if (!state.available) {
        setStatus('Music Lab API unavailable (enter Beat Swarm first)');
        return;
      }
      setStatus('Music Lab snapshot');
      setOutput(state);
      return;
    }
    if (act === 'musicLabExport') {
      const api = getMusicLabApi();
      if (!api || typeof api.exportSession !== 'function') {
        setStatus('Music Lab API unavailable (enter Beat Swarm first)');
        return;
      }
      try {
        const payload = api.exportSession();
        setStatus('Music Lab exported to output');
        setOutput(payload);
      } catch (err) {
        setStatus('Music Lab export failed');
        setOutput({ ok: false, error: String(err && err.message || err) });
      }
      return;
    }
    if (act === 'musicLabSaveResources') {
      const api = getMusicLabApi();
      if (!api || typeof api.exportSession !== 'function') {
        setStatus('Music Lab API unavailable (enter Beat Swarm first)');
        return;
      }
      try {
        const payload = api.exportSession();
        const cfg = await resolveResultsConfig();
        const postUrl = resolveLabPostUrl(cfg, 'music');
        if (!postUrl) {
          setStatus('Music Lab save failed: no music post URL configured');
          setOutput({
            ok: false,
            reason: 'no_post_url',
            hint: 'Set postUrlMusic in resources/perf-lab-auto.json or window.__MUSIC_LAB_RESULTS_URL',
          });
          return;
        }
        const bundle = buildResultsBundle([
          {
            label: 'music-lab-session',
            runId: 'musicLabManualSave',
            createdAt: new Date().toISOString(),
            musicLab: payload,
          },
        ], {
          runId: 'musicLabManualSave',
          notes: 'Manual Music Lab save from Perf Lab UI',
          runMode: 'manual',
          scenarioName: 'music-lab-session',
          testCategory: 'music-lab-session',
          iterationIndex: 1,
          iterationCount: 1,
          labType: 'music',
          kind: 'music-lab',
        });
        const ok = await postResultsBundle(bundle, postUrl, { allowLegacyPerfFallback: true });
        setStatus(ok ? 'Music Lab saved via results endpoint' : 'Music Lab save failed (endpoint)');
        setOutput({
          ok: !!ok,
          postUrl,
          sessionId: String(payload?.sessionId || ''),
          events: Array.isArray(payload?.eventTimeline) ? payload.eventTimeline.length : 0,
          ...getMusicLabDebugState(),
        });
      } catch (err) {
        setStatus('Music Lab save failed');
        setOutput({ ok: false, error: String(err && err.message || err) });
      }
      return;
    }
    if (act === 'musicLabDownload') {
      const api = getMusicLabApi();
      if (!api || typeof api.downloadSession !== 'function') {
        setStatus('Music Lab API unavailable (enter Beat Swarm first)');
        return;
      }
      try {
        const fileName = buildLabResultFileName('music');
        const ok = api.downloadSession(fileName);
        setStatus(ok ? 'Music Lab JSON download started' : 'Music Lab JSON download failed');
        setOutput({
          ok: !!ok,
          fileName,
          ...getMusicLabDebugState(),
        });
      } catch (err) {
        setStatus('Music Lab download failed');
        setOutput({ ok: false, error: String(err && err.message || err) });
      }
      return;
    }
    // --------------------------------------------------------------
    // Footer auto-tests (these are the big buttons in the footer)
    // --------------------------------------------------------------
    if (act === 'autoGeneric') {
      const cfgBase = (await readAutoConfigFromFile()) || readAutoConfig() || {};
      const ts = new Date().toISOString().replace(/[:.]/g, '-');
      await runAuto({
        clear: true,
        save: false,
        download: true,
        postUrl: cfgBase.postUrlPerf || cfgBase.postUrl || window.__PERF_LAB_RESULTS_URL,
        downloadName: `perf-lab-generic-${ts}.json`,
        notes: 'Generic baseline: Mixed (P6a) -> Lots of DrawGrid (P3f) -> Lots of Simple Rhythm (P4b)',
        queue: AUTO_GENERIC_QUEUE,
        runId: 'autoGeneric',
      });
      return;
    }
    if (act === 'autoGenericAdaptiveCompare') {
      const cfgBase = (await readAutoConfigFromFile()) || readAutoConfig() || {};
      const ts = new Date().toISOString().replace(/[:.]/g, '-');
      await runAuto({
        clear: true,
        save: false,
        download: true,
        postUrl: cfgBase.postUrlPerf || cfgBase.postUrl || window.__PERF_LAB_RESULTS_URL,
        downloadName: `perf-lab-generic-adaptive-compare-${ts}.json`,
        notes: 'Generic A/B: compares DrawGrid adaptive DPR OFF vs ON (does not change Auto: Generic).',
        queue: [
          'traceOff',
          'dgAdaptiveOff',
          ...AUTO_GENERIC_QUEUE,
          'dgAdaptiveOn',
          ...AUTO_GENERIC_QUEUE,
        ],
        runId: 'autoGenericAdaptiveCompare',
      });
      return;
    }
    if (act === 'autoFocus') {
      const cfgBase = (await readAutoConfigFromFile()) || readAutoConfig() || {};
      const ts = new Date().toISOString().replace(/[:.]/g, '-');
      await runAuto({
        clear: true,
        save: false,
        postUrl: cfgBase.postUrlPerf || cfgBase.postUrl || window.__PERF_LAB_RESULTS_URL,
        notes: 'Current Focus (single batch): P3f baseline + no-overlays (+ baseline repeat) on one shared build/warmup.',
        queue: AUTO_FOCUS_QUEUE,
        runId: 'autoFocus',
      });
      return;
    }
    if (act === 'autoZoomSpike') {
      const cfgBase = (await readAutoConfigFromFile()) || readAutoConfig() || {};
      await runAuto({
        clear: true,
        save: false,
        postUrl: cfgBase.postUrlPerf || cfgBase.postUrl || window.__PERF_LAB_RESULTS_URL,
        notes: 'Zoom Spike Probe: baseline + commit-spam zoom (anchor ON/OFF) + baseline repeat.',
        queue: AUTO_ZOOM_SPIKE_QUEUE,
        runId: 'autoZoomSpike',
      });
      return;
    }
    if (act === 'autoFocusHeavy') {
      const cfgBase = (await readAutoConfigFromFile()) || readAutoConfig() || {};
      const ts = new Date().toISOString().replace(/[:.]/g, '-');
      await runAuto({
        clear: true,
        save: false,
        postUrl: cfgBase.postUrlPerf || cfgBase.postUrl || window.__PERF_LAB_RESULTS_URL,
        notes: 'Focus Validation (Heavy): force pressure-DPR engagement + catch resize churn (edit AUTO_FOCUS_HEAVY_QUEUE in perf-lab.js)',
        queue: AUTO_FOCUS_HEAVY_QUEUE,
        runId: 'autoFocusHeavy',
      });
      return;
    }
    if (act === 'autoMicro') {
      const cfgBase = (await readAutoConfigFromFile()) || readAutoConfig() || {};
      const ts = new Date().toISOString().replace(/[:.]/g, '-');
      await runAuto({
        clear: true,
        save: false,
        postUrl: cfgBase.postUrlPerf || cfgBase.postUrl || window.__PERF_LAB_RESULTS_URL,
        notes: 'Focus Micro: short, high-signal, typically trace-enabled (edit AUTO_MICRO_QUEUE in perf-lab.js)',
        queue: AUTO_MICRO_QUEUE,
        runId: 'autoMicro',
      });
      return;
    }
    if (act === 'autoBeatSwarmGeneric') {
      const cfgBase = (await readAutoConfigFromFile()) || readAutoConfig() || {};
      const ts = new Date().toISOString().replace(/[:.]/g, '-');
      await runAuto({
        clear: true,
        save: false,
        download: true,
        postUrl: cfgBase.postUrlPerf || cfgBase.postUrl || window.__PERF_LAB_RESULTS_URL,
        downloadName: `perf-lab-beat-swarm-generic-${ts}.json`,
        notes: 'Beat Swarm generic baseline: default empty Beat Swarm scene (idle + pan/zoom).',
        queue: AUTO_BEAT_SWARM_GENERIC_QUEUE,
        runId: 'autoBeatSwarmGeneric',
      });
      return;
    }
    if (act === 'auto') {
      const cfgBase = (await readAutoConfigFromFile()) || readAutoConfig() || {};
      const ts = new Date().toISOString().replace(/[:.]/g, '-');
      await runAuto({
        clear: true,
        save: false,
        postUrl: cfgBase.postUrlPerf || cfgBase.postUrl || window.__PERF_LAB_RESULTS_URL,
        notes: 'Demon Hunt v1: baseline (traceOff) then traceOn; P3f + P4b',
        queue: [
          'traceOff',
          'buildP3',
          'runP3f',
          'buildP4',
          'runP4b',
          'traceOn',
          'buildP3',
          'runP3f',
          'buildP4',
          'runP4b',
        ],
        runId: 'auto',
      });
      return;
    }
  });ov.addEventListener('change', (e) => {
    const t = e.target;
    if (!t) return;
    const key = t.getAttribute && t.getAttribute('data-tog');
    const perfKey = t.getAttribute && t.getAttribute('data-perf');
    const qKey = t.getAttribute && t.getAttribute('data-qlab');
    if (!key && !perfKey && !qKey) return;
    if (qKey) {
      try {
        if (qKey === 'forceScale') {
          const raw = String(t.value || '');
          __pending.qlab.forceScale = raw ? (Number(raw) || null) : null;
        } else if (qKey === 'dgForceTier') {
          const raw = String(t.value || '').trim();
          if (!raw) __pending.qlab.dgForceTier = null;
          else {
            const v = Number(raw);
            __pending.qlab.dgForceTier = Number.isFinite(v) ? (v | 0) : null;
          }
        } else if (qKey === 'lgForceTier') {
          const raw = String(t.value || '').trim();
          if (!raw) __pending.qlab.lgForceTier = null;
          else {
            const v = Number(raw);
            __pending.qlab.lgForceTier = Number.isFinite(v) ? (v | 0) : null;
          }
        } else {
          __pending.qlab[qKey] = Math.max(0, Number(t.value) || 0);
        }
        console.log('[PerfLab] quality lab (pending)', { ...__pending.qlab });
      } catch {}
    }
    if (key) {
      try {
        if (t.tagName === 'INPUT' && t.type === 'checkbox') __pending.particles[key] = !!t.checked;
        else if (t.tagName === 'SELECT') __pending.particles[key] = Math.max(0, Number(t.value) || 1);
        console.log('[PerfLab] particle toggles (pending)', { ...__pending.particles });
      } catch {}
    }
    if (perfKey === 'traceMarks') {
      try {
        __pending.perf.traceMarks = !!t.checked;
        console.log('[PerfLab] trace marks (pending)', { enabled: !!__pending.perf.traceMarks });
      } catch {}
    }
    if (perfKey === 'freezeChainUi') {
      try {
        __pending.perf.freezeChainUi = !!t.checked;
        console.log('[PerfLab] chain UI freeze (pending)', { enabled: !!__pending.perf.freezeChainUi });
      } catch {}
    }
    if (perfKey === 'traceCanvasResize' || perfKey === 'traceDomInRaf') {
      try {
        if (perfKey === 'traceCanvasResize') __pending.perf.traceCanvasResize = !!t.checked;
        if (perfKey === 'traceDomInRaf') __pending.perf.traceDomInRaf = !!t.checked;
        console.log('[PerfLab] trace toggles (pending)', { ...__pending.perf });
      } catch {}
    }
  });

  document.body.appendChild(ov);
  return ov;
}

let lastResult = null;
let lastResults = [];

let lastBundle = null;

const PERF_SPAWN_PADDING = 40;
const PERF_CHAIN_PAD_X = 80;
const PERF_MODE_PAD_X = 48;
const PERF_DRAWGRID_WIDTH = 800;
const PERF_DRAWGRID_HEIGHT_PAD = 160;
const PERF_DRAWGRID_ASPECT = 3 / 4;

const perfMeasuredFootprints = new Map();

async function waitForPanelReady(panel, { timeoutMs = 1200 } = {}) {
  if (!panel) return false;
  const start = performance?.now?.() ?? Date.now();
  const needsModeButtons = ['loopgrid', 'loopgrid-drum', 'bouncer', 'rippler', 'chordwheel', 'drawgrid']
    .includes(panel?.dataset?.toy || '');
  return await new Promise((resolve) => {
    const tick = () => {
      if (!panel.isConnected) return resolve(false);
      const body = panel.querySelector('.toy-body');
      const chain = panel.querySelector(':scope > .toy-chain-btn');
      const modeBtn = needsModeButtons ? panel.querySelector(':scope > .toy-mode-btn') : null;
      if (body && chain && (!needsModeButtons || modeBtn)) return resolve(true);
      const now = performance?.now?.() ?? Date.now();
      if ((now - start) > timeoutMs) return resolve(false);
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
}

async function waitForStablePanelRect(panel, { stableFrames = 3, timeoutMs = 1200 } = {}) {
  if (!panel) return false;
  const start = performance?.now?.() ?? Date.now();
  let last = null;
  let stableCount = 0;
  return await new Promise((resolve) => {
    const tick = () => {
      if (!panel.isConnected) return resolve(false);
      const rect = panel.getBoundingClientRect?.();
      if (rect && rect.width > 0 && rect.height > 0) {
        if (last && Math.abs(rect.width - last.width) < 0.5 && Math.abs(rect.height - last.height) < 0.5) {
          stableCount += 1;
        } else {
          stableCount = 0;
        }
        last = { width: rect.width, height: rect.height };
        if (stableCount >= stableFrames) return resolve(true);
      }
      const now = performance?.now?.() ?? Date.now();
      if ((now - start) > timeoutMs) return resolve(false);
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
}

function measurePanelFootprint(panel) {
  if (!panel) return null;
  const rects = [panel, ...panel.querySelectorAll(':scope > .toy-mode-btn, :scope > .toy-chain-btn')];
  let minLeft = Infinity;
  let minTop = Infinity;
  let maxRight = -Infinity;
  let maxBottom = -Infinity;

  const readBox = (el) => {
    if (el === panel) {
      const w = el.offsetWidth || 0;
      const h = el.offsetHeight || 0;
      return (w > 0 && h > 0) ? { left: 0, top: 0, right: w, bottom: h } : null;
    }
    const w = el.offsetWidth || 0;
    const h = el.offsetHeight || 0;
    if (w > 0 && h > 0) {
      const left = el.offsetLeft || 0;
      const top = el.offsetTop || 0;
      return { left, top, right: left + w, bottom: top + h };
    }
    const left = parseFloat(el.style.left || '0') || 0;
    const top = parseFloat(el.style.top || '0') || 0;
    const size = parseFloat(el.style.getPropertyValue('--c-btn-size') || '0') || 0;
    if (size > 0) {
      return { left, top, right: left + size, bottom: top + size };
    }
    return null;
  };

  for (const el of rects) {
    const r = readBox(el);
    if (!r) continue;
    minLeft = Math.min(minLeft, r.left);
    minTop = Math.min(minTop, r.top);
    maxRight = Math.max(maxRight, r.right);
    maxBottom = Math.max(maxBottom, r.bottom);
  }

  if (!Number.isFinite(minLeft) || !Number.isFinite(maxRight)) return null;
  return { width: Math.max(1, maxRight - minLeft), height: Math.max(1, maxBottom - minTop) };
}

async function ensureMeasuredFootprint(toyType) {
  if (perfMeasuredFootprints.has(toyType)) return perfMeasuredFootprints.get(toyType);
  const factory = window.MusicToyFactory;
  const board = document.getElementById('board');
  if (!factory?.create || !factory?.destroy || !board) return null;

  let storedPositions = null;
  try { storedPositions = localStorage.getItem('toyPositions'); } catch {}

  let panel = null;
  try {
    panel = factory.create(toyType, { centerX: 120, centerY: 120, autoCenter: false });
    if (panel) {
      panel.style.opacity = '0';
      panel.style.pointerEvents = 'none';
    }
  } catch {}

  if (!panel) return null;
  await waitForPanelReady(panel);
  await waitForStablePanelRect(panel);

  const measured = measurePanelFootprint(panel);
  try { factory.destroy(panel); } catch {}
  try {
    if (storedPositions != null) localStorage.setItem('toyPositions', storedPositions);
    else localStorage.removeItem('toyPositions');
  } catch {}

  if (measured) {
    perfMeasuredFootprints.set(toyType, measured);
  }
  return measured;
}

function getCssPanelSize(toyType) {
  const board = document.getElementById('board');
  if (!board) return { width: 0, height: 0 };
  const probe = document.createElement('section');
  probe.className = 'toy-panel';
  probe.dataset.toy = toyType;
  probe.style.position = 'absolute';
  probe.style.left = '-10000px';
  probe.style.top = '-10000px';
  probe.style.visibility = 'hidden';
  board.appendChild(probe);
  let width = 0;
  let height = 0;
  try {
    const cs = getComputedStyle(probe);
    width = parseFloat(cs.width) || 0;
    height = parseFloat(cs.height) || 0;
  } catch {}
  probe.remove();
  return { width, height };
}

function getCatalogSize(toyType) {
  try {
    const catalog = window.MusicToyFactory?.getCatalog?.() || [];
    const match = catalog.find(entry => entry?.type === toyType);
    const size = match?.size || {};
    const cssSize = getCssPanelSize(toyType);
    const width = Math.max(Number(cssSize.width) || 0, Number(size.width) || 0, 380);
    const height = Math.max(Number(cssSize.height) || 0, Number(size.height) || 0, 320);
    return { width, height };
  } catch {
    return { width: 380, height: 320 };
  }
}

function estimateToyFootprint(toyType, { padding = PERF_SPAWN_PADDING, chainPadX = PERF_CHAIN_PAD_X } = {}) {
  const measured = perfMeasuredFootprints.get(toyType);
  const base = getCatalogSize(toyType);
  const hasExternalButtons = ['loopgrid', 'loopgrid-drum', 'bouncer', 'rippler', 'chordwheel', 'drawgrid'].includes(toyType);
  const leftPad = measured ? 0 : (hasExternalButtons ? PERF_MODE_PAD_X : 0);
  let baseWidth = Math.max(1, measured?.width || base.width);
  let baseHeight = Math.max(1, measured?.height || base.height);
  if (toyType === 'drawgrid') {
    baseWidth = Math.max(baseWidth, PERF_DRAWGRID_WIDTH);
    const inferredHeight = Math.round(baseWidth * PERF_DRAWGRID_ASPECT + PERF_DRAWGRID_HEIGHT_PAD);
    baseHeight = Math.max(baseHeight, inferredHeight);
  }
  const extraChainPad = measured ? 0 : chainPadX;
  const width = Math.max(1, baseWidth + (padding * 2) + extraChainPad + leftPad);
  const height = Math.max(1, baseHeight + (padding * 2));
  return { width, height };
}

function estimateGridSpacing(toyType, spacing) {
  const footprint = estimateToyFootprint(toyType);
  const minSpacing = Math.max(footprint.width, footprint.height);
  return Math.max(spacing || 0, minSpacing);
}

function logPerfFootprintDebug(toyType, spacing) {
  try {
    const measured = perfMeasuredFootprints.get(toyType) || null;
    const catalog = getCatalogSize(toyType);
    const footprint = estimateToyFootprint(toyType);
    const minSpacing = Math.max(footprint.width, footprint.height);
    console.log('[PerfLab][footprint]', {
      toyType,
      measured,
      catalog,
      footprint,
      baseSpacing: spacing,
      resolvedSpacing: Math.max(spacing || 0, minSpacing),
    });
  } catch (err) {
    console.warn('[PerfLab][footprint] debug failed', err);
  }
}

function getPanelBounds(panel) {
  if (!panel) return null;
  const rects = [panel, ...panel.querySelectorAll(':scope > .toy-mode-btn, :scope > .toy-chain-btn')];
  let minLeft = Infinity;
  let minTop = Infinity;
  let maxRight = -Infinity;
  let maxBottom = -Infinity;

  const readBox = (el) => {
    if (el === panel) {
      const w = el.offsetWidth || 0;
      const h = el.offsetHeight || 0;
      return (w > 0 && h > 0) ? { left: 0, top: 0, right: w, bottom: h } : null;
    }
    const w = el.offsetWidth || 0;
    const h = el.offsetHeight || 0;
    if (w > 0 && h > 0) {
      const left = el.offsetLeft || 0;
      const top = el.offsetTop || 0;
      return { left, top, right: left + w, bottom: top + h };
    }
    const left = parseFloat(el.style.left || '0') || 0;
    const top = parseFloat(el.style.top || '0') || 0;
    const size = parseFloat(el.style.getPropertyValue('--c-btn-size') || '0') || 0;
    if (size > 0) {
      return { left, top, right: left + size, bottom: top + size };
    }
    return null;
  };

  for (const el of rects) {
    const r = readBox(el);
    if (!r) continue;
    minLeft = Math.min(minLeft, r.left);
    minTop = Math.min(minTop, r.top);
    maxRight = Math.max(maxRight, r.right);
    maxBottom = Math.max(maxBottom, r.bottom);
  }

  if (!Number.isFinite(minLeft) || !Number.isFinite(maxRight)) return null;
  const baseLeft = panel.offsetLeft || 0;
  const baseTop = panel.offsetTop || 0;
  return {
    left: baseLeft + minLeft,
    right: baseLeft + maxRight,
    top: baseTop + minTop,
    bottom: baseTop + maxBottom,
    width: Math.max(1, maxRight - minLeft),
    height: Math.max(1, maxBottom - minTop),
  };
}

function logOverlapReport(selector = '.toy-panel[data-toy="drawgrid"]', limit = 12) {
  try {
    const panels = Array.from(document.querySelectorAll(selector));
    const bounds = panels.map(panel => ({ panel, id: panel.id, bounds: getPanelBounds(panel) }))
      .filter(entry => entry.bounds);
    const overlaps = [];
    for (let i = 0; i < bounds.length; i++) {
      const a = bounds[i];
      for (let j = i + 1; j < bounds.length; j++) {
        const b = bounds[j];
        if (a.bounds.right <= b.bounds.left || a.bounds.left >= b.bounds.right) continue;
        if (a.bounds.bottom <= b.bounds.top || a.bounds.top >= b.bounds.bottom) continue;
        overlaps.push({
          a: a.id,
          b: b.id,
          aBounds: a.bounds,
          bBounds: b.bounds,
        });
        if (overlaps.length >= limit) break;
      }
      if (overlaps.length >= limit) break;
    }
    console.log('[PerfLab][overlap]', {
      selector,
      count: overlaps.length,
      overlaps,
    });
  } catch (err) {
    console.warn('[PerfLab][overlap] debug failed', err);
  }
}

const PERF_LAB_STORAGE_KEY = 'perfLab:lastResults';
const PERF_LAB_AUTO_KEY = 'perfLab:auto';
const DEFAULT_PERF_RESULTS_URL = 'http://localhost:5174/perf-lab-results';
const DEFAULT_MUSIC_RESULTS_URL = 'http://localhost:5174/music-lab-results';
const DEFAULT_DEBUG_OUTPUT_URL = 'http://localhost:5174/debug-output';

function normalizeQueue(input) {
  if (!input) return [];
  if (Array.isArray(input)) return input.map(s => String(s || '').trim()).filter(Boolean);
  if (typeof input === 'string') {
    return input
      .split(/[,\s]+/)
      .map(s => s.trim())
      .filter(Boolean);
  }
  return [];
}

function safeJsonParse(raw) {
  try { return JSON.parse(raw); } catch { return null; }
}

function readMusicLabMetric(payload, path, fallback = NaN) {
  try {
    const parts = String(path || '').split('.').filter(Boolean);
    let cur = payload?.metrics;
    for (const part of parts) {
      if (!cur || typeof cur !== 'object') return fallback;
      cur = cur[part];
    }
    const n = Number(cur);
    return Number.isFinite(n) ? n : fallback;
  } catch {
    return fallback;
  }
}

function summarizeMusicLabSessionPayload(payload) {
  const timeline = Array.isArray(payload?.eventTimeline) ? payload.eventTimeline : [];
  const visualRoleReadability = payload?.metrics?.visualRoleReadability
    && typeof payload.metrics.visualRoleReadability === 'object'
    ? payload.metrics.visualRoleReadability
    : null;
  const laneContinuityAssertion = payload?.metrics?.laneContinuityAssertion
    && typeof payload.metrics.laneContinuityAssertion === 'object'
    ? payload.metrics.laneContinuityAssertion
    : null;
  const level1ArrangementMusicality = payload?.metrics?.level1ArrangementMusicality
    && typeof payload.metrics.level1ArrangementMusicality === 'object'
    ? payload.metrics.level1ArrangementMusicality
    : null;
  const musicIntensityAudition = payload?.metrics?.musicIntensityAudition
    && typeof payload.metrics.musicIntensityAudition === 'object'
    ? payload.metrics.musicIntensityAudition
    : null;
  const systemEventSummary = payload?.systemEventSummary && typeof payload.systemEventSummary === 'object'
    ? payload.systemEventSummary
    : null;
  const cloneSmallObject = (value) => {
    if (!value || typeof value !== 'object') return value;
    try {
      return JSON.parse(JSON.stringify(value));
    } catch {
      return value;
    }
  };
  return {
    sessionId: String(payload?.sessionId || ''),
    startedAtIso: String(payload?.startedAtIso || ''),
    endedAtIso: String(payload?.endedAtIso || ''),
    eventCount: timeline.length,
    paletteChangeCount: Array.isArray(payload?.paletteChanges) ? payload.paletteChanges.length : 0,
    pacingChangeCount: Array.isArray(payload?.pacingChanges) ? payload.pacingChanges.length : 0,
    metrics: {
      notePoolCompliance: readMusicLabMetric(payload, 'notePoolCompliance.poolComplianceRate'),
      intervalSmoothShare: readMusicLabMetric(payload, 'intervalProfile.smoothShare'),
      motifReuseRate: readMusicLabMetric(payload, 'motifReuse.motifReuseRate'),
      responseRate: readMusicLabMetric(payload, 'callResponse.responseRate'),
      paletteContinuityScore: readMusicLabMetric(payload, 'paletteContinuity.paletteContinuityScore'),
      playerMaskingRate: readMusicLabMetric(payload, 'playerMasking.playerMaskingRate'),
      enemyExecutedToCreatedRate: readMusicLabMetric(payload, 'executedToCreatedRate'),
      spawnerExecutedToCreatedRate: readMusicLabMetric(payload, 'spawnerExecutedToCreatedRate'),
      bassExecutedToCreatedRate: readMusicLabMetric(payload, 'bassExecutedToCreatedRate'),
      skippedCreatedEvents: readMusicLabMetric(payload, 'skippedCreatedEvents'),
      spawnerSkippedCreatedEvents: readMusicLabMetric(payload, 'spawnerSkippedCreatedEvents'),
      bassSkippedCreatedEvents: readMusicLabMetric(payload, 'bassSkippedCreatedEvents'),
      maxEnemyStepsWithoutBass: readMusicLabMetric(payload, 'maxEnemyStepsWithoutBass'),
      visualRoleThreeRoleReadableShare: readMusicLabMetric(payload, 'visualRoleThreeRoleReadableShare'),
      visualRoleFullTextureThreeRoleReadableShare: readMusicLabMetric(payload, 'visualRoleFullTextureThreeRoleReadableShare'),
      visualRoleSupportCollapsedDuringLeadShare: readMusicLabMetric(payload, 'visualRoleSupportCollapsedDuringLeadShare'),
      visualRoleFullTextureLeadWithSupportVisibleShare: readMusicLabMetric(payload, 'visualRoleFullTextureLeadWithSupportVisibleShare'),
      visualRoleAvgDistinctReadableRoleCount: readMusicLabMetric(payload, 'visualRoleAvgDistinctReadableRoleCount'),
      visualRoleAvgSupportVisualWeight: readMusicLabMetric(payload, 'visualRoleAvgSupportVisualWeight'),
      formationRoleFullTextureThreeRoleReadableShare: readMusicLabMetric(payload, 'formationRoleFullTextureThreeRoleReadableShare'),
      formationRoleFullTextureLeadWithSupportVisibleShare: readMusicLabMetric(payload, 'formationRoleFullTextureLeadWithSupportVisibleShare'),
      formationRoleSupportCollapsedDuringLeadShare: readMusicLabMetric(payload, 'formationRoleSupportCollapsedDuringLeadShare'),
      formationRoleAvgDistinctReadableRoleCount: readMusicLabMetric(payload, 'formationRoleAvgDistinctReadableRoleCount'),
      laneContinuityAssertionPassed: payload?.metrics?.laneContinuityAssertionPassed === true,
      laneContinuityBreaks: readMusicLabMetric(payload, 'laneContinuityBreaks'),
      laneResetHandoffs: readMusicLabMetric(payload, 'laneResetHandoffs'),
      laneCarrierTransferred: readMusicLabMetric(payload, 'laneCarrierTransferred'),
      laneCarrierUnbound: readMusicLabMetric(payload, 'laneCarrierUnbound'),
      laneSystemVoiceFallbacks: readMusicLabMetric(payload, 'laneSystemVoiceFallbacks'),
      laneVacantFallbacks: readMusicLabMetric(payload, 'laneVacantFallbacks'),
      protectedLaneVacantFallbacks: readMusicLabMetric(payload, 'protectedLaneVacantFallbacks'),
      level1ContractCompliancePassed: payload?.metrics?.level1ContractCompliancePassed === true,
      level1ContractMusicalEventCount: readMusicLabMetric(payload, 'level1ContractMusicalEventCount'),
      level1ContractViolationCount: readMusicLabMetric(payload, 'level1ContractViolationCount'),
      level1ContractViolationRate: readMusicLabMetric(payload, 'level1ContractViolationRate'),
      level1ContractRoleViolationCount: readMusicLabMetric(payload, 'level1ContractRoleViolationCount'),
      level1ContractSparkleViolationCount: readMusicLabMetric(payload, 'level1ContractSparkleViolationCount'),
      level1ContractAnswerViolationCount: readMusicLabMetric(payload, 'level1ContractAnswerViolationCount'),
      level1ArrangementMusicalityPassed: payload?.metrics?.level1ArrangementMusicalityPassed === true,
      level1ArrangementMusicalityFailureCount: readMusicLabMetric(payload, 'level1ArrangementMusicalityFailureCount'),
      level1ArrangementTraceCount: readMusicLabMetric(payload, 'level1ArrangementTraceCount'),
      level1ArrangementIntroSetPieceViolationCount: readMusicLabMetric(payload, 'level1ArrangementIntroSetPieceViolationCount'),
      level1ArrangementPostIntroCount: readMusicLabMetric(payload, 'level1ArrangementPostIntroCount'),
      arrangementSupportCount: readMusicLabMetric(payload, 'arrangementSupportCount'),
      musicIntensityAuditionDetected: payload?.metrics?.musicIntensityAuditionDetected === true,
      musicIntensityAuditionPassed: payload?.metrics?.musicIntensityAuditionPassed === true,
      musicIntensityAuditionFailureCount: readMusicLabMetric(payload, 'musicIntensityAuditionFailureCount'),
    },
    laneContinuityAssertion: laneContinuityAssertion ? cloneSmallObject(laneContinuityAssertion) : null,
    level1ArrangementMusicality: level1ArrangementMusicality ? cloneSmallObject(level1ArrangementMusicality) : null,
    musicIntensityAudition: musicIntensityAudition ? cloneSmallObject(musicIntensityAudition) : null,
    visualRoleReadability: visualRoleReadability
      ? {
          count: Number(visualRoleReadability.count) || 0,
          fullTextureCount: Number(visualRoleReadability.fullTextureCount) || 0,
          threeRoleReadableShare: Number(visualRoleReadability.threeRoleReadableShare) || 0,
          fullTextureThreeRoleReadableShare: Number(visualRoleReadability.fullTextureThreeRoleReadableShare) || 0,
          supportCollapsedDuringLeadShare: Number(visualRoleReadability.supportCollapsedDuringLeadShare) || 0,
          leadWithSupportVisibleShare: Number(visualRoleReadability.leadWithSupportVisibleShare) || 0,
          fullTextureLeadWithSupportVisibleShare: Number(visualRoleReadability.fullTextureLeadWithSupportVisibleShare) || 0,
          avgDistinctReadableRoleCount: Number(visualRoleReadability.avgDistinctReadableRoleCount) || 0,
          avgSupportVisualWeight: Number(visualRoleReadability.avgSupportVisualWeight) || 0,
          formationFullTextureThreeRoleReadableShare: Number(visualRoleReadability.formationFullTextureThreeRoleReadableShare) || 0,
          formationFullTextureLeadWithSupportVisibleShare: Number(visualRoleReadability.formationFullTextureLeadWithSupportVisibleShare) || 0,
          formationSupportCollapsedDuringLeadShare: Number(visualRoleReadability.formationSupportCollapsedDuringLeadShare) || 0,
          formationAvgDistinctReadableRoleCount: Number(visualRoleReadability.formationAvgDistinctReadableRoleCount) || 0,
          byFormationReadableRoleSet: cloneSmallObject(visualRoleReadability.byFormationReadableRoleSet || {}),
          byFormationArchetypeRole: cloneSmallObject(visualRoleReadability.byFormationArchetypeRole || {}),
          readableRoleShares: cloneSmallObject(visualRoleReadability.readableRoleShares || {}),
          byReadableRoleSet: cloneSmallObject(visualRoleReadability.byReadableRoleSet || {}),
          byEnemyHealthSection: cloneSmallObject(visualRoleReadability.byEnemyHealthSection || {}),
        }
      : null,
    systemEventSummary: systemEventSummary
      ? {
          totalCount: Number(systemEventSummary.totalCount) || 0,
          countsByType: cloneSmallObject(systemEventSummary.countsByType || {}),
          countsByReason: cloneSmallObject(systemEventSummary.countsByReason || {}),
          countsByVisualFailureReason: cloneSmallObject(systemEventSummary.countsByVisualFailureReason || {}),
          uniqueSectionIds: cloneSmallObject(systemEventSummary.uniqueSectionIds || []),
        }
      : null,
  };
}

function aggregateMusicRunSummaries(summaries) {
  const list = Array.isArray(summaries) ? summaries.filter((s) => s && typeof s === 'object') : [];
  const count = list.length;
  const avg = (vals) => {
    const nums = vals.map((v) => Number(v)).filter((n) => Number.isFinite(n));
    if (!nums.length) return null;
    return nums.reduce((a, b) => a + b, 0) / nums.length;
  };
  const variance = (vals) => {
    const nums = vals.map((v) => Number(v)).filter((n) => Number.isFinite(n));
    if (nums.length < 2) return null;
    const mean = nums.reduce((a, b) => a + b, 0) / nums.length;
    return nums.reduce((a, b) => a + ((b - mean) * (b - mean)), 0) / nums.length;
  };
  return {
    runCount: count,
    averageEventCount: avg(list.map((s) => s.eventCount)),
    averagePaletteChangeCount: avg(list.map((s) => s.paletteChangeCount)),
    averagePacingChangeCount: avg(list.map((s) => s.pacingChangeCount)),
    averageNotePoolCompliance: avg(list.map((s) => s?.metrics?.notePoolCompliance)),
    averageIntervalSmoothShare: avg(list.map((s) => s?.metrics?.intervalSmoothShare)),
    averageMotifReuseRate: avg(list.map((s) => s?.metrics?.motifReuseRate)),
    averageResponseRate: avg(list.map((s) => s?.metrics?.responseRate)),
    averagePaletteContinuityScore: avg(list.map((s) => s?.metrics?.paletteContinuityScore)),
    averagePlayerMaskingRate: avg(list.map((s) => s?.metrics?.playerMaskingRate)),
    averageEnemyExecutedToCreatedRate: avg(list.map((s) => s?.metrics?.enemyExecutedToCreatedRate)),
    averageSpawnerExecutedToCreatedRate: avg(list.map((s) => s?.metrics?.spawnerExecutedToCreatedRate)),
    averageBassExecutedToCreatedRate: avg(list.map((s) => s?.metrics?.bassExecutedToCreatedRate)),
    averageSkippedCreatedEvents: avg(list.map((s) => s?.metrics?.skippedCreatedEvents)),
    averageSpawnerSkippedCreatedEvents: avg(list.map((s) => s?.metrics?.spawnerSkippedCreatedEvents)),
    averageBassSkippedCreatedEvents: avg(list.map((s) => s?.metrics?.bassSkippedCreatedEvents)),
    averageMaxEnemyStepsWithoutBass: avg(list.map((s) => s?.metrics?.maxEnemyStepsWithoutBass)),
    arrangementMusicalityPassCount: list.filter((s) => s?.metrics?.level1ArrangementMusicalityPassed === true).length,
    averageArrangementMusicalityFailureCount: avg(list.map((s) => s?.metrics?.level1ArrangementMusicalityFailureCount)),
    musicIntensityAuditionPassCount: list.filter((s) => s?.metrics?.musicIntensityAuditionPassed === true).length,
    averageMusicIntensityAuditionFailureCount: avg(list.map((s) => s?.metrics?.musicIntensityAuditionFailureCount)),
    varianceEventCount: variance(list.map((s) => s.eventCount)),
    variancePlayerMaskingRate: variance(list.map((s) => s?.metrics?.playerMaskingRate)),
  };
}

function normalizeLabType(value) {
  const raw = String(value || '').trim().toLowerCase();
  if (raw === 'music' || raw === 'music-lab' || raw === 'musiclab') return 'music';
  return 'perf';
}

function hasMusicLabHint(value) {
  const raw = String(value || '').trim().toLowerCase();
  if (!raw) return false;
  return raw.includes('musiclab') || raw.includes('music-lab') || raw.includes('music lab');
}

function inferLabTypeFromResultsMeta(results, meta = {}) {
  const explicitType = String(meta?.labType || meta?.kind || '').trim();
  if (explicitType) return normalizeLabType(explicitType);

  const rows = Array.isArray(results) ? results : [results];
  for (const row of rows) {
    if (!row || typeof row !== 'object') continue;
    if (row.musicLab && typeof row.musicLab === 'object') return 'music';
  }

  return 'perf';
}

function buildLabResultFileName(labType = 'perf', prefixOverride = '') {
  const mode = normalizeLabType(labType);
  const prefix = String(prefixOverride || (mode === 'music' ? 'music-lab-results' : 'perf-lab-results')).trim() || 'perf-lab-results';
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  return `${prefix}-${ts}.json`;
}

function resolveLabPostUrl(cfg, labType = 'perf') {
  const src = (cfg && typeof cfg === 'object') ? cfg : {};
  const mode = normalizeLabType(labType);
  if (mode === 'music') {
    return src.postUrlMusic
      || src.musicPostUrl
      || window.__MUSIC_LAB_RESULTS_URL
      || src.postUrl
      || window.__PERF_LAB_RESULTS_URL
      || DEFAULT_MUSIC_RESULTS_URL;
  }
  return src.postUrlPerf
    || src.perfPostUrl
    || src.postUrl
    || window.__PERF_LAB_RESULTS_URL
    || DEFAULT_PERF_RESULTS_URL;
}

function resolveDebugOutputPostUrl(cfg) {
  const src = (cfg && typeof cfg === 'object') ? cfg : {};
  return src.debugOutputUrl
    || src.postUrlDebug
    || window.__DEBUG_OUTPUT_URL
    || DEFAULT_DEBUG_OUTPUT_URL;
}

function buildResultsBundle(results, meta = {}) {
  const href = (typeof location !== 'undefined' && location.href) ? location.href : '';
  const ua = (typeof navigator !== 'undefined' && navigator.userAgent) ? navigator.userAgent : '';
  const labType = inferLabTypeFromResultsMeta(results, meta);
  const safeMeta = { ...(meta || {}), labType };
  if (!safeMeta.kind) safeMeta.kind = (labType === 'music') ? 'music-lab' : 'perf-lab';
  const rows = Array.isArray(results) ? results : [];
  const safeResults = rows.map((row) => {
    if (!row || typeof row !== 'object') return row;
    const next = { ...row };
    if (!next.labType) next.labType = labType;
    return next;
  });
  return {
    createdAt: new Date().toISOString(),
    href,
    userAgent: ua,
    meta: safeMeta,
    results: safeResults,
  };
}

function saveResultsBundle(bundle, key = PERF_LAB_STORAGE_KEY) {
  if (!bundle) return false;
  try {
    localStorage.setItem(key, JSON.stringify(bundle));
    return true;
  } catch (err) {
    console.warn('[PerfLab] saveResults failed', err);
    return false;
  }
}

function deriveLegacyPerfResultsUrl(url) {
  const raw = String(url || '').trim();
  if (!raw) return '';
  if (raw.includes('/music-lab-results')) return raw.replace('/music-lab-results', '/perf-lab-results');
  return '';
}

async function fetchWithPerfLabTimeout(url, options = null, timeoutMs = 12000) {
  const ms = Math.max(1000, Math.trunc(Number(timeoutMs) || 12000));
  const opts = options && typeof options === 'object' ? { ...options } : {};
  if (typeof AbortController === 'undefined') return fetch(url, opts);
  const controller = new AbortController();
  const timer = setTimeout(() => {
    try { controller.abort(); } catch {}
  }, ms);
  try {
    return await fetch(url, {
      ...opts,
      signal: opts.signal || controller.signal,
    });
  } finally {
    clearTimeout(timer);
  }
}

async function postResultsBundle(bundle, url, opts = {}) {
  if (!bundle || !url) return false;
  const allowLegacyPerfFallback = !!opts.allowLegacyPerfFallback;
  try {
    const res = await fetchWithPerfLabTimeout(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(bundle),
    });
    if (res && res.ok) return true;
    if (allowLegacyPerfFallback && res && res.status === 404) {
      const fallbackUrl = deriveLegacyPerfResultsUrl(url);
      if (fallbackUrl) {
        try {
          const retry = await fetchWithPerfLabTimeout(fallbackUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bundle),
          });
          return !!(retry && retry.ok);
        } catch {}
      }
    }
    return false;
  } catch (err) {
    console.warn('[PerfLab] postResults failed', err);
    return false;
  }
}

async function postDebugOutputFile({ fileName = '', text = '', meta = null } = {}, url = '') {
  if (!url) return false;
  const resolvedFileName = String(fileName || '').trim();
  const resolvedText = String(text || '');
  if (!resolvedFileName) return false;
  if (!resolvedText.trim()) return false;
  try {
    const res = await fetchWithPerfLabTimeout(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fileName: resolvedFileName,
        text: resolvedText,
        meta: meta && typeof meta === 'object' ? meta : null,
      }),
    });
    return !!(res && res.ok);
  } catch (err) {
    console.warn('[PerfLab] postDebugOutput failed', err);
    return false;
  }
}

function readAutoConfig() {
  let cfg = null;
  try {
    const params = new URLSearchParams(window.location.search || '');
    const raw = params.get('perfAuto') || params.get('perfLabAuto') || '';
    if (raw) {
      const parsed = safeJsonParse(raw);
      if (parsed && typeof parsed === 'object') cfg = parsed;
      else cfg = { queue: normalizeQueue(raw) };
      const delayMs = Number(params.get('perfAutoDelay') || '');
      if (Number.isFinite(delayMs)) cfg.delayMs = delayMs;
      const postUrl = params.get('perfResultsUrl');
      if (postUrl) {
        cfg.postUrl = postUrl;
        cfg.postUrlPerf = postUrl;
      }
      const postUrlPerf = params.get('perfResultsUrlPerf');
      if (postUrlPerf) cfg.postUrlPerf = postUrlPerf;
      const postUrlMusic = params.get('musicResultsUrl');
      if (postUrlMusic) cfg.postUrlMusic = postUrlMusic;
      const saveKey = params.get('perfSaveKey');
      if (saveKey) cfg.saveKey = saveKey;
      const autoStart = params.get('perfAutoStart');
      if (autoStart === '1' || autoStart === 'true') cfg.autoStart = true;
    }
  } catch {}

  if (!cfg) {
    try {
      const stored = localStorage.getItem(PERF_LAB_AUTO_KEY);
      const parsed = safeJsonParse(stored || '');
      if (parsed && typeof parsed === 'object') cfg = parsed;
    } catch {}
  }

  if (!cfg && typeof window !== 'undefined' && window.__PERF_LAB_AUTO) {
    cfg = (typeof window.__PERF_LAB_AUTO === 'object')
      ? { ...window.__PERF_LAB_AUTO }
      : { queue: normalizeQueue(window.__PERF_LAB_AUTO) };
  }

  if (cfg) cfg.queue = normalizeQueue(cfg.queue || cfg.list || cfg.tests);
  return cfg;
}

async function readAutoConfigFromFile(filePath = 'resources/perf-lab-auto.json') {
  try {
    const res = await fetch(filePath, { cache: 'no-store' });
    if (!res || !res.ok) return null;
    const data = await res.json();
    if (!data || typeof data !== 'object') return null;
    data.queue = normalizeQueue(data.queue || data.list || data.tests);
    return data;
  } catch {
    return null;
  }
}


async function resolveResultsConfig() {
  const cfgFile = await readAutoConfigFromFile();
  const cfg = cfgFile || readAutoConfig() || {};
  return cfg;
}

async function publishResultBundle(result, meta = {}) {
  if (!result) return null;
  const cfg = await resolveResultsConfig();
  const publishMeta = {
    queue: meta.queue || cfg.queue || [],
    notes: (meta.notes != null) ? meta.notes : (cfg.notes || ''),
    runId: (meta.runId != null) ? meta.runId : (cfg.runId || ''),
    testCategory: (meta.testCategory != null) ? meta.testCategory : '',
    scenarioName: (meta.scenarioName != null) ? meta.scenarioName : '',
    runMode: (meta.runMode != null) ? meta.runMode : 'manual',
  };
  const labType = inferLabTypeFromResultsMeta([result], publishMeta);
  const bundle = buildResultsBundle([result], {
    ...publishMeta,
    labType,
  });
  lastBundle = bundle;

  const saveKey = cfg.saveKey || PERF_LAB_STORAGE_KEY;
  if (cfg.save !== false) saveResultsBundle(bundle, saveKey);

  const postUrl = resolveLabPostUrl(cfg, labType);
  if (postUrl) await postResultsBundle(bundle, postUrl);
  return bundle;
}

async function persistMusicLabSaveResultOnLatestPerfResult(saveResult, meta = {}) {
  const result = (lastResult && typeof lastResult === 'object') ? lastResult : null;
  if (!result) return null;
  result.musicLabSaveResult = (saveResult && typeof saveResult === 'object') ? { ...saveResult } : null;
  try {
    if (Array.isArray(lastResults) && lastResults.length > 0) {
      lastResults[lastResults.length - 1] = result;
    }
  } catch {}
  try { setOutput(result); } catch {}
  const cfg = await resolveResultsConfig();
  const bundle = buildResultsBundle([result], {
    queue: meta.queue || cfg.queue || [],
    notes: (meta.notes != null) ? meta.notes : (cfg.notes || ''),
    runId: (meta.runId != null) ? meta.runId : (cfg.runId || ''),
    testCategory: (meta.testCategory != null) ? meta.testCategory : '',
    scenarioName: (meta.scenarioName != null) ? meta.scenarioName : '',
    runMode: (meta.runMode != null) ? meta.runMode : 'manual',
    labType: 'perf',
  });
  lastBundle = bundle;
  const saveKey = cfg.saveKey || PERF_LAB_STORAGE_KEY;
  if (cfg.save !== false) saveResultsBundle(bundle, saveKey);
  const postUrl = resolveLabPostUrl(cfg, 'perf');
  if (postUrl) await postResultsBundle(bundle, postUrl);
  return bundle;
}

async function publishMusicLabSaveDebugResult(entry = {}) {
  const cfg = await resolveResultsConfig();
  const postUrl = resolveLabPostUrl(cfg, 'perf');
  if (!postUrl) return { ok: false, reason: 'no_perf_post_url' };
  const row = {
    label: String(entry?.label || 'music-lab-save-debug'),
    createdAt: new Date().toISOString(),
    runId: String(entry?.runId || ''),
    musicLabSaveDebug: {
      ok: entry?.ok === true,
      reason: String(entry?.reason || ''),
      error: String(entry?.error || ''),
      errorStack: String(entry?.errorStack || ''),
      postUrl: String(entry?.postUrl || ''),
      sessionId: String(entry?.sessionId || ''),
      events: Math.max(0, Number(entry?.events) || 0),
      notes: String(entry?.notes || ''),
      sourceLabel: String(entry?.sourceLabel || ''),
      durationMs: Math.max(0, Number(entry?.durationMs) || 0),
      stageCount: Math.max(0, Number(entry?.stageCount) || 0),
      iterationIndex: Math.max(0, Number(entry?.iterationIndex) || 0),
      iterationCount: Math.max(0, Number(entry?.iterationCount) || 0),
    },
  };
  const bundle = buildResultsBundle([row], {
    runId: String(entry?.runId || ''),
    notes: String(entry?.notes || ''),
    runMode: 'manual',
    scenarioName: 'music-lab-save-debug',
    testCategory: 'music-lab-save-debug',
    labType: 'perf',
    kind: 'perf-lab-debug',
  });
  const ok = await postResultsBundle(bundle, postUrl);
  return { ok: !!ok, reason: ok ? '' : 'post_failed', postUrl };
}

function buildBeatSwarmTransitionDebugText(payload, meta = {}) {
  const src = payload && typeof payload === 'object' ? payload : {};
  const eventTimeline = Array.isArray(src.eventTimeline) ? src.eventTimeline : [];
  const systemEvents = Array.isArray(src.systemEvents) ? src.systemEvents : [];
  const transitionSnapshots = systemEvents
    .filter((e) => String(e?.eventType || '').trim().toLowerCase() === 'music_transition_snapshot')
    .sort((a, b) => (Number(a?.barIndex) || 0) - (Number(b?.barIndex) || 0));
  const executedEnemy = eventTimeline
    .filter((e) => String(e?.phase || '').trim().toLowerCase() === 'executed')
    .filter((e) => String(e?.sourceSystem || '').trim().toLowerCase() !== 'player');
  const firstLeadEvent = executedEnemy.find((e) => {
    const laneId = String(e?.musicLaneId || '').trim().toLowerCase();
    const role = String(e?.role || '').trim().toLowerCase();
    return laneId === 'primary_loop_lane' || role === 'lead';
  }) || null;
  const leadEntryBar = Math.max(0, Math.trunc(Number(firstLeadEvent?.barIndex) || 0));
  const rangeStart = Math.max(0, leadEntryBar > 0 ? (leadEntryBar - 4) : 8);
  const rangeEnd = Math.max(rangeStart + 8, leadEntryBar + 8);
  const isBarInRange = (barIndex) => {
    const bar = Math.trunc(Number(barIndex) || 0);
    return bar >= rangeStart && bar <= rangeEnd;
  };
  const leadRenderEvents = eventTimeline.filter((e) => {
    if (!isBarInRange(e?.barIndex)) return false;
    const laneId = String(e?.musicLaneId || '').trim().toLowerCase();
    return laneId === 'primary_loop_lane';
  });
  const secondaryRenderEvents = eventTimeline.filter((e) => {
    if (!isBarInRange(e?.barIndex)) return false;
    const laneId = String(e?.musicLaneId || '').trim().toLowerCase();
    return laneId === 'secondary_loop_lane';
  });
  const leadSuppressionEvents = systemEvents.filter((e) => {
    const eventType = String(e?.eventType || '').trim().toLowerCase();
    return eventType === 'music_primary_loop_group_suppressed' && isBarInRange(e?.barIndex);
  });
  const leadEmissionEvents = systemEvents.filter((e) => {
    const eventType = String(e?.eventType || '').trim().toLowerCase();
    return eventType === 'music_primary_loop_lane_emitted' && isBarInRange(e?.barIndex);
  });
  const summarizeLaneEventsForBar = (events, barIndex) => {
    const barEvents = events.filter((e) => Math.trunc(Number(e?.barIndex) || 0) === barIndex);
    const created = barEvents.filter((e) => String(e?.phase || '').trim().toLowerCase() === 'created');
    const executed = barEvents.filter((e) => String(e?.phase || '').trim().toLowerCase() === 'executed');
    const audible = executed.filter((e) => e?.enemyAudible === true);
    const full = executed.filter((e) => String(e?.musicProminence || '').trim().toLowerCase() === 'full');
    const quiet = executed.filter((e) => String(e?.musicProminence || '').trim().toLowerCase() === 'quiet');
    const trace = executed.filter((e) => String(e?.musicProminence || '').trim().toLowerCase() === 'trace');
    const noteCounts = Object.create(null);
    const instrumentCounts = Object.create(null);
    for (const ev of audible) {
      const note = String(ev?.noteResolved || ev?.note || '').trim();
      const instrument = String(ev?.resolvedPlaybackInstrumentId || ev?.instrumentId || '').trim();
      if (note) noteCounts[note] = (noteCounts[note] || 0) + 1;
      if (instrument) instrumentCounts[instrument] = (instrumentCounts[instrument] || 0) + 1;
    }
    const topNotes = Object.entries(noteCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([note, count]) => `${note}:${count}`)
      .join(', ');
    const topInstruments = Object.entries(instrumentCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 2)
      .map(([instrument, count]) => `${instrument}:${count}`)
      .join(', ');
    return {
      created: created.length,
      executed: executed.length,
      audible: audible.length,
      full: full.length,
      quiet: quiet.length,
      trace: trace.length,
      notes: topNotes,
      instruments: topInstruments,
    };
  };
  const lines = [];
  lines.push('Beat Swarm Transition Debug');
  lines.push(`sessionId=${String(src.sessionId || '')}`);
  lines.push(`runId=${String(meta.runId || '')}`);
  lines.push(`label=${String(meta.label || '')}`);
  lines.push(`leadEntryBar=${leadEntryBar}`);
  lines.push(`range=${rangeStart}-${rangeEnd}`);
  lines.push('');
  lines.push('Per-bar executed audible enemy events:');
  for (let bar = rangeStart; bar <= rangeEnd; bar++) {
    const barEvents = executedEnemy.filter((e) => Math.trunc(Number(e?.barIndex) || 0) === bar);
    const audible = barEvents.filter((e) => e?.enemyAudible === true);
    const playerAudible = eventTimeline.filter((e) => (
      Math.trunc(Number(e?.barIndex) || 0) === bar
      && String(e?.sourceSystem || '').trim().toLowerCase() === 'player'
      && e?.playerAudible === true
    )).length;
    const bucket = Object.create(null);
    for (const ev of audible) {
      const key = `${String(ev?.musicLaneId || '').trim().toLowerCase() || '-'}|${String(ev?.musicLayer || '').trim().toLowerCase() || '-'}|${String(ev?.callResponseLane || '').trim().toLowerCase() || '-'}|${String(ev?.musicProminence || '').trim().toLowerCase() || '-'}`;
      bucket[key] = Math.max(0, Math.trunc(Number(bucket[key]) || 0)) + 1;
    }
    const summary = Object.entries(bucket)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([k, v]) => `${k}:${v}`)
      .join(', ');
    lines.push(`bar ${bar}: audibleEnemy=${audible.length} playerAudible=${playerAudible}${summary ? ` :: ${summary}` : ''}`);
  }
  lines.push('');
  lines.push('Lead / Secondary Render Summary:');
  for (let bar = rangeStart; bar <= rangeEnd; bar++) {
    const lead = summarizeLaneEventsForBar(leadRenderEvents, bar);
    const secondary = summarizeLaneEventsForBar(secondaryRenderEvents, bar);
    const suppressions = leadSuppressionEvents
      .filter((e) => Math.trunc(Number(e?.barIndex) || 0) === bar)
      .reduce((bucket, ev) => {
        const reason = String(ev?.reason || ev?.payload?.reason || '').trim().toLowerCase() || 'unknown';
        bucket[reason] = (bucket[reason] || 0) + 1;
        return bucket;
      }, Object.create(null));
    const emissionSteps = leadEmissionEvents
      .filter((e) => Math.trunc(Number(e?.barIndex) || 0) === bar)
      .map((e) => Math.trunc(Number(e?.stepIndex) || 0));
    const suppressionSummary = Object.entries(suppressions)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([reason, count]) => `${reason}:${count}`)
      .join(', ');
    lines.push(
      `bar ${bar}: `
      + `lead c/e/a/f/q/t=${lead.created}/${lead.executed}/${lead.audible}/${lead.full}/${lead.quiet}/${lead.trace}`
      + `${lead.notes ? ` notes[${lead.notes}]` : ''}`
      + `${lead.instruments ? ` inst[${lead.instruments}]` : ''}`
      + ` | secondary c/e/a/f/q/t=${secondary.created}/${secondary.executed}/${secondary.audible}/${secondary.full}/${secondary.quiet}/${secondary.trace}`
      + `${secondary.notes ? ` notes[${secondary.notes}]` : ''}`
      + `${secondary.instruments ? ` inst[${secondary.instruments}]` : ''}`
      + `${emissionSteps.length ? ` | leadEmitSteps=${emissionSteps.join('/')}` : ''}`
      + `${suppressionSummary ? ` | leadSuppress=${suppressionSummary}` : ''}`
    );
  }
  lines.push('');
  lines.push('Transition snapshots:');
  for (const snap of transitionSnapshots.filter((e) => {
    const bar = Math.trunc(Number(e?.barIndex) || 0);
    return bar >= rangeStart && bar <= rangeEnd;
  })) {
    const payloadLike = snap?.payload && typeof snap.payload === 'object' ? snap.payload : {};
    const groups = Array.isArray(payloadLike.groups) ? payloadLike.groups : [];
    const groupSummary = groups
      .slice(0, 10)
      .map((g) => `${Math.trunc(Number(g?.id) || 0)}:${String(g?.laneId || '')}/${String(g?.profile || '')}/${String(g?.callResponseLane || '')}/alive=${Math.trunc(Number(g?.aliveMemberCount) || 0)}`)
      .join(', ');
    lines.push(
      `bar ${Math.trunc(Number(snap?.barIndex) || 0)} `
      + `intro=${String(payloadLike.introStage || '')} energy=${String(payloadLike.currentEnergyStateName || '')} pacing=${String(payloadLike.pacingState || '')} `
      + `support=${payloadLike?.supportLanePlan ? `${payloadLike.supportLanePlan.active ? 'on' : 'off'} tc=${payloadLike.supportLanePlan.targetCount} i=${Number(payloadLike.supportLanePlan.intensity || 0).toFixed(2)}` : 'n/a'} `
      + `answer=${payloadLike?.answerLanePlan ? `${payloadLike.answerLanePlan.active ? 'on' : 'off'} tc=${payloadLike.answerLanePlan.targetCount} i=${Number(payloadLike.answerLanePlan.intensity || 0).toFixed(2)}` : 'n/a'} `
      + `primary=${payloadLike?.primaryLoopLanePlan ? `${payloadLike.primaryLoopLanePlan.active ? 'on' : 'off'} tc=${payloadLike.primaryLoopLanePlan.targetCount} i=${Number(payloadLike.primaryLoopLanePlan.intensity || 0).toFixed(2)}` : 'n/a'} `
      + `effectiveSupport=${Math.trunc(Number(payloadLike.effectiveDirectorSupportGroups) || 0)} `
      + `effectiveAnswer=${Math.trunc(Number(payloadLike.effectiveDirectorAnswerGroups) || 0)} `
      + `groups=${Math.trunc(Number(payloadLike.activeGroupCount) || 0)}`
    );
    if (groupSummary) lines.push(`  ${groupSummary}`);
  }
  lines.push('');
  lines.push('Lead suppression events in range:');
  for (const ev of leadSuppressionEvents.slice(0, 80)) {
    lines.push(
      `bar ${Math.trunc(Number(ev?.barIndex) || 0)} step ${Math.trunc(Number(ev?.stepIndex) || 0)} `
      + `reason=${String(ev?.reason || ev?.payload?.reason || '')} `
      + `group=${Math.trunc(Number(ev?.groupId || ev?.payload?.groupId) || 0)} `
      + `enemy=${Math.trunc(Number(ev?.enemyId || ev?.payload?.enemyId) || 0)} `
      + `laneMode=${String(ev?.laneMode || ev?.payload?.laneMode || '')} `
      + `soloCarrierType=${String(ev?.soloCarrierType || ev?.payload?.soloCarrierType || '')}`
    );
  }
  lines.push('');
  lines.push('Response events in range:');
  const responseEvents = eventTimeline.filter((e) => {
    const bar = Math.trunc(Number(e?.barIndex) || 0);
    return bar >= rangeStart && bar <= rangeEnd && String(e?.callResponseLane || '').trim().toLowerCase() === 'response';
  });
  for (const ev of responseEvents.slice(0, 40)) {
    lines.push(
      `bar ${Math.trunc(Number(ev?.barIndex) || 0)} step ${Math.trunc(Number(ev?.stepIndex) || 0)} `
      + `phase=${String(ev?.phase || '')} actor=${Math.trunc(Number(ev?.actorId) || 0)} audible=${ev?.enemyAudible === true ? 'y' : 'n'} `
      + `lane=${String(ev?.musicLaneId || '')} layer=${String(ev?.musicLayer || '')} inst=${String(ev?.instrumentId || '')} note=${String(ev?.noteResolved || ev?.note || '')}`
    );
  }
  return lines.join('\n').trim();
}

async function saveMusicLabTransitionDebugOutput(payload, meta = {}) {
  const text = buildBeatSwarmTransitionDebugText(payload, meta);
  if (!text.trim()) return { ok: false, reason: 'empty_transition_debug' };
  const cfg = await resolveResultsConfig();
  const postUrl = resolveDebugOutputPostUrl(cfg);
  const sessionIdPart = String(payload?.sessionId || 'session').replace(/[<>:"/\\|?*\x00-\x1F]/g, '-');
  const runIdPart = String(meta.runId || 'music-lab').replace(/[<>:"/\\|?*\x00-\x1F]/g, '-');
  const fileName = `${runIdPart || 'music-lab'}__transition-debug__${sessionIdPart}.txt`;
  const saved = await postDebugOutputFile({
    fileName,
    text,
    meta: {
      kind: 'beat-swarm-transition-debug',
      sessionId: String(payload?.sessionId || ''),
      runId: String(meta.runId || ''),
      label: String(meta.label || ''),
    },
  }, postUrl);
  return { ok: !!saved, fileName, postUrl };
}

async function publishBs0MusicRunStageDebugResult(entry = {}) {
  const cfg = await resolveResultsConfig();
  const postUrl = resolveLabPostUrl(cfg, 'perf');
  if (!postUrl) return { ok: false, reason: 'no_perf_post_url' };
  const row = {
    label: String(entry?.label || 'music-lab-run-stage-debug'),
    createdAt: new Date().toISOString(),
    runId: String(entry?.runId || ''),
    musicLabRunStageDebug: {
      stage: String(entry?.stage || ''),
      sourceLabel: String(entry?.sourceLabel || ''),
      notes: String(entry?.notes || ''),
      durationMs: Math.max(0, Number(entry?.durationMs) || 0),
      stageCount: Math.max(0, Number(entry?.stageCount) || 0),
      iterationIndex: Math.max(0, Number(entry?.iterationIndex) || 0),
      iterationCount: Math.max(0, Number(entry?.iterationCount) || 0),
      transportRunning: entry?.transportRunning === true,
      beatSwarmActive: entry?.beatSwarmActive === true,
      perfRunTag: String(entry?.perfRunTag || ''),
    },
  };
  const bundle = buildResultsBundle([row], {
    runId: String(entry?.runId || ''),
    notes: String(entry?.notes || ''),
    runMode: 'manual',
    scenarioName: 'music-lab-run-stage-debug',
    testCategory: 'music-lab-run-stage-debug',
    labType: 'perf',
    kind: 'perf-lab-debug',
  });
  const ok = await postResultsBundle(bundle, postUrl);
  return { ok: !!ok, reason: ok ? '' : 'post_failed', postUrl };
}

async function publishRunVariantDebugResult(entry = {}) {
  const cfg = await resolveResultsConfig();
  const postUrl = resolveLabPostUrl(cfg, 'perf');
  if (!postUrl) return { ok: false, reason: 'no_perf_post_url' };
  const row = {
    label: String(entry?.label || 'run-variant-debug'),
    createdAt: new Date().toISOString(),
    runId: String(entry?.runId || ''),
    runVariantDebug: {
      stage: String(entry?.stage || ''),
      sourceLabel: String(entry?.sourceLabel || ''),
      durationMs: Math.max(0, Number(entry?.durationMs) || 0),
      elapsedMs: Math.max(0, Number(entry?.elapsedMs) || 0),
      frameCount: Math.max(0, Number(entry?.frameCount) || 0),
      warmupMs: Math.max(0, Number(entry?.warmupMs) || 0),
      transportRunning: entry?.transportRunning === true,
      beatSwarmActive: entry?.beatSwarmActive === true,
      perfRunTag: String(entry?.perfRunTag || ''),
      detail: String(entry?.detail || ''),
    },
  };
  const bundle = buildResultsBundle([row], {
    runId: String(entry?.runId || ''),
    notes: String(entry?.notes || ''),
    runMode: 'manual',
    scenarioName: 'run-variant-debug',
    testCategory: 'run-variant-debug',
    labType: 'perf',
    kind: 'perf-lab-debug',
  });
  const ok = await postResultsBundle(bundle, postUrl);
  return { ok: !!ok, reason: ok ? '' : 'post_failed', postUrl };
}

const PERF_RUN_LIFECYCLE_DEBUG_STORAGE_KEY = 'mt_perf_run_lifecycle_debug_v1';

async function publishPerfRunLifecycleDebugResult(entry = {}) {
  const cfg = await resolveResultsConfig();
  const postUrl = resolveLabPostUrl(cfg, 'perf');
  if (!postUrl) return { ok: false, reason: 'no_perf_post_url' };
  const row = {
    label: String(entry?.label || 'perf-run-lifecycle-debug'),
    createdAt: new Date().toISOString(),
    runId: String(entry?.runId || ''),
    perfRunLifecycleDebug: {
      stage: String(entry?.stage || ''),
      sourceLabel: String(entry?.sourceLabel || ''),
      durationMs: Math.max(0, Number(entry?.durationMs) || 0),
      elapsedMs: Math.max(0, Number(entry?.elapsedMs) || 0),
      frameCount: Math.max(0, Number(entry?.frameCount) || 0),
      perfRunTag: String(entry?.perfRunTag || ''),
      transportRunning: entry?.transportRunning === true,
      beatSwarmActive: entry?.beatSwarmActive === true,
      detail: String(entry?.detail || ''),
      href: String(entry?.href || ''),
      startedAt: String(entry?.startedAt || ''),
      capturedAt: String(entry?.capturedAt || new Date().toISOString()),
    },
  };
  const bundle = buildResultsBundle([row], {
    runId: String(entry?.runId || ''),
    notes: String(entry?.notes || ''),
    runMode: 'manual',
    scenarioName: 'perf-run-lifecycle-debug',
    testCategory: 'perf-run-lifecycle-debug',
    labType: 'perf',
    kind: 'perf-lab-debug',
  });
  const ok = await postResultsBundle(bundle, postUrl);
  return { ok: !!ok, reason: ok ? '' : 'post_failed', postUrl };
}

function stashPerfRunLifecycleDebug(entry = {}) {
  try {
    localStorage.setItem(PERF_RUN_LIFECYCLE_DEBUG_STORAGE_KEY, JSON.stringify({
      ...entry,
      capturedAt: new Date().toISOString(),
    }));
  } catch {}
}

async function flushPendingPerfRunLifecycleDebug() {
  let raw = '';
  try { raw = String(localStorage.getItem(PERF_RUN_LIFECYCLE_DEBUG_STORAGE_KEY) || ''); } catch {}
  if (!raw) return null;
  try { localStorage.removeItem(PERF_RUN_LIFECYCLE_DEBUG_STORAGE_KEY); } catch {}
  try {
    const parsed = JSON.parse(raw);
    return await publishPerfRunLifecycleDebugResult(parsed);
  } catch {
    return null;
  }
}

function installPerfRunLifecycleDebugHooks() {
  try {
    if (window.__PERF_RUN_LIFECYCLE_DEBUG_HOOKS_INSTALLED) return;
    window.__PERF_RUN_LIFECYCLE_DEBUG_HOOKS_INSTALLED = true;
    const capture = (stage, detail = '') => {
      const ctx = (window.__PERF_ACTIVE_RUN_DEBUG && typeof window.__PERF_ACTIVE_RUN_DEBUG === 'object')
        ? window.__PERF_ACTIVE_RUN_DEBUG
        : null;
      if (!ctx) return;
      stashPerfRunLifecycleDebug({
        label: 'perf-run-lifecycle-debug',
        runId: String(ctx.runId || ''),
        stage,
        sourceLabel: String(ctx.sourceLabel || ''),
        durationMs: Math.max(0, Number(ctx.durationMs) || 0),
        elapsedMs: Math.max(0, Number(((typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now()) - (Number(ctx.wallStartMs) || 0)) || 0),
        frameCount: Math.max(0, Number(ctx.frameCountRef?.()) || 0),
        perfRunTag: String(ctx.perfRunTag || ''),
        transportRunning: !!(typeof isRunning === 'function' && isRunning()),
        beatSwarmActive: !!window.__beatSwarmActive,
        detail: String(detail || ''),
        href: String(location?.href || ''),
        startedAt: String(ctx.startedAt || ''),
      });
    };
    window.addEventListener('beforeunload', () => capture('beforeunload'), { capture: true });
    window.addEventListener('pagehide', () => capture('pagehide'), { capture: true });
    window.addEventListener('error', (event) => {
      capture('error', String(event?.message || event?.error?.message || 'window_error'));
    }, { capture: true });
    window.addEventListener('unhandledrejection', (event) => {
      const reason = event?.reason;
      capture('unhandledrejection', String(reason?.message || reason || 'unhandled_rejection'));
    }, { capture: true });
  } catch {}
}

function publishRunVariantDebugResultAsync(entry = {}) {
  try {
    if (typeof window !== 'undefined' && window.__PERF_LAB_DEFER_DEBUG_POSTS) return;
    Promise.resolve()
      .then(() => publishRunVariantDebugResult(entry))
      .catch(() => {});
  } catch {}
}

try {
  installPerfRunLifecycleDebugHooks();
  Promise.resolve().then(() => flushPendingPerfRunLifecycleDebug()).catch(() => {});
} catch {}

async function runAuto(config = {}) {
  const cfg = (config && typeof config === 'object') ? config : { queue: normalizeQueue(config) };
  const queue = normalizeQueue(cfg.queue || cfg.list || cfg.tests);
  if (!queue.length) {
    setStatus('Auto-run: no tests');
    return [];
  }

  // Guard against accidental re-entrancy (eg. multiple scheduleAutoRun timers, hot reloads, double-clicks)
  if (window.__PERF_LAB_AUTO_RUNNING) {
    setStatus('Auto-run: already running');
    return [];
  }
  window.__PERF_LAB_AUTO_RUNNING = true;

  try {
    if (cfg.clear === true) {
      lastResult = null;
      lastResults = [];
      setOutput(null);
    }

    setStatus('Auto-run: ' + queue.length + ' tests');
    const __prevCtx = window.__PERF_LAB_RUN_CONTEXT;
    const __prevRunTag = window.__PERF_RUN_TAG;
    const __prevRunTagParts = (window.__PERF_RUN_TAG_PARTS && typeof window.__PERF_RUN_TAG_PARTS === 'object')
      ? { ...window.__PERF_RUN_TAG_PARTS }
      : null;
    const __prevTraceMarks = window.__PERF_TRACE_MARKS;
    const __prevTraceLongMs = window.__PERF_TRACE_LONG_MS;
    const __prevTapDotsSim = window.__PERF_TAP_DOTS_SIM;
    const __prevChainUiFreeze = window.__PERF_DISABLE_CHAIN_UI;
    const __prevTrace = (window.__PERF_TRACE && typeof window.__PERF_TRACE === 'object') ? { ...window.__PERF_TRACE } : null;
    let __prevParticles = null;
    const __prevGestureAutoLock = window.__PERF_GESTURE_AUTO_LOCK;
    const __prevDgAdaptiveEnabled = window.__DG_ADAPTIVE_DPR_ENABLED;
    const __prevDgAdaptiveAllowSingle = window.__DG_ADAPTIVE_DPR_ALLOW_SINGLE;
    const __prevDgTierAuto = window.__DG_TIER_AUTO;
    const __prevDgForceTier = window.__DG_FORCE_TIER;
    window.__PERF_LAB_RUN_CONTEXT = 'auto';
    if (cfg.runTag != null) window.__PERF_RUN_TAG = String(cfg.runTag);
    try { window.__PERF_RUN_TAG_PARTS = {}; } catch {}
    if (cfg.traceMarks != null) window.__PERF_TRACE_MARKS = !!cfg.traceMarks;
    if (Number.isFinite(cfg.traceLongMs)) window.__PERF_TRACE_LONG_MS = Number(cfg.traceLongMs);
    if (cfg.tapDotsSim != null) window.__PERF_TAP_DOTS_SIM = !!cfg.tapDotsSim;
    if (cfg.freezeChainUi != null) window.__PERF_DISABLE_CHAIN_UI = !!cfg.freezeChainUi;
    if (cfg.traceCanvasResize != null || cfg.traceDomInRaf != null) {
      try {
        const st = (window.__PERF_TRACE = window.__PERF_TRACE || {});
        if (cfg.traceCanvasResize != null) st.traceCanvasResize = !!cfg.traceCanvasResize;
        if (cfg.traceDomInRaf != null) st.traceDomInRaf = !!cfg.traceDomInRaf;
        // Keep UI in sync (helpful when someone watches the run)
        try { syncUiFromState(); } catch {}
      } catch {}
    }
    if (cfg.particleToggles && typeof cfg.particleToggles === 'object') {
      try {
        const st = (window.__PERF_PARTICLES = window.__PERF_PARTICLES || {});
        __prevParticles = { ...st };
        Object.assign(st, cfg.particleToggles);
      } catch {}
    }
    const wantsGestureLock = cfg.gestureAutoLock === true
      || (cfg.particleToggles
        && (cfg.particleToggles.gestureDrawModulo === 1 || cfg.particleToggles.gestureFieldModulo === 1));
    if (wantsGestureLock) window.__PERF_GESTURE_AUTO_LOCK = true;

    let results;
    try {
      results = await runQueue(queue);
    } finally {
      window.__PERF_LAB_RUN_CONTEXT = __prevCtx;
      window.__PERF_RUN_TAG = __prevRunTag;
      if (__prevRunTagParts && typeof __prevRunTagParts === 'object') {
        try { window.__PERF_RUN_TAG_PARTS = { ...__prevRunTagParts }; } catch {}
      } else {
        try { delete window.__PERF_RUN_TAG_PARTS; } catch {}
      }
      window.__PERF_TRACE_MARKS = __prevTraceMarks;
      window.__PERF_TRACE_LONG_MS = __prevTraceLongMs;
      if (typeof __prevTapDotsSim === 'undefined') {
        try { delete window.__PERF_TAP_DOTS_SIM; } catch {}
      } else {
        window.__PERF_TAP_DOTS_SIM = __prevTapDotsSim;
      }
      if (__prevParticles) {
        try {
          const st = (window.__PERF_PARTICLES = window.__PERF_PARTICLES || {});
          Object.assign(st, __prevParticles);
        } catch {}
      }
      window.__PERF_DISABLE_CHAIN_UI = __prevChainUiFreeze;
      window.__PERF_GESTURE_AUTO_LOCK = __prevGestureAutoLock;
      if (typeof __prevDgAdaptiveEnabled === 'undefined') {
        try { delete window.__DG_ADAPTIVE_DPR_ENABLED; } catch {}
      } else {
        window.__DG_ADAPTIVE_DPR_ENABLED = __prevDgAdaptiveEnabled;
      }
      if (typeof __prevDgAdaptiveAllowSingle === 'undefined') {
        try { delete window.__DG_ADAPTIVE_DPR_ALLOW_SINGLE; } catch {}
      } else {
        window.__DG_ADAPTIVE_DPR_ALLOW_SINGLE = __prevDgAdaptiveAllowSingle;
      }
      if (typeof __prevDgTierAuto === 'undefined') {
        try { delete window.__DG_TIER_AUTO; } catch {}
      } else {
        window.__DG_TIER_AUTO = __prevDgTierAuto;
      }
      if (typeof __prevDgForceTier === 'undefined') {
        try { delete window.__DG_FORCE_TIER; } catch {}
      } else {
        window.__DG_FORCE_TIER = __prevDgForceTier;
      }
      if (__prevTrace) {
        try { window.__PERF_TRACE = { ...__prevTrace }; } catch {}
      }
    }

    const traceSummary = computePerfTraceSummary();
    const bundleMeta = {
      queue,
      traceSummary,
      executedQueue: Array.isArray(window.__PERF_LAB_EXECUTED_QUEUE) ? window.__PERF_LAB_EXECUTED_QUEUE : [],
      notes: cfg.notes || '',
      runId: cfg.runId || '',
      testCategory: cfg.testCategory || '',
      scenarioName: cfg.scenarioName || '',
      runMode: 'auto',
      iterationIndex: Number.isFinite(cfg.iterationIndex) ? Math.max(1, Math.trunc(cfg.iterationIndex)) : 1,
      iterationCount: Number.isFinite(cfg.iterationCount) ? Math.max(1, Math.trunc(cfg.iterationCount)) : 1,
    };
    const labType = inferLabTypeFromResultsMeta(results, bundleMeta);
    const bundle = buildResultsBundle(results, {
      ...bundleMeta,
      labType,
    });
    lastBundle = bundle;

    const saveKey = cfg.saveKey || PERF_LAB_STORAGE_KEY;
    if (cfg.save !== false) saveResultsBundle(bundle, saveKey);

    const postUrl = resolveLabPostUrl(cfg, labType);
    if (postUrl) await postResultsBundle(bundle, postUrl);

    if (cfg.clearAfter !== false) {
      try { clearSceneViaSnapshot(); } catch {}
    }

    setStatus('Auto-run: done (' + results.length + ' results)');
    return results;
  } finally {
    window.__PERF_LAB_AUTO_RUNNING = false;
  }
}

function scheduleAutoRun() {
  // Guard against multiple injections / hot reload re-evaluations of perf-lab.js
  if (window.__PERF_LAB_AUTO_SCHEDULED) return;
  window.__PERF_LAB_AUTO_SCHEDULED = true;

  const cfg = readAutoConfig();
  if (!cfg || !cfg.queue || !cfg.queue.length) return;
  const autoStart = (cfg.autoStart === true) || (cfg.runNow === true);
  if (!autoStart) return;
  const delayMs = Number.isFinite(cfg.delayMs) ? cfg.delayMs : 1200;
  setTimeout(() => {
    runAuto(cfg).catch((err) => console.warn('[PerfLab] auto-run failed', err));
  }, Math.max(0, delayMs));
}


function setStatus(s) {
  const el = document.getElementById('perf-lab-status');
  if (el) el.textContent = s;
}

function setOutput(obj) {
  const el = document.getElementById('perf-lab-output');
  if (!el) return;
  el.textContent = obj ? JSON.stringify(obj, null, 2) : '';
}

function appendOutputLine(line) {
  try {
    const el = document.getElementById('perf-lab-output');
    if (!el) return;
    const prev = String(el.textContent || '');
    const next = prev ? (prev.replace(/\s+$/,'') + '\n' + String(line)) : String(line);
    el.textContent = next;
  } catch {}
}

function pauseHarmonyLab(ov) {
  ov.querySelector('.perf-lab-harmony-frame')?.contentWindow?.postMessage({ type: 'rhythmake:harmony-lab:pause' }, location.origin);
}

// Keep the menu shortcut available while focus is inside the embedded bench.
window.addEventListener('message', (event) => {
  const frame = document.querySelector('#perf-lab-overlay .perf-lab-harmony-frame');
  if (event.origin === location.origin && event.source === frame?.contentWindow && event.data?.type === 'rhythmake:harmony-lab:toggle') toggle();
});

function show() {
  const ov = ensureUI();
  ov.style.display = 'flex';
}

function hide() {
  stopPerfMusicRepeatSpawn();
  const ov = ensureUI();
  pauseHarmonyLab(ov);
  ov.style.display = 'none';
}

function toggle() {
  const ov = ensureUI();
  if (ov.style.display === 'flex') hide();
  else show();
}

function buildP2() {
  try { clearSceneViaSnapshot(); } catch {}
  setStatus('Building P2?O');
  // Particles worst-case: lots of loopgrids (heavy particle fields).
  buildParticleWorstCase({ toyType: 'loopgrid', rows: 8, cols: 10, spacing: 400 });
  setStatus('P2 built');
}

async function buildP2d() {
  try { clearSceneViaSnapshot(); } catch {}
  setStatus('Building P2D...');
  await ensureMeasuredFootprint('loopgrid-drum');
  const spacing = estimateGridSpacing('loopgrid-drum', 400);
  logPerfFootprintDebug('loopgrid-drum', 400);
  buildParticleWorstCase({ toyType: 'loopgrid-drum', rows: 8, cols: 10, spacing });
  try {
    setTimeout(() => {
      document.querySelectorAll('.toy-panel[data-toy="loopgrid-drum"]')
        .forEach(p => {
          try { p.dispatchEvent(new CustomEvent('toy-random', { bubbles: true })); } catch {}
          try { p.dispatchEvent(new CustomEvent('toy-random-notes', { bubbles: true })); } catch {}
        });
    }, 0);
  } catch {}
  setStatus('P2D built');
}

async function buildP3() {
  try { clearSceneViaSnapshot(); } catch {}
  setStatus('Building P3?O');
  // DrawGrid worst-case: lots of drawgrids for canvas-heavy stress.
  await ensureMeasuredFootprint('drawgrid');
  const spacing = estimateGridSpacing('drawgrid', 420);
  logPerfFootprintDebug('drawgrid', 420);
  buildParticleWorstCase({ toyType: 'drawgrid', rows: 6, cols: 8, spacing });
  try {
    const raf = window.requestAnimationFrame?.bind(window) ?? ((fn) => setTimeout(fn, 16));
    raf(() => raf(() => window.resolveToyPanelOverlaps?.()));
  } catch {}
  // Seed drawgrid notes for worst-case visuals.
  try {
    setTimeout(() => {
      document.querySelectorAll('.toy-panel[data-toy=drawgrid]')
        .forEach(p => { try { p.dispatchEvent(new CustomEvent('toy-random', { bubbles: true })); } catch {} });
      document.querySelectorAll('.toy-panel[data-toy=drawgrid]')
        .forEach(p => { try { p.dispatchEvent(new CustomEvent('toy-random-notes', { bubbles: true })); } catch {} });
    }, 0);
  } catch {}
  try {
    setTimeout(() => logOverlapReport('.toy-panel[data-toy="drawgrid"]'), 800);
  } catch {}
  setStatus('P3 built');
}

async function buildP3Lite() {
  try { clearSceneViaSnapshot(); } catch {}
  setStatus('Building P3Lite...');
  // Fast diagnostic variant: fewer drawgrids so build/seed doesn't dominate the run.
  await ensureMeasuredFootprint('drawgrid');
  const spacing = estimateGridSpacing('drawgrid', 420);
  logPerfFootprintDebug('drawgrid', 420);
  buildParticleWorstCase({ toyType: 'drawgrid', rows: 3, cols: 4, spacing });
  try {
    const raf = window.requestAnimationFrame?.bind(window) ?? ((fn) => setTimeout(fn, 16));
    raf(() => raf(() => window.resolveToyPanelOverlaps?.()));
  } catch {}
  // Seed drawgrid notes for comparable visuals.
  try {
    const raf = window.requestAnimationFrame?.bind(window) ?? ((fn) =>
      setTimeout(() => fn((performance?.now?.() ?? Date.now())), 16));
    const panels = Array.from(document.querySelectorAll('.toy-panel[data-toy=drawgrid]'));
    const dispatchBatched = async (evtName, batch = 2) => {
      for (let i = 0; i < panels.length; i += batch) {
        for (const p of panels.slice(i, i + batch)) {
          try { p.dispatchEvent(new CustomEvent(evtName, { bubbles: true })); } catch {}
        }
        // Yield between batches so toy init/seed doesn't block the main thread for seconds.
        await new Promise((r) => raf(() => r()));
      }
    };
    await dispatchBatched('toy-random', 2);
    await dispatchBatched('toy-random-notes', 2);
  } catch {}
  try {
    setTimeout(() => logOverlapReport('.toy-panel[data-toy="drawgrid"]'), 800);
  } catch {}
  setStatus('P3Lite built');
}

async function buildP3Focus() {
  try { clearSceneViaSnapshot(); } catch {}
  setStatus('Building P3Focus...');
  // Tiny build for Current Focus auto-runs: ensures we actually get pan/zoom motion.
  await ensureMeasuredFootprint('drawgrid');
  const spacing = estimateGridSpacing('drawgrid', 520);
  logPerfFootprintDebug('drawgrid', 520);
  buildParticleWorstCase({ toyType: 'drawgrid', rows: 2, cols: 3, spacing });
  try {
    const raf = window.requestAnimationFrame?.bind(window) ?? ((fn) => setTimeout(fn, 16));
    raf(() => raf(() => window.resolveToyPanelOverlaps?.()));
  } catch {}
  // Seed drawgrid notes for comparable visuals (batched + yielding).
  try {
    const raf = window.requestAnimationFrame?.bind(window) ?? ((fn) =>
      setTimeout(() => fn((performance?.now?.() ?? Date.now())), 16));
    const panels = Array.from(document.querySelectorAll('.toy-panel[data-toy=drawgrid]'));
    const dispatchBatched = async (evtName, batch = 1) => {
      for (let i = 0; i < panels.length; i += batch) {
        for (const p of panels.slice(i, i + batch)) {
          try { p.dispatchEvent(new CustomEvent(evtName, { bubbles: true })); } catch {}
        }
        await new Promise((r) => raf(() => r()));
      }
    };
    await dispatchBatched('toy-random', 1);
    await dispatchBatched('toy-random-notes', 1);
  } catch {}
  setStatus('P3Focus built');
}

async function buildP3FocusHeavy() {
  try { clearSceneViaSnapshot(); } catch {}
  setStatus('Building P3FocusHeavy...');
  // Heavy validation build: enough drawgrids to reliably engage pressure-DPR on stronger machines,
  // but still small enough that build/seed doesn't starve the pan/zoom scripts.
  await ensureMeasuredFootprint('drawgrid');
  const spacing = estimateGridSpacing('drawgrid', 520);
  logPerfFootprintDebug('drawgrid', 520);
  // 12 toys (3x4)
  buildParticleWorstCase({ toyType: 'drawgrid', rows: 3, cols: 4, spacing });
  try {
    const raf = window.requestAnimationFrame?.bind(window) ?? ((fn) => setTimeout(fn, 16));
    raf(() => raf(() => window.resolveToyPanelOverlaps?.()));
  } catch {}
  // Seed drawgrid notes for comparable visuals (batched + yielding).
  try {
    const raf = window.requestAnimationFrame?.bind(window) ?? ((fn) =>
      setTimeout(() => fn((performance?.now?.() ?? Date.now())), 16));
    const panels = Array.from(document.querySelectorAll('.toy-panel[data-toy=drawgrid]'));
    const dispatchBatched = async (evtName, batch = 2) => {
      for (let i = 0; i < panels.length; i += batch) {
        for (const p of panels.slice(i, i + batch)) {
          try { p.dispatchEvent(new CustomEvent(evtName, { bubbles: true })); } catch {}
        }
        await new Promise((r) => raf(() => r()));
      }
    };
    await dispatchBatched('toy-random', 2);
    await dispatchBatched('toy-random-notes', 2);
  } catch {}
  setStatus('P3FocusHeavy built');
}

async function buildP4() {
  try { clearSceneViaSnapshot(); } catch {}
  setStatus('Building P4...');
  await ensureMeasuredFootprint('loopgrid');
  const spacing = estimateGridSpacing('loopgrid', 420);
  logPerfFootprintDebug('loopgrid', 420);
  const cam = getCommittedState();
  createToyGrid({ toyType: 'loopgrid', rows: 6, cols: 10, spacing, centerX: cam.x, centerY: cam.y });
  const finalize = (tries = 0) => {
    try {
      const panels = Array.from(document.querySelectorAll('.toy-panel[data-toy="loopgrid"]'));
      const ready = panels.length > 0 && panels.every(p => typeof p.__sequencerStep === 'function');
      if (!ready && tries < 20) {
        setTimeout(() => finalize(tries + 1), 120);
        return;
      }
      panels.forEach(clearPanelChainData);
      seedLoopgridPanels(panels, { density: 0.33, seed: 1337, randomizeNotes: true });
      window.updateChains?.();
      window.updateAllChainUIs?.();
      window.scheduleChainRedraw?.();
      window.resolveToyPanelOverlaps?.();
    } catch {}
  };
  setTimeout(() => finalize(0), 0);
  setStatus('P4 built');
}

function buildP4h() {
  try { clearSceneViaSnapshot(); } catch {}
  setStatus('Building P4H...');
  buildChainedLoopgridStress({
    toyType: 'loopgrid',
    chains: 6,
    chainLength: 10,
    gridCols: 3,
    seed: 1337,
    density: 0.85,   // heavier
    steps: 16,       // more steps
    noteMin: 0,
    noteMax: 35,
    headSpacingX: 560,
    headSpacingY: 420,
    linkSpacingX: 420,
  });
  setStatus('P4H built');
}

function buildP5() {
  try { clearSceneViaSnapshot(); } catch {}
  setStatus('Building P5...');
  buildMixedScene({ drawRows: 3, drawCols: 4, loopRows: 3, loopCols: 4, spacing: 420, gap: 320 });
  setStatus('P5 built');
}

async function buildP6() {
  try { clearSceneViaSnapshot(); } catch {}
  setStatus('Building P6...');
  await ensureMeasuredFootprint('drawgrid');
  const loopFootprint = estimateToyFootprint('loopgrid');
  const headSpacingX = Math.max(560, loopFootprint.width);
  const headSpacingY = Math.max(420, loopFootprint.height);
  const linkSpacingX = Math.max(420, loopFootprint.width);
  const chainLength = 4;
  const gridCols = 2;
  buildChainedLoopgridStress({
    toyType: 'loopgrid',
    chains: 4,
    chainLength,
    gridCols,
    seed: 1337,
    density: 0.35,
    noteMin: 0,
    noteMax: 35,
    headSpacingX,
    headSpacingY,
    linkSpacingX,
    jitterY: 0,
  });
  const drawSpacing = estimateGridSpacing('drawgrid', 460);
  const cam = getCommittedState();
  const chainTotalW = (gridCols - 1) * headSpacingX + (chainLength - 1) * linkSpacingX;
  const drawTotalW = (2 - 1) * drawSpacing;
  const gap = Math.max(320, PERF_SPAWN_PADDING * 2);
  const drawCenterX = cam.x + chainTotalW / 2 + gap + drawTotalW / 2;
  createToyGrid({ toyType: 'drawgrid', rows: 2, cols: 2, spacing: drawSpacing, centerX: drawCenterX, centerY: cam.y });
  try {
    const raf = window.requestAnimationFrame?.bind(window) ?? ((fn) => setTimeout(fn, 16));
    raf(() => raf(() => window.resolveToyPanelOverlaps?.()));
  } catch {}
  setStatus('P6 built');
}

async function buildP7() {
  try { clearSceneViaSnapshot(); } catch {}
  setStatus('Building P7...');
  await ensureMeasuredFootprint('drawgrid');
  await ensureMeasuredFootprint('loopgrid');
  const cam = getCommittedState();
  const chainLength = 4;
  const chainCount = 4;
  const drawFootprint = estimateToyFootprint('drawgrid');
  const loopFootprint = estimateToyFootprint('loopgrid');
  const headSpacingY = Math.max(420, drawFootprint.height, loopFootprint.height);
  const drawLinkSpacingX = Math.max(420, drawFootprint.width);
  const loopLinkSpacingX = Math.max(420, loopFootprint.width);
  const drawBlockW = (chainLength - 1) * drawLinkSpacingX + drawFootprint.width;
  const loopBlockW = (chainLength - 1) * loopLinkSpacingX + loopFootprint.width;
  const gap = Math.max(320, PERF_SPAWN_PADDING * 2);
  const totalW = drawBlockW + loopBlockW + gap;
  const leftX = cam.x - totalW / 2;
  const drawHeadX = leftX + drawFootprint.width / 2;
  const loopHeadX = leftX + drawBlockW + gap + loopFootprint.width / 2;
  const drawChains = createChainedToys({
    toyType: 'drawgrid',
    chains: chainCount,
    chainLength,
    headX: drawHeadX,
    headSpacingY,
    linkSpacingX: drawLinkSpacingX,
    centerY: cam.y,
  });
  const loopChains = createChainedToys({
    toyType: 'loopgrid',
    chains: chainCount,
    chainLength,
    headX: loopHeadX,
    headSpacingY,
    linkSpacingX: loopLinkSpacingX,
    centerY: cam.y,
  });
  const drawPanels = collectPanelsFromChains(drawChains);
  const loopPanels = collectPanelsFromChains(loopChains);
  const finalize = (tries = 0) => {
    const readyDraw = drawPanels.every(p => p?.id && typeof p.__sequencerStep === 'function');
    const readyLoop = loopPanels.every(p => p?.id && p.__gridState && typeof p.__sequencerStep === 'function');
    if ((!readyDraw || !readyLoop) && tries < 20) {
      setTimeout(() => finalize(tries + 1), 120);
      return;
    }
    try {
      try {
        window.__PERF_FORCE_SEQUENCER_ALL = false;
        window.__PERF_FORCE_SEQUENCER_ALL_LOCK = true;
      } catch {}
      linkToyChains(drawChains);
      linkToyChains(loopChains);
      try {
        window.resetChainState?.({ clearDom: false });
      } catch {}
      const initChainActive = (chains) => {
        if (!Array.isArray(chains)) return;
        for (const panels of chains) {
          if (!Array.isArray(panels) || panels.length === 0) continue;
          panels.forEach(p => { if (p?.dataset) p.dataset.chainActive = 'false'; });
          const head = panels[0];
          if (head?.dataset) {
            head.dataset.chainActive = 'true';
            try { head.dispatchEvent(new CustomEvent('chain:set-active', { bubbles: true })); } catch {}
          }
        }
      };
      initChainActive(drawChains);
      initChainActive(loopChains);
        drawPanels.forEach(p => {
          if (p?.dataset && (p.dataset.prevToyId || p.dataset.nextToyId)) {
            p.dataset.autoplay = 'chain';
          }
        });
        loopPanels.forEach(p => {
          if (p?.dataset && (p.dataset.prevToyId || p.dataset.nextToyId)) {
            p.dataset.autoplay = 'chain';
          }
        });
      window.updateChains?.();
      window.updateAllChainUIs?.();
      window.scheduleChainRedraw?.();
      window.resolveToyPanelOverlaps?.();
    } catch {}
    try {
      drawPanels.forEach(p => { try { p.dispatchEvent(new CustomEvent('toy-random', { bubbles: true })); } catch {} });
      drawPanels.forEach(p => { try { p.dispatchEvent(new CustomEvent('toy-random-notes', { bubbles: true })); } catch {} });
        seedLoopgridPanels(loopPanels, { density: 0.35, seed: 1337, randomizeNotes: false });
      syncChainInstruments(drawChains);
      syncChainInstruments(loopChains);
    } catch {}
    try {
      const rows = [];
      const panels = [...drawPanels, ...loopPanels];
      panels.forEach((panel) => {
        const toy = panel?.dataset?.toy || '';
        const headId = panel ? getChainHeadId(panel) : '';
        rows.push({
          id: panel?.id || '',
          toy,
          headId,
          chainActive: panel?.dataset?.chainActive || '',
          prev: panel?.dataset?.prevToyId || '',
          next: panel?.dataset?.nextToyId || '',
          instrument: panel?.dataset?.instrument || '',
        });
      });
      console.table(rows);
    } catch {}
    setTimeout(() => {
      try {
        const initChainActive = (chains) => {
          if (!Array.isArray(chains)) return;
          for (const panels of chains) {
            if (!Array.isArray(panels) || panels.length === 0) continue;
            panels.forEach(p => { if (p?.dataset) p.dataset.chainActive = 'false'; });
            const head = panels[0];
            if (head?.dataset) {
              head.dataset.chainActive = 'true';
              try { head.dispatchEvent(new CustomEvent('chain:set-active', { bubbles: true })); } catch {}
            }
          }
        };
        initChainActive(drawChains);
        initChainActive(loopChains);
        const activeDraw = drawPanels.filter(p => p?.dataset?.chainActive === 'true');
        const activeLoop = loopPanels.filter(p => p?.dataset?.chainActive === 'true');
        console.log('[PerfLab][P7] active counts', {
          draw: activeDraw.length,
          loop: activeLoop.length,
          forceSequencerAll: !!window.__PERF_FORCE_SEQUENCER_ALL,
          noteScheduler: !!window.__NOTE_SCHEDULER_ENABLED,
        });
        console.log('[PerfLab][P7] active draw IDs', activeDraw.map(p => p.id));
      } catch {}
    }, 900);
    setTimeout(() => {
      try {
        const rows = [];
        for (const panel of drawPanels) {
          const headId = panel ? getChainHeadId(panel) : '';
          rows.push({
            id: panel?.id || '',
            headId,
            chainActive: panel?.dataset?.chainActive || '',
            showPlaying: panel?.__dgShowPlaying ? 'true' : 'false',
            hasNotes: panel?.__dgHasNotes ? 'true' : 'false',
          });
        }
        console.table(rows);
      } catch {}
    }, 1800);
    setTimeout(() => {
      try {
        const byHead = new Map();
        drawPanels.forEach((panel) => {
          const headId = getChainHeadId(panel);
          if (!headId) return;
          const entry = byHead.get(headId) || { total: 0, active: [] };
          entry.total += 1;
          if (panel?.dataset?.chainActive === 'true') entry.active.push(panel.id);
          byHead.set(headId, entry);
        });
        for (const [headId, entry] of byHead.entries()) {
          if (entry.active.length !== 1) {
            console.warn('[PerfLab][P7] chainActive mismatch', { headId, total: entry.total, active: entry.active });
          }
        }
      } catch {}
    }, 2200);
    try {
      const observer = new MutationObserver((mutations) => {
        for (const m of mutations) {
          if (m.type !== 'attributes' || m.attributeName !== 'data-chain-active') continue;
          const panel = m.target;
          console.log('[PerfLab][P7] chainActive change', {
            id: panel?.id,
            toy: panel?.dataset?.toy,
            chainActive: panel?.dataset?.chainActive,
          });
        }
      });
      drawPanels.forEach((panel) => {
        if (panel && panel.nodeType === 1) observer.observe(panel, { attributes: true });
      });
      setTimeout(() => { try { observer.disconnect(); } catch {} }, 6000);
    } catch {}
    try { window.Persistence?.markDirty?.(); } catch {}
  };
  setTimeout(() => finalize(0), 0);
  setStatus('P7 built');
}

function getBeatSwarmApi() {
  const api = window.BeatSwarmMode;
  if (!api || typeof api.enter !== 'function' || typeof api.exit !== 'function') return null;
  return api;
}

function getBeatSwarmDebugApi() {
  const dbg = window.__beatSwarmDebug;
  if (!dbg || typeof dbg.preparePerfScenario !== 'function') return null;
  return dbg;
}

function stopPerfMusicRepeatSpawn() {
  const dbg = getBeatSwarmDebugApi();
  if (!dbg || typeof dbg.setPerfEnemyRepeatMode !== 'function') {
    return { ok: false, reason: 'beat_swarm_debug_api_unavailable' };
  }
  return dbg.setPerfEnemyRepeatMode('', false);
}

async function startPerfMusicRepeatSpawn(enemyType = 'drawsnake', options = null) {
  const built = await ensureBS0Built();
  if (!built) {
    return { ok: false, reason: 'beat_swarm_build_failed' };
  }
  const dbg = getBeatSwarmDebugApi();
  if (!dbg || typeof dbg.setPerfEnemyRepeatMode !== 'function') {
    return { ok: false, reason: 'beat_swarm_debug_api_unavailable' };
  }
  const type = String(enemyType || 'drawsnake').trim().toLowerCase() || 'drawsnake';
  const opts = options && typeof options === 'object' ? options : {};
  return dbg.setPerfEnemyRepeatMode(type, true, {
    persistent: opts.persistent !== false,
    behavior: String(opts.behavior || 'none').trim().toLowerCase() || 'none',
    groupCount: Math.max(1, Math.trunc(Number(opts.groupCount) || 8)),
    speedScale: Math.max(0.25, Math.min(4, Number(opts.speedScale) || 1)),
  });
}

function getMusicLabApiGlobal() {
  const api = window.__beatSwarmMusicLab;
  if (!api || typeof api !== 'object') return null;
  if (typeof api.exportSession !== 'function') return null;
  return api;
}

function getMusicTraceCaptureApiGlobal() {
  const api = getMusicLabApiGlobal();
  if (!api || typeof api !== 'object') return null;
  if (typeof api.startTraceCapture !== 'function' || typeof api.stopTraceCapture !== 'function') return null;
  return api;
}

function startMusicTraceCaptureForPerfRun(config = null) {
  const api = getMusicTraceCaptureApiGlobal();
  if (!api) return { ok: false, reason: 'trace_capture_api_unavailable' };
  const cfg = config && typeof config === 'object' ? config : {};
  const include = Array.isArray(cfg.include)
    ? cfg.include.map((value) => String(value || '').trim().toLowerCase()).filter(Boolean)
    : [];
  const exclude = Array.isArray(cfg.exclude)
    ? cfg.exclude.map((value) => String(value || '').trim().toLowerCase()).filter(Boolean)
    : [];
  try {
    window.__beatSwarmMusicTrace = {
      enabled: true,
      include,
      exclude,
      console: cfg.console === true,
    };
  } catch {}
  try {
    const result = api.startTraceCapture({
      include,
      exclude,
      maxLines: Math.max(50, Math.min(20000, Math.trunc(Number(cfg.maxLines) || 300))),
    });
    return {
      ok: true,
      started: result && typeof result === 'object' ? { ...result } : null,
    };
  } catch (err) {
    return {
      ok: false,
      reason: String(err && err.message || err || 'trace_capture_start_failed'),
    };
  }
}

async function finalizeMusicTraceCaptureForPerfRun(config = null) {
  const api = getMusicTraceCaptureApiGlobal();
  if (!api) return { ok: false, reason: 'trace_capture_api_unavailable' };
  const cfg = config && typeof config === 'object' ? config : {};
  const textBeforeStop = typeof api.getTraceCaptureText === 'function' ? String(api.getTraceCaptureText() || '') : '';
  let stopped = null;
  try {
    stopped = api.stopTraceCapture();
  } catch {}
  try {
    window.__beatSwarmMusicTrace = { enabled: false, include: [], exclude: [], console: false };
  } catch {}
  const fileName = String(cfg.fileName || '').trim();
  const textAfterStop = typeof api.getTraceCaptureText === 'function' ? String(api.getTraceCaptureText() || '') : '';
  const text = textAfterStop.trim() ? textAfterStop : textBeforeStop;
  if (!text.trim()) {
    return {
      ok: false,
      reason: 'trace_capture_empty',
      fileName,
      stopped,
    };
  }
  try {
    const cfgResolved = await resolveResultsConfig();
    const postUrl = resolveDebugOutputPostUrl(cfgResolved);
    const saved = await postDebugOutputFile({
      fileName,
      text,
      meta: cfg.meta && typeof cfg.meta === 'object' ? cfg.meta : null,
    }, postUrl);
    if (saved) {
      return {
        ok: true,
        mode: 'server',
        fileName,
        postUrl,
        stopped,
      };
    }
  } catch {}
  try {
    const downloaded = api.downloadTraceCapture(fileName);
    return {
      ok: !!downloaded,
      mode: 'download',
      fileName,
      stopped,
    };
  } catch (err) {
    return {
      ok: false,
      reason: String(err && err.message || err || 'trace_capture_finalize_failed'),
      stopped,
    };
  }
}

function getBeatSwarmPerfSnapshotGlobal() {
  const api = window.__beatSwarmDebug;
  if (!api || typeof api !== 'object') return null;
  if (typeof api.getPerfSnapshot !== 'function') return null;
  try {
    return api.getPerfSnapshot();
  } catch {
    return null;
  }
}

function getBeatSwarmStepEventsPerfSnapshotGlobal() {
  const api = window.__beatSwarmDebug;
  try {
    if (api && typeof api === 'object' && typeof api.getStepEventsPerfSnapshot === 'function') {
      const snapshot = api.getStepEventsPerfSnapshot();
      if (snapshot && typeof snapshot === 'object') return snapshot;
    }
  } catch {
    // fall through
  }
  try {
    const fallback = window.__LAST_BEAT_SWARM_STEP_EVENTS_PERF_SNAPSHOT;
    if (fallback && typeof fallback === 'object') return fallback;
  } catch {}
  try {
    const modeApi = window.BeatSwarmMode;
    if (modeApi && typeof modeApi === 'object' && typeof modeApi.getStepEventsPerfSnapshot === 'function') {
      const snapshot = modeApi.getStepEventsPerfSnapshot();
      if (snapshot && typeof snapshot === 'object') return snapshot;
    }
  } catch {}
  return null;
}

function compactMusicLabPayloadForSave(payload = null) {
  const src = payload && typeof payload === 'object' ? payload : null;
  if (!src) return { payload: src, compacted: false, detail: '' };
  const fullTimeline = Array.isArray(src.eventTimeline) ? src.eventTimeline : [];
  const compactTimelineSource = fullTimeline.filter((ev) => {
    const phase = String(ev?.phase || '').trim().toLowerCase();
    if (phase === 'executed') return true;
    if (phase !== 'created') return false;
    const lane = String(ev?.callResponseLane || '').trim().toLowerCase();
    return lane === 'call' || lane === 'response';
  });
  const compactTimelineTail = compactTimelineSource.slice(-256);
  const compactEventTimeline = compactTimelineTail.map((ev) => {
    const event = ev && typeof ev === 'object' ? ev : {};
    const payload = event?.payload && typeof event.payload === 'object' ? event.payload : {};
    return {
      tMs: Number(event.tMs) || 0,
      phase: String(event.phase || '').trim().toLowerCase(),
      eventId: Number(event.eventId) || 0,
      barIndex: Number(event.barIndex) || 0,
      beatIndex: Number(event.beatIndex) || 0,
      stepIndex: Number(event.stepIndex) || 0,
      actorId: Number(event.actorId) || 0,
      groupId: Number(event.groupId) || 0,
      role: String(event.role || ''),
      noteResolved: String(event.noteResolved || event.note || ''),
      instrumentId: String(event.instrumentId || ''),
      actionType: String(event.actionType || ''),
      threatClass: String(event.threatClass || ''),
      pacingState: String(event.pacingState || ''),
      sourceSystem: String(event.sourceSystem || ''),
      enemyType: String(event.enemyType || ''),
      actionCategory: String(event.actionCategory || payload.actionCategory || '').trim().toLowerCase(),
      audioRequired: event.audioRequired === true || payload.audioRequired === true,
      classificationReason: String(event.classificationReason || payload.classificationReason || '').trim().toLowerCase(),
      playerAudible: event.playerAudible === true,
      enemyAudible: event.enemyAudible === true ? true : (event.enemyAudible === false ? false : null),
      continuityId: String(event.continuityId || ''),
      enemyVisualId: String(event.enemyVisualId || ''),
      enemyRoleColor: String(event.enemyRoleColor || ''),
      playerCadenceMode: String(event.playerCadenceMode || ''),
      callResponseLane: String(event.callResponseLane || '').trim().toLowerCase(),
      callResponseQualified: event.callResponseQualified === true
        ? true
        : (event.callResponseQualified === false ? false : null),
      callResponsePhraseProgress: Number(event.callResponsePhraseProgress) || 0,
      musicLaneId: String(event.musicLaneId || payload.musicLaneId || payload.foundationLaneId || ''),
      musicLanePhraseId: String(event.musicLanePhraseId || payload.musicLanePhraseId || ''),
      musicLanePatternKey: String(event.musicLanePatternKey || payload.musicLanePatternKey || ''),
      musicLaneRawPatternKey: String(event.musicLaneRawPatternKey || payload.musicLaneRawPatternKey || ''),
      musicLaneShapedPatternKey: String(event.musicLaneShapedPatternKey || payload.musicLaneShapedPatternKey || ''),
      musicLaneInterpretationMode: String(event.musicLaneInterpretationMode || payload.musicLaneInterpretationMode || '').trim().toLowerCase(),
      musicLanePhrasePartIndex: Number(event.musicLanePhrasePartIndex ?? payload.musicLanePhrasePartIndex) || 0,
      musicLanePlayerThemeSource: String(event.musicLanePlayerThemeSource || payload.musicLanePlayerThemeSource || ''),
      foundationPlayerThemeSource: String(event.foundationPlayerThemeSource || payload.foundationPlayerThemeSource || ''),
      leadPlayerThemeSource: String(event.leadPlayerThemeSource || payload.leadPlayerThemeSource || ''),
      leadThemeInterpretationMode: String(event.leadThemeInterpretationMode || payload.leadThemeInterpretationMode || '').trim().toLowerCase(),
      leadThemePartIndex: Number(event.leadThemePartIndex ?? payload.leadThemePartIndex) || 0,
      leadThemeStepIndex: Number(event.leadThemeStepIndex ?? payload.leadThemeStepIndex) || 0,
      leadThemePatternKey: String(event.leadThemePatternKey || payload.leadThemePatternKey || ''),
      leadThemeContourKey: String(event.leadThemeContourKey || payload.leadThemeContourKey || ''),
      leadThemeRawStepActive: event.leadThemeRawStepActive === true || payload.leadThemeRawStepActive === true,
      leadThemeRawNote: String(event.leadThemeRawNote || payload.leadThemeRawNote || ''),
      musicLayer: String(event.musicLayer || ''),
      musicProminence: String(event.musicProminence || ''),
      intensityAuditionSection: String(event.intensityAuditionSection || payload.intensityAuditionSection || '').trim().toLowerCase(),
      intensityCadenceStepAdmitted: event.intensityCadenceStepAdmitted === true || payload.intensityCadenceStepAdmitted === true,
      intensityCadenceReason: String(event.intensityCadenceReason || payload.intensityCadenceReason || '').trim().toLowerCase(),
      audioGain: Number(event.audioGain) || 0,
      musicVoiceKey: String(event.musicVoiceKey || payload.musicVoiceKey || ''),
      resolvedPlaybackInstrumentId: String(event.resolvedPlaybackInstrumentId || ''),
      playbackKind: String(event.playbackKind || ''),
      sampleVolumeHint: String(event.sampleVolumeHint || ''),
      sampleVolumeMultiplier: Number(event.sampleVolumeMultiplier) || 0,
      triggerVolume: Number(event.triggerVolume) || 0,
      approxPlaybackVolume: Number(event.approxPlaybackVolume) || 0,
    };
  });
  const focusBarWindow = compactTimelineTail.length > 0
    ? {
        min: Math.max(
          0,
          Math.min(...compactTimelineTail.map((ev) => Number(ev?.barIndex) || 0)) - 2
        ),
        max: Math.max(...compactTimelineTail.map((ev) => Number(ev?.barIndex) || 0)) + 2,
      }
    : { min: 0, max: Number.POSITIVE_INFINITY };
  const compactSessionBeatEvent = (ev) => {
    const event = ev && typeof ev === 'object' ? ev : {};
    const payload = event?.payload && typeof event.payload === 'object' ? event.payload : {};
    return {
      tMs: Number(event.tMs) || 0,
      eventId: Number(event.eventId) || 0,
      barIndex: Number(event.barIndex) || 0,
      beatIndex: Number(event.beatIndex) || 0,
      stepIndex: Number(event.stepIndex) || 0,
      actorId: Number(event.actorId) || 0,
      groupId: Number(event.groupId) || 0,
      role: String(event.role || ''),
      noteResolved: String(event.noteResolved || event.note || ''),
      instrumentId: String(event.instrumentId || ''),
      actionType: String(event.actionType || ''),
      threatClass: String(event.threatClass || ''),
      sourceSystem: String(event.sourceSystem || ''),
      enemyType: String(event.enemyType || ''),
      actionCategory: String(event.actionCategory || payload.actionCategory || '').trim().toLowerCase(),
      audioRequired: event.audioRequired === true || payload.audioRequired === true,
      classificationReason: String(event.classificationReason || payload.classificationReason || '').trim().toLowerCase(),
      enemyAudible: event.enemyAudible === true ? true : (event.enemyAudible === false ? false : null),
      triggerVolume: Number(event.triggerVolume) || 0,
      approxPlaybackVolume: Number(event.approxPlaybackVolume) || 0,
      resolvedPlaybackInstrumentId: String(event.resolvedPlaybackInstrumentId || ''),
      intensityAuditionSection: String(event.intensityAuditionSection || payload.intensityAuditionSection || '').trim().toLowerCase(),
      intensityCadenceStepAdmitted: event.intensityCadenceStepAdmitted === true || payload.intensityCadenceStepAdmitted === true,
      intensityCadenceReason: String(event.intensityCadenceReason || payload.intensityCadenceReason || '').trim().toLowerCase(),
      payload: {
        continuityId: String(payload.continuityId || ''),
        groupEventSource: String(payload.groupEventSource || ''),
        ghostPlayback: payload.ghostPlayback === true,
        musicLayer: String(payload.musicLayer || ''),
        musicLaneId: String(payload.musicLaneId || ''),
        musicLanePhraseId: String(payload.musicLanePhraseId || ''),
        musicLanePatternKey: String(payload.musicLanePatternKey || ''),
        musicLaneRawPatternKey: String(payload.musicLaneRawPatternKey || ''),
        musicLaneShapedPatternKey: String(payload.musicLaneShapedPatternKey || ''),
        musicLaneInterpretationMode: String(payload.musicLaneInterpretationMode || '').trim().toLowerCase(),
        musicLanePhrasePartIndex: Number(payload.musicLanePhrasePartIndex) || 0,
        musicLanePlayerThemeSource: String(payload.musicLanePlayerThemeSource || ''),
        foundationPlayerThemeSource: String(payload.foundationPlayerThemeSource || ''),
        leadPlayerThemeSource: String(payload.leadPlayerThemeSource || ''),
        leadThemeInterpretationMode: String(payload.leadThemeInterpretationMode || '').trim().toLowerCase(),
        leadThemePartIndex: Number(payload.leadThemePartIndex) || 0,
        leadThemeStepIndex: Number(payload.leadThemeStepIndex) || 0,
        leadThemePatternKey: String(payload.leadThemePatternKey || ''),
        leadThemeContourKey: String(payload.leadThemeContourKey || ''),
        leadThemeRawStepActive: payload.leadThemeRawStepActive === true,
        leadThemeRawNote: String(payload.leadThemeRawNote || ''),
        musicProminence: String(payload.musicProminence || ''),
        musicVoiceKey: String(payload.musicVoiceKey || ''),
        audioGain: Number(payload.audioGain) || 0,
        callResponseLane: String(payload.callResponseLane || ''),
        actionCategory: String(payload.actionCategory || event.actionCategory || '').trim().toLowerCase(),
        audioRequired: payload.audioRequired === true || event.audioRequired === true,
        classificationReason: String(payload.classificationReason || event.classificationReason || '').trim().toLowerCase(),
        intensityAuditionSection: String(payload.intensityAuditionSection || event.intensityAuditionSection || '').trim().toLowerCase(),
        intensityCadenceStepAdmitted: payload.intensityCadenceStepAdmitted === true || event.intensityCadenceStepAdmitted === true,
        intensityCadenceReason: String(payload.intensityCadenceReason || event.intensityCadenceReason || '').trim().toLowerCase(),
      },
    };
  };
  const shouldKeepFocusedSessionEvent = (ev) => {
    const event = ev && typeof ev === 'object' ? ev : {};
    const payload = event?.payload && typeof event.payload === 'object' ? event.payload : {};
    const barIndex = Number(event.barIndex) || 0;
    const groupEventSource = String(payload.groupEventSource || '').trim().toLowerCase();
    const laneId = String(payload.musicLaneId || '').trim().toLowerCase();
    const continuityId = String(payload.continuityId || '').trim().toLowerCase();
    const keepByBarWindow = barIndex >= focusBarWindow.min && barIndex <= focusBarWindow.max;
    if (keepByBarWindow) return true;
    if (
      groupEventSource === 'secondary_loop_bridge_fallback'
      || groupEventSource === 'composer_group_response_fallback'
      || groupEventSource === 'answer_ornament_fallback'
      || groupEventSource === 'intro_slot_strict'
    ) return true;
    if (continuityId === 'secondary-loop-bridge-fallback') return true;
    if (
      laneId === 'primary_loop_lane'
      || laneId === 'secondary_loop_lane'
      || laneId === 'foundation_lane'
      || laneId === 'sparkle_lane'
    ) return true;
    return false;
  };
  const srcCreatedEvents = Array.isArray(src?.session?.createdEvents) ? src.session.createdEvents : [];
  const srcExecutedEvents = Array.isArray(src?.session?.executedEvents) ? src.session.executedEvents : [];
  const compactCreatedEvents = srcCreatedEvents
    .filter(shouldKeepFocusedSessionEvent)
    .slice(-192)
    .map(compactSessionBeatEvent);
  const compactExecutedEvents = srcExecutedEvents
    .filter(shouldKeepFocusedSessionEvent)
    .slice(-192)
    .map(compactSessionBeatEvent);
  const enemyRemovals = Array.isArray(src.enemyRemovals) ? src.enemyRemovals : [];
  const compactEnemyRemovals = enemyRemovals.map((ev) => {
    const item = ev && typeof ev === 'object' ? ev : {};
    return {
      tMs: Number(item.tMs) || 0,
      barIndex: Number(item.barIndex) || 0,
      beatIndex: Number(item.beatIndex) || 0,
      stepIndex: Number(item.stepIndex) || 0,
      actorId: Number(item.actorId) || 0,
      groupId: Number(item.groupId) || 0,
      enemyType: String(item.enemyType || ''),
      reason: String(item.reason || ''),
      retireOrigin: String(item.retireOrigin || ''),
      pacingState: String(item.pacingState || ''),
    };
  });
  const systemEvents = Array.isArray(src.systemEvents) ? src.systemEvents : [];
  const focusedSystemEvents = [];
  const lastFocusedComposerStateByGroup = new Map();
  for (const ev of systemEvents) {
    const item = ev && typeof ev === 'object' ? ev : {};
    const eventType = String(item.eventType || '').trim().toLowerCase();
    if (!eventType) continue;
    if (eventType === 'music_structure_intent_state') {
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        sectionId: String(item.sectionId || '').trim().toLowerCase(),
        intent: String(item.intent || '').trim().toLowerCase(),
        sourceEnergyState: String(item.sourceEnergyState || '').trim().toLowerCase(),
        stateAgeBars: Number(item.stateAgeBars) || 0,
      });
      continue;
    }
    if (eventType.endsWith('_deduplicated')) {
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        groupId: Number(item.groupId) || 0,
        targetGroupId: Number(item.targetGroupId) || 0,
        reason: String(item.reason || '').trim().toLowerCase(),
        continuityId: String(item.continuityId || '').trim(),
      });
      continue;
    }
    if (eventType === 'music_singleton_lead_group_created') {
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        enemyId: Number(item.enemyId) || 0,
        groupId: Number(item.groupId) || 0,
        actionType: String(item.actionType || '').trim().toLowerCase(),
        sectionId: String(item.sectionId || '').trim().toLowerCase(),
        currentSectionId: String(item.currentSectionId || '').trim().toLowerCase(),
        currentSectionCycle: Number(item.currentSectionCycle) || 0,
        lastSectionChangeBar: Number(item.lastSectionChangeBar) || 0,
        motifScopeKey: String(item.motifScopeKey || '').trim(),
        continuityId: String(item.continuityId || '').trim(),
        phraseId: String(item.phraseId || '').trim().toLowerCase(),
        directorSpawnId: String(item.directorSpawnId || '').trim().toLowerCase(),
        preferredLaneId: String(item.preferredLaneId || '').trim().toLowerCase(),
        lanePerformerEnemyId: Number(item.lanePerformerEnemyId) || 0,
        lanePerformerGroupId: Number(item.lanePerformerGroupId) || 0,
        laneContinuityId: String(item.laneContinuityId || '').trim(),
      });
      continue;
    }
    if (eventType === 'music_primary_loop_group_suppressed' || eventType === 'music_primary_loop_lane_emitted' || eventType === 'music_primary_loop_owner_trace') {
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        groupId: Number(item.groupId) || 0,
        enemyId: Number(item.enemyId) || 0,
        continuityId: String(item.continuityId || '').trim(),
        reason: String(item.reason || '').trim().toLowerCase(),
        laneMode: String(item.laneMode || '').trim().toLowerCase(),
        soloCarrierType: String(item.soloCarrierType || '').trim().toLowerCase(),
        note: String(item.note || '').trim(),
        instrumentId: String(item.instrumentId || '').trim(),
        actionType: String(item.actionType || '').trim().toLowerCase(),
        performerType: String(item.performerType || '').trim().toLowerCase(),
        eligibleCount: Number(item.eligibleCount) || 0,
        eligibleIds: Array.isArray(item.eligibleIds) ? item.eligibleIds.map((x) => Number(x) || 0).filter((x) => x > 0) : [],
        selectedOwnerId: Number(item.selectedOwnerId) || 0,
        previousPerformerEnemyId: Number(item.previousPerformerEnemyId) || 0,
        performerEnemyId: Number(item.performerEnemyId) || 0,
        performerGroupId: Number(item.performerGroupId) || 0,
        cursor: Number(item.cursor) || 0,
        templateId: String(item.templateId || '').trim().toLowerCase(),
        performerCount: Number(item.performerCount) || 0,
      });
      continue;
    }
    if (eventType === 'music_answer_ornament_fallback') {
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        actorId: Number(item.actorId) || 0,
        groupId: Number(item.groupId) || 0,
        activeMusicMode: String(item.activeMusicMode || '').trim().toLowerCase(),
        step: Number(item.step) || 0,
        wanted: item.wanted === true,
        leadGroups: Number(item.leadGroups) || 0,
        emittedThisStep: item.emittedThisStep === true,
        stepMod8: Number(item.stepMod8) || 0,
        evenBar: item.evenBar === true,
        primaryLoopLaneActive: item.primaryLoopLaneActive === true,
        secondaryLoopLaneActive: item.secondaryLoopLaneActive === true,
        primaryLoopPerformerEnemyId: Number(item.primaryLoopPerformerEnemyId) || 0,
        primaryLoopPerformerGroupId: Number(item.primaryLoopPerformerGroupId) || 0,
        secondaryLoopPerformerEnemyId: Number(item.secondaryLoopPerformerEnemyId) || 0,
        secondaryLoopPerformerGroupId: Number(item.secondaryLoopPerformerGroupId) || 0,
        requestedProminence: String(item.requestedProminence || '').trim().toLowerCase(),
        finalProminence: String(item.finalProminence || '').trim().toLowerCase(),
        decisionReason: String(item.decisionReason || '').trim().toLowerCase(),
        note: String(item.note || '').trim(),
        instrumentId: String(item.instrumentId || '').trim(),
        musicLaneId: String(item.musicLaneId || '').trim().toLowerCase(),
        groupEventSource: String(item.groupEventSource || '').trim().toLowerCase(),
      });
      continue;
    }
    if (eventType === 'music_enemy_director_state') {
      const payload = item?.payload && typeof item.payload === 'object' ? item.payload : item;
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        activeLevelPhase: String(payload.activeLevelPhase || '').trim().toLowerCase(),
        phaseVariant: String(payload.phaseVariant || '').trim().toLowerCase(),
        activeDirectorPhase: String(payload.activeDirectorPhase || '').trim().toLowerCase(),
        targetPressure: Number(payload.targetPressure) || 0,
        targetAliveMin: Number(payload.targetAliveMin) || 0,
        targetAliveMax: Number(payload.targetAliveMax) || 0,
        difficultyRamp: Number(payload.difficultyRamp) || 0,
        arrangementRamp: Number(payload.arrangementRamp) || 0,
        behaviorIntensityTier: String(payload.behaviorIntensityTier || '').trim().toLowerCase(),
        singleBehaviorDensity: Number(payload.singleBehaviorDensity) || 0,
        groupBehaviorDensity: Number(payload.groupBehaviorDensity) || 0,
        eventBehaviorEligibility: String(payload.eventBehaviorEligibility || '').trim().toLowerCase(),
        behaviorNoveltyBias: Number(payload.behaviorNoveltyBias) || 0,
        desiredLaneRoles: Array.isArray(payload.desiredLaneRoles) ? payload.desiredLaneRoles.map((x) => String(x || '').trim().toLowerCase()).filter(Boolean) : [],
        preferredEnemyFamilies: Array.isArray(payload.preferredEnemyFamilies) ? payload.preferredEnemyFamilies.map((x) => String(x || '').trim().toLowerCase()).filter(Boolean) : [],
        suppressedEnemyFamilies: Array.isArray(payload.suppressedEnemyFamilies) ? payload.suppressedEnemyFamilies.map((x) => String(x || '').trim().toLowerCase()).filter(Boolean) : [],
        behaviorAssignmentByRole: payload.behaviorAssignmentByRole && typeof payload.behaviorAssignmentByRole === 'object'
          ? { ...payload.behaviorAssignmentByRole }
          : {},
        activeEventBehaviorId: String(payload.activeEventBehaviorId || '').trim().toLowerCase(),
        varietyPressureByFamily: payload.varietyPressureByFamily && typeof payload.varietyPressureByFamily === 'object'
          ? { ...payload.varietyPressureByFamily }
          : {},
        targetCarrierCounts: payload.targetCarrierCounts && typeof payload.targetCarrierCounts === 'object'
          ? { ...payload.targetCarrierCounts }
          : {},
        threatLessonPhaseIndex: Math.max(0, Math.trunc(Number(payload.threatLessonPhaseIndex) || 0)),
        threatLessonPhaseId: String(payload.threatLessonPhaseId || '').trim().toLowerCase(),
        threatLessonDesiredPhaseIndex: Math.max(0, Math.trunc(Number(payload.threatLessonDesiredPhaseIndex) || 0)),
        threatAbilityPalette: Array.isArray(payload.threatAbilityPalette)
          ? payload.threatAbilityPalette.map((value) => String(value || '').trim().toLowerCase()).filter(Boolean)
          : [],
        maxFeaturedThreats: Math.max(0, Math.trunc(Number(payload.maxFeaturedThreats) || 0)),
        totalAlive: Number(payload.totalAlive) || 0,
      });
      continue;
    }
    if (eventType === 'music_level_phase_state') {
      const payload = item?.payload && typeof item.payload === 'object' ? item.payload : item;
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        activeLevelPhase: String(payload.activeLevelPhase || '').trim().toLowerCase(),
        phaseVariant: String(payload.phaseVariant || '').trim().toLowerCase(),
        phaseValidity: String(payload.phaseValidity || '').trim().toLowerCase(),
        phaseEnteredBar: Number(payload.phaseEnteredBar) || -1,
        earliestTransitionBar: Number(payload.earliestTransitionBar) || 0,
        preferredTransitionWindowStartBar: Number(payload.preferredTransitionWindowStartBar) || 0,
        preferredTransitionWindowEndBar: Number(payload.preferredTransitionWindowEndBar) || 0,
        timeInPhaseBars: Number(payload.timeInPhaseBars) || 0,
        transitionWindowOpen: payload.transitionWindowOpen === true,
        readyToAdvance: payload.readyToAdvance === true,
        holdReason: String(payload.holdReason || '').trim().toLowerCase(),
        readinessFailures: Array.isArray(payload.readinessFailures) ? payload.readinessFailures.map((x) => String(x || '').trim().toLowerCase()).filter(Boolean) : [],
        timeoutBar: Number(payload.timeoutBar) || 0,
        degradedPhaseVariant: String(payload.degradedPhaseVariant || '').trim().toLowerCase(),
        fallbackPhase: String(payload.fallbackPhase || '').trim().toLowerCase(),
        unmetHardRequirements: Array.isArray(payload.unmetHardRequirements) ? payload.unmetHardRequirements.map((x) => String(x || '').trim().toLowerCase()).filter(Boolean) : [],
        unmetSoftRequirements: Array.isArray(payload.unmetSoftRequirements) ? payload.unmetSoftRequirements.map((x) => String(x || '').trim().toLowerCase()).filter(Boolean) : [],
        activeAbortConditions: Array.isArray(payload.activeAbortConditions) ? payload.activeAbortConditions.map((x) => String(x || '').trim().toLowerCase()).filter(Boolean) : [],
        degradeApplied: payload.degradeApplied === true,
        fallbackPending: payload.fallbackPending === true,
        leadMergeStableBars: Number(payload.leadMergeStableBars) || 0,
      });
      continue;
    }
    if (eventType === 'music_secondary_bridge_coverage_trace') {
      const payload = item?.payload && typeof item.payload === 'object' ? item.payload : item;
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        activeMusicMode: String(payload.activeMusicMode || '').trim().toLowerCase(),
        phaseVariant: String(payload.phaseVariant || '').trim().toLowerCase(),
        activeSecondaryLoopCoveragePresent: payload.activeSecondaryLoopCoveragePresent === true,
        reservedSecondaryLoopSpawnNeeded: payload.reservedSecondaryLoopSpawnNeeded === true,
        pendingSecondaryLoopReservation: payload.pendingSecondaryLoopReservation === true,
        bridgeGroupCount: Number(payload.bridgeGroupCount) || 0,
        bridgeGroups: Array.isArray(payload.bridgeGroups) ? payload.bridgeGroups.slice(0, 6) : [],
      });
      continue;
    }
    if (eventType === 'music_event_section_state') {
      const payload = item?.payload && typeof item.payload === 'object' ? item.payload : item;
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        activeEventSection: String(payload.activeEventSection || '').trim().toLowerCase(),
        eventBehaviorClass: String(payload.eventBehaviorClass || '').trim().toLowerCase(),
        actionCategory: String(payload.actionCategory || '').trim().toLowerCase(),
        audioRequired: payload.audioRequired === true,
        classificationReason: String(payload.classificationReason || '').trim().toLowerCase(),
        intensityAuditionSection: String(payload.intensityAuditionSection || '').trim().toLowerCase(),
        enteredBar: Number(payload.enteredBar) || -1,
        endBar: Number(payload.endBar) || -1,
        strongBeatActive: payload.strongBeatActive === true,
        motionDamping: Number(payload.motionDamping) || 0,
        agitationBoost: Number(payload.agitationBoost) || 0,
        presentationPulseScale: Number(payload.presentationPulseScale) || 0,
        eligibleRoles: Array.isArray(payload.eligibleRoles) ? payload.eligibleRoles.map((x) => String(x || '').trim().toLowerCase()).filter(Boolean) : [],
      });
      continue;
    }
    if (eventType === 'music_intensity_cadence_step_admitted') {
      const payload = item?.payload && typeof item.payload === 'object' ? item.payload : item;
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        groupId: Number(payload.groupId) || 0,
        stepInBar: Number(payload.stepInBar) || 0,
        musicLaneId: String(payload.musicLaneId || '').trim().toLowerCase(),
        musicProfileSourceType: String(payload.musicProfileSourceType || '').trim().toLowerCase(),
        intensityAuditionSection: String(payload.intensityAuditionSection || '').trim().toLowerCase(),
        reason: String(payload.reason || '').trim().toLowerCase(),
      });
      continue;
    }
    if (
      eventType === 'music_player_accent_motif_track'
      || eventType === 'music_player_bass_motif_track'
      || eventType === 'music_click_percussion_trigger'
    ) {
      const payload = item?.payload && typeof item.payload === 'object' ? item.payload : item;
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        status: String(payload.status ?? item.status ?? '').trim().toLowerCase(),
        themeId: String(payload.themeId ?? item.themeId ?? '').trim(),
        stage: String(payload.stage ?? payload.intensityAuditionSection ?? item.stage ?? item.intensityAuditionSection ?? '').trim().toLowerCase(),
        sectionBar: Number(payload.sectionBar ?? item.sectionBar) || 0,
        localStep: Number(payload.localStep ?? item.localStep) || 0,
        phrasePartIndex: Number(payload.phrasePartIndex ?? item.phrasePartIndex) || 0,
        patternKey: String(payload.patternKey ?? item.patternKey ?? '').trim(),
        rawPatternKey: String(payload.rawPatternKey ?? item.rawPatternKey ?? '').trim(),
        shapedPatternKey: String(payload.shapedPatternKey ?? item.shapedPatternKey ?? '').trim(),
        interpretationMode: String(payload.interpretationMode ?? item.interpretationMode ?? '').trim().toLowerCase(),
        expectedHit: payload.expectedHit === true || item.expectedHit === true,
        emittedHit: payload.emittedHit === true || item.emittedHit === true,
        riffHit: payload.riffHit === true || item.riffHit === true,
        instrumentId: String(payload.instrumentId ?? item.instrumentId ?? '').trim(),
        requestedNote: String(payload.requestedNote ?? item.requestedNote ?? '').trim(),
        resolvedNote: String(payload.resolvedNote ?? item.resolvedNote ?? '').trim(),
        noteName: String(payload.noteName ?? item.noteName ?? '').trim(),
        source: String(payload.source ?? item.source ?? '').trim().toLowerCase(),
        destOrId: String(payload.destOrId ?? item.destOrId ?? '').trim(),
        preserveRequestedNote: payload.preserveRequestedNote === true || item.preserveRequestedNote === true,
        velocity: Number(payload.velocity ?? item.velocity) || 0,
        reason: String(payload.reason ?? item.reason ?? '').trim().toLowerCase(),
      });
      continue;
    }
    if (
      eventType === 'music_player_layer_state'
      || eventType === 'music_foreground_motif_usage'
      || eventType === 'music_motif_return_state'
      || eventType === 'music_lead_motif_anchor'
    ) {
      const payload = item?.payload && typeof item.payload === 'object' ? item.payload : item;
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        phase: String(payload.phase || item.phase || '').trim().toLowerCase(),
        themeId: String(payload.themeId || item.themeId || '').trim(),
        motifId: String(payload.motifId || item.motifId || '').trim(),
        motifScopeKey: String(payload.motifScopeKey || item.motifScopeKey || '').trim(),
        motifStepIndex: Number(payload.motifStepIndex ?? item.motifStepIndex) || 0,
        motifAgeBars: Number(payload.motifAgeBars ?? item.motifAgeBars) || 0,
        note: String(payload.note || item.note || '').trim(),
        baseNote: String(payload.baseNote || item.baseNote || '').trim(),
        intent: String(payload.intent || item.intent || '').trim().toLowerCase(),
        sectionId: String(payload.sectionId || item.sectionId || '').trim().toLowerCase(),
        intensityAuditionSection: String(payload.intensityAuditionSection || item.intensityAuditionSection || '').trim().toLowerCase(),
        phraseIntent: String(payload.phraseIntent || item.phraseIntent || '').trim().toLowerCase(),
        motifEpoch: Number(payload.motifEpoch ?? item.motifEpoch) || 0,
        requestedLockIndex: Number(payload.requestedLockIndex ?? item.requestedLockIndex) || 0,
        effectiveLockIndex: Number(payload.effectiveLockIndex ?? item.effectiveLockIndex) || 0,
        lookbackLocks: Number(payload.lookbackLocks ?? item.lookbackLocks) || 0,
        returnActive: payload.returnActive === true || item.returnActive === true,
        preDropActive: payload.preDropActive === true || item.preDropActive === true,
        liveSnakeCount: Number(payload.liveSnakeCount ?? item.liveSnakeCount) || 0,
        matchingScopeSnakeCount: Number(payload.matchingScopeSnakeCount ?? item.matchingScopeSnakeCount) || 0,
        primaryLoopUsesScope: payload.primaryLoopUsesScope === true || item.primaryLoopUsesScope === true,
        reuseCount: Number(payload.reuseCount ?? item.reuseCount) || 0,
        returnCount: Number(payload.returnCount ?? item.returnCount) || 0,
        variationCount: Number(payload.variationCount ?? item.variationCount) || 0,
      });
      continue;
    }
    if (eventType === 'music_visual_role_readability_state') {
      const payload = item?.payload && typeof item.payload === 'object' ? item.payload : item;
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        readableRoles: Array.isArray(payload.readableRoles) ? payload.readableRoles.map((x) => String(x || '').trim().toLowerCase()).filter(Boolean) : [],
        distinctReadableRoleCount: Number(payload.distinctReadableRoleCount) || 0,
        foundationVisualWeight: Number(payload.foundationVisualWeight) || 0,
        supportVisualWeight: Number(payload.supportVisualWeight) || 0,
        leadVisualWeight: Number(payload.leadVisualWeight) || 0,
        ornamentVisualWeight: Number(payload.ornamentVisualWeight) || 0,
        supportCollapsedDuringLead: payload.supportCollapsedDuringLead === true,
        leadWithSupportVisible: payload.leadWithSupportVisible === true,
        threeRoleReadable: payload.threeRoleReadable === true,
      });
      continue;
    }
    if (eventType === 'music_paired_dance_trace') {
      const payload = item?.payload && typeof item.payload === 'object' ? item.payload : item;
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        actorId: Number(payload.actorId) || 0,
        groupId: Number(payload.groupId) || 0,
        partnerId: Number(payload.targetEnemyId) || 0,
        phase: String(payload.phase || '').trim().toLowerCase(),
        reason: String(payload.reason || '').trim().toLowerCase(),
        cycleBeat: Number(payload.cycleBeat) || 0,
        cycleIndex: Number(payload.cycleIndex) || 0,
        allPairsReady: payload.allPairsReady === true,
        pairCenterX: Number(payload.pairCenterX) || 0,
        pairCenterY: Number(payload.pairCenterY) || 0,
        targetX: Number(payload.targetX) || 0,
        targetY: Number(payload.targetY) || 0,
        desiredVx: Number(payload.desiredVx) || 0,
        desiredVy: Number(payload.desiredVy) || 0,
        postBlendVx: Number(payload.postBlendVx) || 0,
        postBlendVy: Number(payload.postBlendVy) || 0,
        orbitAngle: Number(payload.orbitAngle) || 0,
        debugFrame: Number(payload.debugFrame) || 0,
      });
      continue;
    }
    if (eventType === 'music_group_performer_trace') {
      const payload = item?.payload && typeof item.payload === 'object' ? item.payload : item;
      focusedSystemEvents.push({
        tMs: Number(item.tMs) || 0,
        eventType,
        barIndex: Number(item.barIndex) || 0,
        beatIndex: Number(item.beatIndex) || 0,
        stepIndex: Number(item.stepIndex) || 0,
        actorId: Number(payload.actorId) || 0,
        groupId: Number(payload.groupId) || 0,
        role: String(payload.role || '').trim().toLowerCase(),
        musicLaneId: String(payload.musicLaneId || '').trim().toLowerCase(),
        reason: String(payload.reason || '').trim().toLowerCase(),
        performerCount: Number(payload.performerCount) || 0,
        selectedPrimaryEnemyId: Number(payload.selectedPrimaryEnemyId) || 0,
        aliveEnemyIdsCsv: String(payload.aliveEnemyIdsCsv || '').trim(),
        visibleEnemyIdsCsv: String(payload.visibleEnemyIdsCsv || '').trim(),
        performerEnemyIdsCsv: String(payload.performerEnemyIdsCsv || '').trim(),
      });
      continue;
    }
    if (eventType !== 'music_composer_group_state') continue;
    const reason = String(item.reason || '').trim().toLowerCase();
    const templateId = String(item.templateId || '').trim();
    const formationArchetype = String(item.formationArchetype || '').trim().toLowerCase();
    const keepComposerState = (
      reason === 'lead_melody'
      || reason === 'answer_ornament'
      || reason === 'secondary_bridge_backbeat'
      || reason === 'spawner_rhythm_pulse'
      || reason === 'spawner_rhythm_backbeat'
      || templateId === 'foundation-buffer'
      || formationArchetype === 'foundation_anchor_line'
      || formationArchetype === 'backbeat_pair'
      || formationArchetype === 'syncopation_stair'
      || formationArchetype === 'lead_arc'
      || formationArchetype === 'answer_echo'
      || String(item.behavioralFormationArchetype || '').trim().toLowerCase() === 'winding_chain'
      || String(item.behavioralFormationArchetype || '').trim().toLowerCase() === 'paired_dance'
      || String(item.behavioralFormationArchetype || '').trim().toLowerCase() === 'advancing_line'
    );
    if (!keepComposerState) continue;
    const groupId = Number(item.groupId) || 0;
    const phase = String(item.phase || '').trim().toLowerCase();
    const stepIndex = Number(item.stepIndex) || 0;
    const signature = [
      phase,
      templateId,
      reason,
      String(item.musicLaneId || '').trim().toLowerCase(),
      String(item.callResponseLane || '').trim().toLowerCase(),
      String(item.sectionId || '').trim().toLowerCase(),
      item.active === true ? '1' : '0',
      item.retiring === true ? '1' : '0',
      String(item.lifecycleState || '').trim().toLowerCase(),
      String(item.instrumentId || '').trim(),
      String(item.note || '').trim(),
      String(item.stage || '').trim().toLowerCase(),
    ].join('|');
    const previous = lastFocusedComposerStateByGroup.get(groupId);
    const shouldKeep = (
      phase !== 'steady'
      || !previous
      || previous.signature !== signature
      || (stepIndex - previous.stepIndex) >= 16
    );
    if (!shouldKeep) continue;
    lastFocusedComposerStateByGroup.set(groupId, { signature, stepIndex });
    focusedSystemEvents.push({
      tMs: Number(item.tMs) || 0,
      eventType,
      phase,
      barIndex: Number(item.barIndex) || 0,
      beatIndex: Number(item.beatIndex) || 0,
      stepIndex,
      groupId,
      continuityId: String(item.continuityId || '').trim(),
      templateId,
      musicLaneId: String(item.musicLaneId || '').trim().toLowerCase(),
      callResponseLane: String(item.callResponseLane || '').trim().toLowerCase(),
      sectionId: String(item.sectionId || '').trim().toLowerCase(),
      role: String(item.role || '').trim().toLowerCase(),
      reason,
      active: item.active === true,
      retiring: item.retiring === true,
      lifecycleState: String(item.lifecycleState || '').trim().toLowerCase(),
      instrumentId: String(item.instrumentId || '').trim(),
      note: String(item.note || '').trim(),
      stage: String(item.stage || '').trim().toLowerCase(),
      formationRole: String(item.formationRole || '').trim().toLowerCase(),
      formationArchetype,
      formationStyleFamily: String(item.formationStyleFamily || '').trim().toLowerCase(),
      formationSpawnRegion: String(item.formationSpawnRegion || '').trim().toLowerCase(),
      formationSpacingProfile: String(item.formationSpacingProfile || '').trim().toLowerCase(),
      formationSymmetry: String(item.formationSymmetry || '').trim().toLowerCase(),
      formationPresentationWeight: Number(item.formationPresentationWeight) || 0,
      formationMergeProtectionActive: item.formationMergeProtectionActive === true,
      formationDesiredMemberCount: Number(item.formationDesiredMemberCount) || 0,
      behavioralFormationArchetype: String(item.behavioralFormationArchetype || '').trim().toLowerCase(),
      behavioralFormationClass: String(item.behavioralFormationClass || '').trim().toLowerCase(),
      behavioralFormationActivationMode: String(item.behavioralFormationActivationMode || '').trim().toLowerCase(),
      behavioralFormationIntensity: Number(item.behavioralFormationIntensity) || 0,
      behavioralFormationActive: item.behavioralFormationActive === true,
      singleBehaviorId: String(item.singleBehaviorId || '').trim().toLowerCase(),
      groupBehaviorId: String(item.groupBehaviorId || '').trim().toLowerCase(),
      eventBehaviorId: String(item.eventBehaviorId || '').trim().toLowerCase(),
      behaviorPriority: String(item.behaviorPriority || '').trim().toLowerCase(),
      behaviorWindow: String(item.behaviorWindow || '').trim().toLowerCase(),
      behaviorSource: String(item.behaviorSource || '').trim().toLowerCase(),
    });
  }
  const compactSystemEvents = focusedSystemEvents.slice(-320);
  const systemEventCountsByType = Object.create(null);
  const systemEventCountsByReason = Object.create(null);
  const systemEventCountsByVisualFailureReason = Object.create(null);
  const sectionIds = new Set();
  for (const ev of systemEvents) {
    const eventType = String(ev?.eventType || '').trim();
    if (eventType) systemEventCountsByType[eventType] = (systemEventCountsByType[eventType] || 0) + 1;
    const reason = String(ev?.reason || '').trim();
    if (reason) systemEventCountsByReason[reason] = (systemEventCountsByReason[reason] || 0) + 1;
    if (eventType === 'music_handoff_visual_continuity_failed') {
      const visualFailureReasons = Array.isArray(ev?.visualFailureReasons) ? ev.visualFailureReasons : [];
      for (const reasonLike of visualFailureReasons) {
        const visualReason = String(reasonLike || '').trim().toLowerCase();
        if (!visualReason) continue;
        systemEventCountsByVisualFailureReason[visualReason] = (systemEventCountsByVisualFailureReason[visualReason] || 0) + 1;
      }
    }
    const sectionId = String(ev?.sectionId || '').trim();
    if (sectionId) sectionIds.add(sectionId);
  }
  const threatBudgetSnapshots = Array.isArray(src.threatBudgetSnapshots) ? src.threatBudgetSnapshots : [];
  const compactThreatBudgetSnapshots = threatBudgetSnapshots
    .filter((snap, index, arr) => {
      const isTail = index >= Math.max(0, arr.length - 32);
      const barIndex = Math.max(0, Math.trunc(Number(snap?.barIndex) || 0));
      return isTail || (barIndex % 8) === 0;
    })
    .map((snap) => ({
      barIndex: Math.max(0, Math.trunc(Number(snap?.barIndex) || 0)),
      beatIndex: Math.max(0, Math.trunc(Number(snap?.beatIndex) || 0)),
      fullThreats: Math.max(0, Math.trunc(Number(snap?.fullThreats) || 0)),
      lightThreats: Math.max(0, Math.trunc(Number(snap?.lightThreats) || 0)),
      audibleAccents: Math.max(0, Math.trunc(Number(snap?.audibleAccents) || 0)),
      cosmeticParticipants: Math.max(0, Math.trunc(Number(snap?.cosmeticParticipants) || 0)),
      combatPressure: Math.max(0, Math.min(1, Number(snap?.combatPressure) || 0)),
      musicalPressure: Math.max(0, Math.min(1, Number(snap?.musicalPressure) || 0)),
      energyState: String(snap?.energyState || '').trim().toLowerCase(),
      pressureState: snap?.pressureState && typeof snap.pressureState === 'object'
        ? {
            sectionIntent: String(snap.pressureState?.sectionIntent || '').trim().toLowerCase(),
            combatPressure: Math.max(0, Math.min(1, Number(snap.pressureState?.combatPressure) || 0)),
            musicalPressure: Math.max(0, Math.min(1, Number(snap.pressureState?.musicalPressure) || 0)),
          }
        : null,
      lanePlan: snap?.lanePlan && typeof snap.lanePlan === 'object'
        ? {
            foundation: snap.lanePlan.foundation || null,
            secondary_loop: snap.lanePlan.secondary_loop || null,
            primary_loop: snap.lanePlan.primary_loop || null,
            sparkle: snap.lanePlan.sparkle || null,
            support: snap.lanePlan.support || null,
            answer: snap.lanePlan.answer || null,
          }
        : null,
      spawnState: snap?.spawnState && typeof snap.spawnState === 'object'
        ? {
            configStatus: String(snap.spawnState?.configStatus || '').trim().toLowerCase(),
            liveBudgetMax: Math.max(0, Number(snap.spawnState?.liveBudgetMax) || 0),
            spawnBudget: Math.max(0, Number(snap.spawnState?.spawnBudget) || 0),
            totalSpawnsNoted: Math.max(0, Math.trunc(Number(snap.spawnState?.totalSpawnsNoted) || 0)),
            matchedChosenSpawnCount: Math.max(0, Math.trunc(Number(snap.spawnState?.matchedChosenSpawnCount) || 0)),
            mismatchedChosenSpawnCount: Math.max(0, Math.trunc(Number(snap.spawnState?.mismatchedChosenSpawnCount) || 0)),
            evaluationCount: Math.max(0, Math.trunc(Number(snap.spawnState?.evaluationCount) || 0)),
            noChoiceCount: Math.max(0, Math.trunc(Number(snap.spawnState?.noChoiceCount) || 0)),
            avgEligibleCount: Math.max(0, Number(snap.spawnState?.avgEligibleCount) || 0),
            maxEligibleCount: Math.max(0, Math.trunc(Number(snap.spawnState?.maxEligibleCount) || 0)),
            lastSpawnedId: String(snap.spawnState?.lastSpawnedId || '').trim().toLowerCase(),
            chosenId: String(snap.spawnState?.chosenId || snap.spawnState?.lastEvaluation?.chosenId || '').trim().toLowerCase(),
            rejectionReasonCounts: snap.spawnState?.rejectionReasonCounts && typeof snap.spawnState.rejectionReasonCounts === 'object'
              ? { ...snap.spawnState.rejectionReasonCounts }
              : {},
          }
        : null,
      countsById: snap?.countsById && typeof snap.countsById === 'object'
        ? { ...snap.countsById }
        : {},
      roleTagCounts: snap?.roleTagCounts && typeof snap.roleTagCounts === 'object'
        ? { ...snap.roleTagCounts }
        : {},
      occupiedSlots: snap?.occupiedSlots && typeof snap.occupiedSlots === 'object'
        ? { ...snap.occupiedSlots }
        : {},
    }));
  const threatBudgetSummary = {
    count: threatBudgetSnapshots.length,
    energyStateCounts: Object.create(null),
    laneActiveBeatCounts: Object.create(null),
    laneCarrierPreferenceCounts: Object.create(null),
    sectionIntentCounts: Object.create(null),
    spawnChosenCounts: Object.create(null),
    spawnConfigLoadedCount: 0,
    avgSpawnLiveBudgetMax: 0,
    avgSpawnBudget: 0,
    totalSpawnsNoted: 0,
    matchedChosenSpawnCount: 0,
    mismatchedChosenSpawnCount: 0,
    spawnEvaluationCount: 0,
    spawnNoChoiceCount: 0,
    spawnAvgEligibleCount: 0,
    spawnMaxEligibleCount: 0,
    spawnRejectionReasonCounts: Object.create(null),
    avgCombatPressure: 0,
    avgMusicalPressure: 0,
    maxUsage: {
      fullThreats: 0,
      lightThreats: 0,
      audibleAccents: 0,
      cosmeticParticipants: 0,
    },
  };
  let pressureSnapshotCount = 0;
  let combatPressureSum = 0;
  let musicalPressureSum = 0;
  let spawnSnapshotCount = 0;
  for (const snap of threatBudgetSnapshots) {
    const energyState = String(snap?.energyState || '').trim();
    if (energyState) threatBudgetSummary.energyStateCounts[energyState] = (threatBudgetSummary.energyStateCounts[energyState] || 0) + 1;
    const lanePlan = snap?.lanePlan && typeof snap.lanePlan === 'object' ? snap.lanePlan : null;
    if (lanePlan) {
      for (const [laneId, lane] of Object.entries(lanePlan)) {
        if (!lane || typeof lane !== 'object') continue;
        const active = lane?.active === true;
        const preferredCarrier = String(lane?.preferredCarrier || '').trim().toLowerCase();
        if (active) threatBudgetSummary.laneActiveBeatCounts[laneId] = (threatBudgetSummary.laneActiveBeatCounts[laneId] || 0) + 1;
        if (active && preferredCarrier) {
          const carrierKey = `${laneId}:${preferredCarrier}`;
          threatBudgetSummary.laneCarrierPreferenceCounts[carrierKey] = (threatBudgetSummary.laneCarrierPreferenceCounts[carrierKey] || 0) + 1;
        }
      }
    }
    const pressureState = snap?.pressureState && typeof snap.pressureState === 'object' ? snap.pressureState : null;
    if (pressureState) {
      const sectionIntent = String(pressureState?.sectionIntent || '').trim().toLowerCase();
      if (sectionIntent) threatBudgetSummary.sectionIntentCounts[sectionIntent] = (threatBudgetSummary.sectionIntentCounts[sectionIntent] || 0) + 1;
      combatPressureSum += Math.max(0, Math.min(1, Number(pressureState?.combatPressure) || 0));
      musicalPressureSum += Math.max(0, Math.min(1, Number(pressureState?.musicalPressure) || 0));
      pressureSnapshotCount += 1;
    }
    const spawnState = snap?.spawnState && typeof snap.spawnState === 'object' ? snap.spawnState : null;
    if (spawnState) {
      const configStatus = String(spawnState?.configStatus || '').trim().toLowerCase();
      if (configStatus === 'loaded') threatBudgetSummary.spawnConfigLoadedCount += 1;
      const chosenId = String(spawnState?.lastEvaluation?.chosenId || '').trim().toLowerCase();
      if (chosenId) threatBudgetSummary.spawnChosenCounts[chosenId] = (threatBudgetSummary.spawnChosenCounts[chosenId] || 0) + 1;
      threatBudgetSummary.avgSpawnLiveBudgetMax += Math.max(0, Number(spawnState?.liveBudgetMax) || 0);
      threatBudgetSummary.avgSpawnBudget += Math.max(0, Number(spawnState?.spawnBudget) || 0);
      threatBudgetSummary.totalSpawnsNoted = Math.max(
        Math.max(0, Math.trunc(Number(threatBudgetSummary.totalSpawnsNoted) || 0)),
        Math.max(0, Math.trunc(Number(spawnState?.totalSpawnsNoted) || 0))
      );
      threatBudgetSummary.matchedChosenSpawnCount = Math.max(
        Math.max(0, Math.trunc(Number(threatBudgetSummary.matchedChosenSpawnCount) || 0)),
        Math.max(0, Math.trunc(Number(spawnState?.matchedChosenSpawnCount) || 0))
      );
      threatBudgetSummary.mismatchedChosenSpawnCount = Math.max(
        Math.max(0, Math.trunc(Number(threatBudgetSummary.mismatchedChosenSpawnCount) || 0)),
        Math.max(0, Math.trunc(Number(spawnState?.mismatchedChosenSpawnCount) || 0))
      );
      threatBudgetSummary.spawnEvaluationCount = Math.max(
        Math.max(0, Math.trunc(Number(threatBudgetSummary.spawnEvaluationCount) || 0)),
        Math.max(0, Math.trunc(Number(spawnState?.evaluationCount) || 0))
      );
      threatBudgetSummary.spawnNoChoiceCount = Math.max(
        Math.max(0, Math.trunc(Number(threatBudgetSummary.spawnNoChoiceCount) || 0)),
        Math.max(0, Math.trunc(Number(spawnState?.noChoiceCount) || 0))
      );
      threatBudgetSummary.spawnAvgEligibleCount = Math.max(
        Number(threatBudgetSummary.spawnAvgEligibleCount) || 0,
        Number(spawnState?.avgEligibleCount) || 0
      );
      threatBudgetSummary.spawnMaxEligibleCount = Math.max(
        Math.max(0, Math.trunc(Number(threatBudgetSummary.spawnMaxEligibleCount) || 0)),
        Math.max(0, Math.trunc(Number(spawnState?.maxEligibleCount) || 0))
      );
      const rejectionReasonCounts = spawnState?.rejectionReasonCounts && typeof spawnState.rejectionReasonCounts === 'object'
        ? spawnState.rejectionReasonCounts
        : {};
      threatBudgetSummary.spawnRejectionReasonCounts ||= Object.create(null);
      for (const [reason, countRaw] of Object.entries(rejectionReasonCounts)) {
        const reasonKey = String(reason || '').trim().toLowerCase();
        if (!reasonKey) continue;
        threatBudgetSummary.spawnRejectionReasonCounts[reasonKey] = Math.max(
          Math.max(0, Math.trunc(Number(threatBudgetSummary.spawnRejectionReasonCounts[reasonKey]) || 0)),
          Math.max(0, Math.trunc(Number(countRaw) || 0))
        );
      }
      spawnSnapshotCount += 1;
    }
    const usage = snap?.usage && typeof snap.usage === 'object' ? snap.usage : null;
    if (!usage) continue;
    threatBudgetSummary.maxUsage.fullThreats = Math.max(threatBudgetSummary.maxUsage.fullThreats, Number(usage.fullThreats) || 0);
    threatBudgetSummary.maxUsage.lightThreats = Math.max(threatBudgetSummary.maxUsage.lightThreats, Number(usage.lightThreats) || 0);
    threatBudgetSummary.maxUsage.audibleAccents = Math.max(threatBudgetSummary.maxUsage.audibleAccents, Number(usage.audibleAccents) || 0);
    threatBudgetSummary.maxUsage.cosmeticParticipants = Math.max(threatBudgetSummary.maxUsage.cosmeticParticipants, Number(usage.cosmeticParticipants) || 0);
  }
  threatBudgetSummary.avgCombatPressure = pressureSnapshotCount > 0 ? (combatPressureSum / pressureSnapshotCount) : 0;
  threatBudgetSummary.avgMusicalPressure = pressureSnapshotCount > 0 ? (musicalPressureSum / pressureSnapshotCount) : 0;
  threatBudgetSummary.avgSpawnLiveBudgetMax = spawnSnapshotCount > 0 ? (threatBudgetSummary.avgSpawnLiveBudgetMax / spawnSnapshotCount) : 0;
  threatBudgetSummary.avgSpawnBudget = spawnSnapshotCount > 0 ? (threatBudgetSummary.avgSpawnBudget / spawnSnapshotCount) : 0;
  const metricsHistory = Array.isArray(src.metricsHistory) ? src.metricsHistory : [];
  const compactMetricsHistory = metricsHistory.map((entry) => {
    const metrics = entry?.metrics && typeof entry.metrics === 'object' ? entry.metrics : {};
    const summary = entry?.sessionSummary && typeof entry.sessionSummary === 'object' ? entry.sessionSummary : {};
    return {
      barIndex: Number(entry?.barIndex) || 0,
      tMs: Number(entry?.tMs) || 0,
      metrics: {
        motifReuseRate: Number(metrics?.motifReuse?.motifReuseRate) || 0,
        responseRate: Number(metrics?.callResponse?.responseRate) || 0,
        paletteContinuityScore: Number(metrics?.paletteContinuity?.paletteContinuityScore) || 0,
        playerMaskingRate: Number(metrics?.playerMasking?.playerMaskingRate) || 0,
        executedToCreatedRate: Number(metrics?.executedToCreatedRate) || 0,
        spawnerExecutedToCreatedRate: Number(metrics?.spawnerExecutedToCreatedRate) || 0,
        bassExecutedToCreatedRate: Number(metrics?.bassExecutedToCreatedRate) || 0,
        maxEnemyStepsWithoutBass: Number(metrics?.maxEnemyStepsWithoutBass) || 0,
        audibleForegroundLaneCount: Number(metrics?.audibleForegroundLaneCount) || 0,
        barsSinceNewForegroundIdea: Number(metrics?.barsSinceNewForegroundIdea) || 0,
        foundationProminence: String(summary.foundationProminence || ''),
        bassFoundation: String(summary.bassFoundation || ''),
        readabilityDensity: String(summary.readabilityDensity || ''),
      },
      sessionSummary: {
        playerMasking: String(summary.playerMasking || ''),
        spawnerFeedback: String(summary.spawnerFeedback || ''),
        beatDelivery: String(summary.beatDelivery || ''),
        bassFoundation: String(summary.bassFoundation || ''),
        readabilityDensity: String(summary.readabilityDensity || ''),
      },
    };
  });
  const compactedPayload = {
    ...src,
    eventTimeline: compactEventTimeline,
    enemyRemovals: compactEnemyRemovals,
    beatSwarmPerfSnapshot: src?.beatSwarmPerfSnapshot && typeof src.beatSwarmPerfSnapshot === 'object'
      ? src.beatSwarmPerfSnapshot
      : null,
    beatSwarmStepEventsPerfSnapshot: src?.beatSwarmStepEventsPerfSnapshot && typeof src.beatSwarmStepEventsPerfSnapshot === 'object'
      ? src.beatSwarmStepEventsPerfSnapshot
      : null,
    systemEvents: compactSystemEvents,
    systemEventSummary: {
      totalCount: systemEvents.length,
      countsByType: systemEventCountsByType,
      countsByReason: systemEventCountsByReason,
      countsByVisualFailureReason: systemEventCountsByVisualFailureReason,
      uniqueSectionIds: Array.from(sectionIds),
    },
    threatBudgetSnapshots: compactThreatBudgetSnapshots,
    threatBudgetSummary,
    metricsHistory: compactMetricsHistory,
    compositionAudit: src?.compositionAudit && typeof src.compositionAudit === 'object'
      ? clonePerfJson(src.compositionAudit)
      : null,
    session: (src.session && typeof src.session === 'object')
      ? {
          ...src.session,
          createdEvents: compactCreatedEvents,
          queuedEvents: [],
          spawnerPipelineEvents: [],
          executedEvents: compactExecutedEvents,
        }
      : src.session,
    saveCompact: {
      compacted: true,
      detail: 'focused_musicality_targets_and_recent_tail',
      originalEventTimelineCount: fullTimeline.length,
      keptEventTimelineCount: compactEventTimeline.length,
      droppedEventTimelineCount: Math.max(0, fullTimeline.length - compactEventTimeline.length),
      originalCreatedEventCount: Array.isArray(src?.session?.createdEvents) ? src.session.createdEvents.length : 0,
      originalQueuedEventCount: Array.isArray(src?.session?.queuedEvents) ? src.session.queuedEvents.length : 0,
      originalSpawnerPipelineEventCount: Array.isArray(src?.session?.spawnerPipelineEvents) ? src.session.spawnerPipelineEvents.length : 0,
      originalSystemEventCount: systemEvents.length,
      keptSystemEventCount: compactSystemEvents.length,
      originalThreatBudgetSnapshotCount: threatBudgetSnapshots.length,
      keptThreatBudgetSnapshotCount: compactThreatBudgetSnapshots.length,
      originalMetricsHistoryCount: metricsHistory.length,
      originalExecutedEventCount: Array.isArray(src?.session?.executedEvents) ? src.session.executedEvents.length : 0,
      keptCreatedEventCount: compactCreatedEvents.length,
      keptExecutedEventCount: compactExecutedEvents.length,
    },
  };
  return {
    payload: compactedPayload,
    compacted: true,
    detail: 'focused_musicality_targets_and_recent_tail',
  };
}

async function saveMusicLabSessionToResourcesGlobal({
  runId = 'musicLabAutoSave',
  label = 'music-lab-session',
  notes = '',
  iterationIndex = 1,
  iterationCount = 1,
  scenarioName = '',
  testCategory = '',
  forceCompactSave = false,
  allowLargeSave = false,
  payloadOverride = null,
} = {}) {
  const api = getMusicLabApiGlobal();
  if (!payloadOverride && (!api || typeof api.exportSession !== 'function')) {
    const result = { ok: false, reason: 'music_lab_api_unavailable', postUrl: '', sessionId: '', events: 0, sessionSummary: null };
    try { window.__LAST_MUSIC_LAB_SAVE_RESULT = { ...result, runId, label, notes }; } catch {}
    try { console.warn('[PerfLab] Music Lab save failed', { ...result, runId, label, notes }); } catch {}
    return result;
  }
  let payload = null;
  try {
    payload = payloadOverride && typeof payloadOverride === 'object'
      ? payloadOverride
      : ((typeof api.exportSessionForSave === 'function')
        ? api.exportSessionForSave({ compact: forceCompactSave === true })
        : api.exportSession());
    if (!payload && api && typeof api.exportSession === 'function') payload = api.exportSession();
  } catch (err) {
    const error = String(err && err.message || err || 'export_failed');
    const errorStack = String(err && err.stack || '');
    const result = {
      ok: false,
      reason: 'export_failed',
      error,
      errorStack,
      postUrl: '',
      sessionId: '',
      events: 0,
      sessionSummary: null,
      payloadDebug: null,
    };
    try { window.__LAST_MUSIC_LAB_SAVE_RESULT = { ...result, runId, label, notes }; } catch {}
    try { console.warn('[PerfLab] Music Lab export failed', { ...result, runId, label, notes }); } catch {}
    return result;
  }
  if (!payload || typeof payload !== 'object') {
    const result = {
      ok: false,
      reason: 'export_returned_null',
      postUrl: '',
      sessionId: '',
      events: 0,
      sessionSummary: null,
      payloadDebug: null,
    };
    try { window.__LAST_MUSIC_LAB_SAVE_RESULT = { ...result, runId, label, notes }; } catch {}
    try { console.warn('[PerfLab] Music Lab export returned null', { ...result, runId, label, notes }); } catch {}
    return result;
  }
  const beatSwarmPerfSnapshot = getBeatSwarmPerfSnapshotGlobal();
  const beatSwarmStepEventsPerfSnapshot = getBeatSwarmStepEventsPerfSnapshotGlobal();
  if (payload && typeof payload === 'object' && beatSwarmPerfSnapshot && typeof beatSwarmPerfSnapshot === 'object') {
    payload.beatSwarmPerfSnapshot = beatSwarmPerfSnapshot;
  }
  if (payload && typeof payload === 'object' && beatSwarmStepEventsPerfSnapshot && typeof beatSwarmStepEventsPerfSnapshot === 'object') {
    payload.beatSwarmStepEventsPerfSnapshot = beatSwarmStepEventsPerfSnapshot;
  }
  try {
    const beatSwarmApi = getBeatSwarmApi();
    const playerMusicThemes = beatSwarmApi && typeof beatSwarmApi.getPlayerMusicThemes === 'function'
      ? beatSwarmApi.getPlayerMusicThemes()
      : null;
    if (payload && typeof payload === 'object' && playerMusicThemes && typeof playerMusicThemes === 'object') {
      payload.playerMusicThemes = clonePerfJson(playerMusicThemes);
    }
    const compositionAudit = beatSwarmApi && typeof beatSwarmApi.getPerfCompositionAuditSnapshot === 'function'
      ? beatSwarmApi.getPerfCompositionAuditSnapshot()
      : null;
    if (payload && typeof payload === 'object' && compositionAudit && typeof compositionAudit === 'object') {
      const executedByStep = new Map();
      const executedByBar = new Map();
      const laneEventCounts = Object.create(null);
      const musicalityLaneRuntime = new Map();
      const leadPhraseRuntime = new Map();
      let playerWeaponEventCount = 0;
      let reducedPlayerWeaponEventCount = 0;
      let minimumPlayerWeaponVolumeMult = 1;
      const timeline = Array.isArray(payload.eventTimeline) ? payload.eventTimeline : [];
      for (const event of timeline) {
        if (String(event?.phase || '').trim().toLowerCase() !== 'executed') continue;
        const audible = event?.playerAudible === true
          || event?.enemyAudible === true
          || event?.audioRequired === true
          || Number(event?.approxPlaybackVolume) > 0
          || Number(event?.triggerVolume) > 0;
        if (!audible) continue;
        const stepIndex = Math.max(0, Math.trunc(Number(event?.stepIndex) || 0));
        const barIndex = Math.max(0, Math.trunc(Number(event?.barIndex) || 0));
        const laneId = String(event?.musicLaneId || event?.payload?.musicLaneId || event?.sourceSystem || 'unassigned').trim().toLowerCase() || 'unassigned';
        const bucket = executedByStep.get(stepIndex) || {
          stepIndex,
          count: 0,
          lanes: Object.create(null),
          actions: Object.create(null),
        };
        bucket.count += 1;
        bucket.lanes[laneId] = (bucket.lanes[laneId] || 0) + 1;
        const actionType = String(event?.actionType || 'unknown').trim().toLowerCase() || 'unknown';
        if (actionType === 'player-weapon-step') {
          const volumeMultRaw = Number(event?.payload?.playerSoundVolumeMult);
          const volumeMult = Number.isFinite(volumeMultRaw) ? volumeMultRaw : 1;
          playerWeaponEventCount += 1;
          minimumPlayerWeaponVolumeMult = Math.min(minimumPlayerWeaponVolumeMult, volumeMult);
          if (volumeMult < 0.999) reducedPlayerWeaponEventCount += 1;
        }
        bucket.actions[actionType] = (bucket.actions[actionType] || 0) + 1;
        executedByStep.set(stepIndex, bucket);
        laneEventCounts[laneId] = (laneEventCounts[laneId] || 0) + 1;
        const barBucket = executedByBar.get(barIndex) || {
          barIndex,
          eventCount: 0,
          lanes: Object.create(null),
          notesByLane: Object.create(null),
          actionsByLane: Object.create(null),
        };
        barBucket.eventCount += 1;
        barBucket.lanes[laneId] = (barBucket.lanes[laneId] || 0) + 1;
        const resolvedNote = String(event?.noteResolved || event?.note || '').trim();
        if (resolvedNote) {
          const notes = Array.isArray(barBucket.notesByLane[laneId]) ? barBucket.notesByLane[laneId] : [];
          notes.push(resolvedNote);
          barBucket.notesByLane[laneId] = notes;

          const laneMusic = musicalityLaneRuntime.get(laneId) || {
            laneId,
            eventCount: 0,
            noteCounts: Object.create(null),
            actionCounts: Object.create(null),
            interpretationCounts: Object.create(null),
            onsetGapCounts: Object.create(null),
            sameNoteTransitions: 0,
            transitionCount: 0,
            rawNoteComparisonCount: 0,
            rawNoteExactMatchCount: 0,
            previousNote: '',
            previousStep: -1,
            runNote: '',
            runLength: 0,
            runStartStep: -1,
            repeatedRuns: [],
            noteSequence: [],
          };
          const interpretationMode = String(event?.leadThemeInterpretationMode || '').trim().toLowerCase() || 'unclassified';
          const rawLeadNote = String(event?.leadThemeRawNote || '').trim();
          laneMusic.eventCount += 1;
          laneMusic.noteSequence.push(resolvedNote);
          laneMusic.noteCounts[resolvedNote] = (laneMusic.noteCounts[resolvedNote] || 0) + 1;
          laneMusic.actionCounts[actionType] = (laneMusic.actionCounts[actionType] || 0) + 1;
          laneMusic.interpretationCounts[interpretationMode] = (laneMusic.interpretationCounts[interpretationMode] || 0) + 1;
          if (laneMusic.previousNote) {
            laneMusic.transitionCount += 1;
            if (laneMusic.previousNote === resolvedNote) laneMusic.sameNoteTransitions += 1;
          }
          if (laneMusic.previousStep >= 0) {
            const onsetGap = Math.max(0, stepIndex - laneMusic.previousStep);
            laneMusic.onsetGapCounts[onsetGap] = (laneMusic.onsetGapCounts[onsetGap] || 0) + 1;
          }
          if (rawLeadNote) {
            laneMusic.rawNoteComparisonCount += 1;
            if (rawLeadNote === resolvedNote) laneMusic.rawNoteExactMatchCount += 1;
          }
          if (laneMusic.runNote === resolvedNote) {
            laneMusic.runLength += 1;
          } else {
            if (laneMusic.runLength > 1) {
              laneMusic.repeatedRuns.push({
                note: laneMusic.runNote,
                length: laneMusic.runLength,
                startStep: laneMusic.runStartStep,
                endStep: laneMusic.previousStep,
              });
            }
            laneMusic.runNote = resolvedNote;
            laneMusic.runLength = 1;
            laneMusic.runStartStep = stepIndex;
          }
          laneMusic.previousNote = resolvedNote;
          laneMusic.previousStep = stepIndex;
          musicalityLaneRuntime.set(laneId, laneMusic);

          if (laneId === 'primary_loop_lane') {
            const phraseIndex = Math.floor(barIndex / 4);
            const phrase = leadPhraseRuntime.get(phraseIndex) || {
              phraseIndex,
              startBar: phraseIndex * 4,
              endBar: (phraseIndex * 4) + 3,
              steps: [],
              notes: [],
              rawNotes: [],
              actions: [],
              interpretationModes: [],
              audioGains: [],
            };
            phrase.steps.push(stepIndex);
            phrase.notes.push(resolvedNote);
            phrase.rawNotes.push(rawLeadNote);
            phrase.actions.push(actionType);
            phrase.interpretationModes.push(interpretationMode);
            phrase.audioGains.push(Number.isFinite(Number(event?.audioGain)) ? Number(event.audioGain) : null);
            leadPhraseRuntime.set(phraseIndex, phrase);
          }
        }
        const actions = Array.isArray(barBucket.actionsByLane[laneId]) ? barBucket.actionsByLane[laneId] : [];
        actions.push(actionType);
        barBucket.actionsByLane[laneId] = actions;
        executedByBar.set(barIndex, barBucket);
      }
      const concurrencySteps = Array.from(executedByStep.values()).sort((a, b) => a.stepIndex - b.stepIndex);
      const musicalityLanes = Array.from(musicalityLaneRuntime.values()).map((lane) => {
        if (lane.runLength > 1) {
          lane.repeatedRuns.push({
            note: lane.runNote,
            length: lane.runLength,
            startStep: lane.runStartStep,
            endStep: lane.previousStep,
          });
        }
        const periodicMatchRates = Object.create(null);
        for (const lag of [2, 4, 8]) {
          let matches = 0;
          const comparisons = Math.max(0, lane.noteSequence.length - lag);
          for (let noteIndex = lag; noteIndex < lane.noteSequence.length; noteIndex += 1) {
            if (lane.noteSequence[noteIndex] === lane.noteSequence[noteIndex - lag]) matches += 1;
          }
          periodicMatchRates[lag] = comparisons > 0 ? matches / comparisons : 0;
        }
        return {
          laneId: lane.laneId,
          eventCount: lane.eventCount,
          uniqueNoteCount: Object.keys(lane.noteCounts).length,
          noteCounts: lane.noteCounts,
          actionCounts: lane.actionCounts,
          interpretationCounts: lane.interpretationCounts,
          onsetGapCounts: lane.onsetGapCounts,
          sameNoteTransitions: lane.sameNoteTransitions,
          sameNoteTransitionRate: lane.transitionCount > 0 ? lane.sameNoteTransitions / lane.transitionCount : 0,
          rawNoteComparisonCount: lane.rawNoteComparisonCount,
          rawNoteExactMatchCount: lane.rawNoteExactMatchCount,
          rawNoteExactMatchRate: lane.rawNoteComparisonCount > 0
            ? lane.rawNoteExactMatchCount / lane.rawNoteComparisonCount
            : null,
          periodicMatchRates,
          longestRepeatedRuns: lane.repeatedRuns
            .slice()
            .sort((a, b) => b.length - a.length || a.startStep - b.startStep)
            .slice(0, 12),
        };
      });
      const leadPhrases = Array.from(leadPhraseRuntime.values()).map((phrase) => {
        let repeatedTransitions = 0;
        for (let noteIndex = 1; noteIndex < phrase.notes.length; noteIndex += 1) {
          if (phrase.notes[noteIndex] === phrase.notes[noteIndex - 1]) repeatedTransitions += 1;
        }
        return {
          ...phrase,
          uniqueNoteCount: Array.from(new Set(phrase.notes)).length,
          sameNoteTransitionRate: phrase.notes.length > 1
            ? repeatedTransitions / (phrase.notes.length - 1)
            : 0,
        };
      });
      compositionAudit.musicality = {
        lanes: musicalityLanes,
        leadPhrases,
      };
      const counts = concurrencySteps.map((entry) => entry.count).sort((a, b) => a - b);
      compositionAudit.playbackConcurrency = {
        audibleStepCount: counts.length,
        averageEventsPerAudibleStep: counts.length ? counts.reduce((sum, count) => sum + count, 0) / counts.length : 0,
        p90EventsPerAudibleStep: counts.length ? counts[Math.min(counts.length - 1, Math.floor(counts.length * 0.9))] : 0,
        maxEventsPerAudibleStep: counts.length ? counts[counts.length - 1] : 0,
        stepsAtLeast3: counts.filter((count) => count >= 3).length,
        stepsAtLeast4: counts.filter((count) => count >= 4).length,
        stepsAtLeast5: counts.filter((count) => count >= 5).length,
        playerWeaponEventCount,
        reducedPlayerWeaponEventCount,
        minimumPlayerWeaponVolumeMult: playerWeaponEventCount > 0 ? minimumPlayerWeaponVolumeMult : null,
        laneEventCounts,
        busiestSteps: concurrencySteps
          .slice()
          .sort((a, b) => b.count - a.count || a.stepIndex - b.stepIndex)
          .slice(0, 24),
      };
      compositionAudit.playbackByBar = (Array.isArray(compositionAudit.bars) ? compositionAudit.bars : [])
        .map((bar) => {
          const barIndex = Math.max(0, Math.trunc(Number(bar?.barIndex) || 0));
          return executedByBar.get(barIndex) || {
            barIndex,
            eventCount: 0,
            lanes: Object.create(null),
            notesByLane: Object.create(null),
            actionsByLane: Object.create(null),
          };
        });
      payload.compositionAudit = clonePerfJson(compositionAudit);
    }
  } catch {}
  const payloadDebug = {
    sessionId: String(payload?.sessionId || ''),
    eventTimelineCount: Array.isArray(payload?.eventTimeline) ? payload.eventTimeline.length : 0,
    executedEventCount: Array.isArray(payload?.session?.executedEvents) ? payload.session.executedEvents.length : 0,
    createdEventCount: Array.isArray(payload?.session?.createdEvents) ? payload.session.createdEvents.length : 0,
    spawnerPipelineEventCount: Array.isArray(payload?.session?.spawnerPipelineEvents) ? payload.session.spawnerPipelineEvents.length : 0,
    metricsHistoryCount: Array.isArray(payload?.metricsHistory) ? payload.metricsHistory.length : 0,
    beatSwarmPerfBucketCount: beatSwarmPerfSnapshot && typeof beatSwarmPerfSnapshot?.buckets === 'object'
      ? Object.keys(beatSwarmPerfSnapshot.buckets).length
      : 0,
    beatSwarmStepEventsPerfBucketCount: beatSwarmStepEventsPerfSnapshot && typeof beatSwarmStepEventsPerfSnapshot?.buckets === 'object'
      ? Object.keys(beatSwarmStepEventsPerfSnapshot.buckets).length
      : 0,
  };
  const cfg = await resolveResultsConfig();
  const postUrl = resolveLabPostUrl(cfg, 'music');
  if (!postUrl) {
    const result = {
      ok: false,
      reason: 'no_post_url',
      postUrl: '',
      sessionId: String(payload?.sessionId || ''),
      events: Array.isArray(payload?.eventTimeline) ? payload.eventTimeline.length : 0,
      sessionSummary: summarizeMusicLabSessionPayload(payload),
      payloadDebug,
    };
    try { window.__LAST_MUSIC_LAB_SAVE_RESULT = { ...result, runId, label, notes }; } catch {}
    try { console.warn('[PerfLab] Music Lab save failed', { ...result, runId, label, notes }); } catch {}
    return result;
  }
  let payloadForSave = payload;
  let compactedSave = false;
  let compactedSaveDetail = '';
  let preflightBundleBytes = 0;
  const saveTimestampIso = new Date().toISOString();
  const saveInstanceId = [
    String(runId || 'musicLabAutoSave').trim() || 'musicLabAutoSave',
    String(payload?.sessionId || '').trim() || 'session',
    saveTimestampIso.replace(/[<>:"/\\|?*\x00-\x1F]/g, '-'),
  ].join('__');
  if (forceCompactSave !== true) {
    try {
      const preflightBundle = buildResultsBundle([
        {
          label: String(label || 'music-lab-session'),
          runId: String(runId || 'musicLabAutoSave'),
          createdAt: new Date().toISOString(),
          musicLab: payload,
        },
      ], {
        runId: String(runId || 'musicLabAutoSave'),
        notes: String(notes || ''),
        runMode: 'auto',
        scenarioName: String(scenarioName || label || 'music-lab-session'),
        testCategory: String(testCategory || 'music-lab-session'),
        iterationIndex: Math.max(1, Math.trunc(Number(iterationIndex) || 1)),
        iterationCount: Math.max(1, Math.trunc(Number(iterationCount) || 1)),
        labType: 'music',
        kind: 'music-lab',
      });
      preflightBundleBytes = String(JSON.stringify(preflightBundle) || '').length;
    } catch {}
  }
  if (forceCompactSave === true || (allowLargeSave !== true && preflightBundleBytes > 5000000)) {
    const compacted = compactMusicLabPayloadForSave(payload);
    payloadForSave = compacted.payload;
    compactedSave = compacted.compacted === true;
    compactedSaveDetail = String(compacted.detail || '');
  }
  const bundle = buildResultsBundle([
    {
      label: String(label || 'music-lab-session'),
      runId: String(runId || 'musicLabAutoSave'),
      createdAt: new Date().toISOString(),
      musicLab: payloadForSave,
    },
  ], {
    runId: String(runId || 'musicLabAutoSave'),
    notes: String(notes || ''),
    runMode: 'auto',
    scenarioName: String(scenarioName || label || 'music-lab-session'),
    testCategory: String(testCategory || 'music-lab-session'),
    iterationIndex: Math.max(1, Math.trunc(Number(iterationIndex) || 1)),
    iterationCount: Math.max(1, Math.trunc(Number(iterationCount) || 1)),
    labType: 'music',
    kind: 'music-lab',
    saveTimestampIso,
    saveInstanceId,
  });
  let bundleBytes = 0;
  try {
    bundleBytes = String(JSON.stringify(bundle) || '').length;
  } catch {}
  let ok = await postResultsBundle(bundle, postUrl, { allowLegacyPerfFallback: true });
  let fallbackJsonSaved = false;
  let fallbackJsonFileName = '';
  let mirrorJsonSaved = false;
  let mirrorJsonFileName = '';
  let summaryJsonSaved = false;
  let summaryJsonFileName = '';
  if (!ok) {
    try {
      const debugOutputUrl = resolveDebugOutputPostUrl(cfg);
      fallbackJsonFileName = `resources-debug-${String(runId || 'musicLabAutoSave').trim() || 'musicLabAutoSave'}-results.json`;
      fallbackJsonSaved = await postDebugOutputFile({
        fileName: fallbackJsonFileName,
        text: JSON.stringify(bundle, null, 2),
        meta: {
          source: 'music-lab-results-fallback',
          runId: String(runId || 'musicLabAutoSave'),
          label: String(label || 'music-lab-session'),
          scenarioName: String(scenarioName || label || 'music-lab-session'),
          compactedSave,
          compactedSaveDetail,
        },
      }, debugOutputUrl);
      if (fallbackJsonSaved) ok = true;
    } catch {}
  }
  try {
    const debugOutputUrl = resolveDebugOutputPostUrl(cfg);
    mirrorJsonFileName = `resources-debug-${saveInstanceId}-results.json`;
    mirrorJsonSaved = await postDebugOutputFile({
      fileName: mirrorJsonFileName,
      text: JSON.stringify(bundle, null, 2),
      meta: {
        source: 'music-lab-results-mirror',
        runId: String(runId || 'musicLabAutoSave'),
        label: String(label || 'music-lab-session'),
        scenarioName: String(scenarioName || label || 'music-lab-session'),
        sessionId: String(payload?.sessionId || ''),
        saveTimestampIso,
        saveInstanceId,
        compactedSave,
        compactedSaveDetail,
      },
    }, debugOutputUrl);
  } catch {}
  const sessionSummary = summarizeMusicLabSessionPayload(payload);
  let transitionDebug = null;
  try {
    transitionDebug = await saveMusicLabTransitionDebugOutput(payload, {
      runId,
      label,
    });
  } catch (err) {
    transitionDebug = {
      ok: false,
      reason: String(err && err.message || err || 'transition_debug_failed'),
    };
  }
  try {
    const debugOutputUrl = resolveDebugOutputPostUrl(cfg);
    const summaryBundle = {
      kind: 'music-lab-summary',
      runId: String(runId || 'musicLabAutoSave'),
      label: String(label || 'music-lab-session'),
      scenarioName: String(scenarioName || label || 'music-lab-session'),
      sessionId: String(payload?.sessionId || ''),
      saveTimestampIso,
      saveInstanceId,
      compactedSave,
      compactedSaveDetail,
      payloadDebug: {
        ...payloadDebug,
        preflightBundleBytes,
        bundleBytes,
      },
      sessionSummary,
      compositionAudit: payloadForSave?.compositionAudit && typeof payloadForSave.compositionAudit === 'object'
        ? clonePerfJson(payloadForSave.compositionAudit)
        : null,
      transitionDebug,
    };
    summaryJsonFileName = `resources-debug-${saveInstanceId}-summary.json`;
    summaryJsonSaved = await postDebugOutputFile({
      fileName: summaryJsonFileName,
      text: JSON.stringify(summaryBundle, null, 2),
      meta: {
        source: 'music-lab-summary',
        runId: String(runId || 'musicLabAutoSave'),
        sessionId: String(payload?.sessionId || ''),
        scenarioName: String(scenarioName || label || 'music-lab-session'),
        saveTimestampIso,
        saveInstanceId,
      },
    }, debugOutputUrl);
  } catch {}
  const result = {
    ok: !!ok,
    reason: ok ? (fallbackJsonSaved ? 'debug_output_fallback_saved' : '') : 'post_failed',
    postUrl,
    sessionId: String(payload?.sessionId || ''),
    events: Array.isArray(payload?.eventTimeline) ? payload.eventTimeline.length : 0,
    sessionSummary,
    transitionDebug,
    fallbackJsonSaved,
    fallbackJsonFileName,
    mirrorJsonSaved,
    mirrorJsonFileName,
    summaryJsonSaved,
    summaryJsonFileName,
    payloadDebug: {
      ...payloadDebug,
      preflightBundleBytes,
      bundleBytes,
      compactedSave,
      compactedSaveDetail,
      saveTimestampIso,
      saveInstanceId,
    },
  };
  try { window.__LAST_MUSIC_LAB_SAVE_RESULT = { ...result, runId, label, notes }; } catch {}
  try {
    if (ok) console.info('[PerfLab] Music Lab save succeeded', { ...result, runId, label, notes });
    else console.warn('[PerfLab] Music Lab save failed', { ...result, runId, label, notes });
  } catch {}
  return result;
}

function exportMusicLabPayloadForDeferredSave() {
  const api = getMusicLabApiGlobal();
  if (!api || typeof api.exportSession !== 'function') {
    return {
      ok: false,
      reason: 'music_lab_api_unavailable',
      payload: null,
      payloadDebug: null,
    };
  }
  let payload = null;
  try {
    payload = (typeof api.exportSessionForSave === 'function')
      ? api.exportSessionForSave({ compact: true })
      : api.exportSession();
    if (!payload && typeof api.exportSession === 'function') payload = api.exportSession();
  } catch (err) {
    return {
      ok: false,
      reason: 'export_failed',
      error: String(err && err.message || err || 'export_failed'),
      payload: null,
      payloadDebug: null,
    };
  }
  if (!payload || typeof payload !== 'object') {
    return {
      ok: false,
      reason: 'export_returned_null',
      payload: null,
      payloadDebug: null,
    };
  }
  const beatSwarmPerfSnapshot = getBeatSwarmPerfSnapshotGlobal();
  const beatSwarmStepEventsPerfSnapshot = getBeatSwarmStepEventsPerfSnapshotGlobal();
  if (beatSwarmPerfSnapshot && typeof beatSwarmPerfSnapshot === 'object') {
    payload.beatSwarmPerfSnapshot = beatSwarmPerfSnapshot;
  }
  if (beatSwarmStepEventsPerfSnapshot && typeof beatSwarmStepEventsPerfSnapshot === 'object') {
    payload.beatSwarmStepEventsPerfSnapshot = beatSwarmStepEventsPerfSnapshot;
  }
  return {
    ok: true,
    reason: '',
    payload,
    payloadDebug: {
      sessionId: String(payload?.sessionId || ''),
      eventTimelineCount: Array.isArray(payload?.eventTimeline) ? payload.eventTimeline.length : 0,
      executedEventCount: Array.isArray(payload?.session?.executedEvents) ? payload.session.executedEvents.length : 0,
      createdEventCount: Array.isArray(payload?.session?.createdEvents) ? payload.session.createdEvents.length : 0,
      metricsHistoryCount: Array.isArray(payload?.metricsHistory) ? payload.metricsHistory.length : 0,
    },
  };
}

async function saveDeferredMusicLabBatchToResourcesGlobal({
  runId = 'musicLabBatchAutoSave',
  label = 'music-lab-batch',
  notes = '',
  scenarioName = '',
  testCategory = '',
  forceCompactSave = false,
  runs = [],
} = {}) {
  const cfg = await resolveResultsConfig();
  const postUrl = resolveLabPostUrl(cfg, 'music');
  if (!postUrl) return { ok: false, reason: 'no_post_url', postUrl: '', runDetails: [] };
  const runItems = Array.isArray(runs) ? runs : [];
  const saveTimestampIso = new Date().toISOString();
  const results = [];
  const runDetails = [];
  for (const item of runItems) {
    const args = item?.args && typeof item.args === 'object' ? item.args : {};
    const payload = item?.payload && typeof item.payload === 'object' ? item.payload : null;
    const runIndex = Math.max(1, Math.trunc(Number(args.iterationIndex) || results.length + 1));
    const runIdForItem = String(args.runId || `${runId}_run${runIndex}`).trim() || `${runId}_run${runIndex}`;
    const compacted = forceCompactSave === true ? compactMusicLabPayloadForSave(payload) : { payload, compacted: false, detail: '' };
    const payloadForSave = compacted.payload;
    const sessionSummary = summarizeMusicLabSessionPayload(payload);
    results.push({
      label: String(args.label || `${label}-run${runIndex}`),
      runId: runIdForItem,
      createdAt: new Date().toISOString(),
      iterationIndex: runIndex,
      iterationCount: Math.max(1, Math.trunc(Number(args.iterationCount) || runItems.length || 1)),
      musicLab: payloadForSave,
    });
    runDetails.push({
      runIndex,
      runId: runIdForItem,
      saved: false,
      reason: '',
      sessionId: String(payload?.sessionId || ''),
      events: Array.isArray(payload?.eventTimeline) ? payload.eventTimeline.length : 0,
      sessionSummary,
      compactedSave: compacted.compacted === true,
      compactedSaveDetail: String(compacted.detail || ''),
    });
  }
  const aggregateSummary = aggregateMusicRunSummaries(
    runDetails.map((detail) => detail.sessionSummary).filter(Boolean)
  );
  const bundle = buildResultsBundle(results, {
    runId: String(runId || 'musicLabBatchAutoSave'),
    notes: String(notes || ''),
    runMode: 'multi-run',
    scenarioName: String(scenarioName || label || 'music-lab-batch'),
    testCategory: String(testCategory || scenarioName || 'music-lab-batch'),
    iterationIndex: 1,
    iterationCount: Math.max(1, Math.trunc(Number(runItems.length) || 1)),
    labType: 'music',
    kind: 'music-lab-batch',
    saveTimestampIso,
    aggregateSummary,
    runDetails,
  });
  const ok = await postResultsBundle(bundle, postUrl, { allowLegacyPerfFallback: true });
  for (const detail of runDetails) {
    detail.saved = !!ok;
    detail.reason = ok ? '' : 'post_failed';
  }
  return {
    ok: !!ok,
    reason: ok ? '' : 'post_failed',
    postUrl,
    runCount: runDetails.length,
    runDetails,
    aggregateSummary,
  };
}

async function publishGroupedMusicLabScenarioBundle({
  scenarioName = 'beat-swarm-music-multi-run',
  runId = 'musicLabScenarioBundle',
  notes = '',
  stageCount = 0,
  durationMs = 0,
  repeatCount = 0,
  runOutcomes = [],
} = {}) {
  const cfg = await resolveResultsConfig();
  const postUrl = resolveLabPostUrl(cfg, 'music');
  if (!postUrl) return { ok: false, reason: 'no_post_url' };

  const runDetails = Array.isArray(runOutcomes) ? runOutcomes.map((r) => ({
    runIndex: Math.max(1, Math.trunc(Number(r?.runIndex) || 1)),
    runId: String(r?.runId || ''),
    saved: !!r?.saved,
    reason: String(r?.reason || ''),
    sessionId: String(r?.sessionId || ''),
    events: Math.max(0, Number(r?.events) || 0),
    sessionSummary: (r?.sessionSummary && typeof r.sessionSummary === 'object') ? r.sessionSummary : null,
  })) : [];
  const aggregateSummary = aggregateMusicRunSummaries(
    runDetails.map((r) => r.sessionSummary).filter(Boolean)
  );

  const bundle = buildResultsBundle([
    {
      label: String(scenarioName || 'beat-swarm-music-multi-run'),
      runId: String(runId || 'musicLabScenarioBundle'),
      createdAt: new Date().toISOString(),
      stageCount: Math.max(0, Math.trunc(Number(stageCount) || 0)),
      durationMs: Math.max(0, Math.trunc(Number(durationMs) || 0)),
      runDetails,
      aggregateSummary,
    },
  ], {
    runId: String(runId || 'musicLabScenarioBundle'),
    notes: String(notes || ''),
    testCategory: 'beat-swarm-music',
    scenarioName: String(scenarioName || 'beat-swarm-music-multi-run'),
    runMode: 'multi-run',
    iterationIndex: 1,
    iterationCount: Math.max(1, Math.trunc(Number(repeatCount) || runDetails.length || 1)),
    labType: 'music',
    kind: 'music-lab-scenario',
  });

  const ok = await postResultsBundle(bundle, postUrl, { allowLegacyPerfFallback: true });
  return {
    ok: !!ok,
    reason: ok ? '' : 'post_failed',
    postUrl,
    runCount: runDetails.length,
    aggregateSummary,
  };
}

async function buildBS0() {
  try { clearSceneViaSnapshot(); } catch {}
  setStatus('Building BS0...');
  const api = getBeatSwarmApi();
  if (!api) {
    setStatus('BS0 build failed (Beat Swarm API unavailable)');
    return false;
  }
  try { api.exit(); } catch {}
  try { api.enter(); } catch {}
  try { if (!isRunning()) startTransport(); } catch {}
  setStatus('BS0 built');
  return true;
}

function waitForPerfLabMs(ms = 0) {
  return new Promise((resolve) => {
    try {
      setTimeout(resolve, Math.max(0, Number(ms) || 0));
    } catch {
      resolve();
    }
  });
}

async function waitForTransportRunning(timeoutMs = 1800) {
  const deadline = Date.now() + Math.max(50, Number(timeoutMs) || 1800);
  while (Date.now() < deadline) {
    try {
      if (isRunning()) return true;
    } catch {}
    await waitForPerfLabMs(50);
  }
  try {
    return !!isRunning();
  } catch {
    return false;
  }
}

async function ensureBS0Built() {
  const api = getBeatSwarmApi();
  if (!api) return false;
  try {
    if (!api.isActive?.()) await buildBS0();
  } catch {
    await buildBS0();
  }
  return true;
}

async function prepareBS0StaticStage(stageCount = 2, enemyCount = 24) {
  const ok = await ensureBS0Built();
  if (!ok) return false;
  const dbg = getBeatSwarmDebugApi();
  if (!dbg) return false;
  try { dbg.preparePerfScenario({ stageCount, enemyCount }); } catch {}
  return true;
}

function clonePerfJson(value) {
  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return null;
  }
}

function captureMusicLaneCarrierPolicyOverrideState() {
  const state = {
    hasDirect: false,
    direct: null,
    hasNestedRoot: false,
    hasNestedPolicy: false,
    nestedPolicy: null,
  };
  try {
    state.hasDirect = typeof window !== 'undefined'
      && Object.prototype.hasOwnProperty.call(window, '__beatSwarmLaneCarrierPolicy');
    state.direct = clonePerfJson(window.__beatSwarmLaneCarrierPolicy);
  } catch {}
  try {
    const root = window.__beatSwarmTestOverrides;
    state.hasNestedRoot = !!root && typeof root === 'object';
    state.hasNestedPolicy = state.hasNestedRoot
      && Object.prototype.hasOwnProperty.call(root, 'laneCarrierPolicy');
    state.nestedPolicy = clonePerfJson(root?.laneCarrierPolicy);
  } catch {}
  return state;
}

function restoreMusicLaneCarrierPolicyOverrideState(stateLike = null) {
  const state = stateLike && typeof stateLike === 'object' ? stateLike : null;
  if (!state) return;
  try {
    if (state.hasDirect) window.__beatSwarmLaneCarrierPolicy = clonePerfJson(state.direct);
    else delete window.__beatSwarmLaneCarrierPolicy;
  } catch {}
  try {
    const root = (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object')
      ? window.__beatSwarmTestOverrides
      : {};
    if (state.hasNestedPolicy) {
      root.laneCarrierPolicy = clonePerfJson(state.nestedPolicy);
      window.__beatSwarmTestOverrides = root;
    } else if (state.hasNestedRoot) {
      delete root.laneCarrierPolicy;
      window.__beatSwarmTestOverrides = root;
    } else if (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object') {
      delete window.__beatSwarmTestOverrides.laneCarrierPolicy;
    }
  } catch {}
}

function applyMusicLaneCarrierPolicyOverride(policyLike = null) {
  const policy = policyLike && typeof policyLike === 'object' ? clonePerfJson(policyLike) : null;
  try {
    if (policy) {
      window.__beatSwarmLaneCarrierPolicy = clonePerfJson(policy);
      const root = (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object')
        ? window.__beatSwarmTestOverrides
        : {};
      root.laneCarrierPolicy = clonePerfJson(policy);
      window.__beatSwarmTestOverrides = root;
    } else {
      delete window.__beatSwarmLaneCarrierPolicy;
      if (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object') {
        delete window.__beatSwarmTestOverrides.laneCarrierPolicy;
      }
    }
  } catch {}
}

function captureMusicHandoffSlotPreferenceOverrideState() {
  const state = {
    hasNestedRoot: false,
    hasNestedPreference: false,
    nestedPreference: null,
  };
  try {
    const root = window.__beatSwarmTestOverrides;
    state.hasNestedRoot = !!root && typeof root === 'object';
    state.hasNestedPreference = state.hasNestedRoot
      && Object.prototype.hasOwnProperty.call(root, 'handoffSlotPreference');
    state.nestedPreference = clonePerfJson(root?.handoffSlotPreference);
  } catch {}
  return state;
}

function restoreMusicHandoffSlotPreferenceOverrideState(stateLike = null) {
  const state = stateLike && typeof stateLike === 'object' ? stateLike : null;
  if (!state) return;
  try {
    const root = (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object')
      ? window.__beatSwarmTestOverrides
      : {};
    if (state.hasNestedPreference) {
      root.handoffSlotPreference = clonePerfJson(state.nestedPreference);
      window.__beatSwarmTestOverrides = root;
    } else if (state.hasNestedRoot) {
      delete root.handoffSlotPreference;
      window.__beatSwarmTestOverrides = root;
    } else if (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object') {
      delete window.__beatSwarmTestOverrides.handoffSlotPreference;
    }
  } catch {}
}

function applyMusicHandoffSlotPreferenceOverride(preferenceLike = null) {
  const preference = preferenceLike && typeof preferenceLike === 'object' ? clonePerfJson(preferenceLike) : null;
  try {
    if (preference) {
      const root = (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object')
        ? window.__beatSwarmTestOverrides
        : {};
      root.handoffSlotPreference = clonePerfJson(preference);
      window.__beatSwarmTestOverrides = root;
    } else {
      if (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object') {
        delete window.__beatSwarmTestOverrides.handoffSlotPreference;
      }
    }
  } catch {}
}

function captureMusicForcedHandoffReceiverSlotOverrideState() {
  const state = {
    hasNestedRoot: false,
    hasNestedForcedReceiverSlot: false,
    nestedForcedReceiverSlot: null,
  };
  try {
    const root = window.__beatSwarmTestOverrides;
    state.hasNestedRoot = !!root && typeof root === 'object';
    state.hasNestedForcedReceiverSlot = state.hasNestedRoot
      && Object.prototype.hasOwnProperty.call(root, 'forcedHandoffReceiverSlot');
    state.nestedForcedReceiverSlot = clonePerfJson(root?.forcedHandoffReceiverSlot);
  } catch {}
  return state;
}

function restoreMusicForcedHandoffReceiverSlotOverrideState(stateLike = null) {
  const state = stateLike && typeof stateLike === 'object' ? stateLike : null;
  if (!state) return;
  try {
    const root = (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object')
      ? window.__beatSwarmTestOverrides
      : {};
    if (state.hasNestedForcedReceiverSlot) {
      root.forcedHandoffReceiverSlot = clonePerfJson(state.nestedForcedReceiverSlot);
      window.__beatSwarmTestOverrides = root;
    } else if (state.hasNestedRoot) {
      delete root.forcedHandoffReceiverSlot;
      window.__beatSwarmTestOverrides = root;
    } else if (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object') {
      delete window.__beatSwarmTestOverrides.forcedHandoffReceiverSlot;
    }
  } catch {}
}

function applyMusicForcedHandoffReceiverSlotOverride(overrideLike = null) {
  const override = overrideLike && typeof overrideLike === 'object' ? clonePerfJson(overrideLike) : null;
  try {
    if (override) {
      const root = (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object')
        ? window.__beatSwarmTestOverrides
        : {};
      root.forcedHandoffReceiverSlot = clonePerfJson(override);
      window.__beatSwarmTestOverrides = root;
    } else {
      if (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object') {
        delete window.__beatSwarmTestOverrides.forcedHandoffReceiverSlot;
      }
    }
  } catch {}
}

function captureMusicForcedProbeHandoffOverrideState() {
  const state = {
    hasNestedRoot: false,
    hasNestedForcedProbeHandoff: false,
    nestedForcedProbeHandoff: null,
  };
  try {
    const root = window.__beatSwarmTestOverrides;
    state.hasNestedRoot = !!root && typeof root === 'object';
    state.hasNestedForcedProbeHandoff = state.hasNestedRoot
      && Object.prototype.hasOwnProperty.call(root, 'forcedProbeHandoff');
    state.nestedForcedProbeHandoff = clonePerfJson(root?.forcedProbeHandoff);
  } catch {}
  return state;
}

function restoreMusicForcedProbeHandoffOverrideState(stateLike = null) {
  const state = stateLike && typeof stateLike === 'object' ? stateLike : null;
  if (!state) return;
  try {
    const root = (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object')
      ? window.__beatSwarmTestOverrides
      : {};
    if (state.hasNestedForcedProbeHandoff) {
      root.forcedProbeHandoff = clonePerfJson(state.nestedForcedProbeHandoff);
      window.__beatSwarmTestOverrides = root;
    } else if (state.hasNestedRoot) {
      delete root.forcedProbeHandoff;
      window.__beatSwarmTestOverrides = root;
    } else if (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object') {
      delete window.__beatSwarmTestOverrides.forcedProbeHandoff;
    }
  } catch {}
}

function applyMusicForcedProbeHandoffOverride(overrideLike = null) {
  const override = overrideLike && typeof overrideLike === 'object' ? clonePerfJson(overrideLike) : null;
  try {
    if (override) {
      const root = (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object')
        ? window.__beatSwarmTestOverrides
        : {};
      root.forcedProbeHandoff = clonePerfJson(override);
      window.__beatSwarmTestOverrides = root;
    } else {
      if (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object') {
        delete window.__beatSwarmTestOverrides.forcedProbeHandoff;
      }
    }
  } catch {}
}

function sleepPerfLabMs(ms = 0) {
  return new Promise((resolve) => {
    try { setTimeout(resolve, Math.max(0, Math.trunc(Number(ms) || 0))); } catch { resolve(); }
  });
}

const MUSIC_LAB_PROBE_SUPPORTED_POLICY = Object.freeze({
  foundation_lane: Object.freeze(['group', 'spawner']),
  primary_loop_lane: Object.freeze(['drawsnake']),
  secondary_loop_lane: Object.freeze(['group', 'spawner']),
  sparkle_lane: Object.freeze(['spawner', 'group']),
});
const MUSIC_LAB_PROBE_SUPPORTED_HANDOFF_SLOTS = Object.freeze(['group', 'special', 'large', 'generic']);

function normalizeMusicLabProbeLaneCarrierPolicy(policy = null) {
  const requestedPolicy = policy && typeof policy === 'object' ? policy : {};
  const normalizedPolicy = {};
  const unsupportedRequests = [];
  for (const [laneId, supportedList] of Object.entries(MUSIC_LAB_PROBE_SUPPORTED_POLICY)) {
    const requestedList = Array.isArray(requestedPolicy?.[laneId]) && requestedPolicy[laneId].length
      ? requestedPolicy[laneId]
      : supportedList;
    const nextList = [];
    const seen = new Set();
    for (const value of requestedList) {
      const carrier = String(value || '').trim().toLowerCase();
      if (!carrier || seen.has(carrier)) continue;
      seen.add(carrier);
      if (supportedList.includes(carrier)) nextList.push(carrier);
      else unsupportedRequests.push({ laneId, carrier });
    }
    normalizedPolicy[laneId] = nextList.length ? nextList : Array.from(supportedList);
  }
  return {
    normalizedPolicy,
    unsupportedRequests,
  };
}

function normalizeMusicLabProbeHandoffSlotPreference(preference = null) {
  const requestedPreference = preference && typeof preference === 'object' ? preference : {};
  const normalizedPreference = {};
  const unsupportedRequests = [];
  for (const sourceSlot of MUSIC_LAB_PROBE_SUPPORTED_HANDOFF_SLOTS) {
    const requestedList = Array.isArray(requestedPreference?.[sourceSlot]) && requestedPreference[sourceSlot].length
      ? requestedPreference[sourceSlot]
      : null;
    if (!requestedList) continue;
    const nextList = [];
    const seen = new Set();
    for (const value of requestedList) {
      const slot = String(value || '').trim().toLowerCase();
      if (!slot || seen.has(slot)) continue;
      seen.add(slot);
      if (MUSIC_LAB_PROBE_SUPPORTED_HANDOFF_SLOTS.includes(slot)) nextList.push(slot);
      else unsupportedRequests.push({ sourceSlot, slot });
    }
    if (nextList.length) normalizedPreference[sourceSlot] = nextList;
  }
  return {
    normalizedPreference,
    unsupportedRequests,
  };
}

function normalizeMusicLabProbeForcedHandoffReceiverSlot(overrideLike = null) {
  const requestedOverride = overrideLike && typeof overrideLike === 'object' ? overrideLike : {};
  const normalizedOverride = {};
  const unsupportedRequests = [];
  for (const sourceSlot of MUSIC_LAB_PROBE_SUPPORTED_HANDOFF_SLOTS) {
    const slot = String(requestedOverride?.[sourceSlot] || '').trim().toLowerCase();
    if (!slot) continue;
    if (MUSIC_LAB_PROBE_SUPPORTED_HANDOFF_SLOTS.includes(slot)) normalizedOverride[sourceSlot] = slot;
    else unsupportedRequests.push({ sourceSlot, slot });
  }
  return {
    normalizedOverride,
    unsupportedRequests,
  };
}

async function runBS0Stage(stageCount = 1, opts = null) {
  const cfg = opts && typeof opts === 'object' ? opts : {};
  const durationMs = Math.max(1000, Number(cfg.durationMs) || 9000);
  const repeatCount = Math.max(1, Math.round(Number(cfg.repeatCount) || 1));
  const enemyCount = Math.max(1, Math.round(Number(cfg.enemyCount) || 24));
  const freshResetEachRun = cfg.freshResetEachRun !== false;
  const restartTransportEachRun = cfg.restartTransportEachRun !== false;
  const resetMusicLabEachRun = cfg.resetMusicLabEachRun !== false;
  const saveMusicLabEachRun = cfg.saveMusicLabEachRun === true;
  const deferMusicLabSaveUntilBatchEnd = saveMusicLabEachRun && cfg.deferMusicLabSaveUntilBatchEnd === true;
  const publishPerfArtifacts = cfg.publishPerfArtifacts === true
    || (cfg.publishPerfArtifacts !== false && !saveMusicLabEachRun);
  const saveRunIdBase = String(cfg.saveRunIdBase || `musicLab_bs0_s${stageCount}`).trim() || `musicLab_bs0_s${stageCount}`;
  const saveNotes = String(cfg.saveNotes || '').trim();
  const groupedScenarioName = String(cfg.groupedScenarioName || `beat-swarm-s${stageCount}-music-multi-run`).trim() || `beat-swarm-s${stageCount}-music-multi-run`;
  const groupedRunId = String(cfg.groupedRunId || `${saveRunIdBase}_scenario`).trim() || `${saveRunIdBase}_scenario`;
  const groupedNotes = String(cfg.groupedNotes || `Grouped scenario bundle for BS0 S${stageCount} music multi-run.`).trim()
    || `Grouped scenario bundle for BS0 S${stageCount} music multi-run.`;
  const traceCaptureConfig = cfg.traceCapture && typeof cfg.traceCapture === 'object'
    ? cfg.traceCapture
    : null;
  const tagPrefix = String(cfg.tagPrefix || `BS0S${stageCount}`).trim() || `BS0S${stageCount}`;
  const labelPrefix = String(cfg.labelPrefix || `BS0_stage${stageCount}_beatswarm_static_fire`).trim() || `BS0_stage${stageCount}_beatswarm_static_fire`;
  const statusPrefix = String(cfg.statusPrefix || `Running BS0 S${stageCount} (static player, ${stageCount} stage weapon, onscreen enemies)`).trim()
    || `Running BS0 S${stageCount} (static player, ${stageCount} stage weapon, onscreen enemies)`;
  const suppressCompletionUi = cfg.suppressCompletionUi === true;
  const prevDur = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  let prevMusicLabEnabled = null;
  let prevMusicLabRealtimeMetricsEnabled = null;
  let prevMusicLabLightweightSystemEventsEnabled = null;
  const prevBeatSwarmTestOverrides = clonePerfJson(window.__beatSwarmTestOverrides);
  const hadBeatSwarmTestOverrides = (() => {
    try { return Object.prototype.hasOwnProperty.call(window, '__beatSwarmTestOverrides'); } catch { return false; }
  })();
  const runOutcomes = [];
  const deferredMusicLabSaves = [];
  const totalMinutes = Number(((durationMs * repeatCount) / 60000).toFixed(1));
  try {
    try { window.__PERF_LAB_DURATION_MS = durationMs; } catch {}
    if (cfg.beatSwarmTestOverrides && typeof cfg.beatSwarmTestOverrides === 'object') {
      try {
        const root = (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object')
          ? clonePerfJson(window.__beatSwarmTestOverrides)
          : {};
        window.__beatSwarmTestOverrides = {
          ...(root || {}),
          ...clonePerfJson(cfg.beatSwarmTestOverrides),
        };
      } catch {}
    }
    if (traceCaptureConfig?.enabled !== true) {
      try { window.__beatSwarmMusicTrace = { enabled: false, include: [], exclude: [], console: false }; } catch {}
      try { getMusicTraceCaptureApiGlobal()?.stopTraceCapture?.(); } catch {}
    }
    for (let runIndex = 1; runIndex <= repeatCount; runIndex += 1) {
      if (freshResetEachRun) {
        const rebuilt = await buildBS0();
        if (!rebuilt) {
          setStatus(`BS0 S${stageCount} failed (fresh reset failed)`);
          return { ok: false, reason: 'fresh_reset_failed', stageCount, runIndex, repeatCount, durationMs };
        }
      }
      if (restartTransportEachRun) {
        try { stopTransport(); } catch {}
        await waitForPerfLabMs(120);
        try { startTransport(); } catch {}
        await waitForTransportRunning(2200);
        await waitForPerfLabMs(120);
      }
      const runSuffix = repeatCount > 1 ? `_run${runIndex}` : '';
      const runHuman = repeatCount > 1 ? ` [${runIndex}/${repeatCount}]` : '';
      const musicLabApi = getMusicLabApiGlobal();
      if (musicLabApi && typeof musicLabApi.setEnabled === 'function') {
        if (prevMusicLabEnabled === null && typeof musicLabApi.isEnabled === 'function') {
          try { prevMusicLabEnabled = musicLabApi.isEnabled() === true; } catch { prevMusicLabEnabled = false; }
        }
        if (
          prevMusicLabRealtimeMetricsEnabled === null
          && typeof musicLabApi.isRealtimeMetricsEnabled === 'function'
        ) {
          try { prevMusicLabRealtimeMetricsEnabled = musicLabApi.isRealtimeMetricsEnabled() === true; } catch { prevMusicLabRealtimeMetricsEnabled = true; }
        }
        if (
          prevMusicLabLightweightSystemEventsEnabled === null
          && typeof musicLabApi.isLightweightSystemEventsEnabled === 'function'
        ) {
          try { prevMusicLabLightweightSystemEventsEnabled = musicLabApi.isLightweightSystemEventsEnabled() === true; } catch { prevMusicLabLightweightSystemEventsEnabled = false; }
        }
        try { musicLabApi.setEnabled(true); } catch {}
        try { musicLabApi.setRealtimeMetricsEnabled?.(cfg.keepMusicLabRealtimeMetrics === true); } catch {}
        try { musicLabApi.setLightweightSystemEventsEnabled?.(true); } catch {}
      }
      if (resetMusicLabEachRun) {
        const api = musicLabApi || getMusicLabApiGlobal();
        if (api && typeof api.reset === 'function') {
          try { api.reset('perf-lab-run'); } catch {}
        }
      }
      const ok = await prepareBS0StaticStage(stageCount, enemyCount);
      if (!ok) {
        setStatus(`BS0 S${stageCount} failed (Beat Swarm debug API unavailable)`);
        return { ok: false, reason: 'debug_api_unavailable', stageCount, runIndex, repeatCount, durationMs };
      }
      if (traceCaptureConfig?.enabled === true && cfg.traceBeforeSetup === true) {
        try {
          await startMusicTraceCaptureForPerfRun({
            include: Array.isArray(traceCaptureConfig.include) ? traceCaptureConfig.include : [],
            exclude: Array.isArray(traceCaptureConfig.exclude) ? traceCaptureConfig.exclude : [],
            maxLines: traceCaptureConfig.maxLines,
          });
        } catch {}
      }
      if (typeof cfg.setupAfterPrepare === 'function') {
        try {
          await cfg.setupAfterPrepare({
            runIndex,
            repeatCount,
            durationMs,
            stageCount,
            musicLabApi: musicLabApi || getMusicLabApiGlobal(),
          });
        } catch (err) {
          setStatus(`BS0 S${stageCount} failed (setup hook failed)`);
          setOutput({
            ok: false,
            stageCount,
            runIndex,
            repeatCount,
            durationMs,
            reason: 'setup_after_prepare_failed',
            error: String(err && err.message || err || 'unknown_error'),
          });
          return {
            ok: false,
            stageCount,
            runIndex,
            repeatCount,
            durationMs,
            reason: 'setup_after_prepare_failed',
            error: String(err && err.message || err || 'unknown_error'),
          };
        }
      }
      if (traceCaptureConfig?.enabled === true && cfg.traceBeforeSetup !== true) {
        try {
          await startMusicTraceCaptureForPerfRun({
            include: Array.isArray(traceCaptureConfig.include) ? traceCaptureConfig.include : [],
            exclude: Array.isArray(traceCaptureConfig.exclude) ? traceCaptureConfig.exclude : [],
            maxLines: traceCaptureConfig.maxLines,
          });
        } catch {}
      }
      try { window.__PERF_RUN_TAG = `${tagPrefix}${runSuffix}`; } catch {}
      try {
        await runVariantPlaying(
          `${labelPrefix}${runSuffix}`,
          null,
          `${statusPrefix}${runHuman}...`,
          {
            durationMs,
            stopTransportAtEnd: !saveMusicLabEachRun,
            publishResultAtEnd: publishPerfArtifacts,
          }
        );
      } catch (err) {
        if (typeof cfg.teardownAfterRun === 'function') {
          try { await cfg.teardownAfterRun({ runIndex, repeatCount, durationMs, stageCount, failed: true }); } catch {}
        }
        try { delete window.__PERF_LAB_DEFER_DEBUG_POSTS; } catch {}
        try { window.__PERF_ACTIVE_RUN_DEBUG = null; } catch {}
        if (publishPerfArtifacts) {
          try {
            await publishBs0MusicRunStageDebugResult({
              label: `music-lab-run-stage-debug${runSuffix}`,
              runId: `${saveRunIdBase}${runSuffix}`,
              stage: 'run_variant_threw',
              sourceLabel: `${labelPrefix}${runSuffix}`,
              notes: `${saveNotes || `Auto save for BS0 S${stageCount} run ${runIndex}/${repeatCount}`} | ${String(err && err.message || err || 'unknown_error')}`,
              durationMs,
              stageCount,
              iterationIndex: runIndex,
              iterationCount: repeatCount,
              transportRunning: isRunning(),
              beatSwarmActive: !!window.__beatSwarmActive,
              perfRunTag: String(window.__PERF_RUN_TAG || ''),
            });
          } catch {}
        }
        setStatus(`BS0 S${stageCount} run ${runIndex}/${repeatCount} failed during benchmark`);
        setOutput({
          ok: false,
          stageCount,
          runIndex,
          repeatCount,
          durationMs,
          reason: 'run_variant_failed',
          error: String(err && err.message || err || 'unknown_error'),
        });
        return {
          ok: false,
          stageCount,
          runIndex,
          repeatCount,
          durationMs,
          reason: 'run_variant_failed',
          error: String(err && err.message || err || 'unknown_error'),
        };
      }
      if (typeof cfg.teardownAfterRun === 'function') {
        try { await cfg.teardownAfterRun({ runIndex, repeatCount, durationMs, stageCount, failed: false }); } catch {}
      }
      try { stopTransport(); } catch {}
      if (publishPerfArtifacts) {
        try {
          await publishBs0MusicRunStageDebugResult({
            label: `music-lab-run-stage-debug${runSuffix}`,
            runId: `${saveRunIdBase}${runSuffix}`,
            stage: 'after_run_variant',
            sourceLabel: `${labelPrefix}${runSuffix}`,
            notes: saveNotes || `Auto save for BS0 S${stageCount} run ${runIndex}/${repeatCount}`,
            durationMs,
            stageCount,
            iterationIndex: runIndex,
            iterationCount: repeatCount,
            transportRunning: isRunning(),
            beatSwarmActive: !!window.__beatSwarmActive,
            perfRunTag: String(window.__PERF_RUN_TAG || ''),
          });
        } catch {}
      }
      let traceCaptureResult = null;
      if (publishPerfArtifacts) {
        try {
          await publishBs0MusicRunStageDebugResult({
            label: `music-lab-run-stage-debug${runSuffix}`,
            runId: `${saveRunIdBase}${runSuffix}`,
            stage: traceCaptureConfig?.enabled === true ? 'before_trace_finalize' : 'trace_finalize_skipped',
            sourceLabel: `${labelPrefix}${runSuffix}`,
            notes: saveNotes || `Auto save for BS0 S${stageCount} run ${runIndex}/${repeatCount}`,
            durationMs,
            stageCount,
            iterationIndex: runIndex,
            iterationCount: repeatCount,
            transportRunning: isRunning(),
            beatSwarmActive: !!window.__beatSwarmActive,
            perfRunTag: String(window.__PERF_RUN_TAG || ''),
          });
        } catch {}
      }
      if (traceCaptureConfig?.enabled === true) {
        const traceFilePrefix = String(
          traceCaptureConfig.fileNamePrefix || `beat-swarm-trace-s${stageCount}${runSuffix}`
        ).trim();
        const traceFileBase = repeatCount > 1 ? `${traceFilePrefix}${runSuffix}` : traceFilePrefix;
        traceCaptureResult = await finalizeMusicTraceCaptureForPerfRun({
          fileName: `${traceFileBase}.txt`,
          preferOutputDirectory: traceCaptureConfig.preferOutputDirectory !== false,
        });
      }
      if (publishPerfArtifacts) {
        try {
          await publishBs0MusicRunStageDebugResult({
            label: `music-lab-run-stage-debug${runSuffix}`,
            runId: `${saveRunIdBase}${runSuffix}`,
            stage: 'after_trace_finalize',
            sourceLabel: `${labelPrefix}${runSuffix}`,
            notes: saveNotes || `Auto save for BS0 S${stageCount} run ${runIndex}/${repeatCount}`,
            durationMs,
            stageCount,
            iterationIndex: runIndex,
            iterationCount: repeatCount,
            transportRunning: isRunning(),
            beatSwarmActive: !!window.__beatSwarmActive,
            perfRunTag: String(window.__PERF_RUN_TAG || ''),
          });
        } catch {}
      }
      if (saveMusicLabEachRun) {
        if (publishPerfArtifacts) {
          try {
            await publishBs0MusicRunStageDebugResult({
              label: `music-lab-run-stage-debug${runSuffix}`,
              runId: `${saveRunIdBase}${runSuffix}`,
              stage: 'before_music_save',
              sourceLabel: `${labelPrefix}${runSuffix}`,
              notes: saveNotes || `Auto save for BS0 S${stageCount} run ${runIndex}/${repeatCount}`,
              durationMs,
              stageCount,
              iterationIndex: runIndex,
              iterationCount: repeatCount,
              transportRunning: isRunning(),
              beatSwarmActive: !!window.__beatSwarmActive,
              perfRunTag: String(window.__PERF_RUN_TAG || ''),
            });
          } catch {}
        }
        const saveArgs = {
          runId: `${saveRunIdBase}${runSuffix}`,
          label: `music-lab-session${runSuffix}`,
          notes: saveNotes || `Auto save for BS0 S${stageCount} run ${runIndex}/${repeatCount}`,
          iterationIndex: runIndex,
          iterationCount: repeatCount,
          scenarioName: groupedScenarioName,
          testCategory: groupedScenarioName,
          forceCompactSave: cfg.forceCompactSave === true,
          allowLargeSave: cfg.allowLargeSave === true,
        };
        const deferredExport = deferMusicLabSaveUntilBatchEnd
          ? exportMusicLabPayloadForDeferredSave()
          : null;
        let save = null;
        try {
          save = deferMusicLabSaveUntilBatchEnd
            ? {
                ok: deferredExport?.ok === true,
                reason: String(deferredExport?.reason || ''),
                postUrl: 'deferred_until_batch_end',
                sessionId: String(deferredExport?.payload?.sessionId || ''),
                events: Array.isArray(deferredExport?.payload?.eventTimeline) ? deferredExport.payload.eventTimeline.length : 0,
                sessionSummary: deferredExport?.payload ? summarizeMusicLabSessionPayload(deferredExport.payload) : null,
                payloadDebug: deferredExport?.payloadDebug || null,
                deferred: true,
              }
            : await saveMusicLabSessionToResourcesGlobal(saveArgs);
        } catch (err) {
          save = {
            ok: false,
            reason: 'save_call_threw',
            error: String(err && err.message || err || 'save_call_threw'),
            errorStack: String(err && err.stack || ''),
            postUrl: '',
            sessionId: '',
            events: 0,
            sessionSummary: null,
            payloadDebug: null,
          };
          try { window.__LAST_MUSIC_LAB_SAVE_RESULT = { ...save, ...saveArgs }; } catch {}
          try { console.warn('[PerfLab] Music Lab save call threw', { save, saveArgs }); } catch {}
        }
        if (deferMusicLabSaveUntilBatchEnd && save.ok) {
          deferredMusicLabSaves.push({
            args: saveArgs,
            payload: deferredExport.payload,
          });
        }
        runOutcomes.push({
          runIndex,
          runId: `${saveRunIdBase}${runSuffix}`,
          saved: !!save?.ok,
          reason: String(save?.reason || ''),
          postUrl: String(save?.postUrl || ''),
          sessionId: String(save?.sessionId || ''),
          events: Math.max(0, Number(save?.events) || 0),
          sessionSummary: (save?.sessionSummary && typeof save.sessionSummary === 'object') ? save.sessionSummary : null,
          traceCapture: traceCaptureResult && typeof traceCaptureResult === 'object' ? { ...traceCaptureResult } : null,
        });
        try {
          console.info('[PerfLab] BS0 Music run save outcome', {
            stageCount,
            runIndex,
            repeatCount,
            durationMs,
            runId: `${saveRunIdBase}${runSuffix}`,
            label: `music-lab-session${runSuffix}`,
            save,
          });
        } catch {}
        if (!deferMusicLabSaveUntilBatchEnd) try {
          const cfgResolved = await resolveResultsConfig();
          const debugOutputUrl = resolveDebugOutputPostUrl(cfgResolved);
          const saveResultText = [
            `runId=${String(`${saveRunIdBase}${runSuffix}`)}`,
            `label=${String(`music-lab-session${runSuffix}`)}`,
            `stageCount=${Math.max(0, Math.trunc(Number(stageCount) || 0))}`,
            `runIndex=${Math.max(0, Math.trunc(Number(runIndex) || 0))}`,
            `repeatCount=${Math.max(0, Math.trunc(Number(repeatCount) || 0))}`,
            `durationMs=${Math.max(0, Math.trunc(Number(durationMs) || 0))}`,
            `ok=${save?.ok === true}`,
            `reason=${String(save?.reason || '')}`,
            `postUrl=${String(save?.postUrl || '')}`,
            `sessionId=${String(save?.sessionId || '')}`,
            `events=${Math.max(0, Number(save?.events) || 0)}`,
            `fallbackJsonSaved=${save?.fallbackJsonSaved === true}`,
            `fallbackJsonFileName=${String(save?.fallbackJsonFileName || '')}`,
            `mirrorJsonSaved=${save?.mirrorJsonSaved === true}`,
            `mirrorJsonFileName=${String(save?.mirrorJsonFileName || '')}`,
            `summaryJsonSaved=${save?.summaryJsonSaved === true}`,
            `summaryJsonFileName=${String(save?.summaryJsonFileName || '')}`,
            `transitionDebugOk=${save?.transitionDebug?.ok === true}`,
            `transitionDebugReason=${String(save?.transitionDebug?.reason || '')}`,
            `error=${String(save?.error || '')}`,
            `errorStack=${String(save?.errorStack || '')}`,
            `payloadDebug=${JSON.stringify(save?.payloadDebug || {})}`,
            `sessionSummary=${JSON.stringify(save?.sessionSummary || {})}`,
          ].join('\n');
          await postDebugOutputFile({
            fileName: `resources-debug-${String(saveRunIdBase || 'musicLabSave').trim() || 'musicLabSave'}${runSuffix}-save-result.txt`,
            text: saveResultText,
            meta: {
              source: 'music-lab-save-result-text',
              runId: String(`${saveRunIdBase}${runSuffix}`),
              stageCount: Math.max(0, Math.trunc(Number(stageCount) || 0)),
              runIndex: Math.max(0, Math.trunc(Number(runIndex) || 0)),
              repeatCount: Math.max(0, Math.trunc(Number(repeatCount) || 0)),
            },
          }, debugOutputUrl);
        } catch {}
        if (publishPerfArtifacts) {
          try {
            await persistMusicLabSaveResultOnLatestPerfResult(save, {
              queue: [`${labelPrefix}${runSuffix}`],
              notes: saveNotes || `Auto save for BS0 S${stageCount} run ${runIndex}/${repeatCount}`,
              runId: 'manual',
              runMode: 'manual',
            });
          } catch {}
          try {
            await publishMusicLabSaveDebugResult({
              label: `music-lab-save-debug${runSuffix}`,
              runId: `${saveRunIdBase}${runSuffix}`,
              ok: !!save?.ok,
              reason: String(save?.reason || ''),
              error: String(save?.error || ''),
              errorStack: String(save?.errorStack || ''),
              postUrl: String(save?.postUrl || ''),
              sessionId: String(save?.sessionId || ''),
              events: Math.max(0, Number(save?.events) || 0),
              notes: saveNotes || `Auto save for BS0 S${stageCount} run ${runIndex}/${repeatCount}`,
              sourceLabel: `${labelPrefix}${runSuffix}`,
              durationMs,
              stageCount,
              iterationIndex: runIndex,
              iterationCount: repeatCount,
            });
          } catch {}
        }
        try { stopTransport(); } catch {}
        if (!save?.ok) {
          setStatus(`BS0 S${stageCount} run ${runIndex}/${repeatCount} save failed`);
          setOutput({
            ok: false,
            stageCount,
            runIndex,
            repeatCount,
            durationMs,
            reason: String(save?.reason || 'save_failed'),
            postUrl: String(save?.postUrl || ''),
            hint: 'Ensure perf-lab results server is running and music postUrl points to /music-lab-results.',
          });
          return {
            ok: false,
            stageCount,
            runIndex,
            repeatCount,
            durationMs,
            reason: String(save?.reason || 'save_failed'),
            postUrl: String(save?.postUrl || ''),
          };
        }
      }
    }
    if (saveMusicLabEachRun) {
      if (deferMusicLabSaveUntilBatchEnd) {
        const postedBatch = await saveDeferredMusicLabBatchToResourcesGlobal({
          runId: groupedRunId,
          label: groupedScenarioName,
          notes: groupedNotes,
          scenarioName: groupedScenarioName,
          testCategory: groupedScenarioName,
          forceCompactSave: cfg.forceCompactSave === true,
          runs: deferredMusicLabSaves,
        });
        for (const detail of (Array.isArray(postedBatch?.runDetails) ? postedBatch.runDetails : [])) {
          const runIndex = Math.max(1, Math.trunc(Number(detail?.runIndex) || 1));
          const existingOutcome = runOutcomes.find((outcome) => Math.max(1, Math.trunc(Number(outcome?.runIndex) || 1)) === runIndex);
          if (!existingOutcome) continue;
          existingOutcome.saved = postedBatch?.ok === true;
          existingOutcome.reason = String(postedBatch?.reason || '');
          existingOutcome.postUrl = String(postedBatch?.postUrl || '');
          existingOutcome.sessionId = String(detail?.sessionId || existingOutcome.sessionId || '');
          existingOutcome.events = Math.max(0, Number(detail?.events) || Number(existingOutcome.events) || 0);
          existingOutcome.sessionSummary = (detail?.sessionSummary && typeof detail.sessionSummary === 'object')
            ? detail.sessionSummary
            : existingOutcome.sessionSummary;
          existingOutcome.deferredBatchPosted = true;
        }
        if (!postedBatch?.ok) {
          setStatus(`BS0 S${stageCount} deferred batch save failed`);
          setOutput({
            ok: false,
            stageCount,
            repeatCount,
            durationMs,
            reason: String(postedBatch?.reason || 'deferred_batch_save_failed'),
            postUrl: String(postedBatch?.postUrl || ''),
          });
          return {
            ok: false,
            stageCount,
            repeatCount,
            durationMs,
            reason: String(postedBatch?.reason || 'deferred_batch_save_failed'),
            postUrl: String(postedBatch?.postUrl || ''),
          };
        }
      }
      let groupedScenario = null;
      if (repeatCount > 1 && !deferMusicLabSaveUntilBatchEnd) {
        groupedScenario = await publishGroupedMusicLabScenarioBundle({
          scenarioName: groupedScenarioName,
          runId: groupedRunId,
          notes: groupedNotes,
          stageCount,
          durationMs,
          repeatCount,
          runOutcomes,
        });
      }
      if (!suppressCompletionUi) {
        setStatus(`BS0 S${stageCount} complete (${repeatCount} x ${(durationMs / 60000).toFixed(1)}m, total ${totalMinutes}m)`);
        setOutput({
          ok: true,
          stageCount,
          repeatCount,
          durationMs,
          totalMinutes,
          saves: runOutcomes,
          groupedScenario: groupedScenario || null,
        });
      }
      return {
        ok: true,
        stageCount,
        repeatCount,
        durationMs,
        totalMinutes,
        saves: runOutcomes,
        groupedScenario: groupedScenario || null,
      };
    }
    if (!suppressCompletionUi) {
      setStatus(`BS0 S${stageCount} complete (${repeatCount} x ${(durationMs / 1000).toFixed(0)}s)`);
      setOutput({ ok: true, stageCount, repeatCount, durationMs, totalMinutes, saves: runOutcomes });
    }
    return { ok: true, stageCount, repeatCount, durationMs, totalMinutes, saves: runOutcomes };
  } finally {
    try { window.__PERF_LAB_DURATION_MS = prevDur; } catch {}
    try { window.__PERF_RUN_TAG = prevTag; } catch {}
    try {
      if (hadBeatSwarmTestOverrides) window.__beatSwarmTestOverrides = clonePerfJson(prevBeatSwarmTestOverrides);
      else delete window.__beatSwarmTestOverrides;
    } catch {}
    if (prevMusicLabEnabled !== null) {
      const api = getMusicLabApiGlobal();
      if (api && typeof api.setEnabled === 'function') {
        try { api.setEnabled(prevMusicLabEnabled); } catch {}
      }
    }
    if (prevMusicLabRealtimeMetricsEnabled !== null) {
      const api = getMusicLabApiGlobal();
      if (api && typeof api.setRealtimeMetricsEnabled === 'function') {
        try { api.setRealtimeMetricsEnabled(prevMusicLabRealtimeMetricsEnabled); } catch {}
      }
    }
    if (prevMusicLabLightweightSystemEventsEnabled !== null) {
      const api = getMusicLabApiGlobal();
      if (api && typeof api.setLightweightSystemEventsEnabled === 'function') {
        try { api.setLightweightSystemEventsEnabled(prevMusicLabLightweightSystemEventsEnabled); } catch {}
      }
    }
  }
}

async function runBS0s1() { await runBS0Stage(1); }
async function runBS0s2() { await runBS0Stage(2); }
async function runBS0s3() { await runBS0Stage(3); }
async function runBS0s4() { await runBS0Stage(4); }
async function runBS0s5() { await runBS0Stage(5); }

const DEFAULT_MUSIC_TRACE_CAPTURE_CONFIG = Object.freeze({
  enabled: false,
  include: Object.freeze([
    'music_singleton_lead_group_created',
    'music_primary_lead_request',
    'music_primary_loop_coverage_status',
    'music_primary_lead_snapshot',
    'music_primary_loop_owner_trace',
    'music_composer_group_state',
    'music_group_performer_trace',
    'music_paired_dance_trace',
  ]),
  maxLines: 300,
  preferOutputDirectory: true,
  fileNamePrefix: 'resources-debug-trace',
});

async function runBS0s3MusicLabTriplet() {
  await runBS0Stage(3, {
    durationMs: 180000,
    repeatCount: 3,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_bs0_s3_3x3m',
    saveNotes: 'Beat Swarm Music Lab auto run: S3, 3 runs x 3 minutes, one file per run.',
    groupedScenarioName: 'retro_shooter_intro_pacing_s3_3x3m',
    groupedRunId: 'musicLab_bs0_s3_3x3m_scenario',
    groupedNotes: 'Beat Swarm Music Lab grouped scenario: S3, 3 runs x 3 minutes, with aggregate summary.',
    tagPrefix: 'BS0S3MusicLab3x3m',
    labelPrefix: 'BS0_stage3_beatswarm_static_fire_musiclab_3m',
    statusPrefix: 'Running BS0 S3 Music Lab playtest (3 minutes)',
    traceCapture: {
      ...DEFAULT_MUSIC_TRACE_CAPTURE_CONFIG,
      fileNamePrefix: 'resources-debug-musicLab_bs0_s3_3x3m',
    },
  });
}

async function runBS0s3MusicLabSingle() {
  await runBS0Stage(3, {
    durationMs: 180000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_bs0_s3_1x3m',
    saveNotes: 'Beat Swarm Music Lab quick run: S3, 1 run x 3 minutes.',
    groupedScenarioName: 'retro_shooter_intro_pacing_s3_1x3m',
    groupedRunId: 'musicLab_bs0_s3_1x3m_scenario',
    groupedNotes: 'Beat Swarm Music Lab grouped scenario: S3, 1 run x 3 minutes.',
    tagPrefix: 'BS0S3MusicLab1x3m',
    labelPrefix: 'BS0_stage3_beatswarm_static_fire_musiclab_1x3m',
    statusPrefix: 'Running BS0 S3 Music Lab quick playtest (3 minutes)',
    traceCapture: {
      ...DEFAULT_MUSIC_TRACE_CAPTURE_CONFIG,
      fileNamePrefix: 'resources-debug-musicLab_bs0_s3_1x3m',
    },
  });
}

async function runBS0s3MusicLabSingle5m() {
  await runBS0Stage(3, {
    durationMs: 300000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_bs0_s3_1x5m',
    saveNotes: 'Beat Swarm Music Lab structure run: S3, 1 run x 5 minutes.',
    groupedScenarioName: 'retro_shooter_intro_pacing_s3_1x5m',
    groupedRunId: 'musicLab_bs0_s3_1x5m_scenario',
    groupedNotes: 'Beat Swarm Music Lab grouped scenario: S3, 1 run x 5 minutes.',
    tagPrefix: 'BS0S3MusicLab1x5m',
    labelPrefix: 'BS0_stage3_beatswarm_static_fire_musiclab_1x5m',
    statusPrefix: 'Running BS0 S3 Music Lab structure pass (5 minutes)',
    traceCapture: {
      ...DEFAULT_MUSIC_TRACE_CAPTURE_CONFIG,
      fileNamePrefix: 'resources-debug-musicLab_bs0_s3_1x5m',
    },
  });
}

async function runBS0s3MusicLabAssessment5m() {
  await runBS0Stage(3, {
    durationMs: 300000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    saveRunIdBase: 'musicLab_bs0_s3_assessment_1x5m',
    saveNotes: 'Beat Swarm Music Lab assessment run: S3, 1 run x 5 minutes, compact save for structured review.',
    groupedScenarioName: 'retro_shooter_intro_pacing_s3_assessment_1x5m',
    groupedRunId: 'musicLab_bs0_s3_assessment_1x5m_scenario',
    groupedNotes: 'Beat Swarm Music Lab assessment scenario: S3, 1 run x 5 minutes, compact save for structured review.',
    tagPrefix: 'BS0S3MusicLabAssessment1x5m',
    labelPrefix: 'BS0_stage3_beatswarm_static_fire_musiclab_assessment_1x5m',
    statusPrefix: 'Running BS0 S3 Music Lab assessment pass (5 minutes, compact save)',
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabArrangement5m() {
  await runBS0Stage(3, {
    durationMs: 300000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    saveRunIdBase: 'musicLab_bs0_s3_arrangement_musicality_1x5m',
    saveNotes: [
      'Beat Swarm Music Lab arrangement musicality run: validate the Level 1 intro set piece, arrangement-state coverage, lead phrasing, support shaping, lane continuity, contract compliance, and visual readability.',
      'Expected: intro remains staged; body/build/cadence/recovery all appear; build favors ascending lead motion and higher support budgets; cadence uses punctuation; recovery strips support back.',
    ].join(' '),
    groupedScenarioName: 'retro_shooter_intro_pacing_s3_arrangement_musicality_1x5m',
    groupedRunId: 'musicLab_bs0_s3_arrangement_musicality_1x5m_scenario',
    groupedNotes: 'Beat Swarm Music Lab arrangement musicality scenario: 1 run x 5 minutes, compact save, focused on director-led musical arrangement rather than HP-section durability.',
    tagPrefix: 'BS0S3MusicLabArrangementMusicality1x5m',
    labelPrefix: 'BS0_stage3_beatswarm_static_fire_musiclab_arrangement_musicality_1x5m',
    statusPrefix: 'Running BS0 S3 Music Lab arrangement musicality pass (5 minutes, compact save)',
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabIntensityRamp150s() {
  await runBS0Stage(3, {
    durationMs: 150000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    beatSwarmTestOverrides: {
      musicIntensityAudition: {
        enabled: true,
        mode: 'ramp_release',
      },
    },
    saveRunIdBase: 'musicLab_bs0_s3_intensity_ramp_release_1x150s',
    saveNotes: [
      'Beat Swarm Music Lab intensity audition: intro set piece, then low, medium, build, peak, release, and settle arrangement levels.',
      'Expected: the intro continues normally into the audition; later stages add denser rhythm/lead/support/ornament layers and release strips back.',
    ].join(' '),
    groupedScenarioName: 'retro_shooter_intro_pacing_s3_intensity_ramp_release_1x150s',
    groupedRunId: 'musicLab_bs0_s3_intensity_ramp_release_1x150s_scenario',
    groupedNotes: 'Beat Swarm Music Lab intensity audition scenario: 1 run x 150 seconds, compact save, focused on hearing musical intensity transitions after the fixed intro set piece.',
    tagPrefix: 'BS0S3MusicLabIntensityRampRelease1x150s',
    labelPrefix: 'BS0_stage3_beatswarm_static_fire_musiclab_intensity_ramp_release_1x150s',
    statusPrefix: 'Running BS0 S3 Music Lab intensity ramp/release audition (150 seconds, compact save)',
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabCompositionFlow4m() {
  await runBS0Stage(3, {
    durationMs: 240000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    beatSwarmTestOverrides: {
      musicIntensityAudition: {
        enabled: true,
        mode: 'ramp_release',
      },
    },
    saveRunIdBase: 'musicLab_bs0_s3_composition_full_flow_1x4m',
    saveNotes: [
      'Beat Swarm Music Lab composition full-flow listen: normal intro set piece into low, medium, build, peak, release, and settle.',
      'Assess the music as a complete composition: identity/style, bass drive, motif recognition, section transitions, release shape, repetition, and combat-audio separation.',
    ].join(' '),
    groupedScenarioName: 'retro_shooter_intro_pacing_s3_composition_full_flow_1x4m',
    groupedRunId: 'musicLab_bs0_s3_composition_full_flow_1x4m_scenario',
    groupedNotes: 'Beat Swarm composition full-flow scenario: 1 run x 4 minutes, compact save, focused on whole-track listening rather than isolated intensity diagnosis.',
    tagPrefix: 'BS0S3MusicLabCompositionFullFlow1x4m',
    labelPrefix: 'BS0_stage3_beatswarm_static_fire_musiclab_composition_full_flow_1x4m',
    statusPrefix: 'Running BS0 S3 Music Lab composition full flow (4 minutes, compact save)',
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabCompositionPacingFlow4m() {
  await runBS0Stage(3, {
    durationMs: 240000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    beatSwarmTestOverrides: {
      musicIntensityAudition: {
        enabled: true,
        mode: 'composition_loop',
      },
    },
    saveRunIdBase: 'musicLab_bs0_s3_composition_pacing_flow_1x4m',
    saveNotes: [
      'Beat Swarm Music Lab composition pacing flow: normal intro set piece, then repeated low/medium/build/peak/release/short-settle cycles.',
      'Assess whether music and enemy presentation can breathe, resolve, and regain momentum without spending the rest of the run in settle.',
    ].join(' '),
    groupedScenarioName: 'retro_shooter_intro_pacing_s3_composition_pacing_flow_1x4m',
    groupedRunId: 'musicLab_bs0_s3_composition_pacing_flow_1x4m_scenario',
    groupedNotes: 'Beat Swarm composition pacing scenario: 1 run x 4 minutes, compact save, focused on repeated music pacing cycles instead of a single ramp into long settle.',
    tagPrefix: 'BS0S3MusicLabCompositionPacingFlow1x4m',
    labelPrefix: 'BS0_stage3_beatswarm_static_fire_musiclab_composition_pacing_flow_1x4m',
    statusPrefix: 'Running BS0 S3 Music Lab composition pacing flow (4 minutes, compact save)',
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabTapOrbFoundationDebug75s() {
  const debugPattern = [
    true, false, false, true, false, false, false, false,
    false, false, true, false, false, false, true, false,
  ];
  const debugPatternKey = ['10010000', '00100010'];
  await runBS0Stage(3, {
    durationMs: 75000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    beatSwarmTestOverrides: {
      musicIntensityAudition: {
        enabled: true,
        mode: 'fixed_section',
        fixedSection: 'low',
        introBars: 0,
      },
    },
    async setupAfterPrepare() {
      const debugApi = window.__beatSwarmDebug;
      const modeApi = window.BeatSwarmMode;
      const apply = typeof debugApi?.applyTapOrbFoundationDebugPattern === 'function'
        ? debugApi.applyTapOrbFoundationDebugPattern.bind(debugApi)
        : (typeof modeApi?.applyTapOrbFoundationDebugPattern === 'function'
          ? modeApi.applyTapOrbFoundationDebugPattern.bind(modeApi)
          : null);
      if (typeof apply !== 'function') {
        throw new Error('tap_orb_foundation_debug_api_unavailable');
      }
      const result = apply(debugPattern, {
        source: 'perf_lab_tap_orb_foundation_debug',
        instrumentId: 'BASS TONE 3',
        note: 'C3',
      });
      const bassTheme = (() => {
        try { return window.BeatSwarmMode?.getPlayerMusicTheme?.('bassDrive') || null; } catch { return null; }
      })();
      try {
        window.__beatSwarmTapOrbFoundationDebugExpected = {
          patternChain: debugPatternKey.slice(),
          instrumentId: 'BASS TONE 3',
          note: 'C3',
          result,
          bassTheme,
        };
      } catch {}
      setOutput({
        ok: true,
        setup: 'tap_orb_foundation_debug_pattern_applied',
        expectedPatternChain: debugPatternKey,
        expectedInstrumentId: 'BASS TONE 3',
        expectedNote: 'C3',
        result,
        bassTheme,
      });
    },
    saveRunIdBase: 'musicLab_bs0_s3_tap_orb_foundation_debug_1x75s',
    saveNotes: [
      'Beat Swarm Music Lab tap-orb foundation debug: seed the completed tap-orb Bass Drive motif as two 8-step toys, then run fixed Low Intensity with no intro.',
      `Expected Bass Drive patternChain=${debugPatternKey.join('|')}, instrument=BASS TONE 3, note=C3.`,
      'Validate that the committed pause-menu Bass Drive motif and the director foundation lane match the seeded two-toy rhythm, without instrument substitution.',
    ].join(' '),
    groupedScenarioName: 'retro_shooter_tap_orb_foundation_debug_1x75s',
    groupedRunId: 'musicLab_bs0_s3_tap_orb_foundation_debug_1x75s_scenario',
    groupedNotes: `Tap-orb foundation debug scenario: expected two-toy Bass Drive pattern ${debugPatternKey.join('|')} at BASS TONE 3 / C3.`,
    tagPrefix: 'BS0S3TapOrbFoundationDebug1x75s',
    labelPrefix: 'BS0_stage3_beatswarm_tap_orb_foundation_debug_1x75s',
    statusPrefix: 'Running BS0 S3 tap-orb foundation commit debug (75 seconds, compact save)',
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabAccentRewriteDebug90s() {
  await runBS0Stage(3, {
    durationMs: 90000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    beatSwarmTestOverrides: {
      musicIntensityAudition: {
        enabled: true,
        mode: 'fixed_section',
        fixedSection: 'medium',
        introBars: 0,
      },
    },
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startTapOrbAccentRewriteEvent !== 'function') {
        throw new Error('accent_rewrite_debug_api_unavailable');
      }
      const result = modeApi.startTapOrbAccentRewriteEvent({
        source: 'perf_lab_accent_rewrite_debug',
        reason: 'accent_rewrite_lab',
        durationBars: 16,
      });
      try {
        window.__beatSwarmAccentRewriteDebugExpected = {
          mode: 'tap_orb_accent_rewrite',
          expectedTheme: 'accentRhythm',
          expectedInstrumentFromTheme: 'CLICK PERCUSSION SHORT',
          traceEvents: [
            'beat_swarm_music_rewrite_event_requested',
            'beat_swarm_music_rewrite_event_started',
            'tap_orb_accent_rewrite_activated',
            'tap_orb_accent_rewrite_committed_to_theme',
            'beat_swarm_music_rewrite_event_completed',
          ],
          result,
        };
      } catch {}
      setOutput({
        ok: true,
        setup: 'tap_orb_accent_rewrite_started',
        notes: 'Collect eight tap orbs. The saved Music Lab output should show accent rewrite activation and commit events, and the pause-menu Accent Rhythm should match the collected two-toy pattern.',
        result,
      });
    },
    saveRunIdBase: 'musicLab_bs0_s3_accent_rewrite_tap_orb_debug_1x90s',
    saveNotes: [
      'Beat Swarm Music Lab accent rewrite debug: fixed Medium Intensity, intro skipped, immediately starts a tap-orb Accent Rhythm rewrite event.',
      'Expected result: eight collected orb slots become the two-toy Accent Rhythm motif, using the existing Accent Rhythm instrument/note.',
      'Use tap_orb_accent_rewrite_committed_to_theme and beat_swarm_music_rewrite_event_completed to verify the event lifecycle and committed motif.',
    ].join(' '),
    groupedScenarioName: 'retro_shooter_accent_rewrite_tap_orb_debug_1x90s',
    groupedRunId: 'musicLab_bs0_s3_accent_rewrite_tap_orb_debug_1x90s_scenario',
    groupedNotes: 'Accent rewrite debug scenario: tap-orb interaction authors the Accent Rhythm player motif during a fixed Medium Intensity run.',
    tagPrefix: 'BS0S3AccentRewriteTapOrbDebug1x90s',
    labelPrefix: 'BS0_stage3_beatswarm_accent_rewrite_tap_orb_debug_1x90s',
    statusPrefix: 'Running BS0 S3 accent rewrite tap-orb debug (90 seconds, compact save)',
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabMusicMissileRewriteDebug120s(options = null) {
  const opts = options && typeof options === 'object' ? options : {};
  const themeId = String(opts.themeId || 'accentRhythm').trim() || 'accentRhythm';
  const laneId = String(opts.laneId || 'secondary_loop_lane').trim() || 'secondary_loop_lane';
  const expectedInstrument = String(opts.expectedInstrument || (laneId === 'foundation_lane' ? 'BASS TONE 3' : 'CLICK PERCUSSION SHORT')).trim();
  const targetSlug = `${themeId}_${laneId}`.replace(/[^a-z0-9]+/gi, '_').toLowerCase();
  const targetLabel = themeId === 'bassDrive' ? 'Bass Drive' : (themeId === 'accentRhythm' ? 'Accent Rhythm' : themeId);
  const durationMs = Math.max(30000, Math.trunc(Number(opts.durationMs) || 120000));
  const durationSeconds = Math.round(durationMs / 1000);
  const followupEvents = Array.isArray(opts.followupEvents) ? opts.followupEvents.filter(Boolean) : [];
  await runBS0Stage(3, {
    durationMs,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    beatSwarmTestOverrides: {
      musicIntensityAudition: {
        enabled: true,
        mode: 'fixed_section',
        fixedSection: 'medium',
        introBars: 0,
      },
    },
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startMusicMissileRhythmRewriteEvent !== 'function') {
        throw new Error('music_missile_rewrite_debug_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const result = modeApi.startMusicMissileRhythmRewriteEvent({
        themeId,
        laneId,
        source: 'perf_lab_music_missile_rewrite',
        reason: `music_missile_${targetSlug}_rewrite_lab`,
        durationBars: 4096,
      });
      if (followupEvents.length) {
        const firstEventId = String(result?.activeEvent?.id || '').trim();
        void (async () => {
          const deadline = Date.now() + Math.max(30000, durationMs - 30000);
          let previousEventId = firstEventId;
          let previousInteraction = 'music_missile';
          for (let index = 0; index < followupEvents.length; index += 1) {
            let completed = false;
            while (Date.now() < deadline) {
              await waitForPerfLabMs(500);
              const snapshot = modeApi.getMusicRewriteEventSnapshot?.() || {};
              completed = Array.isArray(snapshot.history)
                && snapshot.history.some((entry) => String(entry?.id || '').trim() === previousEventId && entry?.status === 'complete');
              if (completed) break;
            }
            if (!completed) throw new Error(`event_completion_timeout:${previousEventId}`);
            if (previousInteraction === 'music_missile') {
              while (Date.now() < deadline && modeApi.getMusicMissileEventSnapshot?.()?.postCompletePlaybackActive === true) {
                await waitForPerfLabMs(250);
              }
            } else if (previousInteraction === 'tap_orb') {
              while (Date.now() < deadline && modeApi.getTapOrbEventSnapshot?.()?.active === true) {
                await waitForPerfLabMs(250);
              }
            }
            const next = followupEvents[index] || {};
            const interaction = String(next.interaction || 'tap_orb').trim().toLowerCase();
            const nextThemeId = String(next.themeId || 'accentRhythm').trim() || 'accentRhythm';
            const nextLaneId = String(next.laneId || 'secondary_loop_lane').trim() || 'secondary_loop_lane';
            const startEvent = interaction === 'music_missile'
              ? modeApi.startMusicMissileRhythmRewriteEvent
              : modeApi.startTapOrbRhythmRewriteEvent;
            const nextResult = startEvent?.({
              themeId: nextThemeId,
              laneId: nextLaneId,
              source: 'perf_lab_rhythm_reuse_matrix',
              reason: `${interaction}_${nextThemeId}_${nextLaneId}_reuse_matrix`,
              durationBars: 4096,
            });
            previousEventId = String(nextResult?.activeEvent?.id || '').trim();
            previousInteraction = interaction;
            if (!previousEventId) throw new Error(`event_start_failed:${index + 2}:${interaction}:${nextThemeId}`);
            setOutput({
              ok: true,
              setup: 'rhythm_reuse_matrix_event_started',
              eventNumber: index + 2,
              interaction,
              nextThemeId,
              nextLaneId,
              nextResult,
            });
          }
        })().catch((err) => {
          setOutput({ ok: false, error: `rhythm_reuse_sequence_failed:${String(err?.message || err)}` });
        });
      }
      try {
        window.__beatSwarmMusicMissileDebugExpected = {
          mode: 'music_missile_rhythm_rewrite',
          expectedTheme: themeId,
          expectedLane: laneId,
          expectedInstrumentFromTheme: expectedInstrument,
          traceEvents: [
            'music_missile_rewrite_started',
            'music_missile_carrier_spawned',
            'music_missile_pickup_spawned',
            'music_missile_collected',
            'music_missile_released',
            'music_missile_impact_queued',
            'music_missile_quantized_explosion',
            'music_missile_motif_hit',
            'music_missile_rewrite_committed_to_theme',
          ],
          result,
        };
      } catch {}
      setOutput({
        ok: true,
        setup: 'music_missile_rhythm_rewrite_started',
        notes: `Kill marked carriers, collect their pickups, then release orbiting music missiles. Eight quantized explosions should commit ${targetLabel} on ${laneId}.`,
        result,
      });
    },
    saveRunIdBase: `musicLab_bs0_s3_music_missile_${targetSlug}_rewrite_1x${durationSeconds}s`,
    saveNotes: [
      `Beat Swarm Music Lab music-missile rewrite debug targeting ${targetLabel} on ${laneId}: fixed Medium Intensity with intro skipped.`,
      'Marked enemies drop arena-anchored pickups. Pickups create wide-orbit music missiles.',
      `Release or orbit-ram impacts detonate on quantized steps and author the two-toy ${targetLabel} motif.`,
    ].join(' '),
    groupedScenarioName: `retro_shooter_music_missile_${targetSlug}_rewrite_1x${durationSeconds}s`,
    groupedRunId: `musicLab_bs0_s3_music_missile_${targetSlug}_rewrite_1x${durationSeconds}s_scenario`,
    groupedNotes: `Music missile interaction authors ${targetLabel} from eight quantized missile explosions.`,
    tagPrefix: `BS0S3MusicMissile${targetSlug}Rewrite1x${durationSeconds}s`,
    labelPrefix: `BS0_stage3_beatswarm_music_missile_${targetSlug}_rewrite_1x${durationSeconds}s`,
    statusPrefix: `Running BS0 S3 music missile ${targetLabel} rewrite (${durationSeconds} seconds, compact save)`,
    traceCapture: { enabled: false },
  });
}

async function runBS0s3MusicLabPinballBouncerRewriteDebug120s(options = null) {
  const opts = options && typeof options === 'object' ? options : {};
  const themeId = String(opts.themeId || 'accentRhythm').trim() || 'accentRhythm';
  const laneId = String(opts.laneId || 'secondary_loop_lane').trim() || 'secondary_loop_lane';
  const durationMs = Math.max(30000, Math.trunc(Number(opts.durationMs) || 120000));
  const durationSeconds = Math.max(1, Math.round(durationMs / 1000));
  await runBS0Stage(3, {
    durationMs,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    beatSwarmTestOverrides: {
      musicIntensityAudition: {
        enabled: true,
        mode: 'fixed_section',
        fixedSection: 'medium',
        introBars: 0,
      },
    },
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startPinballBouncerRhythmRewriteEvent !== 'function') {
        throw new Error('pinball_bouncer_rewrite_debug_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const result = modeApi.startPinballBouncerRhythmRewriteEvent({
        themeId,
        laneId,
        source: 'perf_lab_pinball_bouncer_rewrite',
        reason: `pinball_bouncer_${themeId}_${laneId}_rewrite_lab`,
        durationBars: 4096,
      });
      try {
        window.__beatSwarmPinballBouncerDebugExpected = {
          mode: 'pinball_bouncer_rhythm_rewrite',
          expectedTheme: themeId,
          expectedLane: laneId,
          traceEvents: [
            'pinball_bouncer_rewrite_started',
            'pinball_bouncer_spawned',
            'pinball_bouncer_hit_queued',
            'pinball_bouncer_quantized_impact',
            'pinball_bouncer_motif_hit',
            'pinball_bouncer_rewrite_committed_to_theme',
          ],
          result,
        };
      } catch {}
      setOutput({
        ok: true,
        setup: 'pinball_bouncer_rhythm_rewrite_started',
        notes: 'Bump eight pinball bouncers. Each collision should bounce the player, queue a quantized note, remove the bouncer, and commit the authored motif.',
        result,
      });
    },
    saveRunIdBase: `musicLab_bs0_s3_pinball_bouncer_${themeId}_${laneId}_rewrite_1x${durationSeconds}s`,
    saveNotes: [
      `Beat Swarm Music Lab pinball-bouncer rewrite debug targeting ${themeId} on ${laneId}: fixed Medium Intensity with intro skipped.`,
      'Bouncers stage into the arena, become bright on arrival, then author rhythm notes when the player collides with them.',
    ].join(' '),
    groupedScenarioName: `retro_shooter_pinball_bouncer_${themeId}_${laneId}_rewrite_1x${durationSeconds}s`,
    groupedRunId: `musicLab_bs0_s3_pinball_bouncer_${themeId}_${laneId}_rewrite_1x${durationSeconds}s_scenario`,
    groupedNotes: `Pinball bouncer interaction authors ${themeId} from eight quantized collision bounces.`,
    tagPrefix: `BS0S3PinballBouncer${themeId}Rewrite1x${durationSeconds}s`,
    labelPrefix: `BS0_stage3_beatswarm_pinball_bouncer_${themeId}_${laneId}_rewrite_1x${durationSeconds}s`,
    statusPrefix: `Running BS0 S3 pinball bouncer ${themeId} rewrite (${durationSeconds} seconds, compact save)`,
    traceCapture: { enabled: false },
  });
}

async function runBS0s3MusicLabGateStartTapOrbHandoffDebug150s() {
  await runBS0Stage(3, {
    durationMs: 180000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    async setupAfterPrepare() {
      const api = getBeatSwarmApi();
      if (!api || typeof api.enter !== 'function') {
        throw new Error('beat_swarm_api_unavailable');
      }
      try { api.exit?.(); } catch {}
      await waitForPerfLabMs(80);
      try { api.enter?.({ weaponGateIntro: true, weaponGateSequence: 'missiles_bouncers' }); } catch (err) {
        throw new Error(`weapon_gate_intro_start_failed:${String(err?.message || err)}`);
      }
      try { if (!isRunning()) startTransport(); } catch {}
      try {
        window.__beatSwarmGateStartTapOrbDebugExpected = {
          mode: 'gate_missile_pinball_lead_ball_sequence',
          expectedMissileTheme: 'bassDrive',
          expectedPinballTheme: 'accentRhythm',
          expectedLeadTheme: 'leadTheme',
          traceEvents: [
            'music_missile_rewrite_started',
            'music_missile_quantized_explosion',
            'music_missile_rewrite_committed_to_theme',
            'pinball_bouncer_rewrite_started',
            'pinball_bouncer_quantized_impact',
            'pinball_bouncer_rewrite_committed_to_theme',
            'lead_ball_rewrite_started',
            'lead_ball_quantized_impact',
            'lead_ball_rewrite_committed_to_theme',
          ],
        };
      } catch {}
      setOutput({
        ok: true,
        setup: 'weapon_gate_missile_pinball_lead_ball_sequence_started',
        notes: 'Complete the gate corridor, author Bass Drive with rocket pickups, author Accent Rhythm with pinball bouncers, then author Lead Theme with the two-ball pickup event.',
      });
    },
    saveRunIdBase: 'musicLab_bs0_s3_gate_missile_pinball_lead_ball_sequence_1x180s',
    saveNotes: [
      'Beat Swarm Music Lab onboarding sequence: run the real gate corridor, event-driven music-missile Bass Drive creation, pinball-bouncer Accent Rhythm creation, then two-ball Lead Theme creation.',
      'Use the missile, pinball-bouncer, and lead-ball rewrite commit events to compare committed motifs against director lane playback.',
      'Expected result: the weapon, Bass Drive, Accent Rhythm, and Lead Theme motifs commit in order without replacing or interrupting the preceding motif.',
    ].join(' '),
    groupedScenarioName: 'retro_shooter_gate_missile_pinball_lead_ball_sequence_1x180s',
    groupedRunId: 'musicLab_bs0_s3_gate_missile_pinball_lead_ball_sequence_1x180s_scenario',
    groupedNotes: 'Complete onboarding chain: gate weapon motif, music-missile Bass Drive, pinball-bouncer Accent Rhythm, and two-ball Lead Theme events.',
    tagPrefix: 'BS0S3GateMissilePinballLeadBallSequence1x180s',
    labelPrefix: 'BS0_stage3_beatswarm_gate_missile_pinball_lead_ball_sequence_1x180s',
    statusPrefix: 'Running BS0 S3 gate + missiles + bouncers + balls (180 seconds, compact save)',
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabGateToLeadGatesDebug120s() {
  await runBS0Stage(3, {
    durationMs: 60000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    beatSwarmTestOverrides: {
      leadGateAuthoringOnly: true,
    },
    async setupAfterPrepare() {
      const api = getBeatSwarmApi();
      if (!api || typeof api.enter !== 'function') {
        throw new Error('beat_swarm_api_unavailable');
      }
      try { api.exit?.(); } catch {}
      await waitForPerfLabMs(80);
      try { window.__BEAT_SWARM_LEAD_GATE_DEBUG = true; } catch {}
      try { api.enter?.({ weaponGateIntro: true, weaponGateSequence: 'lead_gates' }); } catch (err) {
        throw new Error(`weapon_gate_lead_gate_start_failed:${String(err?.message || err)}`);
      }
      try { if (!isRunning()) startTransport(); } catch {}
      try {
        window.__beatSwarmGateToLeadGatesDebugExpected = {
          mode: 'gate_to_lead_gates',
          expectedTheme: 'leadTheme',
          expectedLane: 'primary_loop_lane',
          debugFlag: '__BEAT_SWARM_LEAD_GATE_DEBUG',
          traceEvents: [
            'lead_gate_rewrite_started',
            'lead_gate_note_selected',
            'lead_gate_rewrite_committed_to_theme',
            'music_primary_loop_lane_emitted',
          ],
        };
      } catch {}
      setOutput({
        ok: true,
        setup: 'weapon_gate_to_lead_gates_started',
        notes: 'Complete the weapon gate corridor, then watch the lead gates cross the arena centre. Broader music variation is suppressed for this focused 60s test.',
      });
    },
    saveRunIdBase: 'musicLab_bs0_s3_gate_to_lead_gates_debug_1x60s',
    saveNotes: [
      'Beat Swarm Music Lab lead-gate debug: run the real weapon gate corridor, then directly enter the lead-theme gate authoring event.',
      'Focused authoring-only override suppresses foundation, accent, support, sparkle, and answer lanes so broader arrangement variation does not mask the gate test.',
      'Console flag __BEAT_SWARM_LEAD_GATE_DEBUG is enabled; inspect [BeatSwarmLeadGate] motion/select/complete logs for gate speed and commit diagnostics.',
      'Expected result: gates move visibly across the arena, select notes at centre crossing, commit leadTheme, and primary_loop_lane repeats afterward.',
    ].join(' '),
    groupedScenarioName: 'retro_shooter_gate_to_lead_gates_debug_1x60s',
    groupedRunId: 'musicLab_bs0_s3_gate_to_lead_gates_debug_1x60s_scenario',
    groupedNotes: 'Isolated gate corridor into lead-theme gate authoring debug scenario.',
    tagPrefix: 'BS0S3GateToLeadGatesDebug1x60s',
    labelPrefix: 'BS0_stage3_beatswarm_gate_to_lead_gates_debug_1x60s',
    statusPrefix: 'Running BS0 S3 gate -> lead gates debug (60 seconds, compact save)',
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabGateToLeadBallDebug60s() {
  await runBS0Stage(3, {
    durationMs: 60000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    beatSwarmTestOverrides: {
      leadGateAuthoringOnly: true,
    },
    async setupAfterPrepare() {
      const api = getBeatSwarmApi();
      if (!api || typeof api.enter !== 'function') {
        throw new Error('beat_swarm_api_unavailable');
      }
      try { api.exit?.(); } catch {}
      await waitForPerfLabMs(80);
      try { window.__BEAT_SWARM_LEAD_BALL_DEBUG = true; } catch {}
      try { api.enter?.({ weaponGateIntro: true, weaponGateSequence: 'lead_ball' }); } catch (err) {
        throw new Error(`weapon_gate_lead_ball_start_failed:${String(err?.message || err)}`);
      }
      try { if (!isRunning()) startTransport(); } catch {}
      try {
        window.__beatSwarmGateToLeadBallDebugExpected = {
          mode: 'gate_to_lead_ball',
          expectedTheme: 'leadTheme',
          expectedLane: 'primary_loop_lane',
          traceEvents: [
            'lead_ball_rewrite_requested',
            'lead_ball_rewrite_started',
            'lead_ball_motif_hit',
            'lead_ball_rewrite_committed_to_theme',
            'music_primary_loop_lane_emitted',
          ],
        };
      } catch {}
      setOutput({
        ok: true,
        setup: 'weapon_gate_to_lead_ball_started',
        notes: 'Complete the weapon gate corridor, then bump the lead ball so it authors a lead motif from quantized enemy impacts.',
      });
    },
    saveRunIdBase: 'musicLab_bs0_s3_gate_to_lead_ball_debug_1x60s',
    saveNotes: [
      'Beat Swarm Music Lab lead-ball debug: real weapon gate corridor, then lead ball authoring event.',
      'Focused authoring-only override suppresses broader arrangement lanes so the lead-ball motif can be heard clearly.',
      'Expected result: the ball hits enemies on quantized beats, commits leadTheme, and primary_loop_lane repeats afterward.',
    ].join(' '),
    groupedScenarioName: 'retro_shooter_gate_to_lead_ball_debug_1x60s',
    groupedRunId: 'musicLab_bs0_s3_gate_to_lead_ball_debug_1x60s_scenario',
    groupedNotes: 'Isolated gate corridor into lead-ball theme authoring debug scenario.',
    tagPrefix: 'BS0S3GateToLeadBallDebug1x60s',
    labelPrefix: 'BS0_stage3_beatswarm_gate_to_lead_ball_debug_1x60s',
    statusPrefix: 'Running BS0 S3 gate -> lead ball debug (60 seconds, compact save)',
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabIntensityRampDebug150s() {
  await runBS0Stage(3, {
    durationMs: 150000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    allowLargeSave: false,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    beatSwarmTestOverrides: {
      musicIntensityAudition: {
        enabled: true,
        mode: 'ramp_release',
      },
    },
    saveRunIdBase: 'musicLab_bs0_s3_intensity_ramp_debug_compact_1x150s',
    saveNotes: [
      'Beat Swarm Music Lab intensity audition debug: compact save for checking stage metrics and recent/pinned event detail without large resource files.',
      'Use full-save instrumentation only temporarily when exact full-flow event attribution is needed.',
    ].join(' '),
    groupedScenarioName: 'retro_shooter_intro_pacing_s3_intensity_ramp_debug_compact_1x150s',
    groupedRunId: 'musicLab_bs0_s3_intensity_ramp_debug_compact_1x150s_scenario',
    groupedNotes: 'Beat Swarm Music Lab compact intensity audition debug: 1 run x 150 seconds, compact save.',
    tagPrefix: 'BS0S3MusicLabIntensityRampDebugCompact1x150s',
    labelPrefix: 'BS0_stage3_beatswarm_static_fire_musiclab_intensity_ramp_debug_compact_1x150s',
    statusPrefix: 'Running BS0 S3 Music Lab intensity ramp debug (150 seconds, compact save)',
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabIntensityListenSection(sectionIdLike = 'low') {
  const requestedSectionId = String(sectionIdLike || 'low').trim().toLowerCase() || 'low';
  const releaseOnly = requestedSectionId === 'release_only' || requestedSectionId === 'release-only';
  const sectionId = releaseOnly ? 'release' : requestedSectionId;
  const allowedSections = new Set(['silent', 'low', 'medium', 'build', 'peak', 'release', 'settle']);
  const section = allowedSections.has(sectionId) ? sectionId : 'low';
  const sectionLabel = section === 'silent'
    ? 'Silent / Weapon Only'
    : (section === 'release'
      ? (releaseOnly ? 'Release Only / No Intro' : 'Peak -> Release')
      : `${section.charAt(0).toUpperCase()}${section.slice(1)} Intensity`);
  const sectionSlug = section === 'release'
    ? (releaseOnly ? 'release_only' : 'peak_release')
    : section.replace(/[^a-z0-9]+/g, '_');
  const durationMs = section === 'peak' ? 45000 : (section === 'release' ? 60000 : 90000);
  const durationLabel = section === 'peak' ? '45s' : (section === 'release' ? '60s' : '90s');
  const auditionMode = section === 'release' && !releaseOnly ? 'release_transition' : 'fixed_section';
  await runBS0Stage(3, {
    durationMs,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    beatSwarmTestOverrides: {
      musicIntensityAudition: {
        enabled: true,
        mode: auditionMode,
        fixedSection: section,
        introBars: (section === 'peak' || section === 'release') ? 0 : 12,
      },
    },
    saveRunIdBase: `musicLab_bs0_s3_listen_${sectionSlug}_1x${durationLabel}`,
    saveNotes: [
      section === 'peak'
        ? 'Beat Swarm Music Lab focused listening run: fixed Peak Intensity from the start; intro skipped for motif clarity testing.'
        : (section === 'release'
          ? (releaseOnly
            ? 'Beat Swarm Music Lab focused listening run: fixed Release from the start; intro skipped for isolated release tuning.'
            : 'Beat Swarm Music Lab focused listening run: Peak, then Release, then Settle, so both release entry and exit are tested.')
          : `Beat Swarm Music Lab focused listening run: normal intro, then fixed ${sectionLabel} arrangement state.`),
      'Listen for clarity of player-generated motifs, motif repetition fatigue, lane balance, and whether the state has a distinct musical identity.',
    ].join(' '),
    groupedScenarioName: `retro_shooter_intro_pacing_s3_listen_${sectionSlug}_1x${durationLabel}`,
    groupedRunId: `musicLab_bs0_s3_listen_${sectionSlug}_1x${durationLabel}_scenario`,
    groupedNotes: `Beat Swarm focused listening scenario: ${sectionLabel}, 1 run x ${durationLabel}, compact save.`,
    tagPrefix: `BS0S3MusicLabListen${sectionLabel.replace(/[^A-Za-z0-9]+/g, '')}1x${durationLabel}`,
    labelPrefix: `BS0_stage3_beatswarm_static_fire_musiclab_listen_${sectionSlug}_1x${durationLabel}`,
    statusPrefix: `Running BS0 S3 focused listening pass: ${sectionLabel} (${durationLabel}, compact save)`,
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabHpSections5m() {
  const hpSections = [
    { id: 'baseline_1x', label: '1x HP baseline', startBar: 0, endBar: 56, multiplier: 1 },
    { id: 'durability_1_5x', label: '1.5x HP durability', startBar: 56, endBar: 100, multiplier: 1.5 },
    { id: 'durability_2x', label: '2x HP durability', startBar: 100, multiplier: 2 },
  ];
  await runBS0Stage(3, {
    durationMs: 300000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    beatSwarmTestOverrides: {
      enemyHealthSections: hpSections,
      enemyHealthSectionEmitNonce: `hp-sections-${Date.now()}`,
    },
    saveRunIdBase: 'musicLab_bs0_s3_hp_sections_1x5m',
    saveNotes: `Beat Swarm Music Lab HP-section assessment: validate music-role readability under combat durability changes. hpSections=${JSON.stringify(hpSections)}`,
    groupedScenarioName: 'retro_shooter_intro_pacing_s3_hp_sections_1x5m',
    groupedRunId: 'musicLab_bs0_s3_hp_sections_1x5m_scenario',
    groupedNotes: 'Beat Swarm Music Lab HP-section scenario: 1x, 1.5x, and 2x enemy HP sections in one 5-minute compact save.',
    tagPrefix: 'BS0S3MusicLabHpSections1x5m',
    labelPrefix: 'BS0_stage3_beatswarm_static_fire_musiclab_hp_sections_1x5m',
    statusPrefix: 'Running BS0 S3 Music Lab HP-section assessment (5 minutes, compact save)',
    traceCapture: {
      enabled: false,
    },
  });
}

async function runBS0s3MusicLabSingle1m() {
  await runBS0Stage(3, {
    durationMs: 60000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_bs0_s3_1x1m',
    saveNotes: 'Beat Swarm Music Lab quick run: S3, 1 run x 1 minute.',
    groupedScenarioName: 'retro_shooter_intro_pacing_s3_1x1m',
    groupedRunId: 'musicLab_bs0_s3_1x1m_scenario',
    groupedNotes: 'Beat Swarm Music Lab grouped scenario: S3, 1 run x 1 minute.',
    tagPrefix: 'BS0S3MusicLab1x1m',
    labelPrefix: 'BS0_stage3_beatswarm_static_fire_musiclab_1x1m',
    statusPrefix: 'Running BS0 S3 Music Lab quick playtest (1 minute)',
    traceCapture: {
      ...DEFAULT_MUSIC_TRACE_CAPTURE_CONFIG,
      fileNamePrefix: 'resources-debug-musicLab_bs0_s3_1x1m',
    },
  });
}

async function runGunnerCombatProfilesDebug() {
  await runBS0Stage(1, {
    durationMs: 60000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_gunner_combat_profiles_1x60s',
    saveNotes: 'Gunner combat profile test: 16 beats each of straight, spread, and burst, followed by all patterns together.',
    groupedScenarioName: 'beat_swarm_gunner_combat_profiles_1x60s',
    groupedRunId: 'musicLab_gunner_combat_profiles_1x60s_scenario',
    groupedNotes: 'Focused Gunner vertical slice using production enemy combat scheduling and hostile projectiles.',
    tagPrefix: 'GunnerCombatProfiles1x60s',
    labelPrefix: 'BS0_gunner_combat_profiles_1x60s',
    statusPrefix: 'Running Gunner combat profiles: straight, spread, burst, combined',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startGunnerCombatTest !== 'function') {
        throw new Error('gunner_combat_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startGunnerCombatTest();
      if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 3) {
        throw new Error('gunner_combat_test_spawn_failed');
      }
      try { window.__BEAT_SWARM_GUNNER_COMBAT_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_test_phase',
        'enemy_combat_attack',
      ],
      maxLines: 420,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-gunner-combat-profiles',
    },
  });
}

async function runSeekerCombatProfilesDebug() {
  await runBS0Stage(1, {
    durationMs: 60000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_seeker_combat_profiles_1x60s',
    saveNotes: 'Seeker combat profile test: 16 beats of pursuit with a strong homing shot, 16 beats of interception with a weak homing swarm, then both together.',
    groupedScenarioName: 'beat_swarm_seeker_combat_profiles_1x60s',
    groupedRunId: 'musicLab_seeker_combat_profiles_1x60s_scenario',
    groupedNotes: 'Focused Seeker vertical slice using production movement, combat scheduling, and hostile projectiles.',
    tagPrefix: 'SeekerCombatProfiles1x60s',
    labelPrefix: 'BS0_seeker_combat_profiles_1x60s',
    statusPrefix: 'Running Seeker combat profiles: pursuit, interception, combined',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startSeekerCombatTest !== 'function') {
        throw new Error('seeker_combat_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startSeekerCombatTest();
      if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 2) {
        throw new Error('seeker_combat_test_spawn_failed');
      }
      try { window.__BEAT_SWARM_SEEKER_COMBAT_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_test_phase',
        'enemy_combat_attack',
      ],
      maxLines: 420,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-seeker-combat-profiles',
    },
  });
}

async function runLaserSpinnerCombatProfilesDebug() {
  await runBS0Stage(1, {
    durationMs: 60000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_laser_spinner_profiles_1x60s',
    saveNotes: 'Laser Spinner test: 16 beats of a sweeping laser, 16 beats of rotating radial spokes, then both hazards together.',
    groupedScenarioName: 'beat_swarm_laser_spinner_profiles_1x60s',
    groupedRunId: 'musicLab_laser_spinner_profiles_1x60s_scenario',
    groupedNotes: 'Focused Laser Spinner vertical slice using production combat scheduling and a persistent hostile hazard runtime.',
    tagPrefix: 'LaserSpinnerProfiles1x60s',
    labelPrefix: 'BS0_laser_spinner_profiles_1x60s',
    statusPrefix: 'Running Laser Spinner profiles: sweep, radial, combined',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startLaserSpinnerCombatTest !== 'function') {
        throw new Error('laser_spinner_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startLaserSpinnerCombatTest();
      if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 2) {
        throw new Error('laser_spinner_test_spawn_failed');
      }
      try { window.__BEAT_SWARM_LASER_SPINNER_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_test_phase',
        'enemy_combat_attack',
        'enemy_combat_anchor_ready',
        'enemy_laser_activated',
        'enemy_laser_locked',
        'enemy_laser_player_contact',
      ],
      maxLines: 520,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-laser-spinner-profiles',
    },
  });
}

async function runShapeCasterCombatProfilesDebug() {
  await runBS0Stage(1, {
    durationMs: 60000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_shape_caster_profiles_1x60s',
    saveNotes: 'Shape Caster test: 16 beats of safe-inside approach regions, 16 beats of safe-outside evacuation regions, then both together.',
    groupedScenarioName: 'beat_swarm_shape_caster_profiles_1x60s',
    groupedRunId: 'musicLab_shape_caster_profiles_1x60s_scenario',
    groupedNotes: 'Focused Shape Caster vertical slice using production combat scheduling, persistent regions, and surface-field destruction.',
    tagPrefix: 'ShapeCasterProfiles1x60s',
    labelPrefix: 'BS0_shape_caster_profiles_1x60s',
    statusPrefix: 'Running Shape Caster profiles: safe inside, safe outside, combined',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startShapeCasterCombatTest !== 'function') {
        throw new Error('shape_caster_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startShapeCasterCombatTest();
      if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 2) {
        throw new Error('shape_caster_test_spawn_failed');
      }
      try { window.__BEAT_SWARM_SHAPE_CASTER_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_test_phase',
        'enemy_combat_attack',
        'enemy_shape_activated',
        'enemy_shape_player_contact',
      ],
      maxLines: 520,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-shape-caster-profiles',
    },
  });
}

async function runChargerCombatProfilesDebug() {
  await runBS0Stage(1, {
    durationMs: 60000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_charger_profiles_1x60s',
    saveNotes: 'Charger test: 16 beats of direct aimed charges, 16 beats of predictive interception charges, then both together.',
    groupedScenarioName: 'beat_swarm_charger_profiles_1x60s',
    groupedRunId: 'musicLab_charger_profiles_1x60s_scenario',
    groupedNotes: 'Focused Charger vertical slice using production combat scheduling and physical enemy movement.',
    tagPrefix: 'ChargerProfiles1x60s',
    labelPrefix: 'BS0_charger_profiles_1x60s',
    statusPrefix: 'Running Charger profiles: direct, intercept, combined',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startChargerCombatTest !== 'function') {
        throw new Error('charger_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startChargerCombatTest();
      if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 2) {
        throw new Error('charger_test_spawn_failed');
      }
      try { window.__BEAT_SWARM_CHARGER_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_test_phase',
        'enemy_combat_attack',
        'enemy_charge_activated',
        'enemy_charge_player_contact',
      ],
      maxLines: 520,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-charger-profiles',
    },
  });
}

async function runConductorCombatProfilesDebug() {
  await runBS0Stage(1, {
    durationMs: 60000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_conductor_profiles_1x60s',
    saveNotes: 'Conductor test: 16 beats shielding a pair, 16 beats shielding a wider field, then both conductors with four active Gunner threats.',
    groupedScenarioName: 'beat_swarm_conductor_profiles_1x60s',
    groupedRunId: 'musicLab_conductor_profiles_1x60s_scenario',
    groupedNotes: 'Focused Conductor vertical slice testing visible protection links and target-priority combat.',
    tagPrefix: 'ConductorProfiles1x60s',
    labelPrefix: 'BS0_conductor_profiles_1x60s',
    statusPrefix: 'Running Conductor profiles: pair, field, combined',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startConductorCombatTest !== 'function') {
        throw new Error('conductor_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startConductorCombatTest();
      if (
        snapshot?.active !== true
        || !Array.isArray(snapshot?.enemyIds)
        || snapshot.enemyIds.length !== 2
        || !Array.isArray(snapshot?.supportEnemyIds)
        || snapshot.supportEnemyIds.length !== 4
      ) {
        throw new Error('conductor_test_spawn_failed');
      }
      try { window.__BEAT_SWARM_CONDUCTOR_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_test_phase',
        'enemy_combat_attack',
        'enemy_conductor_links_created',
        'enemy_conductor_damage_absorbed',
      ],
      maxLines: 620,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-conductor-profiles',
    },
  });
}

async function runLaserVariantsDebug() {
  await runBS0Stage(1, {
    durationMs: 60000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_laser_variants_1x60s',
    saveNotes: 'Laser variants: tracking warning then lock, thin cross-arena beam, thick cross-arena beam, then all variants together.',
    groupedScenarioName: 'beat_swarm_laser_variants_1x60s',
    groupedRunId: 'musicLab_laser_variants_1x60s_scenario',
    groupedNotes: 'Focused aiming, anchor movement, charge warning, width, and collision validation.',
    tagPrefix: 'LaserVariants1x60s',
    labelPrefix: 'BS0_laser_variants_1x60s',
    statusPrefix: 'Running laser variants: tracking, thin, thick, combined',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startLaserVariantCombatTest !== 'function') {
        throw new Error('laser_variant_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startLaserVariantCombatTest();
      if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 3) {
        throw new Error('laser_variant_test_spawn_failed');
      }
      try { window.__BEAT_SWARM_LASER_VARIANT_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_test_phase',
        'enemy_combat_attack',
        'enemy_combat_anchor_ready',
        'enemy_laser_activated',
        'enemy_laser_player_contact',
      ],
      maxLines: 720,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-laser-variants',
    },
  });
}

async function runSymmetricLaserGroupDebug() {
  await runBS0Stage(1, {
    durationMs: 45000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_symmetric_laser_group_1x45s',
    saveNotes: 'Four Laser Spinners travel to rotationally symmetric anchors, wait for the full group, then charge offset thin beams on one shared cadence.',
    groupedScenarioName: 'beat_swarm_symmetric_laser_group_1x45s',
    groupedRunId: 'musicLab_symmetric_laser_group_1x45s_scenario',
    groupedNotes: 'First coordinated enemy-group attack using production individual laser hazards.',
    tagPrefix: 'SymmetricLaserGroup1x45s',
    labelPrefix: 'BS0_symmetric_laser_group_1x45s',
    statusPrefix: 'Running symmetric laser formation',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startSymmetricLaserGroupTest !== 'function') {
        throw new Error('symmetric_laser_group_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startSymmetricLaserGroupTest();
      if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 4) {
        throw new Error('symmetric_laser_group_test_spawn_failed');
      }
      try { window.__BEAT_SWARM_SYMMETRIC_LASER_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_group_formation_started',
        'enemy_combat_test_phase',
        'enemy_combat_attack',
        'enemy_combat_anchor_ready',
        'enemy_laser_activated',
        'enemy_laser_player_contact',
      ],
      maxLines: 820,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-symmetric-laser-group',
    },
  });
}

async function runTrackedLaserMotifsDebug() {
  await runBS0Stage(1, {
    durationMs: 75000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_arena_tracked_laser_motifs_1x75s',
    saveNotes: 'Four Laser Spinners maintain rotational symmetry around the moving arena, then compare regular unison with stable per-enemy drum and pitched lead assignments.',
    groupedScenarioName: 'beat_swarm_arena_tracked_laser_motifs_1x75s',
    groupedRunId: 'musicLab_arena_tracked_laser_motifs_1x75s_scenario',
    groupedNotes: 'Arena-relative formation tracking and shared looping musical attack schedules.',
    tagPrefix: 'ArenaTrackedLaserMotifs1x75s',
    labelPrefix: 'BS0_arena_tracked_laser_motifs_1x75s',
    statusPrefix: 'Running arena-tracked laser motifs',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startTrackedLaserMotifGroupTest !== 'function') {
        throw new Error('tracked_laser_motif_group_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startTrackedLaserMotifGroupTest();
      if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 4) {
        throw new Error('tracked_laser_motif_group_test_spawn_failed');
      }
      try { window.__BEAT_SWARM_TRACKED_LASER_MOTIF_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_group_formation_started',
        'enemy_combat_group_motif_assigned',
        'enemy_combat_group_motif_member_ended',
        'enemy_combat_test_phase',
        'enemy_combat_attack',
        'enemy_combat_anchor_ready',
        'enemy_laser_activated',
        'enemy_laser_player_contact',
      ],
      maxLines: 1100,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-arena-tracked-laser-motifs',
    },
  });
}

async function runGunnerPercussionFormationDebug() {
  await runBS0Stage(1, {
    durationMs: 60000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_gunner_percussion_formation_1x60s',
    saveNotes: 'Director-owned four-member Gunner formation. Each living enemy retains fixed solo or paired motif steps and layers Drum Snare 1 over quiet projectile fire.',
    groupedScenarioName: 'beat_swarm_gunner_percussion_formation_1x60s',
    groupedRunId: 'musicLab_gunner_percussion_formation_1x60s_scenario',
    groupedNotes: 'Cross-profile validation of reusable musical formation plans and enemy-owned loop voices.',
    tagPrefix: 'GunnerPercussionFormation1x60s',
    labelPrefix: 'BS0_gunner_percussion_formation_1x60s',
    statusPrefix: 'Running Gunner percussion formation',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startGunnerPercussionFormationTest !== 'function') {
        throw new Error('gunner_percussion_formation_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startGunnerPercussionFormationTest();
      if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 4) {
        throw new Error('gunner_percussion_formation_test_spawn_failed');
      }
      try { window.__BEAT_SWARM_GUNNER_PERCUSSION_FORMATION_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_group_formation_started',
        'enemy_combat_group_motif_assigned',
        'enemy_combat_group_motif_member_ended',
        'enemy_combat_test_phase',
        'enemy_combat_anchor_ready',
        'enemy_combat_attack',
      ],
      maxLines: 900,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-gunner-percussion-formation',
    },
  });
}

async function runDualMusicalFormationDebug() {
  await runBS0Stage(1, {
    durationMs: 75000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_dual_musical_formation_1x75s',
    saveNotes: 'Independent musical formations: four outer Laser Spinners play an electro hand-clap rhythm while three inner Gunners play a separate kick-drum rhythm.',
    groupedScenarioName: 'beat_swarm_dual_musical_formation_1x75s',
    groupedRunId: 'musicLab_dual_musical_formation_1x75s_scenario',
    groupedNotes: 'Tests two simultaneous director-owned enemy rhythms as an additive variation layer over the established score.',
    tagPrefix: 'DualMusicalFormation1x75s',
    labelPrefix: 'BS0_dual_musical_formation_1x75s',
    statusPrefix: 'Running dual musical formations',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startDualMusicalFormationTest !== 'function') {
        throw new Error('dual_musical_formation_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startDualMusicalFormationTest();
      if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 7) {
        throw new Error('dual_musical_formation_test_spawn_failed');
      }
      try { window.__BEAT_SWARM_DUAL_MUSICAL_FORMATION_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_group_formation_started',
        'enemy_combat_group_motif_assigned',
        'enemy_combat_group_motif_member_ended',
        'enemy_combat_test_phase',
        'enemy_combat_anchor_ready',
        'enemy_combat_attack',
        'enemy_laser_activated',
        'enemy_laser_player_contact',
      ],
      maxLines: 1500,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-dual-musical-formation',
    },
  });
}

async function runLeadResponseFormationDebug() {
  await runBS0Stage(1, {
    durationMs: 60000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    saveRunIdBase: 'musicLab_lead_response_formation_1x60s',
    saveNotes: 'Focused production derivation test: a seeded player Lead Theme plays with one laser formation carrying a one-beat-delayed, pentatonic-shifted contour response.',
    groupedScenarioName: 'beat_swarm_lead_response_formation_1x60s',
    groupedRunId: 'musicLab_lead_response_formation_1x60s_scenario',
    groupedNotes: 'Validates recognizable player lead identity, response separation, assigned pitches, and exact beat scheduling without production threat-budget variance.',
    tagPrefix: 'LeadResponseFormation1x60s',
    labelPrefix: 'BS0_lead_response_formation_1x60s',
    statusPrefix: 'Running lead response formation',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startLeadResponseFormationTest !== 'function') {
        throw new Error('lead_response_formation_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startLeadResponseFormationTest({ memberCount: 4 });
      if (snapshot?.active !== true || snapshot?.enemyIds?.length !== 4) {
        throw new Error(`lead_response_formation_test_spawn_failed:${String(snapshot?.reason || 'unknown')}`);
      }
      try { window.__BEAT_SWARM_LEAD_RESPONSE_FORMATION_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'lead_response_formation_test_started',
        'director_musical_formation_spawned',
        'lead_ball_rewrite_committed_to_theme',
        'lead_ball_literal_loop_timing',
        'music_primary_loop_lane_emitted',
        'music_primary_loop_coverage_status',
        'music_primary_loop_owner_trace',
        'music_composer_group_state',
        'enemy_combat_group_motif_assigned',
        'enemy_combat_group_motif_member_ended',
        'enemy_combat_anchor_ready',
        'enemy_combat_attack',
        'enemy_laser_activated',
      ],
      maxLines: 1200,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-lead-response-formation',
    },
  });
}

async function runAccentSubdivisionFormationDebug() {
  await runBS0Stage(1, {
    durationMs: 60000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    saveRunIdBase: 'musicLab_accent_subdivision_formation_1x60s',
    saveNotes: 'Focused subdivision test: the authored Accent Rhythm plays while a laser formation preserves and reinforces its exact eighth-note positions.',
    groupedScenarioName: 'beat_swarm_accent_subdivision_formation_1x60s',
    groupedRunId: 'musicLab_accent_subdivision_formation_1x60s_scenario',
    groupedNotes: 'Validates exact Accent offbeats, global loop phase, member allocation, laser warning timing, and quantized activation.',
    tagPrefix: 'AccentSubdivisionFormation1x60s',
    labelPrefix: 'BS0_accent_subdivision_formation_1x60s',
    statusPrefix: 'Running Accent offbeat formation',
    keepMusicLabRealtimeMetrics: true,
    traceBeforeSetup: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startAccentSubdivisionFormationTest !== 'function') {
        throw new Error('accent_subdivision_formation_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startAccentSubdivisionFormationTest({ memberCount: 4 });
      if (snapshot?.active !== true || snapshot?.enemyIds?.length !== 4) {
        throw new Error(`accent_subdivision_formation_test_spawn_failed:${String(snapshot?.reason || 'unknown')}`);
      }
      try { window.__BEAT_SWARM_ACCENT_SUBDIVISION_FORMATION_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'accent_subdivision_formation_test_started',
        'director_musical_formation_spawned',
        'enemy_combat_group_motif_assigned',
        'enemy_combat_anchor_ready',
        'enemy_combat_attack',
        'enemy_laser_activated',
      ],
      maxLines: 1400,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-accent-subdivision-formation',
    },
  });
}

async function runFullScoreArrangementDebug() {
  await runBS0Stage(3, {
    durationMs: 75000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    traceBeforeSetup: true,
    beatSwarmTestOverrides: {
      musicIntensityAudition: {
        enabled: true,
        mode: 'fixed_section',
        fixedSection: 'peak',
        introBars: 0,
        keepAuthoredLeadPresent: true,
      },
    },
    saveRunIdBase: 'musicLab_full_score_arrangements_1x75s',
    saveNotes: [
      'Focused full-score arrangement mix test at fixed Peak intensity.',
      'Seeds recognizable Foundation Rhythm, Accent Rhythm, and ball-authored Lead Theme material, while retaining the prepared player weapon.',
      'Runs production-derived Gunner/Foundation reinforcement, Laser/Accent reinforcement, and delayed pentatonic Lead response together.',
      'Assess whether the arrangement adds energy and variation without masking or replacing any player-owned core motif.',
    ].join(' '),
    groupedScenarioName: 'beat_swarm_full_score_arrangements_1x75s',
    groupedRunId: 'musicLab_full_score_arrangements_1x75s_scenario',
    groupedNotes: 'Combined production arrangement roles over a complete seeded player score at fixed Peak intensity.',
    tagPrefix: 'FullScoreArrangements1x75s',
    labelPrefix: 'BS0_full_score_arrangements_1x75s',
    statusPrefix: 'Running full score and arrangements',
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startFullScoreArrangementTest !== 'function') {
        throw new Error('full_score_arrangement_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startFullScoreArrangementTest();
      if (snapshot?.active !== true || snapshot?.groups?.length !== 3) {
        throw new Error(`full_score_arrangement_test_spawn_failed:${String(snapshot?.reason || 'unknown')}`);
      }
      try { window.__BEAT_SWARM_FULL_SCORE_ARRANGEMENT_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'full_score_arrangement_test_started',
        'music_level1_arrangement_state',
        'music_lane_focus_changed',
        'music_lane_focus_presentation',
        'music_primary_loop_lane_emitted',
        'director_musical_formation_spawned',
        'enemy_combat_group_motif_assigned',
        'enemy_combat_group_motif_member_ended',
        'enemy_combat_anchor_ready',
        'enemy_combat_attack',
        'enemy_laser_activated',
      ],
      maxLines: 2200,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-full-score-arrangements',
    },
  });
}

async function runArrangementIntensityRampDebug() {
  await runBS0Stage(3, {
    durationMs: 115000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    traceBeforeSetup: true,
    beatSwarmTestOverrides: {
      musicIntensityAudition: {
        enabled: true,
        mode: 'ramp_release',
        introBars: 0,
        keepAuthoredLeadPresent: true,
      },
    },
    saveRunIdBase: 'musicLab_arrangement_intensity_ramp_1x115s',
    saveNotes: [
      'Seeded full player score through the standard Low, Medium, Build, Peak, Release, and Settle intensity audition.',
      'The production arrangement policy should keep Low player-owned, introduce Foundation reinforcement at Medium, add Accent reinforcement during Build, and permit Lead response at Peak.',
      'Release and Settle should add no new formations. Muted formations should move into a visible outer holding orbit, return if their motif is reactivated, or pulse red for two motif loops before exploding.',
      'Assess progressive density, motif recognition, transition smoothness, and whether temporary arrangement voices ever mask the immutable weapon or player-owned core lanes.',
    ].join(' '),
    groupedScenarioName: 'beat_swarm_arrangement_intensity_ramp_1x115s',
    groupedRunId: 'musicLab_arrangement_intensity_ramp_1x115s_scenario',
    groupedNotes: 'Focused production arrangement-policy ramp over a complete seeded player score, without onboarding setup time.',
    tagPrefix: 'ArrangementIntensityRamp1x115s',
    labelPrefix: 'BS0_arrangement_intensity_ramp_1x115s',
    statusPrefix: 'Running arrangement intensity ramp',
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startSeededArrangementIntensityFlowTest !== 'function') {
        throw new Error('arrangement_intensity_flow_test_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startSeededArrangementIntensityFlowTest();
      if (snapshot?.active !== true) {
        throw new Error('arrangement_intensity_flow_test_start_failed');
      }
      try { window.__BEAT_SWARM_ARRANGEMENT_INTENSITY_FLOW_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'seeded_arrangement_intensity_flow_test_started',
        'music_level1_arrangement_state',
        'music_lane_focus_changed',
        'music_lane_focus_presentation',
        'music_primary_loop_lane_emitted',
        'director_musical_formation_policy',
        'director_musical_formation_spawned',
        'director_musical_formation_ended',
        'director_musical_formation_holding',
        'director_musical_formation_overload_warning',
        'director_musical_formation_overload_returning',
        'director_musical_formation_recalled',
        'director_musical_formation_overloaded',
        'director_musical_formation_overload_exploded',
        'enemy_basic_lane_carrier_status',
        'enemy_basic_lane_carrier_spawned',
        'director_elite_spawn_blocked',
        'director_threat_admission',
        'enemy_combat_group_motif_assigned',
        'enemy_combat_group_motif_member_ended',
        'enemy_combat_attack',
        'enemy_basic_ability_fired',
        'enemy_combat_activation_visual_started',
        'enemy_laser_locked',
        'enemy_laser_activated',
      ],
      maxLines: 3600,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-arrangement-intensity-ramp',
    },
  });
}

async function runEnemyArchitectureDebug() {
  const durationMs = 70000;
  const modeApi = window.BeatSwarmMode;
  if (!modeApi || typeof modeApi.startEnemyArchitectureTest !== 'function') {
    setStatus('Enemy architecture lab failed: test API unavailable');
    return { ok: false, reason: 'enemy_architecture_test_api_unavailable' };
  }
  const rebuilt = await buildBS0();
  if (!rebuilt) return { ok: false, reason: 'fresh_reset_failed' };
  try { stopTransport(); } catch {}
  await waitForPerfLabMs(120);
  try { startTransport(); } catch {}
  await waitForTransportRunning(2200);
  await waitForPerfLabMs(120);
  const musicLabApi = getMusicLabApiGlobal();
  try { musicLabApi?.setEnabled?.(true); } catch {}
  try { musicLabApi?.setRealtimeMetricsEnabled?.(true); } catch {}
  try { musicLabApi?.setLightweightSystemEventsEnabled?.(true); } catch {}
  try { musicLabApi?.reset?.('enemy-architecture-lab'); } catch {}
  const prepared = await prepareBS0StaticStage(1, 1);
  if (!prepared) {
    setStatus('Enemy architecture lab failed: Beat Swarm setup unavailable');
    return { ok: false, reason: 'debug_api_unavailable' };
  }
  try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
  let traceStartResult = null;
  try {
    traceStartResult = await startMusicTraceCaptureForPerfRun({
      include: [
        'enemy_architecture_test_started',
        'enemy_architecture_lane_event',
        'enemy_architecture_movement_phrase',
        'enemy_architecture_elite_budget',
        'enemy_architecture_ability_fired',
        'enemy_architecture_carrier_arrived',
        'enemy_architecture_threat_phase',
        'director_musical_formation_spawned',
      ],
      maxLines: 900,
    });
  } catch (err) {
    traceStartResult = { ok: false, reason: String(err?.message || err || 'trace_start_failed') };
  }
  const snapshot = modeApi.startEnemyArchitectureTest();
  if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 2) {
    try { modeApi.stopEnemyArchitectureTest?.(); } catch {}
    try { stopTransport(); } catch {}
    setStatus('Enemy architecture lab failed: enemies did not spawn');
    return { ok: false, reason: 'enemy_architecture_test_spawn_failed', snapshot };
  }
  try { window.__BEAT_SWARM_ENEMY_ARCHITECTURE_TEST = snapshot; } catch {}
  const deadlineMs = Date.now() + durationMs;
  try { window.__BEAT_SWARM_ENEMY_ARCHITECTURE_DEADLINE_MS = deadlineMs; } catch {}
  while (Date.now() < deadlineMs) {
    const remainingSeconds = Math.max(0, Math.ceil((deadlineMs - Date.now()) / 1000));
    setStatus(`Running enemy lane and movement architecture lab (${remainingSeconds}s remaining)`);
    await waitForPerfLabMs(Math.min(1000, Math.max(1, deadlineMs - Date.now())));
  }
  const finalSnapshot = modeApi.getEnemyArchitectureTestSnapshot?.() || null;
  const assertions = {
    simplePrefillCount: Array.isArray(snapshot?.enemyIds) && snapshot.enemyIds.length === 2,
    simplePrefillUsesOnlyWind: Array.isArray(snapshot?.basicEnemyDescriptors)
      && snapshot.basicEnemyDescriptors.length === 2
      && snapshot.basicEnemyDescriptors.every((descriptor) => descriptor?.abilityFamily === 'wind_push'),
    eliteDeferredDuringTeaching: Array.isArray(snapshot?.eliteEnemyIds) && snapshot.eliteEnemyIds.length === 0,
    eliteSpawnedForCombinedPressure: Array.isArray(finalSnapshot?.eliteEnemyIds) && finalSnapshot.eliteEnemyIds.length === 2,
    allowedBudgetPassed: snapshot?.eliteBudgetChecks?.allowed?.allowed === true,
    blockedBudgetPassed: snapshot?.eliteBudgetChecks?.blocked?.allowed === false,
    blockedForDensity: Array.isArray(snapshot?.eliteBudgetChecks?.blocked?.reasons)
      && snapshot.eliteBudgetChecks.blocked.reasons.includes('additive_density_budget'),
    eliteSurvived: Array.isArray(finalSnapshot?.eliteAliveEnemyIds) && finalSnapshot.eliteAliveEnemyIds.length === 2,
    controlledAbilityPalette: Array.isArray(snapshot?.abilityPalette)
      && ['projectile', 'laser', 'local_explosion', 'wind_push'].every((family) => snapshot.abilityPalette.includes(family)),
    basicAbilityFamiliesConfigured: Array.isArray(finalSnapshot?.basicEnemyDescriptors)
      && ['projectile', 'laser', 'local_explosion', 'wind_push'].every((family) => (
        finalSnapshot.basicEnemyDescriptors.some((descriptor) => descriptor?.abilityFamily === family)
      )),
    finalBasicEnemyCount: Array.isArray(finalSnapshot?.basicEnemyDescriptors)
      && finalSnapshot.basicEnemyDescriptors.length === 6,
    abilitySilhouettesConfigured: Array.isArray(finalSnapshot?.basicEnemyDescriptors)
      && finalSnapshot.basicEnemyDescriptors.length === 6
      && finalSnapshot.basicEnemyDescriptors.every((descriptor) => String(descriptor?.abilitySilhouette || '').trim().length > 0),
    mixedAbilitiesExecuted: ['projectile', 'laser', 'local_explosion', 'wind_push'].every((family) => (
      Math.max(0, Math.trunc(Number(finalSnapshot?.abilityEventCounts?.[family]) || 0)) > 0
    )),
    allThreatPhasesReached: Array.isArray(finalSnapshot?.threatPhaseHistory)
      && ['simple_prefill', 'laser_teach', 'laser_consolidate', 'local_aoe_introduction', 'projectile_introduction', 'combined_pressure']
        .every((phaseId) => finalSnapshot.threatPhaseHistory.some((phase) => phase?.phaseId === phaseId)),
    visibleRosterArrivedByPhase: [2, 3, 3, 4, 5, 6].every((expectedCount, phaseIndex) => {
      const phase = finalSnapshot?.threatPhaseHistory?.find((entry) => entry?.phaseIndex === phaseIndex);
      const visibleCount = Object.values(phase?.activeAbilityCounts || {}).reduce((sum, count) => (
        sum + Math.max(0, Math.trunc(Number(count) || 0))
      ), 0);
      return visibleCount === expectedCount;
    }),
    threatCapsRespected: Math.max(0, Math.trunc(Number(finalSnapshot?.threatViolationCount) || 0)) === 0
      && Array.isArray(finalSnapshot?.threatPhaseHistory)
      && finalSnapshot.threatPhaseHistory.every((phase) => (
        Math.max(0, Math.trunc(Number(phase?.activeFeaturedThreats) || 0))
          <= Math.max(0, Math.trunc(Number(phase?.maxFeaturedThreats) || 0))
      )),
    featuredThreatEscalatedToTwo: Math.max(0, Math.trunc(Number(finalSnapshot?.maxObservedFeaturedThreats) || 0)) === 2,
  };
  const assertionsPassed = Object.values(assertions).every(Boolean);
  try { window.__BEAT_SWARM_ENEMY_ARCHITECTURE_TEST_RESULT = finalSnapshot; } catch {}
  try { modeApi.stopEnemyArchitectureTest?.(); } catch {}
  try { stopTransport(); } catch {}
  setStatus('Enemy lane and movement architecture lab complete (70s); saving results');
  let traceCaptureResult = null;
  try {
    traceCaptureResult = await finalizeMusicTraceCaptureForPerfRun({
      fileName: 'resources-debug-enemy-lane-movement-architecture.txt',
      preferOutputDirectory: true,
    });
  } catch (err) {
    traceCaptureResult = { ok: false, reason: String(err?.message || err || 'trace_finalize_failed') };
  }
  const summary = {
    ok: true,
    createdAt: new Date().toISOString(),
    durationMs,
    initial: snapshot,
    result: finalSnapshot,
    assertions,
    assertionsPassed,
    traceStart: traceStartResult,
    traceCapture: traceCaptureResult,
  };
  let summarySaved = false;
  let summaryFileName = '';
  try {
    const cfg = await resolveResultsConfig();
    const postUrl = resolveDebugOutputPostUrl(cfg);
    summaryFileName = `resources-debug-enemy-lane-movement-architecture-${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
    summarySaved = await postDebugOutputFile({
      fileName: summaryFileName,
      text: JSON.stringify(summary, null, 2),
      meta: { source: 'enemy-architecture-focused-lab', durationMs },
    }, postUrl);
  } catch {}
  const output = { ...summary, summarySaved, summaryFileName };
  try { window.__BEAT_SWARM_ENEMY_ARCHITECTURE_SAVE_RESULT = output; } catch {}
  setStatus(summarySaved
    ? `Enemy lane and movement architecture lab complete (70s); ${assertionsPassed ? 'lane, ability, and elite checks passed' : 'architecture checks failed'}; results saved`
    : 'Enemy lane and movement architecture lab complete (70s); result save failed');
  setOutput(output);
  return output;
}

async function runAuthoringIntensityHandoffDebug() {
  let handoffAudit = null;
  const result = await runBS0Stage(3, {
    durationMs: 210000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    suppressCompletionUi: true,
    traceBeforeSetup: true,
    saveRunIdBase: 'musicLab_authoring_intensity_handoff_1x210s',
    saveNotes: 'Autopilot production authoring followed by Low, Medium, Build, Peak, Release, and Settle. Validates empty lanes, commits, literal protection, persistence, and interaction-backed density requests.',
    groupedScenarioName: 'beat_swarm_authoring_intensity_handoff_1x210s',
    groupedRunId: 'musicLab_authoring_intensity_handoff_1x210s_scenario',
    groupedNotes: 'Focused validation of player-authored motif ownership across the complete production intensity sequence.',
    tagPrefix: 'AuthoringIntensityHandoff1x210s',
    labelPrefix: 'BS0_authoring_intensity_handoff_1x210s',
    statusPrefix: 'Running authoring and intensity handoff',
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.armDirectorFormationFlowAfterOnboarding !== 'function') {
        throw new Error('authoring_intensity_handoff_api_unavailable');
      }
      try { modeApi.exit?.(); } catch {}
      await waitForPerfLabMs(80);
      modeApi.enter?.({ weaponGateIntro: true, weaponGateSequence: 'missiles_bouncers' });
      modeApi.setPerfCompositionAuditAutoControl?.(true);
      modeApi.armDirectorFormationFlowAfterOnboarding();
    },
    async teardownAfterRun() {
      const traceText = String(getMusicTraceCaptureApiGlobal()?.getTraceCaptureText?.() || '');
      const records = parseBeatSwarmTraceRecords(traceText);
      const themes = window.BeatSwarmMode?.getPlayerMusicThemes?.() || null;
      handoffAudit = evaluateAuthoringIntensityHandoffTrace(records, themes);
      try { window.__BEAT_SWARM_AUTHORING_INTENSITY_HANDOFF = handoffAudit; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'music_contribution_empty_lanes_armed',
        'music_contribution_started',
        'music_contribution_completed',
        'music_contribution_protection_armed',
        'music_contribution_protection_expired',
        'music_rhythm_rewrite_committed_to_theme',
        'lead_ball_rewrite_committed_to_theme',
        'director_formation_flow_started_after_onboarding',
        'music_level1_arrangement_state',
        'music_primary_loop_lane_emitted',
        'director_density_contribution_requested',
        'music_density_request_queued_as_contribution',
      ],
      maxLines: 5000,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-authoring-intensity-handoff',
    },
  });
  const summary = {
    ok: result?.ok === true && handoffAudit?.assertionsPassed === true,
    createdAt: new Date().toISOString(),
    durationMs: 210000,
    run: result,
    audit: handoffAudit,
  };
  let summarySaved = false;
  let summaryFileName = '';
  try {
    const cfg = await resolveResultsConfig();
    const postUrl = resolveDebugOutputPostUrl(cfg);
    summaryFileName = `resources-debug-authoring-intensity-handoff-${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
    summarySaved = await postDebugOutputFile({
      fileName: summaryFileName,
      text: JSON.stringify(summary, null, 2),
      meta: { source: 'authoring-intensity-handoff-lab', durationMs: 210000 },
    }, postUrl);
  } catch {}
  const output = { ...summary, summarySaved, summaryFileName };
  setStatus(summarySaved
    ? `Authoring and intensity handoff complete; ${summary.ok ? 'checks passed' : 'checks need review'}; results saved`
    : 'Authoring and intensity handoff complete; result save failed');
  setOutput(output);
  return output;
}

async function runDirectorFormationIntensityFlowDebug() {
  await runBS0Stage(3, {
    durationMs: 300000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: true,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    saveRunIdBase: 'musicLab_production_onboarding_flow_1x300s',
    saveNotes: [
      'Autopilot run of the full first-level music onboarding into the director musical-formation intensity flow.',
      'The player authors the weapon in the gate corridor, Bass Drive with rocket pickups, Accent Rhythm with bouncers, and Lead Theme with the lead ball.',
      'Only after every contribution commits does the production pacing loop begin at Low and enable musical enemy formations.',
      'Build and Peak may request another interaction when a player-authored lane remains below their desired density; motifs are never silently populated.',
      'Expected: Low has player motifs only; Medium introduces one Gunner/Kick formation; Build adds one Laser/Clap formation; Peak sustains both.',
      'Release and Settle spawn no new formations. Muted surviving groups enter an outer holding pattern, return inside during an accelerating two-loop red overload warning, then explode if their motif does not return.',
      'If a requested group is completely defeated while its intensity policy still calls for it, the director may replace it after the normal phrase cooldown.',
      'The production threat lesson begins with non-damaging wind carriers and preserves each enemy ability for its lifetime. After onboarding, this budget-focused lab explicitly marks the lesson complete so Medium, Build, and Peak can validate optional elite admission without changing production progression.',
    ].join(' '),
    groupedScenarioName: 'beat_swarm_production_onboarding_flow_1x300s',
    groupedRunId: 'musicLab_production_onboarding_flow_1x300s_scenario',
    groupedNotes: 'Validates real music onboarding followed by player-only Low, Gunner/Kick Medium, added Laser/Clap Build, both at Peak, and survivor-only Release/Settle.',
    tagPrefix: 'ProductionOnboardingFlow1x300s',
    labelPrefix: 'BS0_production_onboarding_flow_1x300s',
    statusPrefix: 'Running production onboarding flow',
    async setupAfterPrepare() {
      window.__BEAT_SWARM_COMPOSER_EXECUTION_DEBUG = false;
      const testOverrides = window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object'
        ? window.__beatSwarmTestOverrides
        : (window.__beatSwarmTestOverrides = {});
      testOverrides.productionOnboardingFormationBudgetReady = true;
      const modeApi = window.BeatSwarmMode;
      if (
        !modeApi
        || typeof modeApi.armDirectorFormationFlowAfterOnboarding !== 'function'
        || typeof modeApi.setPerfCompositionAuditAutoControl !== 'function'
      ) {
        throw new Error('director_musical_formation_layer_api_unavailable');
      }
      try { modeApi.exit?.(); } catch {}
      await waitForPerfLabMs(80);
      try { modeApi.enter?.({ weaponGateIntro: true, weaponGateSequence: 'missiles_bouncers' }); } catch (err) {
        throw new Error(`formation_onboarding_start_failed:${String(err?.message || err)}`);
      }
      modeApi.setPerfCompositionAuditAutoControl(true);
      const snapshot = modeApi.armDirectorFormationFlowAfterOnboarding();
      try {
        window.__BEAT_SWARM_DIRECTOR_FORMATION_FLOW_TEST = {
          ...snapshot,
          onboarding: true,
          autopilot: true,
        };
      } catch {}
    },
    async teardownAfterRun() {
      window.__BEAT_SWARM_COMPOSER_EXECUTION_DEBUG = false;
      if (window.__beatSwarmTestOverrides && typeof window.__beatSwarmTestOverrides === 'object') {
        delete window.__beatSwarmTestOverrides.productionOnboardingFormationBudgetReady;
      }
    },
    traceCapture: {
      enabled: true,
      include: [
        'music_level1_arrangement_state',
        'music_enemy_director_state',
        'music_lane_focus_changed',
        'music_lane_focus_presentation',
        'music_mix_debug',
        'music_hero_visual_representation',
        'music_hero_visual_readability',
        'music_hero_carrier_lifecycle',
        'music_lane_carrier_trigger_timing',
        'enemy_wind_push_visual_status',
        'enemy_wind_push_triggered',
        'enemy_basic_lane_carrier_lifecycle',
        'music_enemy_threat_lesson_advanced',
        'music_enemy_threat_lesson_test_override',
        'director_threat_admission',
        'director_elite_spawn_blocked',
        'music_enemy_director_cleanup',
        'director_musical_formation_policy',
        'director_musical_formation_spawned',
        'director_musical_formation_ended',
        'director_musical_formation_holding',
        'director_musical_formation_recalled',
        'director_musical_formation_overload_warning',
        'director_musical_formation_overload_returning',
        'director_musical_formation_overload_armed',
        'director_musical_formation_overloaded',
        'director_musical_formation_overload_exploded',
        'director_formation_flow_started_after_onboarding',
        'director_density_contribution_requested',
        'music_density_request_queued_as_contribution',
        'music_contribution_started',
        'music_contribution_completed',
        'music_rhythm_rewrite_committed_to_theme',
        'lead_gate_rewrite_committed_to_theme',
        'lead_ball_target_reserve_checked',
        'lead_ball_rewrite_started',
        'lead_ball_launched',
        'lead_ball_route_sample',
        'lead_ball_viewport_bounce',
        'lead_ball_hit_queued',
        'lead_ball_hit_rejected',
        'lead_ball_quantized_impact',
        'enemy_combat_group_motif_assigned',
        'enemy_combat_group_motif_member_ended',
        'enemy_combat_attack',
        'enemy_laser_activated',
        'enemy_basic_ability_fired',
        'enemy_combat_prepare_visual_started',
        'enemy_combat_activation_visual_started',
        'enemy_basic_lane_carrier_spawned',
        'enemy_basic_lane_carrier_status',
      ],
      maxLines: 15000,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-production-onboarding-flow',
    },
  });
}

async function runOnboardingCompositionAuditDebug() {
  await runBS0Stage(3, {
    durationMs: 240000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    forceCompactSave: false,
    keepMusicLabRealtimeMetrics: true,
    publishPerfArtifacts: false,
    saveRunIdBase: 'musicLab_onboarding_composition_audit_1x240s',
    saveNotes: [
      'Autopilot composition audit of the production first-level onboarding and director flow.',
      'The test pulls and releases the corridor launch, steers through weapon gates, and pursues live missile pickups, bouncers, and lead-ball pickups.',
      'Full Music Lab data is retained to correlate authored motif density, lead polyphony, lane overlap, enemy formation attacks, prominence, and approximate playback volume.',
    ].join(' '),
    groupedScenarioName: 'beat_swarm_onboarding_composition_audit_1x240s',
    groupedRunId: 'musicLab_onboarding_composition_audit_1x240s_scenario',
    groupedNotes: 'Measures where the production score becomes crowded while deterministic test-only controls complete its music interactions.',
    tagPrefix: 'OnboardingCompositionAudit1x240s',
    labelPrefix: 'BS0_onboarding_composition_audit_1x240s',
    statusPrefix: 'Running onboarding composition audit',
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.setPerfCompositionAuditAutoControl !== 'function') {
        throw new Error('composition_audit_autopilot_api_unavailable');
      }
      try { modeApi.exit?.(); } catch {}
      await waitForPerfLabMs(80);
      try { modeApi.enter?.({ weaponGateIntro: true, weaponGateSequence: 'missiles_bouncers' }); } catch (err) {
        throw new Error(`composition_audit_onboarding_start_failed:${String(err?.message || err)}`);
      }
      modeApi.setPerfCompositionAuditAutoControl(true);
      const snapshot = modeApi.armDirectorFormationFlowAfterOnboarding?.() || null;
      try { window.__BEAT_SWARM_COMPOSITION_AUDIT = { ...snapshot, autopilot: true }; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'music_composition_audit_bar',
        'music_player_lead_polyphony_triggered',
        'music_level1_arrangement_state',
        'music_player_layer_state',
        'music_readability_snapshot',
        'music_primary_lead_request',
        'music_contribution_started',
        'music_contribution_completed',
        'music_contribution_protection_armed',
        'music_contribution_protection_expired',
        'music_missile_motif_hit',
        'pinball_bouncer_motif_hit',
        'lead_ball_motif_hit',
        'music_rhythm_rewrite_committed_to_theme',
        'lead_ball_rewrite_committed_to_theme',
        'music_authoring_lane_audio_suppressed',
        'director_musical_formation_spawned',
        'director_musical_formation_holding',
        'director_musical_formation_overload_warning',
        'director_musical_formation_overload_returning',
        'director_musical_formation_recalled',
        'director_musical_formation_overloaded',
        'director_musical_formation_overload_exploded',
        'enemy_basic_lane_carrier_status',
        'enemy_basic_lane_carrier_spawned',
        'enemy_combat_group_motif_assigned',
        'enemy_combat_attack',
      ],
      maxLines: 6000,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-onboarding-composition-audit',
    },
  });
}

async function runShapeCasterGunnerCombinationDebug() {
  await runBS0Stage(1, {
    durationMs: 45000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_shape_caster_gunner_combo_1x45s',
    saveNotes: 'Combination test: remain inside the Shape Caster safe circle while threading spread and burst fire from two Gunners.',
    groupedScenarioName: 'beat_swarm_shape_caster_gunner_combo_1x45s',
    groupedRunId: 'musicLab_shape_caster_gunner_combo_1x45s_scenario',
    groupedNotes: 'First mixed-profile validation using only shared production combat scheduling.',
    tagPrefix: 'ShapeCasterGunnerCombo1x45s',
    labelPrefix: 'BS0_shape_caster_gunner_combo_1x45s',
    statusPrefix: 'Running Shape Caster + Gunner combination',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startShapeCasterGunnerCombinationTest !== 'function') {
        throw new Error('shape_caster_gunner_combination_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startShapeCasterGunnerCombinationTest();
      if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 3) {
        throw new Error('shape_caster_gunner_combination_spawn_failed');
      }
      try { window.__BEAT_SWARM_SHAPE_GUNNER_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_combination_started',
        'enemy_combat_test_phase',
        'enemy_combat_attack',
        'enemy_shape_activated',
        'enemy_shape_player_contact',
      ],
      maxLines: 620,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-shape-caster-gunner-combo',
    },
  });
}

async function runShapeCasterSeekerCombinationDebug() {
  await runBS0Stage(1, {
    durationMs: 45000,
    repeatCount: 1,
    enemyCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_shape_caster_seeker_combo_1x45s',
    saveNotes: 'Combination test: remain inside the Shape Caster safe circle while managing a pursuing Seeker and its sustained homing shots.',
    groupedScenarioName: 'beat_swarm_shape_caster_seeker_combo_1x45s',
    groupedRunId: 'musicLab_shape_caster_seeker_combo_1x45s_scenario',
    groupedNotes: 'Mixed-profile approach-versus-retreat validation using shared production combat scheduling.',
    tagPrefix: 'ShapeCasterSeekerCombo1x45s',
    labelPrefix: 'BS0_shape_caster_seeker_combo_1x45s',
    statusPrefix: 'Running Shape Caster + Seeker combination',
    keepMusicLabRealtimeMetrics: true,
    async setupAfterPrepare() {
      const modeApi = window.BeatSwarmMode;
      if (!modeApi || typeof modeApi.startShapeCasterSeekerCombinationTest !== 'function') {
        throw new Error('shape_caster_seeker_combination_api_unavailable');
      }
      try { window.__beatSwarmDebug?.setPerfAutoMove?.(false); } catch {}
      const snapshot = modeApi.startShapeCasterSeekerCombinationTest();
      if (snapshot?.active !== true || !Array.isArray(snapshot?.enemyIds) || snapshot.enemyIds.length !== 2) {
        throw new Error('shape_caster_seeker_combination_spawn_failed');
      }
      try { window.__BEAT_SWARM_SHAPE_SEEKER_TEST = snapshot; } catch {}
    },
    traceCapture: {
      enabled: true,
      include: [
        'enemy_combat_combination_started',
        'enemy_combat_test_phase',
        'enemy_combat_attack',
        'enemy_shape_activated',
        'enemy_shape_player_contact',
      ],
      maxLines: 620,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-shape-caster-seeker-combo',
    },
  });
}

async function runBS0BehaviorTaxonomyDebug() {
  await runBS0Stage(3, {
    durationMs: 60000,
    repeatCount: 1,
    freshResetEachRun: true,
    restartTransportEachRun: true,
    resetMusicLabEachRun: true,
    saveMusicLabEachRun: true,
    saveRunIdBase: 'musicLab_behavior_taxonomy_debug_1x1m',
    saveNotes: 'Beat Swarm behavior taxonomy debug: verify director-assigned single/group/event behavior IDs and propagation into composer groups during real gameplay.',
    groupedScenarioName: 'beat_swarm_behavior_taxonomy_debug_1x1m',
    groupedRunId: 'musicLab_behavior_taxonomy_debug_1x1m_scenario',
    groupedNotes: 'Behavior taxonomy debug scenario: one 1-minute Beat Swarm run with focused director/group/event behavior tracing.',
    tagPrefix: 'BS0BehaviorTaxonomyDebug1x1m',
    labelPrefix: 'BS0_stage3_behavior_taxonomy_debug_1x1m',
    statusPrefix: 'Running Beat Swarm behavior taxonomy debug (1 minute)',
    traceCapture: {
      enabled: true,
      include: [
        'music_level_phase_state',
        'music_enemy_director_state',
        'music_composer_group_state',
        'music_group_performer_trace',
        'music_secondary_bridge_coverage_trace',
        'music_event_section_state',
        'music_visual_role_readability_state',
      ],
      maxLines: 360,
      preferOutputDirectory: true,
      fileNamePrefix: 'resources-debug-behavior-taxonomy',
    },
  });
}

async function runBS0SlotBodyProbeSuite() {
  const scenarios = [
    {
      id: 'intro_group_baseline',
      label: 'Intro Group Baseline',
      stageCount: 3,
      durationMs: 45000,
      laneCarrierPolicy: {
        foundation_lane: ['group'],
        primary_loop_lane: ['drawsnake', 'group'],
        secondary_loop_lane: ['group'],
        sparkle_lane: ['spawner', 'group'],
      },
      notes: 'Fast slot/body baseline: preserve intro group-first pulse/backbeat ownership while keeping primary loop drawsnake-first.',
    },
    {
      id: 'foundation_spawner_swap',
      label: 'Foundation Spawner Swap',
      stageCount: 4,
      durationMs: 60000,
      laneCarrierPolicy: {
        foundation_lane: ['spawner'],
        primary_loop_lane: ['drawsnake', 'group'],
        secondary_loop_lane: ['spawner', 'group'],
        sparkle_lane: ['spawner', 'group'],
      },
      notes: 'Force foundation and secondary loop toward spawner where eligible to verify slot continuity under body substitution.',
    },
  ];
  const previousOverrideState = captureMusicLaneCarrierPolicyOverrideState();
  const suiteOutcomes = [];
  try {
    for (let i = 0; i < scenarios.length; i += 1) {
      const scenario = scenarios[i];
      const normalizedScenario = normalizeMusicLabProbeLaneCarrierPolicy(scenario.laneCarrierPolicy);
      const effectiveLaneCarrierPolicy = normalizedScenario.normalizedPolicy;
      const stageCount = Math.max(1, Math.trunc(Number(scenario.stageCount) || 3));
      const unsupportedPolicyText = normalizedScenario.unsupportedRequests.length
        ? ` unsupported=${JSON.stringify(normalizedScenario.unsupportedRequests)}`
        : '';
      try {
        window.__LAST_SLOT_BODY_PROBE_SUITE = {
          phase: 'starting_scenario',
          scenarioIndex: i + 1,
          scenarioCount: scenarios.length,
          scenarioId: scenario.id,
          label: scenario.label,
          stageCount,
          requestedLaneCarrierPolicy: clonePerfJson(scenario.laneCarrierPolicy),
          effectiveLaneCarrierPolicy: clonePerfJson(effectiveLaneCarrierPolicy),
          unsupportedRequests: clonePerfJson(normalizedScenario.unsupportedRequests),
        };
      } catch {}
      applyMusicLaneCarrierPolicyOverride(effectiveLaneCarrierPolicy);
      setStatus(`Running Slot/Body Probe ${i + 1}/${scenarios.length}: ${scenario.label}`);
      let result = null;
      try {
        result = await runBS0Stage(stageCount, {
          durationMs: Math.max(15000, Number(scenario.durationMs) || 45000),
          repeatCount: 1,
          freshResetEachRun: true,
          restartTransportEachRun: true,
          resetMusicLabEachRun: true,
          saveMusicLabEachRun: true,
          saveRunIdBase: `musicLab_slot_body_${scenario.id}`,
          saveNotes: `${scenario.notes} policy=${JSON.stringify(effectiveLaneCarrierPolicy)}${unsupportedPolicyText}`,
          groupedScenarioName: `slot_body_probe_${scenario.id}`,
          groupedRunId: `musicLab_slot_body_${scenario.id}_scenario`,
          groupedNotes: `${scenario.notes} policy=${JSON.stringify(effectiveLaneCarrierPolicy)}${unsupportedPolicyText}`,
          tagPrefix: `SlotBodyProbe_${scenario.id}`,
          labelPrefix: `BS0_stage${stageCount}_slot_body_probe_${scenario.id}`,
          statusPrefix: `Running Slot/Body Probe: ${scenario.label}`,
          suppressCompletionUi: true,
        });
      } catch (err) {
        const errorText = String(err && err.message || err || 'unknown_error');
        suiteOutcomes.push({
          scenarioId: scenario.id,
          label: scenario.label,
          stageCount,
          ok: false,
          reason: errorText,
          requestedLaneCarrierPolicy: clonePerfJson(scenario.laneCarrierPolicy),
          effectiveLaneCarrierPolicy: clonePerfJson(effectiveLaneCarrierPolicy),
          unsupportedRequests: clonePerfJson(normalizedScenario.unsupportedRequests),
          saves: [],
        });
        try {
          window.__LAST_SLOT_BODY_PROBE_SUITE = {
            phase: 'scenario_threw',
            scenarioIndex: i + 1,
            scenarioCount: scenarios.length,
            scenarioId: scenario.id,
            label: scenario.label,
            error: errorText,
            suiteOutcomes,
          };
        } catch {}
        setStatus(`Slot/Body probe threw at ${scenario.label}`);
        setOutput({
          ok: false,
          scenarioId: scenario.id,
          label: scenario.label,
          reason: errorText,
          suiteOutcomes,
        });
        return { ok: false, scenarioId: scenario.id, reason: errorText, suiteOutcomes };
      }
      suiteOutcomes.push({
        scenarioId: scenario.id,
        label: scenario.label,
        stageCount,
        ok: result?.ok === true,
        reason: String(result?.reason || ''),
        requestedLaneCarrierPolicy: clonePerfJson(scenario.laneCarrierPolicy),
        effectiveLaneCarrierPolicy: clonePerfJson(effectiveLaneCarrierPolicy),
        unsupportedRequests: clonePerfJson(normalizedScenario.unsupportedRequests),
        saves: Array.isArray(result?.saves) ? result.saves : [],
      });
      try {
        window.__LAST_SLOT_BODY_PROBE_SUITE = {
          phase: 'completed_scenario',
          scenarioIndex: i + 1,
          scenarioCount: scenarios.length,
          scenarioId: scenario.id,
          label: scenario.label,
          result,
          suiteOutcomes,
        };
      } catch {}
      if (result?.ok !== true) {
        setStatus(`Slot/Body probe stopped at ${scenario.label}`);
        setOutput({
          ok: false,
          scenarioId: scenario.id,
          label: scenario.label,
          reason: String(result?.reason || 'probe_failed'),
          suiteOutcomes,
        });
        return { ok: false, scenarioId: scenario.id, reason: String(result?.reason || 'probe_failed'), suiteOutcomes };
      }
      setOutput({
        ok: true,
        phase: 'scenario-complete',
        scenarioIndex: i + 1,
        scenarioCount: scenarios.length,
        scenarioId: scenario.id,
        label: scenario.label,
        suiteOutcomes,
      });
      await sleepPerfLabMs(250);
    }
    let groupedScenario = null;
    try {
      groupedScenario = await publishGroupedMusicLabScenarioBundle({
        scenarioName: 'slot_body_probe_suite',
        runId: 'musicLab_slot_body_probe_suite',
        notes: 'Grouped scenario bundle for fast slot/body probe suite.',
        stageCount: 3,
        durationMs: scenarios.reduce((sum, scenario) => sum + Math.max(15000, Number(scenario.durationMs) || 45000), 0),
        repeatCount: suiteOutcomes.length,
        runOutcomes: suiteOutcomes.flatMap((scenario, idx) => {
          const saves = Array.isArray(scenario.saves) ? scenario.saves : [];
          return saves.map((save) => ({
            runIndex: Math.max(1, Math.trunc(Number(save?.runIndex) || (idx + 1))),
            runId: String(save?.runId || ''),
            saved: !!save?.saved,
            reason: String(save?.reason || ''),
            sessionId: String(save?.sessionId || ''),
            events: Math.max(0, Number(save?.events) || 0),
            sessionSummary: (save?.sessionSummary && typeof save.sessionSummary === 'object') ? save.sessionSummary : null,
          }));
        }),
      });
    } catch {}
    setStatus('Slot/Body probe suite complete');
    setOutput({
      ok: true,
      scenarioCount: scenarios.length,
      suiteOutcomes,
      groupedScenario,
    });
    try {
      window.__LAST_SLOT_BODY_PROBE_SUITE = {
        phase: 'suite_complete',
        scenarioCount: scenarios.length,
        suiteOutcomes,
        groupedScenario,
      };
    } catch {}
    return { ok: true, scenarioCount: scenarios.length, suiteOutcomes, groupedScenario };
  } finally {
    restoreMusicLaneCarrierPolicyOverrideState(previousOverrideState);
  }
}

async function runBS0HandoffMatrixProbeSuite() {
  const scenarios = [
    {
      id: 'snake_group_large',
      label: 'Snake -> Group -> Large',
      stageCount: 4,
      durationMs: 45000,
      laneCarrierPolicy: {
        foundation_lane: ['group'],
        primary_loop_lane: ['drawsnake'],
        secondary_loop_lane: ['group'],
        sparkle_lane: ['group', 'spawner'],
      },
      handoffSlotPreference: {
        special: ['group', 'large', 'generic', 'special'],
        group: ['large', 'generic', 'group', 'special'],
      },
      forcedHandoffReceiverSlot: {
        special: 'group',
        group: 'large',
      },
      forcedProbeHandoff: {
        sourceEnemyType: 'drawsnake',
        minBeatIndex: 16,
      },
      notes: 'Force drawsnake handoff through groups first, then prefer large singleton receivers for follow-on continuity.',
    },
    {
      id: 'snake_group_generic',
      label: 'Snake -> Group -> Generic',
      stageCount: 4,
      durationMs: 45000,
      laneCarrierPolicy: {
        foundation_lane: ['group'],
        primary_loop_lane: ['drawsnake'],
        secondary_loop_lane: ['group'],
        sparkle_lane: ['group', 'spawner'],
      },
      handoffSlotPreference: {
        special: ['group', 'generic', 'large', 'special'],
        group: ['generic', 'large', 'group', 'special'],
      },
      forcedHandoffReceiverSlot: {
        special: 'group',
        group: 'generic',
      },
      forcedProbeHandoff: {
        sourceEnemyType: 'drawsnake',
        minBeatIndex: 16,
      },
      notes: 'Force drawsnake handoff through groups first, then prefer generic singleton receivers for follow-on continuity.',
    },
    {
      id: 'spawner_group_large',
      label: 'Spawner -> Group -> Large',
      stageCount: 4,
      durationMs: 45000,
      laneCarrierPolicy: {
        foundation_lane: ['spawner', 'group'],
        primary_loop_lane: ['drawsnake'],
        secondary_loop_lane: ['spawner', 'group'],
        sparkle_lane: ['spawner', 'group'],
      },
      handoffSlotPreference: {
        special: ['group', 'large', 'generic', 'special'],
        group: ['large', 'generic', 'group', 'special'],
      },
      forcedHandoffReceiverSlot: {
        special: 'group',
        group: 'large',
      },
      forcedProbeHandoff: {
        sourceEnemyType: 'spawner',
        minBeatIndex: 16,
      },
      notes: 'Force spawner handoff through groups first, then prefer large singleton receivers for follow-on continuity.',
    },
    {
      id: 'spawner_group_generic',
      label: 'Spawner -> Group -> Generic',
      stageCount: 4,
      durationMs: 45000,
      laneCarrierPolicy: {
        foundation_lane: ['spawner', 'group'],
        primary_loop_lane: ['drawsnake'],
        secondary_loop_lane: ['spawner', 'group'],
        sparkle_lane: ['spawner', 'group'],
      },
      handoffSlotPreference: {
        special: ['group', 'generic', 'large', 'special'],
        group: ['generic', 'large', 'group', 'special'],
      },
      forcedHandoffReceiverSlot: {
        special: 'group',
        group: 'generic',
      },
      forcedProbeHandoff: {
        sourceEnemyType: 'spawner',
        minBeatIndex: 16,
      },
      notes: 'Force spawner handoff through groups first, then prefer generic singleton receivers for follow-on continuity.',
    },
  ];
  const previousLanePolicyState = captureMusicLaneCarrierPolicyOverrideState();
  const previousHandoffPreferenceState = captureMusicHandoffSlotPreferenceOverrideState();
  const previousForcedReceiverSlotState = captureMusicForcedHandoffReceiverSlotOverrideState();
  const previousForcedProbeHandoffState = captureMusicForcedProbeHandoffOverrideState();
  const suiteOutcomes = [];
  try {
    for (let i = 0; i < scenarios.length; i += 1) {
      const scenario = scenarios[i];
      const normalizedScenario = normalizeMusicLabProbeLaneCarrierPolicy(scenario.laneCarrierPolicy);
      const normalizedPreference = normalizeMusicLabProbeHandoffSlotPreference(scenario.handoffSlotPreference);
      const normalizedForcedReceiverSlot = normalizeMusicLabProbeForcedHandoffReceiverSlot(scenario.forcedHandoffReceiverSlot);
      const effectiveLaneCarrierPolicy = normalizedScenario.normalizedPolicy;
      const effectiveHandoffSlotPreference = normalizedPreference.normalizedPreference;
      const effectiveForcedReceiverSlot = normalizedForcedReceiverSlot.normalizedOverride;
      const effectiveForcedProbeHandoff = clonePerfJson(scenario.forcedProbeHandoff) || null;
      const stageCount = Math.max(1, Math.trunc(Number(scenario.stageCount) || 4));
      const unsupportedPolicyText = normalizedScenario.unsupportedRequests.length
        ? ` unsupportedPolicy=${JSON.stringify(normalizedScenario.unsupportedRequests)}`
        : '';
      const unsupportedPreferenceText = normalizedPreference.unsupportedRequests.length
        ? ` unsupportedHandoff=${JSON.stringify(normalizedPreference.unsupportedRequests)}`
        : '';
      const unsupportedForcedReceiverText = normalizedForcedReceiverSlot.unsupportedRequests.length
        ? ` unsupportedForcedReceiver=${JSON.stringify(normalizedForcedReceiverSlot.unsupportedRequests)}`
        : '';
      try {
        window.__LAST_HANDOFF_MATRIX_PROBE_SUITE = {
          phase: 'starting_scenario',
          scenarioIndex: i + 1,
          scenarioCount: scenarios.length,
          scenarioId: scenario.id,
          label: scenario.label,
          stageCount,
          requestedLaneCarrierPolicy: clonePerfJson(scenario.laneCarrierPolicy),
          effectiveLaneCarrierPolicy: clonePerfJson(effectiveLaneCarrierPolicy),
          requestedHandoffSlotPreference: clonePerfJson(scenario.handoffSlotPreference),
          effectiveHandoffSlotPreference: clonePerfJson(effectiveHandoffSlotPreference),
          requestedForcedHandoffReceiverSlot: clonePerfJson(scenario.forcedHandoffReceiverSlot),
          effectiveForcedHandoffReceiverSlot: clonePerfJson(effectiveForcedReceiverSlot),
          requestedForcedProbeHandoff: clonePerfJson(scenario.forcedProbeHandoff),
          effectiveForcedProbeHandoff: clonePerfJson(effectiveForcedProbeHandoff),
          unsupportedPolicyRequests: clonePerfJson(normalizedScenario.unsupportedRequests),
          unsupportedHandoffRequests: clonePerfJson(normalizedPreference.unsupportedRequests),
          unsupportedForcedReceiverRequests: clonePerfJson(normalizedForcedReceiverSlot.unsupportedRequests),
        };
      } catch {}
      applyMusicLaneCarrierPolicyOverride(effectiveLaneCarrierPolicy);
      applyMusicHandoffSlotPreferenceOverride(effectiveHandoffSlotPreference);
      applyMusicForcedHandoffReceiverSlotOverride(effectiveForcedReceiverSlot);
      applyMusicForcedProbeHandoffOverride(effectiveForcedProbeHandoff);
      setStatus(`Running Handoff Matrix Probe ${i + 1}/${scenarios.length}: ${scenario.label}`);
      let result = null;
      try {
        result = await runBS0Stage(stageCount, {
          durationMs: Math.max(15000, Number(scenario.durationMs) || 45000),
          repeatCount: 1,
          freshResetEachRun: true,
          restartTransportEachRun: true,
          resetMusicLabEachRun: true,
          saveMusicLabEachRun: true,
          saveRunIdBase: `musicLab_handoff_matrix_${scenario.id}`,
          saveNotes: `${scenario.notes} policy=${JSON.stringify(effectiveLaneCarrierPolicy)} handoff=${JSON.stringify(effectiveHandoffSlotPreference)} forcedReceiver=${JSON.stringify(effectiveForcedReceiverSlot)} forcedProbe=${JSON.stringify(effectiveForcedProbeHandoff)}${unsupportedPolicyText}${unsupportedPreferenceText}${unsupportedForcedReceiverText}`,
          groupedScenarioName: `handoff_matrix_probe_${scenario.id}`,
          groupedRunId: `musicLab_handoff_matrix_${scenario.id}_scenario`,
          groupedNotes: `${scenario.notes} policy=${JSON.stringify(effectiveLaneCarrierPolicy)} handoff=${JSON.stringify(effectiveHandoffSlotPreference)} forcedReceiver=${JSON.stringify(effectiveForcedReceiverSlot)} forcedProbe=${JSON.stringify(effectiveForcedProbeHandoff)}${unsupportedPolicyText}${unsupportedPreferenceText}${unsupportedForcedReceiverText}`,
          tagPrefix: `HandoffMatrix_${scenario.id}`,
          labelPrefix: `BS0_stage${stageCount}_handoff_matrix_${scenario.id}`,
          statusPrefix: `Running Handoff Matrix Probe: ${scenario.label}`,
          suppressCompletionUi: true,
        });
      } catch (err) {
        const errorText = String(err && err.message || err || 'unknown_error');
        suiteOutcomes.push({
          scenarioId: scenario.id,
          label: scenario.label,
          stageCount,
          ok: false,
          reason: errorText,
          requestedLaneCarrierPolicy: clonePerfJson(scenario.laneCarrierPolicy),
          effectiveLaneCarrierPolicy: clonePerfJson(effectiveLaneCarrierPolicy),
          requestedHandoffSlotPreference: clonePerfJson(scenario.handoffSlotPreference),
          effectiveHandoffSlotPreference: clonePerfJson(effectiveHandoffSlotPreference),
          requestedForcedHandoffReceiverSlot: clonePerfJson(scenario.forcedHandoffReceiverSlot),
          effectiveForcedHandoffReceiverSlot: clonePerfJson(effectiveForcedReceiverSlot),
          requestedForcedProbeHandoff: clonePerfJson(scenario.forcedProbeHandoff),
          effectiveForcedProbeHandoff: clonePerfJson(effectiveForcedProbeHandoff),
          unsupportedPolicyRequests: clonePerfJson(normalizedScenario.unsupportedRequests),
          unsupportedHandoffRequests: clonePerfJson(normalizedPreference.unsupportedRequests),
          unsupportedForcedReceiverRequests: clonePerfJson(normalizedForcedReceiverSlot.unsupportedRequests),
          saves: [],
        });
        try {
          window.__LAST_HANDOFF_MATRIX_PROBE_SUITE = {
            phase: 'scenario_threw',
            scenarioIndex: i + 1,
            scenarioCount: scenarios.length,
            scenarioId: scenario.id,
            label: scenario.label,
            error: errorText,
            suiteOutcomes,
          };
        } catch {}
        setStatus(`Handoff matrix probe threw at ${scenario.label}`);
        setOutput({
          ok: false,
          scenarioId: scenario.id,
          label: scenario.label,
          reason: errorText,
          suiteOutcomes,
        });
        return { ok: false, scenarioId: scenario.id, reason: errorText, suiteOutcomes };
      }
      suiteOutcomes.push({
        scenarioId: scenario.id,
        label: scenario.label,
        stageCount,
        ok: result?.ok === true,
        reason: String(result?.reason || ''),
        requestedLaneCarrierPolicy: clonePerfJson(scenario.laneCarrierPolicy),
        effectiveLaneCarrierPolicy: clonePerfJson(effectiveLaneCarrierPolicy),
        requestedHandoffSlotPreference: clonePerfJson(scenario.handoffSlotPreference),
        effectiveHandoffSlotPreference: clonePerfJson(effectiveHandoffSlotPreference),
        requestedForcedHandoffReceiverSlot: clonePerfJson(scenario.forcedHandoffReceiverSlot),
        effectiveForcedHandoffReceiverSlot: clonePerfJson(effectiveForcedReceiverSlot),
        requestedForcedProbeHandoff: clonePerfJson(scenario.forcedProbeHandoff),
        effectiveForcedProbeHandoff: clonePerfJson(effectiveForcedProbeHandoff),
        unsupportedPolicyRequests: clonePerfJson(normalizedScenario.unsupportedRequests),
        unsupportedHandoffRequests: clonePerfJson(normalizedPreference.unsupportedRequests),
        unsupportedForcedReceiverRequests: clonePerfJson(normalizedForcedReceiverSlot.unsupportedRequests),
        saves: Array.isArray(result?.saves) ? result.saves : [],
      });
      try {
        window.__LAST_HANDOFF_MATRIX_PROBE_SUITE = {
          phase: 'completed_scenario',
          scenarioIndex: i + 1,
          scenarioCount: scenarios.length,
          scenarioId: scenario.id,
          label: scenario.label,
          result,
          suiteOutcomes,
        };
      } catch {}
      if (result?.ok !== true) {
        setStatus(`Handoff matrix probe stopped at ${scenario.label}`);
        setOutput({
          ok: false,
          scenarioId: scenario.id,
          label: scenario.label,
          reason: String(result?.reason || 'probe_failed'),
          suiteOutcomes,
        });
        return { ok: false, scenarioId: scenario.id, reason: String(result?.reason || 'probe_failed'), suiteOutcomes };
      }
      setOutput({
        ok: true,
        phase: 'scenario-complete',
        scenarioIndex: i + 1,
        scenarioCount: scenarios.length,
        scenarioId: scenario.id,
        label: scenario.label,
        suiteOutcomes,
      });
      await sleepPerfLabMs(250);
    }
    let groupedScenario = null;
    try {
      groupedScenario = await publishGroupedMusicLabScenarioBundle({
        scenarioName: 'handoff_matrix_probe_suite',
        runId: 'musicLab_handoff_matrix_probe_suite',
        notes: 'Grouped scenario bundle for expanded handoff matrix probe suite.',
        stageCount: 4,
        durationMs: scenarios.reduce((sum, scenario) => sum + Math.max(15000, Number(scenario.durationMs) || 45000), 0),
        repeatCount: suiteOutcomes.length,
        runOutcomes: suiteOutcomes.flatMap((scenario, idx) => {
          const saves = Array.isArray(scenario.saves) ? scenario.saves : [];
          return saves.map((save) => ({
            runIndex: Math.max(1, Math.trunc(Number(save?.runIndex) || (idx + 1))),
            runId: String(save?.runId || ''),
            saved: !!save?.saved,
            reason: String(save?.reason || ''),
            sessionId: String(save?.sessionId || ''),
            events: Math.max(0, Number(save?.events) || 0),
            sessionSummary: (save?.sessionSummary && typeof save.sessionSummary === 'object') ? save.sessionSummary : null,
          }));
        }),
      });
    } catch {}
    setStatus('Handoff matrix probe suite complete');
    setOutput({
      ok: true,
      scenarioCount: scenarios.length,
      suiteOutcomes,
      groupedScenario,
    });
    try {
      window.__LAST_HANDOFF_MATRIX_PROBE_SUITE = {
        phase: 'suite_complete',
        scenarioCount: scenarios.length,
        suiteOutcomes,
        groupedScenario,
      };
    } catch {}
    return { ok: true, scenarioCount: scenarios.length, suiteOutcomes, groupedScenario };
  } finally {
    restoreMusicForcedProbeHandoffOverrideState(previousForcedProbeHandoffState);
    restoreMusicForcedHandoffReceiverSlotOverrideState(previousForcedReceiverSlotState);
    restoreMusicHandoffSlotPreferenceOverrideState(previousHandoffPreferenceState);
    restoreMusicLaneCarrierPolicyOverrideState(previousLanePolicyState);
  }
}

async function runBS0a() {
  await runBS0s1();
}

async function runBS0b() {
  await runBS0s2();
}

async function runP7a() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const prevForce = window.__PERF_FORCE_SEQUENCER_ALL;
  try {
    window.__PERF_FORCE_SEQUENCER_ALL = false;
    await runVariantPlaying(
      'P7a_mixed_chains_playing_panzoom_all',
      panZoom,
      'Running P7a (mixed chains, all toys active)...'
    );
  } finally {
    window.__PERF_FORCE_SEQUENCER_ALL = prevForce;
  }
}

async function runP7b() {
  const drawPanels = Array.from(document.querySelectorAll('.toy-panel[data-toy="drawgrid"]'));
  const loopPanels = Array.from(document.querySelectorAll('.toy-panel[data-toy="loopgrid"]'));

  const pickSome = (arr) => arr.filter((_, i) => (i % 3) === 0);

  // Drawgrid: truly empty (no strokes, no nodes)
  const drawEmptyIds = pickSome(drawPanels).map(panelIdSafe).filter(Boolean);
  if (drawEmptyIds.length) silenceDrawgridPanels(drawEmptyIds);

  // Loopgrid: truly empty (no rendered nodes)
  const loopEmptyPanels = pickSome(loopPanels);
  if (loopEmptyPanels.length) emptyLoopgridPanels(loopEmptyPanels);

  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const prevForce = window.__PERF_FORCE_SEQUENCER_ALL;
  try {
    window.__PERF_FORCE_SEQUENCER_ALL = false;
    await runVariantPlaying(
      'P7b_mixed_chains_playing_panzoom_some_empty',
      panZoom,
      'Running P7b (mixed chains, some toys empty)...'
    );
  } finally {
    window.__PERF_FORCE_SEQUENCER_ALL = prevForce;
  }
}

function collectToyTypeCounts() {
  const counts = {};
  try {
    document.querySelectorAll('.toy-panel').forEach((panel) => {
      const type = panel?.dataset?.toy || panel?.getAttribute?.('data-toy') || 'unknown';
      counts[type] = (counts[type] || 0) + 1;
    });
  } catch {}
  return counts;
}

function forcePerfWarmup() {
  try {
    const panels = document.querySelectorAll('.toy-panel[data-toy="drawgrid"]');
    let did = false;
    panels.forEach((panel) => {
      try {
        if (panel?.__dgPerfWarmup) {
          did = true;
          panel.__dgPerfWarmup();
        }
      } catch {}
    });
    if (did) {
      try {
        window.__PERF_WARMUP_COUNT = (window.__PERF_WARMUP_COUNT || 0) + 1;
        window.__PERF_WARMUP_TS = Date.now();
      } catch {}
      try { window.__PerfFrameProf?.mark?.('perf.warmup', 0.001); } catch {}
    }
  } catch {}
}

function percentile(sortedAsc, p) {
  if (!sortedAsc.length) return 0;
  const idx = Math.min(sortedAsc.length - 1, Math.max(0, Math.floor((p / 100) * (sortedAsc.length - 1))));
  return sortedAsc[idx];
}

function statsFromFrameMs(frameMs) {
  const sorted = frameMs.slice().sort((a, b) => a - b);
  const sum = frameMs.reduce((a, b) => a + b, 0);
  const avg = frameMs.length ? sum / frameMs.length : 0;

  const over16 = frameMs.filter(v => v > 16.7).length;
  const over33 = frameMs.filter(v => v > 33.3).length;
  const over50 = frameMs.filter(v => v > 50.0).length;

  return {
    samples: frameMs.length,
    frameMs: {
      avg,
      p50: percentile(sorted, 50),
      p95: percentile(sorted, 95),
      p99: percentile(sorted, 99),
      worst: sorted.length ? sorted[sorted.length - 1] : 0,
    },
    counts: {
      over16ms: over16,
      over33ms: over33,
      over50ms: over50,
    }
  };
}

async function runVariant(label, step, statusText) {
  setStatus(statusText || `Running ${label}?O`);
  setOutput(null);
  lastResult = null;

  try { window.__PERF_CAM_BOUNDS = null; } catch {}

  // Lock particle quality so FPS-driven LOD doesn???t ??save us??? during the test.
  setParticleQualityLock('ultra');

  const durationMs = (typeof window !== 'undefined' && Number.isFinite(window.__PERF_LAB_DURATION_MS))
    ? Math.max(1000, Number(window.__PERF_LAB_DURATION_MS))
    : 30000;
  const result = await runBenchmark({
    label,
    durationMs,
    warmupMs: 1200,
    step,
    warmupAction: forcePerfWarmup,
  });

  try {
    const toys = document.querySelectorAll('.toy-panel, .toy').length;
    const chains = document.querySelectorAll('[data-chain-parent], [data-chain-has-child]').length;
    result.sceneMeta = {
      toys,
      chainMarkers: chains,
      cam: window.__ZoomCoordinator?.getCommittedState?.() || null,
      toyTypes: collectToyTypeCounts(),
      camBounds: window.__PERF_CAM_BOUNDS || null,
    };
  } catch {}

  // Unlock
  setParticleQualityLock(null);

  // Attach toggle state to results for easier comparisons.
  try {
    result.particleToggles = {
      ...(window.__PERF_PARTICLES || {}),
      logFreeze: !!(window.__PERF_PARTICLES && window.__PERF_PARTICLES.logFreeze),
    };
  } catch {}

  // Mirror runVariantPlaying(): capture perf flags so bundles self-verify trace state.
  try {
    let dgPlayheadSeparateEffectiveKnown = 0;
    let dgPlayheadSeparateEffectiveOn = 0;
    let dgTierKnown = 0;
    let dgTierM1 = 0;
    let dgTier0 = 0;
    let dgTier1 = 0;
    let dgTier2 = 0;
    let dgTier3 = 0;
    let dgOverlayLoadShedKnown = 0;
    let dgOverlayLoadShedOn = 0;
    let dgAdaptiveVisibilityOkKnown = 0;
    let dgAdaptiveVisibilityOkOn = 0;
    try {
      const panels = Array.from(document.querySelectorAll('.toy-panel'));
      for (const p of panels) {
        if (!p || p.__dgUseSeparatePlayhead === undefined) continue;
        dgPlayheadSeparateEffectiveKnown++;
        if (p.__dgUseSeparatePlayhead) dgPlayheadSeparateEffectiveOn++;
        if (p.__dgOverlayLoadShed !== undefined) {
          dgOverlayLoadShedKnown++;
          if (p.__dgOverlayLoadShed) dgOverlayLoadShedOn++;
        }
        if (p.__dgAdaptiveVisibilityOk !== undefined) {
          dgAdaptiveVisibilityOkKnown++;
          if (p.__dgAdaptiveVisibilityOk) dgAdaptiveVisibilityOkOn++;
        }
        const t = Number(p.__dgQualityTier);
        if (!Number.isFinite(t)) continue;
        dgTierKnown++;
        if (t <= -1) dgTierM1++;
        else if (t === 0) dgTier0++;
        else if (t === 1) dgTier1++;
        else if (t === 2) dgTier2++;
        else dgTier3++;
      }
    } catch {}
    result.flags = {
      traceCanvasResize: !!(window.__PERF_TRACE && window.__PERF_TRACE.traceCanvasResize),
      traceDomInRaf: !!(window.__PERF_TRACE && window.__PERF_TRACE.traceDomInRaf),
      disableLoopgridRender: !!window.__PERF_DISABLE_LOOPGRID_RENDER,
      disableChains: !!window.__PERF_DISABLE_CHAINS,
      disableChainConnectors: !!window.__PERF_DISABLE_CHAIN_CONNECTORS,
      disableTapDots: !!window.__PERF_DISABLE_TAP_DOTS,
      disableOverlays: !!window.__PERF_DISABLE_OVERLAYS,
      disableOverlayStrokes: !!window.__PERF_DG_OVERLAY_STROKES_OFF,
      disableOverlayCore: !!window.__PERF_DG_OVERLAY_CORE_OFF,
      dgDisableParticles: !!window.__PERF_DG_DISABLE_PARTICLES,
      disablePulses: !!window.__PERF_DISABLE_PULSES,
      freezeAllUnfocused: !!window.__PERF_FREEZE_ALL_UNFOCUSED,
      loopgridGestureRenderMod: Number(window.__PERF_LOOPGRID_GESTURE_RENDER_MOD) || 1,
      loopgridChainCache: !!window.__PERF_LOOPGRID_CHAIN_CACHE,
      noPaint: !!window.__PERF_NO_PAINT,
      noPaintActive: !!window.__PERF_NO_PAINT_ACTIVE,
      paintOnlyActive: !!window.__PERF_PAINT_ONLY_ACTIVE,
      noDomUpdates: !!window.__PERF_NO_DOM_UPDATES,
      disableChainUi: !!window.__PERF_DISABLE_CHAIN_UI,
      traceMarks: !!window.__PERF_TRACE_MARKS,
      tapDotsSim: !!window.__PERF_TAP_DOTS_SIM,
      playheadSeparateCanvas: !!window.__DG_PLAYHEAD_SEPARATE_CANVAS,
      dgPlayheadSeparateEffectiveKnown,
      dgPlayheadSeparateEffectiveOn,
      dgTierKnown,
      dgTierM1,
      dgTier0,
      dgTier1,
      dgTier2,
      dgTier3,
      dgOverlayLoadShedKnown,
      dgOverlayLoadShedOn,
      dgAdaptiveVisibilityOkKnown,
      dgAdaptiveVisibilityOkOn,
      dgTotalCount: Math.max(0, Number(window.__DRAWGRID_GLOBAL?.totalCount) || 0),
      dgSingleCanvas: !!window.__DG_SINGLE_CANVAS,
      runTag: String(window.__PERF_RUN_TAG || ''),
    };
  } catch {}

  // Attach buffered trace (tail only) to avoid console overhead during perf.
  try {
    result.trace = window.__PERF_TRACE_SNAPSHOT ? window.__PERF_TRACE_SNAPSHOT(220) : null;
  } catch {}
  try {
    const keep = (typeof window !== 'undefined') ? !!window.__PERF_TRACE_KEEP_BUFFER : false;
    if (!keep && window.__PERF_TRACE_CLEAR) window.__PERF_TRACE_CLEAR();
  } catch {}
  lastResult = result;
  lastResults.push(result);
  setOutput(result);
  setStatus('Done');
  try { console.log('[PerfLab] result', result); } catch {}
  try { if (window.__PERF_LAB_RUN_CONTEXT !== 'auto') await publishResultBundle(result, { queue: [label], notes: statusText || '', runId: 'manual' }); } catch {}
}

// -------------------------------------------------------------------
// Perf run tag helpers
// -------------------------------------------------------------------
function __perfSetRunTagPart(key, tag) {
  try {
    if (!window.__PERF_RUN_TAG_PARTS || typeof window.__PERF_RUN_TAG_PARTS !== 'object') {
      window.__PERF_RUN_TAG_PARTS = {};
    }
    if (tag == null || tag === '') {
      try { delete window.__PERF_RUN_TAG_PARTS[key]; } catch {}
    } else {
      window.__PERF_RUN_TAG_PARTS[key] = String(tag);
    }
  } catch {}
}

function __perfGetRunTagSuffix() {
  try {
    const tags = [];

    // Back-compat: single string tag
    const single = String(window.__PERF_RUN_TAG || '').trim();
    if (single) tags.push(single);

    // New: keyed parts (stable ordering)
    const parts = window.__PERF_RUN_TAG_PARTS;
    if (parts && typeof parts === 'object') {
      const keys = Object.keys(parts).sort();
      for (const k of keys) {
        const v = String(parts[k] || '').trim();
        if (v) tags.push(v);
      }
    }

    // New: array of tags (optional)
    const arr = window.__PERF_RUN_TAGS;
    if (Array.isArray(arr)) {
      for (const v of arr) {
        const s = String(v || '').trim();
        if (s) tags.push(s);
      }
    }

    // Dedupe while preserving order
    const seen = new Set();
    const out = [];
    for (const t of tags) {
      if (seen.has(t)) continue;
      seen.add(t);
      out.push(t);
    }

    return out.length ? `__${out.join('+')}` : '';
  } catch {}
  return '';
}

async function runVariantPlaying(label, step, statusText, options = null) {
  const opts = options && typeof options === 'object' ? options : {};
  const stopTransportAtEnd = opts.stopTransportAtEnd !== false;
  const publishResultAtEnd = opts.publishResultAtEnd !== false;
  const hardTimeoutMs = Math.max(15000, Number(opts.hardTimeoutMs) || 8000);
  const warmupMs = 1200;
  // Make variant labels self-describing (tier/AB toggles, etc).
  // Without this, perf-lab-results-<timestamp>.json ends up with many identical labels,
  // which is painful to compare.
  const fullLabel = (() => {
    try {
      return `${label}${__perfGetRunTagSuffix()}`;
    } catch {}
    return label;
  })();
  const slowMs = (typeof window !== 'undefined' && Number.isFinite(window.__PERF_FRAME_PROF_SLOW_MS))
    ? window.__PERF_FRAME_PROF_SLOW_MS
    : 50;
  const traceLongMs = (typeof window !== 'undefined' && Number.isFinite(window.__PERF_TRACE_LONG_MS))
    ? window.__PERF_TRACE_LONG_MS
    : slowMs;
  const maxSamples = (typeof window !== 'undefined' && Number.isFinite(window.__PERF_FRAME_PROF_MAX))
    ? window.__PERF_FRAME_PROF_MAX
    : 120;
  const prof = makeFrameProfiler({ slowMs, maxSamples });
  window.__PerfFrameProf = prof; // so you can dump it from console
  const durationMs = Number.isFinite(Number(opts.durationMs))
    ? Math.max(1000, Number(opts.durationMs))
    : ((typeof window !== 'undefined' && Number.isFinite(window.__PERF_LAB_DURATION_MS))
      ? Math.max(1000, Number(window.__PERF_LAB_DURATION_MS))
      : 30000);
  const scriptStep = step;
  const nowMs = () => (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  const raf = (fn) => (window.requestAnimationFrame ? window.requestAnimationFrame(fn) : setTimeout(() => fn(nowMs()), 16));
  const defer = (fn) => (typeof setTimeout === 'function' ? setTimeout(fn, 0) : raf(fn));
  let warmupDid = false;
  let pendingFrame = null;
  let pendingFrameTimer = 0;
  let rafWrapped = false;
  let rafOriginal = null;
  const frameMs = [];
  let runVariantFrameCount = 0;
  const warmupTriggerMs = Math.max(0, Math.min(warmupMs - 50, warmupMs * 0.5));
  let startMs = null;
  let lastMs = null;
  const wallStartMs = nowMs();
  setStatus(statusText || `Running ${label}...`);
  setOutput(null);
  lastResult = null;
  try { window.__PERF_LAB_DEFER_DEBUG_POSTS = true; } catch {}

  try { window.__PERF_CAM_BOUNDS = null; } catch {}
  const traceMarksEnabled = () => !!window.__PERF_TRACE_MARKS
    && typeof performance !== 'undefined'
    && typeof performance.measure === 'function';
  if (traceMarksEnabled() && typeof performance.clearMeasures === 'function') {
    try { performance.clearMeasures('mt:frame.long'); } catch {}
  }

  // Lock particle quality so FPS-driven LOD does not save us during the test.
  setParticleQualityLock('ultra');

  // Ensure transport is running during the sample window
  try {
    try {
      window.__PERF_ACTIVE_RUN_DEBUG = {
        runId: String(fullLabel || ''),
        sourceLabel: fullLabel,
        durationMs,
        perfRunTag: String(window.__PERF_RUN_TAG || ''),
        startedAt: new Date().toISOString(),
        wallStartMs,
        frameCountRef: () => runVariantFrameCount,
      };
    } catch {}
    if (!isRunning()) startTransport();
  } catch {}

  // Wrap rAF to catch untagged work inside rAF callbacks.
  try {
    if (!window.__PERF_RAF_WRAPPED && typeof window.requestAnimationFrame === 'function') {
      rafOriginal = window.requestAnimationFrame;
      window.__PERF_RAF_ORIG = rafOriginal;
      window.requestAnimationFrame = function(callback) {
        return rafOriginal.call(window, function(ts) {
          const __perfOn = !!(window.__PerfFrameProf && typeof performance !== 'undefined' && performance.now);
          const t0 = __perfOn ? performance.now() : 0;
          const tag = (callback && typeof callback.__perfRafTag === 'string') ? callback.__perfRafTag : 'perf.raf.other';
          try { return callback(ts); }
          finally {
            if (__perfOn && t0) {
              try { window.__PerfFrameProf.mark(tag, performance.now() - t0); } catch {}
            }
          }
        });
      };
      window.__PERF_RAF_WRAPPED = true;
      rafWrapped = true;
    }
  } catch {}

  // Reset per-run pulse/outline counters
  try {
    window.__PERF_PULSE_COUNT = 0;
    window.__PERF_OUTLINE_SYNC_COUNT = 0;
    window.__PERF_WARMUP_COUNT = 0;
    window.__PERF_DG_BACKING_RESIZE_COUNT = 0;
    window.__PERF_DG_OVERLAY_RESIZE_COUNT = 0;
  } catch {}

  const result = await new Promise((resolve, reject) => {
    const finalizePendingFrame = () => {
      if (!pendingFrame) return;
      if (traceMarksEnabled()
        && pendingFrame.frameDt >= traceLongMs
        && Number.isFinite(pendingFrame.meta?.traceStart)
        && Number.isFinite(pendingFrame.meta?.traceEnd)) {
        try {
          performance.measure('mt:frame.long', {
            start: pendingFrame.meta.traceStart,
            end: pendingFrame.meta.traceEnd,
          });
        } catch {}
      }
      prof.endFrame(pendingFrame.frameDt, pendingFrame.meta);
      pendingFrame = null;
      pendingFrameTimer = 0;
    };
    let settled = false;
    let watchdogTimer = 0;
    let durationTimer = 0;
    const clearWatchdog = () => {
      if (!watchdogTimer) return;
      try { clearTimeout(watchdogTimer); } catch {}
      watchdogTimer = 0;
    };
    const clearDurationTimer = () => {
      if (!durationTimer) return;
      try { clearTimeout(durationTimer); } catch {}
      durationTimer = 0;
    };
    const settleResolve = (value) => {
      if (settled) return;
      settled = true;
      clearWatchdog();
      clearDurationTimer();
      resolve(value);
    };
    const settleReject = (err) => {
      if (settled) return;
      settled = true;
      clearWatchdog();
      clearDurationTimer();
      reject(err);
    };
    durationTimer = setTimeout(() => {
      if (pendingFrame) finalizePendingFrame();
      const s = statsFromFrameMs(frameMs);
      settleResolve({
        label: fullLabel,
        durationMs,
        warmupMs,
        createdAt: new Date().toISOString(),
        ...s,
      });
    }, durationMs);
    watchdogTimer = setTimeout(() => {
      const elapsedMs = Math.max(0, nowMs() - wallStartMs);
      publishRunVariantDebugResultAsync({
        label: `run-variant-debug__${fullLabel}`,
        runId: String(fullLabel || ''),
        stage: 'watchdog_timeout',
        sourceLabel: fullLabel,
        durationMs,
        elapsedMs,
        frameCount: runVariantFrameCount,
        warmupMs,
        transportRunning: isRunning(),
        beatSwarmActive: !!window.__beatSwarmActive,
        perfRunTag: String(window.__PERF_RUN_TAG || ''),
      });
      settleReject(new Error(`runVariantPlaying watchdog timeout after ${elapsedMs}ms`));
    }, durationMs + hardTimeoutMs);

      const stepFrame = (ts) => {
        try {
        if (settled) return;
        if (startMs === null) {
          startMs = ts;
          lastMs = ts;
        }

        const t = ts - startMs;
        const dtMs = ts - lastMs;
        lastMs = ts;
        runVariantFrameCount += 1;

        if (pendingFrame) finalizePendingFrame();

        const t0 = nowMs();
        const s0 = nowMs();
        try { if (scriptStep) scriptStep(t, dtMs, Math.min(1, t / durationMs)); } catch {}
        let forceSample = false;
        let warmupTag = false;
        if (!warmupDid && t >= warmupTriggerMs && t <= warmupMs) {
          warmupDid = true;
          forceSample = true;
          warmupTag = true;
          try { forcePerfWarmup(); } catch {}
        }
        prof.mark('script', nowMs() - s0);
        const workMs = Math.max(0, nowMs() - t0);
        const frameDt = Number.isFinite(dtMs) ? dtMs : (nowMs() - t0);
        const idleMs = Math.max(0, frameDt - workMs);
        const frameStart = Number.isFinite(dtMs) ? (ts - dtMs) : ts;
        const frameEnd = ts;
        pendingFrame = {
          frameDt,
          meta: { workMs, idleMs, forceSample, warmupTag, traceStart: frameStart, traceEnd: frameEnd },
        };
        if (!pendingFrameTimer) pendingFrameTimer = defer(finalizePendingFrame);

        if (t > warmupMs) frameMs.push(frameDt);

        if (t >= durationMs) {
          publishRunVariantDebugResultAsync({
            label: `run-variant-debug__${fullLabel}`,
            runId: String(fullLabel || ''),
            stage: 'duration_reached',
            sourceLabel: fullLabel,
            durationMs,
            elapsedMs: t,
            frameCount: runVariantFrameCount,
            warmupMs,
            transportRunning: isRunning(),
            beatSwarmActive: !!window.__beatSwarmActive,
            perfRunTag: String(window.__PERF_RUN_TAG || ''),
          });
          if (pendingFrame) finalizePendingFrame();
          const s = statsFromFrameMs(frameMs);
          settleResolve({
            label: fullLabel,
            durationMs,
            warmupMs,
            createdAt: new Date().toISOString(),
            ...s,
          });
          return;
        }
        raf(stepFrame);
        } catch (err) {
          publishRunVariantDebugResultAsync({
            label: `run-variant-debug__${fullLabel}`,
            runId: String(fullLabel || ''),
            stage: 'frame_threw',
            sourceLabel: fullLabel,
            durationMs,
            elapsedMs: Math.max(0, nowMs() - wallStartMs),
            frameCount: runVariantFrameCount,
            warmupMs,
            transportRunning: isRunning(),
            beatSwarmActive: !!window.__beatSwarmActive,
            perfRunTag: String(window.__PERF_RUN_TAG || ''),
            notes: String(err && err.message || err || 'unknown_error'),
          });
          settleReject(err);
        }
      };
      stepFrame.__perfRafTag = 'perf.raf.benchmark';
      raf(stepFrame);
    });

  try {
    result.pulseCount = window.__PERF_PULSE_COUNT || 0;
    result.outlineSyncCount = window.__PERF_OUTLINE_SYNC_COUNT || 0;
    result.warmupCount = window.__PERF_WARMUP_COUNT || 0;
    result.warmupTs = window.__PERF_WARMUP_TS || null;
    result.dgBackingResizeCount = window.__PERF_DG_BACKING_RESIZE_COUNT || 0;
    result.dgOverlayResizeCount = window.__PERF_DG_OVERLAY_RESIZE_COUNT || 0;
  } catch {}

  try {
    const samples = prof.snapshot();
    const worstSample = prof.getWorst ? prof.getWorst() : null;
    result.frameProfile = summarizeFrameProfile(samples);
    result.warmupProfile = prof.getWarmup ? prof.getWarmup() : null;
    if (worstSample) {
      result.frameProfileWorst = summarizeWorstFrame([worstSample]);
    } else {
      result.frameProfileWorst = summarizeWorstFrame(samples);
    }
  } catch {}

  try {
    const toys = document.querySelectorAll('.toy-panel, .toy').length;
    const chains = document.querySelectorAll('[data-chain-parent], [data-chain-has-child]').length;
    result.sceneMeta = {
      toys,
      chainMarkers: chains,
      cam: window.__ZoomCoordinator?.getCommittedState?.() || null,
      toyTypes: collectToyTypeCounts(),
      camBounds: window.__PERF_CAM_BOUNDS || null,
    };
  } catch {}

  // Stop after test to avoid surprise audio continuing.
  // BS0 music-lab runs can defer this until after the session export completes.
  if (stopTransportAtEnd) {
    try { stopTransport(); } catch {}
  }

  // Restore rAF if we wrapped it.
  if (rafWrapped && rafOriginal) {
    try { window.requestAnimationFrame = rafOriginal; } catch {}
    try { delete window.__PERF_RAF_WRAPPED; } catch {}
    try { delete window.__PERF_RAF_ORIG; } catch {}
  }

  setParticleQualityLock(null);

  try {
    result.particleToggles = { ...(window.__PERF_PARTICLES || {}) };
    result.particleTempPatch = window.__PERF_PARTICLES__TEMP_PATCH || null;
    result.playing = true;
    result.musicLabSaveResult = (window.__LAST_MUSIC_LAB_SAVE_RESULT && typeof window.__LAST_MUSIC_LAB_SAVE_RESULT === 'object')
      ? { ...window.__LAST_MUSIC_LAB_SAVE_RESULT }
      : null;
    let dgPlayheadSeparateEffectiveKnown = 0;
      let dgPlayheadSeparateEffectiveOn = 0;
      let dgTierKnown = 0;
      let dgTierM1 = 0;
      let dgTier0 = 0;
      let dgTier1 = 0;
      let dgTier2 = 0;
      let dgTier3 = 0;
      let dgOverlayLoadShedKnown = 0;
      let dgOverlayLoadShedOn = 0;
      let dgAdaptiveVisibilityOkKnown = 0;
      let dgAdaptiveVisibilityOkOn = 0;
      try {
        const panels = Array.from(document.querySelectorAll('.toy-panel'));
        for (const p of panels) {
          if (!p || p.__dgUseSeparatePlayhead === undefined) continue;
          dgPlayheadSeparateEffectiveKnown++;
          if (p.__dgUseSeparatePlayhead) dgPlayheadSeparateEffectiveOn++;
          if (p.__dgOverlayLoadShed !== undefined) {
            dgOverlayLoadShedKnown++;
            if (p.__dgOverlayLoadShed) dgOverlayLoadShedOn++;
          }
          if (p.__dgAdaptiveVisibilityOk !== undefined) {
            dgAdaptiveVisibilityOkKnown++;
            if (p.__dgAdaptiveVisibilityOk) dgAdaptiveVisibilityOkOn++;
          }
          const t = Number(p.__dgQualityTier);
          if (!Number.isFinite(t)) continue;
          dgTierKnown++;
          if (t <= -1) dgTierM1++;
          else if (t === 0) dgTier0++;
          else if (t === 1) dgTier1++;
          else if (t === 2) dgTier2++;
          else dgTier3++;
        }
      } catch {}
      result.flags = {
        // Perf trace toggles (demon hunting)
        traceCanvasResize: !!(window.__PERF_TRACE && window.__PERF_TRACE.traceCanvasResize),
        traceDomInRaf: !!(window.__PERF_TRACE && window.__PERF_TRACE.traceDomInRaf),

        disableLoopgridRender: !!window.__PERF_DISABLE_LOOPGRID_RENDER,
        disableChains: !!window.__PERF_DISABLE_CHAINS,
        disableChainConnectors: !!window.__PERF_DISABLE_CHAIN_CONNECTORS,
        disableTapDots: !!window.__PERF_DISABLE_TAP_DOTS,
        disableOverlays: !!window.__PERF_DISABLE_OVERLAYS,
        disableOverlayStrokes: !!window.__PERF_DG_OVERLAY_STROKES_OFF,
        disableOverlayCore: !!window.__PERF_DG_OVERLAY_CORE_OFF,
        dgDisableParticles: !!window.__PERF_DG_DISABLE_PARTICLES,
        disablePulses: !!window.__PERF_DISABLE_PULSES,
        freezeAllUnfocused: !!window.__PERF_FREEZE_ALL_UNFOCUSED,
        loopgridGestureRenderMod: Number(window.__PERF_LOOPGRID_GESTURE_RENDER_MOD) || 1,
        loopgridChainCache: !!window.__PERF_LOOPGRID_CHAIN_CACHE,
        noPaint: !!window.__PERF_NO_PAINT,
        noPaintActive: !!window.__PERF_NO_PAINT_ACTIVE,
        paintOnlyActive: !!window.__PERF_PAINT_ONLY_ACTIVE,
        noDomUpdates: !!window.__PERF_NO_DOM_UPDATES,
        disableChainUi: !!window.__PERF_DISABLE_CHAIN_UI,
        traceMarks: !!window.__PERF_TRACE_MARKS,
        tapDotsSim: !!window.__PERF_TAP_DOTS_SIM,
        playheadSeparateCanvas: !!window.__DG_PLAYHEAD_SEPARATE_CANVAS,
        dgPlayheadSeparateEffectiveKnown,
        dgPlayheadSeparateEffectiveOn,
        dgTierKnown,
        dgTierM1,
        dgTier0,
        dgTier1,
        dgTier2,
        dgTier3,
        dgOverlayLoadShedKnown,
        dgOverlayLoadShedOn,
        dgAdaptiveVisibilityOkKnown,
        dgAdaptiveVisibilityOkOn,
        dgTotalCount: Math.max(0, Number(window.__DRAWGRID_GLOBAL?.totalCount) || 0),
        dgSingleCanvas: !!window.__DG_SINGLE_CANVAS,
        runTag: String(window.__PERF_RUN_TAG || ''),
      };
    result.gestureSkipCount = window.__PERF_LOOPGRID_GESTURE_SKIP || 0;
  } catch {}

  // Attach buffered trace (tail only) to avoid console overhead during perf.
  try {
    result.trace = window.__PERF_TRACE_SNAPSHOT ? window.__PERF_TRACE_SNAPSHOT(220) : null;
  } catch {}
  try {
    const keep = (typeof window !== 'undefined') ? !!window.__PERF_TRACE_KEEP_BUFFER : false;
    if (!keep && window.__PERF_TRACE_CLEAR) window.__PERF_TRACE_CLEAR();
  } catch {}

  try { window.__PerfFrameProf?.dump?.(label); } catch {}

  publishRunVariantDebugResultAsync({
    label: `run-variant-debug__${fullLabel}`,
    runId: String(fullLabel || ''),
    stage: 'after_resolve',
    sourceLabel: fullLabel,
    durationMs,
    elapsedMs: durationMs,
    frameCount: runVariantFrameCount,
    warmupMs,
    transportRunning: isRunning(),
    beatSwarmActive: !!window.__beatSwarmActive,
    perfRunTag: String(window.__PERF_RUN_TAG || ''),
  });

  lastResult = result;
  lastResults.push(result);
  setOutput(result);
  setStatus('Done');
  try { console.log('[PerfLab] result', result); } catch {}
  try {
    if (publishResultAtEnd && window.__PERF_LAB_RUN_CONTEXT !== 'auto') {
      await publishResultBundle(result, { queue: [label], notes: statusText || '', runId: 'manual' });
    }
  } catch {}
  try { window.__PERF_ACTIVE_RUN_DEBUG = null; } catch {}
  try { delete window.__PERF_LAB_DEFER_DEBUG_POSTS; } catch {}
}

async function withTempPerfParticles(patch, fn) {
  const st = (window.__PERF_PARTICLES = window.__PERF_PARTICLES || {});
  const prev = { ...st };
  Object.assign(st, patch || {});
  window.__PERF_PARTICLES__TEMP_PATCH = patch || null;
  try { return await fn(); }
  finally {
    window.__PERF_PARTICLES__TEMP_PATCH = null;
    Object.assign(st, prev);
  }
}

function makeFrameProfiler({ slowMs = 50, maxSamples = 120 } = {}) {
  const out = [];
  let warmup = null;
  let worst = null;
  return {
    mark(name, dt) {
      // accumulate by name for the current frame
      const cur = (this.__cur ||= { t: performance.now(), parts: {} });
      cur.parts[name] = (cur.parts[name] || 0) + (dt || 0);
    },
    endFrame(frameDt, meta = {}) {
      if (!this.__cur) return;
      const cur = this.__cur;
      this.__cur = null;

      const parts = cur.parts || {};
      let sum = 0;
      for (const k in parts) {
        const v = parts[k];
        if (Number.isFinite(v)) sum += v;
      }
      const unattributed = Math.max(0, frameDt - sum);
      if (unattributed > 0) parts.unattributed = unattributed;
      const scriptMs = Number.isFinite(parts.script) ? parts.script : 0;
      const nonScript = Math.max(0, frameDt - scriptMs);
      if (nonScript > 0) parts['frame.nonScript'] = nonScript;

      if (meta.warmupTag) {
        warmup = {
          t: cur.t,
          frameDt,
          parts: { ...parts },
          workMs: meta.workMs,
          idleMs: meta.idleMs,
        };
      }
      const shouldCaptureMem =
        meta.forceSample ||
        frameDt >= slowMs ||
        !worst ||
        frameDt > (worst.frameDt || 0);
      const memory = shouldCaptureMem ? readPerfMemory() : null;
      const sample = { t: cur.t, frameDt, parts, workMs: meta.workMs, idleMs: meta.idleMs, memory };
      if (!worst || (sample.frameDt > (worst.frameDt || 0))) worst = sample;
      if (frameDt >= slowMs || meta.forceSample) {
        out.push(sample);
        if (out.length > maxSamples) out.shift();
      }
    },
    snapshot() { return out.slice(); },
    getWorst() { return worst ? { ...worst, parts: { ...(worst.parts || {}) } } : null; },
    getWarmup() { return warmup ? { ...warmup, parts: { ...(warmup.parts || {}) } } : null; },
    dump(label = 'frame-profiler') {
      console.log(`[${label}] samples=${out.length}`, out);
      return out;
    },
    reset() { out.length = 0; },
  };
}

function summarizeFrameProfile(samples) {
  const out = { samples: 0, parts: {}, work: { totalMs: 0, avgMs: 0 }, idle: { totalMs: 0, avgMs: 0 } };
  if (!Array.isArray(samples) || samples.length === 0) return out;
  out.samples = samples.length;
  for (const s of samples) {
    const parts = s?.parts || {};
    if (Number.isFinite(s?.workMs)) out.work.totalMs += s.workMs;
    if (Number.isFinite(s?.idleMs)) out.idle.totalMs += s.idleMs;
    for (const k in parts) {
      const v = parts[k];
      if (!Number.isFinite(v)) continue;
      const p = (out.parts[k] ||= { totalMs: 0 });
      p.totalMs += v;
    }
  }
  for (const k in out.parts) {
    const v = out.parts[k];
    if (!v || !Number.isFinite(v.totalMs)) continue;
    v.avgMs = v.totalMs / out.samples;
  }
  if (out.samples > 0) {
    out.work.avgMs = out.work.totalMs / out.samples;
    out.idle.avgMs = out.idle.totalMs / out.samples;
  }
  return out;
}
function composeSteps(...steps) {
  return function step(tMs, dtMs, progress) {
    for (const s of steps) {
      try { if (typeof s === 'function') s(tMs, dtMs, progress); } catch {}
    }
  };
}

async function withTempAnchorDisabled(disabled, fn) {
  const prev = window.__MT_ANCHOR_DISABLED;
  window.__MT_ANCHOR_DISABLED = !!disabled;
  try { initBoardAnchor(); } catch {}
  try { return await fn(); }
  finally {
    window.__MT_ANCHOR_DISABLED = prev;
    try { initBoardAnchor(); } catch {}
  }
}


async function withTempAnchorEnabled(fn) {
  let prev = null;
  let hadPrev = false;
  try {
    prev = localStorage.getItem('mt_anchor_enabled');
    hadPrev = prev !== null;
    localStorage.setItem('mt_anchor_enabled', '1');
  } catch {}
  try { return await withTempAnchorDisabled(false, fn); }
  finally {
    try {
      if (hadPrev) localStorage.setItem('mt_anchor_enabled', prev);
      else localStorage.removeItem('mt_anchor_enabled');
    } catch {}
  }
}

async function withTempPerfAnchor(patch, fn) {
  const st = (window.__PERF_ANCHOR = window.__PERF_ANCHOR || {});
  const prev = { ...st };
  Object.assign(st, patch || {});
  try { return await fn(); }
  finally { Object.assign(st, prev); }
}

function clearSceneViaSnapshot() {
  const P = window.Persistence;
  if (!P || typeof P.getSnapshot !== 'function' || typeof P.applySnapshot !== 'function') {
    console.warn('[PerfLab] Persistence API not ready');
    return false;
  }
  const snap = P.getSnapshot();
  snap.toys = [];
  snap.chains = [];
  const ok = !!P.applySnapshot(snap);
  try { window.resetChainState?.({ clearDom: true }); } catch {}
  return ok;
}

function createToyGrid({ toyType, rows, cols, spacing, centerX, centerY }) {
  const factory = window.MusicToyFactory;
  if (!factory || typeof factory.create !== 'function') {
    console.warn('[PerfLab] MusicToyFactory.create not ready');
    return false;
  }

  const totalW = (cols - 1) * spacing;
  const totalH = (rows - 1) * spacing;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const x = centerX + (c * spacing - totalW / 2);
      const y = centerY + (r * spacing - totalH / 2);
      try {
        factory.create(toyType, { centerX: x, centerY: y, autoCenter: false, allowOffscreen: true, skipSpawnPlacement: true });
      } catch (err) {
        console.warn('[PerfLab] create failed', { toyType, r, c }, err);
      }
    }
  }
  return true;
}

function createChainedToys({
  toyType,
  chains = 4,
  chainLength = 4,
  headX,
  headSpacingY,
  linkSpacingX,
  centerY,
  jitterY = 0,
} = {}) {
  const factory = window.MusicToyFactory;
  if (!factory || typeof factory.create !== 'function') {
    console.warn('[PerfLab] MusicToyFactory.create not ready');
    return [];
  }
  const rows = Math.max(1, chains | 0);
  const totalH = (rows - 1) * headSpacingY;
  const out = [];
  for (let r = 0; r < rows; r++) {
    const baseY = centerY + (r * headSpacingY - totalH / 2);
    const panels = [];
    for (let k = 0; k < chainLength; k++) {
      const x = headX + k * linkSpacingX;
      const jitter = Math.max(0, Number.isFinite(jitterY) ? jitterY : 0);
      const y = baseY + (jitter ? Math.round((Math.random() * 2 - 1) * jitter) : 0);
      try {
        const panel = factory.create(toyType, {
          centerX: x,
          centerY: y,
          autoCenter: false,
          allowOffscreen: true,
          skipSpawnPlacement: true,
        });
        if (panel) panels.push(panel);
      } catch (err) {
        console.warn('[PerfLab] create failed', { toyType, r, k }, err);
      }
    }
    out.push(panels);
  }
  return out;
}

function readPerfMemory() {
  try {
    const mem = (typeof performance !== 'undefined') ? performance.memory : null;
    if (!mem) return null;
    return {
      used: mem.usedJSHeapSize,
      total: mem.totalJSHeapSize,
      limit: mem.jsHeapSizeLimit,
    };
  } catch {
    return null;
  }
}

function summarizeWorstFrame(samples, limit = 8) {
  if (!Array.isArray(samples) || samples.length === 0) return null;
  let worst = samples[0];
  for (let i = 1; i < samples.length; i++) {
    const s = samples[i];
    if ((s?.frameDt || 0) > (worst?.frameDt || 0)) worst = s;
  }
  if (!worst) return null;
  const parts = worst.parts || {};
  const rows = Object.keys(parts)
    .map((name) => ({ name, ms: parts[name] }))
    .filter((row) => Number.isFinite(row.ms))
    .sort((a, b) => b.ms - a.ms)
    .slice(0, Math.max(1, limit | 0));
  return {
    frameDt: worst.frameDt,
    workMs: worst.workMs,
    idleMs: worst.idleMs,
    memory: worst.memory || null,
    parts: rows,
  };
}

function linkToyChains(chains) {
  if (!Array.isArray(chains)) return;
  for (const panels of chains) {
    for (let k = 0; k < (panels?.length || 0) - 1; k++) {
      const a = panels[k];
      const b = panels[k + 1];
      if (!a?.id || !b?.id) continue;
      a.dataset.nextToyId = b.id;
      a.dataset.chainHasChild = '1';
      b.dataset.prevToyId = a.id;
      b.dataset.chainParent = a.id;
    }
  }
}

function collectPanelsFromChains(chains) {
  const out = [];
  if (!Array.isArray(chains)) return out;
  for (const chain of chains) {
    if (!Array.isArray(chain)) continue;
    for (const panel of chain) {
      if (panel) out.push(panel);
    }
  }
  return out;
}

function mulberry32(seed) {
  let a = (seed >>> 0) || 1;
  return function rand() {
    a |= 0;
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function seedLoopgridPanels(panels, { density = 0.35, seed = 1337, randomizeNotes = true } = {}) {
  const rand = mulberry32(seed);
  let seeded = 0;
  for (const panel of panels) {
    const st = panel?.__gridState;
    if (!st || !Array.isArray(st.steps) || !Array.isArray(st.noteIndices)) continue;
    let anyOn = false;
    for (let i = 0; i < st.steps.length; i++) {
      const on = rand() < density;
      st.steps[i] = on;
      if (on) anyOn = true;
    }
    if (!anyOn && st.steps.length) {
      st.steps[Math.floor(rand() * st.steps.length)] = true;
    }
      if (randomizeNotes) {
        const palette = Array.isArray(st.notePalette) && st.notePalette.length ? st.notePalette : null;
        for (let i = 0; i < st.noteIndices.length; i++) {
          if (palette) {
            const pick = Math.floor(rand() * palette.length);
            st.noteIndices[i] = pick;
          }
        }
      }
    try {
      panel.dispatchEvent(new CustomEvent('loopgrid:update', {
        detail: {
          reason: 'perf-seed',
          steps: Array.from(st.steps),
          noteIndices: Array.from(st.noteIndices),
        },
      }));
    } catch {}
    seeded += 1;
  }
  return seeded;
}

function silenceLoopgridPanels(panels = []) {
  let changed = 0;
  for (const panel of panels) {
    const st = panel?.__gridState;
    if (!st || !Array.isArray(st.steps) || !Array.isArray(st.noteIndices)) continue;
    for (let i = 0; i < st.steps.length; i++) {
      st.steps[i] = false;
    }
    try {
      panel.dispatchEvent(new CustomEvent('loopgrid:update', {
        detail: {
          reason: 'perf-silence',
          steps: Array.from(st.steps),
          noteIndices: Array.from(st.noteIndices),
        },
      }));
      changed += 1;
    } catch {}
  }
  return changed;
}

function panelIdSafe(panel) {
  return panel?.id || panel?.dataset?.toyid || panel?.dataset?.toyId || '';
}

function emptyLoopgridPanels(panels = []) {
  const P = window.Persistence;
  if (!P || typeof P.getSnapshot !== 'function' || typeof P.applySnapshot !== 'function') return false;

  const ids = new Set((panels || []).map(panelIdSafe).filter(Boolean));
  if (ids.size === 0) return false;

  let changed = 0;
  try {
    const snap = P.getSnapshot();
    const toys = Array.isArray(snap?.toys) ? snap.toys : [];

    for (const t of toys) {
      const id = t?.id;
      if (!id || !ids.has(id)) continue;

      t.state = t.state || {};
      // Make it truly “empty” (no rendered nodes)
      t.state.steps = [];
      t.state.noteIndices = [];
      t.state.notes = [];
      changed++;
    }

    if (!changed) return false;

    const ok = !!P.applySnapshot(snap);
    if (!ok) return false;

    // Nudge visuals
    try {
      window.updateAllToys?.();
      window.scheduleAllToysRedraw?.();
      window.requestAnimationFrame?.(() => {
        window.updateAllToys?.();
        window.scheduleAllToysRedraw?.();
      });
    } catch {}

    // Nudge loopgrid panels directly too (safe, best-effort)
    try {
      ids.forEach((id) => {
        const panel = document.getElementById(id);
        if (!panel) return;
        panel.dispatchEvent(new CustomEvent('loopgrid:update', {
          detail: { reason: 'perf-empty', steps: [], noteIndices: [] },
          bubbles: true,
        }));
      });
    } catch {}

    try { window.Persistence?.markDirty?.(); } catch {}
    return true;
  } catch {
    return false;
  }
}

function getChainHeadId(panel) {
  let current = panel;
  let sanity = 50;
  while (current && current.dataset?.prevToyId && sanity-- > 0) {
    const prev = document.getElementById(current.dataset.prevToyId);
    if (!prev || prev === current) break;
    current = prev;
  }
  return current?.id || '';
}

function syncChainInstruments(chains) {
  if (!Array.isArray(chains)) return;
  for (const panels of chains) {
    if (!Array.isArray(panels) || panels.length === 0) continue;
    const head = panels[0];
    const instrument = head?.dataset?.instrument;
    if (!instrument) continue;
    panels.forEach((panel) => {
      if (!panel?.dataset) return;
      panel.dataset.instrument = instrument;
      panel.dataset.instrumentPersisted = '1';
      try { panel.dispatchEvent(new CustomEvent('toy-instrument', { detail: { value: instrument }, bubbles: true })); } catch {}
      try { panel.dispatchEvent(new CustomEvent('toy:instrument', { detail: { name: instrument, value: instrument }, bubbles: true })); } catch {}
    });
  }
}

function buildMixedScene({
  drawRows = 3,
  drawCols = 4,
  loopRows = 3,
  loopCols = 4,
  spacing = 420,
  gap = 320,
} = {}) {
  clearSceneViaSnapshot();

  const cam = getCommittedState();
  const drawW = (drawCols - 1) * spacing;
  const loopW = (loopCols - 1) * spacing;
  const totalW = drawW + loopW + gap;
  const leftX = cam.x - totalW / 2;
  const drawCenterX = leftX + drawW / 2;
  const loopCenterX = leftX + drawW + gap + loopW / 2;
  const centerY = cam.y;

  createToyGrid({ toyType: 'drawgrid', rows: drawRows, cols: drawCols, spacing, centerX: drawCenterX, centerY });
  createToyGrid({ toyType: 'loopgrid', rows: loopRows, cols: loopCols, spacing, centerX: loopCenterX, centerY });
  return true;
}

function makeToyRandomiseOnceScript({
  selector,
  atMs = 250,
  seed = 1337,
  useSeededRandom = true,
  eventName = 'toy-random-notes',
  eventNames = null,
  readyCheck = null,
  retryMs = 250,
  timeoutMs = 4000,
  repeatCount = 1,
  repeatEveryMs = 400,
} = {}) {
  const fireAt = Math.max(0, Number(atMs) || 0);
  const sel = selector || '.toy-panel';
  const events = (Array.isArray(eventNames) && eventNames.length) ? eventNames : [eventName];
  const retryEvery = Math.max(50, Number(retryMs) || 250);
  const timeout = Math.max(0, Number(timeoutMs) || 0);
  const repeats = Math.max(1, Math.round(repeatCount || 1));
  const repeatEvery = Math.max(80, Number(repeatEveryMs) || 400);

  return function step(tMs) {
    if (step.__didFire) return;
    if (tMs < fireAt) return;
    if (!step.__firstTryMs) step.__firstTryMs = tMs;
    if (timeout > 0 && (tMs - step.__firstTryMs) > timeout) {
      step.__didFire = true;
      return;
    }

    const panels = document.querySelectorAll(sel);
    if (!panels || panels.length === 0) return;
    if (typeof readyCheck === 'function') {
      let allReady = true;
      panels.forEach((panel) => {
        try { if (!readyCheck(panel)) allReady = false; } catch { allReady = false; }
      });
      if (!allReady) {
        const k = Math.floor((tMs - fireAt) / retryEvery);
        if (k !== step.__lastRetryK) step.__lastRetryK = k;
        return;
      }
    }

    if (!step.__fireStartMs) step.__fireStartMs = tMs;

    const fire = () => {
      panels.forEach((panel) => {
        for (const evt of events) {
          try { panel.dispatchEvent(new CustomEvent(evt, { bubbles: true })); } catch {}
        }
      });
    };

    const k = Math.floor((tMs - step.__fireStartMs) / repeatEvery);
    if (k !== step.__lastFireK && k < repeats) {
      step.__lastFireK = k;
      if (useSeededRandom) {
        const prev = Math.random;
        let s = (seed + k * 1013904223) >>> 0;
        Math.random = () => {
          s = (1664525 * s + 1013904223) >>> 0;
          return s / 4294967296;
        };
        try {
          fire();
        } finally {
          Math.random = prev;
        }
      } else {
        fire();
      }
    }
    if (k >= (repeats - 1)) step.__didFire = true;
  };
}

function makeToyClearOnceScript({
  selector,
  atMs = 250,
  readyCheck = null,
  retryMs = 250,
  timeoutMs = 4000,
  repeatCount = 1,
  repeatEveryMs = 400,
} = {}) {
  return makeToyRandomiseOnceScript({
    selector,
    atMs,
    useSeededRandom: false,
    eventName: 'toy-clear',
    readyCheck,
    retryMs,
    timeoutMs,
    repeatCount,
    repeatEveryMs,
  });
}

function silenceDrawgridPanels(panelIds) {
  const P = window.Persistence;
  if (!P || typeof P.getSnapshot !== 'function' || typeof P.applySnapshot !== 'function') return false;
  const ids = new Set(panelIds || []);
  if (ids.size === 0) return false;

  let changed = 0;
  try {
    const snap = P.getSnapshot();
    const toys = Array.isArray(snap?.toys) ? snap.toys : [];
    for (const t of toys) {
      const id = t?.id || t?.toyId;
      if (!id || !ids.has(id)) continue;
      t.state = t.state || {};
      t.state.strokes = [];
      t.state.manualOverrides = [];
      const nodes = t.state.nodes || {};
      nodes.list = [];
      nodes.active = [];
      nodes.disabled = [];
      nodes.groups = [];
      t.state.nodes = nodes;
      changed++;
      }
    if (!changed) return false;
    const ok = !!P.applySnapshot(snap);
    if (!ok) return false;
      try {
        try {
          if (typeof isRunning === 'function' && typeof startTransport === 'function') {
            if (!isRunning()) startTransport();
          }
        } catch {}
        window.updateAllToys?.();
        window.scheduleAllToysRedraw?.();
        window.requestAnimationFrame?.(() => {
          window.updateAllToys?.();
          window.scheduleAllToysRedraw?.();
        });
      } catch {}
      try {
        ids.forEach((id) => {
          const panel = document.getElementById(id);
          if (!panel) return;
          panel.dispatchEvent(new CustomEvent('toy-clear', {
            detail: { user: true, reason: 'perf-empty' },
            bubbles: true,
          }));
        });
      } catch {}
      try { window.Persistence?.markDirty?.(); } catch {}
    return true;
  } catch {
    return false;
  }
}

function makeDrawgridSilenceOnceScript({
  selector,
  atMs = 250,
  clearEvery = null,
  readyCheck = null,
  retryMs = 250,
  timeoutMs = 4000,
} = {}) {
  const fireAt = Math.max(0, Number(atMs) || 0);
  const sel = selector || '.toy-panel[data-toy="drawgrid"]';
  const every = Number.isFinite(clearEvery) ? Math.max(1, Math.floor(clearEvery)) : null;
  const retryEvery = Math.max(50, Number(retryMs) || 250);
  const timeout = Math.max(0, Number(timeoutMs) || 0);

  return function step(tMs) {
    if (step.__didFire) return;
    if (tMs < fireAt) return;
    if (!step.__firstTryMs) step.__firstTryMs = tMs;
    if (timeout > 0 && (tMs - step.__firstTryMs) > timeout) {
      step.__didFire = true;
      return;
    }

    const panels = document.querySelectorAll(sel);
    if (!panels || panels.length === 0) return;
    if (typeof readyCheck === 'function') {
      let allReady = true;
      panels.forEach((panel) => {
        try { if (!readyCheck(panel)) allReady = false; } catch { allReady = false; }
      });
      if (!allReady) {
        const k = Math.floor((tMs - fireAt) / retryEvery);
        if (k !== step.__lastRetryK) step.__lastRetryK = k;
        return;
      }
    }

    const ids = [];
    panels.forEach((panel, idx) => {
      if (every && (idx % every !== 0)) return;
      if (panel?.id) ids.push(panel.id);
    });
    if (ids.length > 0) silenceDrawgridPanels(ids);
    step.__didFire = true;
  };
}

function makeToyClearSubsetOnceScript({
  selector,
  atMs = 250,
  clearEvery = 4,
  readyCheck = null,
  retryMs = 250,
  timeoutMs = 4000,
} = {}) {
  const fireAt = Math.max(0, Number(atMs) || 0);
  const sel = selector || '.toy-panel';
  const every = Math.max(1, Math.floor(clearEvery) || 1);
  const retryEvery = Math.max(50, Number(retryMs) || 250);
  const timeout = Math.max(0, Number(timeoutMs) || 0);

  return function step(tMs) {
    if (step.__didFire) return;
    if (tMs < fireAt) return;
    if (!step.__firstTryMs) step.__firstTryMs = tMs;
    if (timeout > 0 && (tMs - step.__firstTryMs) > timeout) {
      step.__didFire = true;
      return;
    }

    const panels = document.querySelectorAll(sel);
    if (!panels || panels.length === 0) return;
    if (typeof readyCheck === 'function') {
      let allReady = true;
      panels.forEach((panel) => {
        try { if (!readyCheck(panel)) allReady = false; } catch { allReady = false; }
      });
      if (!allReady) {
        const k = Math.floor((tMs - fireAt) / retryEvery);
        if (k !== step.__lastRetryK) step.__lastRetryK = k;
        return;
      }
    }

    panels.forEach((panel, idx) => {
      if (idx % every !== 0) return;
      try { panel.dispatchEvent(new CustomEvent('toy-clear', { bubbles: true })); } catch {}
    });
    step.__didFire = true;
  };
}

function clearPanelChainData(panel) {
  if (!panel || !panel.dataset) return;
  try {
    delete panel.dataset.nextToyId;
    delete panel.dataset.prevToyId;
    delete panel.dataset.chainHasChild;
    delete panel.dataset.chainParent;
    delete panel.dataset.chainActive;
  } catch {}
}

function linkPanelsIntoChains(panels, { chainLength = 4 } = {}) {
  const list = Array.from(panels || []).filter((panel) => panel && panel.id);
  if (list.length < 2) return;
  list.forEach(clearPanelChainData);

  const size = Math.max(2, Math.floor(chainLength) || 2);
  for (let i = 0; i < list.length; i += size) {
    const chunk = list.slice(i, i + size);
    chunk.forEach((panel) => {
      if (panel?.dataset) {
        panel.dataset.chainActive = 'false';
        panel.dataset.autoplay = 'chain';
      }
    });
    for (let k = 0; k < chunk.length - 1; k++) {
      const a = chunk[k];
      const b = chunk[k + 1];
      if (!a?.id || !b?.id) continue;
      a.dataset.nextToyId = b.id;
      a.dataset.chainHasChild = '1';
      b.dataset.prevToyId = a.id;
      b.dataset.chainParent = a.id;
    }
    const head = chunk[0];
    if (head?.dataset) {
      head.dataset.chainActive = 'true';
      try { head.dispatchEvent(new CustomEvent('chain:set-active', { bubbles: true })); } catch {}
    }
  }

  try {
    window.updateChains?.();
    window.updateAllChainUIs?.();
    window.scheduleChainRedraw?.();
  } catch {}
}

function makeChainOnceScript({
  selector,
  chainLength = 4,
  atMs = 350,
} = {}) {
  const fireAt = Math.max(0, Number(atMs) || 0);
  const sel = selector || '.toy-panel';
  return function step(tMs) {
    if (step.__didFire) return;
    if (tMs < fireAt) return;
    const panels = document.querySelectorAll(sel);
    if (!panels || panels.length < 2) return;
    linkPanelsIntoChains(panels, { chainLength });
    step.__didFire = true;
  };
}

function makeEnsureTransportScript({ atMs = 400 } = {}) {
  const fireAt = Math.max(0, Number(atMs) || 0);
  return function step(tMs) {
    if (step.__didFire) return;
    if (tMs < fireAt) return;
    step.__didFire = true;
    try { if (typeof startTransport === 'function') startTransport(); } catch {}
  };
}

async function runP2a() {
  // Static: no pan/zoom, no overview.
  const step = () => {};
  await runVariant('P2a_particles_static', step, 'Running P2a (static)?O');
}

async function runP2b() {
  // Pan/Zoom only: no overview toggles.
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  await runVariant('P2b_particles_panzoom', step, 'Running P2b (pan/zoom)?O');
}

async function runP2c() {
  // Overview spam only: no camera motion.
  const step = makeOverviewSpamScript({
    idleMs: 2000,
    toggles: 12,
    spanMs: 26000,
  });
  await runVariant('P2c_particles_overview', step, 'Running P2c (overview spam)?O');
}

async function runP2d() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  await runVariantPlaying('P2d_drums_panzoom', step, 'Running P2d (drums pan/zoom)...');
}

async function runP3a() {
  const step = () => {};
  await runVariant('P3a_drawgrid_static', step, 'Running P3a (static)?O');
}

async function runP3b() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  await runVariant('P3b_drawgrid_panzoom', step, 'Running P3b (pan/zoom)?O');
}

async function runP3c() {
  const step = makeOverviewSpamScript({
    idleMs: 2000,
    toggles: 12,
    spanMs: 26000,
  });
  await runVariant('P3c_drawgrid_overview', step, 'Running P3c (overview spam)?O');
}

async function runP3d() {
  const step = makeOverviewOnceScript({
    idleMs: 2000,
    onMs: 6000,
  });
  await runVariant('P3d_drawgrid_overview_once', step, 'Running P3d (overview once)?O');
}
async function runP3e() {
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(randOnce);
  await withTempAnchorDisabled(false, async () => {
    await runVariantPlaying(
      'P3e_drawgrid_playing_rand_once_anchor_on',
      step,
      'Running P3e (playing + randomise once, anchor ON)...'
    );
  });
}

async function runP3e2() {
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(randOnce);
  await withTempAnchorDisabled(true, async () => {
    await runVariantPlaying(
      'P3e2_drawgrid_playing_rand_once_anchor_off',
      step,
      'Running P3e2 (playing + randomise once, anchor OFF)...'
    );
  });
}

  async function runP3f() {
    const prevDisableOverlays = window.__PERF_DG_DISABLE_OVERLAYS;
    const prevOverlayCore = window.__PERF_DG_OVERLAY_CORE_OFF;
    const prevOverlayStrokes = window.__PERF_DG_OVERLAY_STROKES_OFF;
    const prevDisableChainWork = window.__PERF_DISABLE_CHAIN_WORK;
    const forceOverlays =
      !window.__PERF_DG_DISABLE_OVERLAYS &&
      !window.__PERF_DG_OVERLAY_CORE_OFF &&
      !window.__PERF_DG_OVERLAY_STROKES_OFF;
    try {
      window.__PERF_DISABLE_CHAIN_WORK = false;
      if (forceOverlays) {
        window.__PERF_DG_DISABLE_OVERLAYS = false;
        window.__PERF_DG_OVERLAY_CORE_OFF = false;
        window.__PERF_DG_OVERLAY_STROKES_OFF = false;
      }
    } catch {}
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);
    await withTempAnchorDisabled(false, async () => {
      // IMPORTANT: variants like runP3fNoParticles/runP3fNoOverlays wrap runP3f()
      // and set window.__PERF_RUN_TAG. If we don't bake that into the label,
      // perf-lab-results-<timestamp>.json ends up with duplicate labels that are hard to compare.
      const __runTag = (() => {
        try { return window.__PERF_RUN_TAG; } catch { return null; }
      })();
      const __baseLabel = 'P3f_drawgrid_playing_panzoom_rand_once_anchor_on';
      const __label = (__runTag && typeof __runTag === 'string' && __runTag.trim())
        ? `${__baseLabel}__${__runTag.trim()}`
        : __baseLabel;
      await runVariantPlaying(
        __label,
        step,
        'Running P3f (playing pan/zoom + randomise once, anchor ON)...'
      );
    });
    try { window.__PERF_DISABLE_CHAIN_WORK = prevDisableChainWork; } catch {}
    try {
      window.__PERF_DG_DISABLE_OVERLAYS = prevDisableOverlays;
      window.__PERF_DG_OVERLAY_CORE_OFF = prevOverlayCore;
      window.__PERF_DG_OVERLAY_STROKES_OFF = prevOverlayStrokes;
    } catch {}
  }

async function runP3fShort() {
  // Short probe run: useful for trace-on console correlation.
  const prev = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  try { window.__PERF_LAB_DURATION_MS = 12000; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fShort'; } catch {}
  await runP3f();
  try { window.__PERF_LAB_DURATION_MS = prev; } catch {}
  try { window.__PERF_RUN_TAG = prevTag; } catch {}
}

// Focus P3f: tuned for "we need motion NOW" and longer sampling time.
// This avoids the problem where warmup + idle consume most of the short run.
async function runP3fFocus() {
  const prevDisableOverlays = window.__PERF_DG_DISABLE_OVERLAYS;
  const prevOverlayCore = window.__PERF_DG_OVERLAY_CORE_OFF;
  const prevOverlayStrokes = window.__PERF_DG_OVERLAY_STROKES_OFF;
  const prevDisableChainWork = window.__PERF_DISABLE_CHAIN_WORK;
  const forceOverlays =
    !window.__PERF_DG_DISABLE_OVERLAYS &&
    !window.__PERF_DG_OVERLAY_CORE_OFF &&
    !window.__PERF_DG_OVERLAY_STROKES_OFF;
  try {
    window.__PERF_DISABLE_CHAIN_WORK = false;
    if (forceOverlays) {
      window.__PERF_DG_DISABLE_OVERLAYS = false;
      window.__PERF_DG_OVERLAY_CORE_OFF = false;
      window.__PERF_DG_OVERLAY_STROKES_OFF = false;
    }
  } catch {}

  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 500,
    panMs: 9000,
    zoomMs: 9000,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);

  await withTempAnchorDisabled(false, async () => {
    const __runTag = (() => { try { return window.__PERF_RUN_TAG; } catch { return null; } })();
    const __baseLabel = 'P3f_focus_drawgrid_playing_panzoom_rand_once_anchor_on';
    const __label = (__runTag && typeof __runTag === 'string' && __runTag.trim())
      ? `${__baseLabel}__${__runTag.trim()}`
      : __baseLabel;
    await runVariantPlaying(
      __label,
      step,
      'Running P3f Focus (playing pan/zoom + randomise once, anchor ON)...'
    );
  });

  try { window.__PERF_DISABLE_CHAIN_WORK = prevDisableChainWork; } catch {}
  try {
    window.__PERF_DG_DISABLE_OVERLAYS = prevDisableOverlays;
    window.__PERF_DG_OVERLAY_CORE_OFF = prevOverlayCore;
    window.__PERF_DG_OVERLAY_STROKES_OFF = prevOverlayStrokes;
  } catch {}
}

async function runP3fFocusShort() {
  // Focus probe: long enough to meaningfully pan/zoom, but still fast-ish.
  const prev = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  const hadTag = (prevTag && typeof prevTag === 'string' && prevTag.trim());
  try { window.__PERF_LAB_DURATION_MS = 26000; } catch {}
  // IMPORTANT: allow wrapper runs (NoOverlays/NoParticles/etc.) to set their own tag.
  try { if (!hadTag) window.__PERF_RUN_TAG = 'P3fFocus'; } catch {}
  await runP3fFocus();
  try { window.__PERF_LAB_DURATION_MS = prev; } catch {}
  try { window.__PERF_RUN_TAG = prevTag; } catch {}
}

async function runP3fFocusShort2() {
  // Same as runP3fFocusShort but with a different tag so we can compare run-to-run noise.
  const prevTag = window.__PERF_RUN_TAG;
  const prev = window.__PERF_LAB_DURATION_MS;
  try { window.__PERF_LAB_DURATION_MS = 26000; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fFocus2'; } catch {}
  await runP3fFocus();
  try { window.__PERF_LAB_DURATION_MS = prev; } catch {}
  try { window.__PERF_RUN_TAG = prevTag; } catch {}
}

async function runP3fMultiCanvasFocusShort() {
  // Focus A/B:
  // - rebuild P3Focus with multi-canvas (single-canvas OFF)
  // - run the same focus script
  // - rebuild back to baseline (single-canvas ON) so subsequent focus runs are comparable
  const prevTag = window.__PERF_RUN_TAG;
  const prevSingle = (typeof window !== 'undefined') ? window.__DG_SINGLE_CANVAS : undefined;

  try { if (typeof window !== 'undefined') window.__DG_SINGLE_CANVAS = false; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fFocus_MultiCanvas'; } catch {}

  // IMPORTANT: DrawGrid reads canvas topology at creation time.
  // So to actually A/B, we must rebuild the focus scene when toggling.
  await buildP3Focus();
  await warmupFirstAppearance();
  await warmupSettle();
  await runP3fFocusShort();

  // Restore baseline for later variants in AUTO_FOCUS_QUEUE.
  // IMPORTANT: default to multi-canvas if we don't have a previous value.
  // Single-canvas is a topology change and can blank visuals if DrawGrid's composite path regresses.
  try { if (typeof window !== 'undefined') window.__DG_SINGLE_CANVAS = (prevSingle !== undefined) ? prevSingle : false; } catch {}
  try { window.__PERF_RUN_TAG = prevTag; } catch {}
  await buildP3Focus();
  await warmupFirstAppearance();
  await warmupSettle();
}

async function runP3fNoOverlaysFocusShort() {
  const prevTag = window.__PERF_RUN_TAG;
  const prevDisableOverlaysDG = window.__PERF_DG_DISABLE_OVERLAYS;
  const prevDisableOverlaysGeneric = window.__PERF_DISABLE_OVERLAYS;
  // IMPORTANT: some paths read the generic toggle, others read the DG-specific one.
  // Set both so the run truly isolates overlays.
  try { window.__PERF_DG_DISABLE_OVERLAYS = true; } catch {}
  try { window.__PERF_DISABLE_OVERLAYS = true; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fFocus_NoOverlays'; } catch {}
  await runP3fFocusShort();
  try { window.__PERF_DG_DISABLE_OVERLAYS = prevDisableOverlaysDG; } catch {}
  try { window.__PERF_DISABLE_OVERLAYS = prevDisableOverlaysGeneric; } catch {}
  try { window.__PERF_RUN_TAG = prevTag; } catch {}
}

async function runP3fNoParticlesFocusShort() {
  const prevTag = window.__PERF_RUN_TAG;
  const prev = window.__PERF_DG_DISABLE_PARTICLES;
  try { window.__PERF_DG_DISABLE_PARTICLES = true; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fFocus_NoParticles'; } catch {}
  await runP3fFocusShort();
  try { window.__PERF_DG_DISABLE_PARTICLES = prev; } catch {}
  try { window.__PERF_RUN_TAG = prevTag; } catch {}
}

async function runP3fTapDotsFocusShort() {
  // Focus variant: simulate the board "tap dots" ripple while running the DrawGrid focus script.
  // This makes tap-dots cost visible in frame profiles (otherwise it often doesn't trigger during auto runs).
  const prevTag = window.__PERF_RUN_TAG;
  const prevSim = window.__PERF_TAP_DOTS_SIM;
  const prevDisable = window.__PERF_DISABLE_TAP_DOTS;
  try { window.__PERF_TAP_DOTS_SIM = true; } catch {}
  // Ensure tap dots aren't disabled by an earlier variant.
  try { window.__PERF_DISABLE_TAP_DOTS = false; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fFocus_TapDotsSim'; } catch {}
  await runP3fFocusShort();
  try { window.__PERF_TAP_DOTS_SIM = prevSim; } catch {}
  try { window.__PERF_DISABLE_TAP_DOTS = prevDisable; } catch {}
  try { window.__PERF_RUN_TAG = prevTag; } catch {}
}

async function runP3fShort2() {
  // Same as P3fShort but with a different tag so we can compare run-to-run noise.
  const prev = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  try { window.__PERF_LAB_DURATION_MS = 12000; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fShort2'; } catch {}
  await runP3f();
  try { window.__PERF_LAB_DURATION_MS = prev; } catch {}
  try { window.__PERF_RUN_TAG = prevTag; } catch {}
}

async function warmupFirstAppearance() {
  // Reduce variance from first-time paints:
  // - forces initial canvas allocations
  // - triggers first raster/composite passes
  // - surfaces anything that only happens when toys first appear
  setStatus('Warmup: first appearance');
  const raf = window.requestAnimationFrame?.bind(window) ?? ((fn) => setTimeout(() => fn((performance?.now?.() ?? Date.now())), 16));
  const waitRafs = (n) => new Promise((resolve) => {
    let left = Math.max(0, n|0);
    const step = () => {
      left--;
      if (left <= 0) return resolve();
      raf(step);
    };
    raf(step);
  });
  const waitMs = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms|0)));

  try { overviewMode(true); } catch {}
  await waitRafs(6);
  // Small settle to allow async decode/compositor catches to land outside sampling.
  await waitMs(120);
  try { overviewMode(false); } catch {}
  await waitRafs(6);
  await waitMs(120);
  setStatus('Warmup: done');
}

async function warmupSettle() {
  // Purpose: reduce run-to-run variance that comes from async decode, compositor catch-up,
  // and late style/layout work landing immediately after first-appearance warmup.
  //
  // IMPORTANT: This is NOT trying to "improve" perf, only to make measurements stable.
  // Keep it short and tunable.
  const raf = window.requestAnimationFrame?.bind(window) ?? ((fn) => setTimeout(() => fn((performance?.now?.() ?? Date.now())), 16));
  const waitRafs = (n) => new Promise((resolve) => {
    let left = Math.max(0, n|0);
    const step = () => {
      left--;
      if (left <= 0) return resolve();
      raf(step);
    };
    raf(step);
  });
  const waitMs = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms|0)));

  const settleMs = (() => {
    const v = window.__PERF_WARMUP_SETTLE_MS;
    return (typeof v === 'number' && isFinite(v) && v >= 0) ? v : 700;
  })();
  const settleRafs = (() => {
    const v = window.__PERF_WARMUP_SETTLE_RAFS;
    return (typeof v === 'number' && isFinite(v) && v >= 0) ? (v|0) : 12;
  })();

  setStatus(`Warmup: settle (${settleMs}ms, ${settleRafs}rafs)`);
  // Give the browser a small idle window, then a few RAFs to flush any pending visual work.
  await waitMs(settleMs);
  await waitRafs(settleRafs);
  setStatus('Warmup: settle done');
}

async function runP3fNoOverlaysShort() {
  // Short probe run with DrawGrid overlays disabled.
  const prevDur = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  const prevNoOverlays = window.__PERF_DG_DISABLE_OVERLAYS;
  const prevNoOverlaysGeneric = window.__PERF_DISABLE_OVERLAYS;
  try { window.__PERF_LAB_DURATION_MS = 12000; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fNoOverlaysShort'; } catch {}
  window.__PERF_DG_DISABLE_OVERLAYS = true;
  // Keep result flags honest (PerfHarness often reads the generic flag).
  window.__PERF_DISABLE_OVERLAYS = true;
  try {
    await runP3f();
  } finally {
    window.__PERF_DG_DISABLE_OVERLAYS = prevNoOverlays;
    window.__PERF_DISABLE_OVERLAYS = prevNoOverlaysGeneric;
    try { window.__PERF_LAB_DURATION_MS = prevDur; } catch {}
    try { window.__PERF_RUN_TAG = prevTag; } catch {}
  }
}

async function runP3fNoOverlaysShort2() {
  // Same as P3fNoOverlaysShort but with a different tag for run-to-run variance checks.
  const prevDur = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  const prevNoOverlays = window.__PERF_DG_DISABLE_OVERLAYS;
  const prevNoOverlaysGeneric = window.__PERF_DISABLE_OVERLAYS;
  try { window.__PERF_LAB_DURATION_MS = 12000; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fNoOverlaysShort2'; } catch {}
  window.__PERF_DG_DISABLE_OVERLAYS = true;
  // Keep result flags honest (PerfHarness often reads the generic flag).
  window.__PERF_DISABLE_OVERLAYS = true;
  try {
    await runP3f();
  } finally {
    window.__PERF_DG_DISABLE_OVERLAYS = prevNoOverlays;
    window.__PERF_DISABLE_OVERLAYS = prevNoOverlaysGeneric;
    try { window.__PERF_LAB_DURATION_MS = prevDur; } catch {}
    try { window.__PERF_RUN_TAG = prevTag; } catch {}
  }
}

async function runP3fNoParticlesShort() {
  // Short probe run with particle fields disabled (aimed at frame.nonScript / raster pressure).
  const prevDur = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  const prevNoParticles = window.__PERF_DG_DISABLE_PARTICLES;
  try { window.__PERF_LAB_DURATION_MS = 12000; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fNoParticlesShort'; } catch {}
  try {
    window.__PERF_DG_DISABLE_PARTICLES = true;
    await runP3f();
  } finally {
    window.__PERF_DG_DISABLE_PARTICLES = prevNoParticles;
    try { window.__PERF_LAB_DURATION_MS = prevDur; } catch {}
    try { window.__PERF_RUN_TAG = prevTag; } catch {}
  }
}

async function runP3fNoParticlesShort2() {
  // Same as P3fNoParticlesShort but with a different tag for run-to-run variance checks.
  const prevDur = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  const prevNoParticles = window.__PERF_DG_DISABLE_PARTICLES;
  try { window.__PERF_LAB_DURATION_MS = 12000; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fNoParticlesShort2'; } catch {}
  try {
    window.__PERF_DG_DISABLE_PARTICLES = true;
    await runP3f();
  } finally {
    window.__PERF_DG_DISABLE_PARTICLES = prevNoParticles;
    try { window.__PERF_LAB_DURATION_MS = prevDur; } catch {}
    try { window.__PERF_RUN_TAG = prevTag; } catch {}
  }
}

async function runP3fNoOverlayCoreShort() {
  // Short probe run with DrawGrid overlay CORE disabled.
  const prevDur = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  const prev = window.__PERF_DG_OVERLAY_CORE_OFF;
  const prevGeneric = window.__PERF_DISABLE_OVERLAY_CORE;
  try { window.__PERF_LAB_DURATION_MS = 12000; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fNoOverlayCoreShort'; } catch {}
  window.__PERF_DG_OVERLAY_CORE_OFF = true;
  // Keep result flags honest (PerfHarness often reads the generic flag).
  window.__PERF_DISABLE_OVERLAY_CORE = true;
  try {
    await runP3f();
  } finally {
    window.__PERF_DG_OVERLAY_CORE_OFF = prev;
    window.__PERF_DISABLE_OVERLAY_CORE = prevGeneric;
    try { window.__PERF_LAB_DURATION_MS = prevDur; } catch {}
    try { window.__PERF_RUN_TAG = prevTag; } catch {}
  }
}

async function runP3fNoOverlayStrokesShort() {
  // Short probe run with DrawGrid overlay STROKES disabled.
  const prevDur = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  const prev = window.__PERF_DG_OVERLAY_STROKES_OFF;
  const prevGeneric = window.__PERF_DISABLE_OVERLAY_STROKES;
  try { window.__PERF_LAB_DURATION_MS = 12000; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fNoOverlayStrokesShort'; } catch {}
  window.__PERF_DG_OVERLAY_STROKES_OFF = true;
  // Keep result flags honest (PerfHarness often reads the generic flag).
  window.__PERF_DISABLE_OVERLAY_STROKES = true;
  try {
    await runP3f();
  } finally {
    window.__PERF_DG_OVERLAY_STROKES_OFF = prev;
    window.__PERF_DISABLE_OVERLAY_STROKES = prevGeneric;
    try { window.__PERF_LAB_DURATION_MS = prevDur; } catch {}
    try { window.__PERF_RUN_TAG = prevTag; } catch {}
  }
}

async function runP3PauseDomProbe() {
  // Goal: deterministically test "Play → Pause → Wait" to catch DOM-in-RAF spam while paused.
  // Best used with traceDomInRaf enabled.
  const prev = window.__PERF_LAB_DURATION_MS;
  try { window.__PERF_LAB_DURATION_MS = 12000; } catch {}

  // Ensure starting from stopped for determinism.
  try { stopTransport(); } catch {}

  let didStart = false;
  let didStop = false;

  const step = (t) => {
    // Start immediately
    if (!didStart) {
      didStart = true;
      try { startTransport(); } catch {}
    }
    // Pause after ~2s
    if (!didStop && t >= 2000) {
      didStop = true;
      try { stopTransport(); } catch {}
    }
    // After this we just sit paused until the benchmark ends.
  };

  try {
    await runVariant(
      'P3_pause_dom_probe_play_pause_wait',
      step,
      'Running Pause DOM-in-RAF Probe (Play → Pause → Wait)…'
    );
  } finally {
    try { stopTransport(); } catch {}
    try {
      if (prev == null) delete window.__PERF_LAB_DURATION_MS;
      else window.__PERF_LAB_DURATION_MS = prev;
    } catch {}
  }
}

async function autoPauseDom() {
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  await runAuto({
    clear: true,
    save: true,
    download: true,
    traceDomInRaf: true,
    traceCanvasResize: false,
    // Make the probe deterministic: no auto gesture/quality modulation.
    // Also enforces your "no frame skipping" preference for the probe itself.
    gestureAutoLock: true,
    particleToggles: {
      gestureDrawModulo: 1,
      gestureFieldModulo: 1,
    },
    downloadName: `perf-lab-pause-dom-probe-${ts}.json`,
    notes: 'Auto probe: enable Trace DOM-in-RAF; build P3; run play→pause→wait benchmark to catch DOM-in-RAF spam while paused.',
    queue: [
      'buildP3',
      'runP3PauseDomProbe',
    ],
  });
}

async function runP3fPlayheadSeparateOff() {
  const prev = window.__DG_PLAYHEAD_SEPARATE_CANVAS;
  const prevForce = window.__DG_PLAYHEAD_SEPARATE_CANVAS_FORCE;
  const prevTag = window.__PERF_RUN_TAG;
  try { window.__DG_PLAYHEAD_SEPARATE_CANVAS = false; } catch {}
  try { window.__DG_PLAYHEAD_SEPARATE_CANVAS_FORCE = true; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fPlayheadSeparateOff'; } catch {}
  await runP3f();
  try { window.__DG_PLAYHEAD_SEPARATE_CANVAS = prev; } catch {}
  try { window.__DG_PLAYHEAD_SEPARATE_CANVAS_FORCE = prevForce; } catch {}
  try { window.__PERF_RUN_TAG = prevTag; } catch {}
}

async function runP3fPlayheadSeparateOn() {
  const prev = window.__DG_PLAYHEAD_SEPARATE_CANVAS;
  const prevForce = window.__DG_PLAYHEAD_SEPARATE_CANVAS_FORCE;
  const prevTag = window.__PERF_RUN_TAG;
  try { window.__DG_PLAYHEAD_SEPARATE_CANVAS = true; } catch {}
  try { window.__DG_PLAYHEAD_SEPARATE_CANVAS_FORCE = true; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fPlayheadSeparateOn'; } catch {}
  await runP3f();
  try { window.__DG_PLAYHEAD_SEPARATE_CANVAS = prev; } catch {}
  try { window.__DG_PLAYHEAD_SEPARATE_CANVAS_FORCE = prevForce; } catch {}
  try { window.__PERF_RUN_TAG = prevTag; } catch {}
}

async function runP3fPlayheadEvery4() {
  const prev = window.__PERF_DG_PLAYHEAD_EVERY;
  const prevTag = window.__PERF_RUN_TAG;
  try { window.__PERF_DG_PLAYHEAD_EVERY = 4; } catch {}
  try { window.__PERF_RUN_TAG = 'P3fPlayheadEvery4'; } catch {}
  await runP3f();
  try { window.__PERF_DG_PLAYHEAD_EVERY = prev; } catch {}
  try { window.__PERF_RUN_TAG = prevTag; } catch {}
}

async function runP3f2() {
  try { window.__PERF_DISABLE_CHAIN_WORK = true; } catch {}
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);
  await withTempAnchorDisabled(true, async () => {
    await runVariantPlaying(
      'P3f2_drawgrid_playing_panzoom_rand_once_anchor_off',
      step,
      'Running P3f2 (playing pan/zoom + randomise once, anchor OFF)...'
    );
  });
  try { window.__PERF_DISABLE_CHAIN_WORK = false; } catch {}
}

async function runP3fEmptyNoNotes() {
  const prevTag = window.__PERF_RUN_TAG;
  const prevDisableOverlays = window.__PERF_DG_DISABLE_OVERLAYS;
  const prevOverlayCore = window.__PERF_DG_OVERLAY_CORE_OFF;
  const prevOverlayStrokes = window.__PERF_DG_OVERLAY_STROKES_OFF;
  const prevForceSequencerAll = window.__PERF_FORCE_SEQUENCER_ALL;
  const prevDisableChainWork = window.__PERF_DISABLE_CHAIN_WORK;
  const forceOverlays =
    !window.__PERF_DG_DISABLE_OVERLAYS &&
    !window.__PERF_DG_OVERLAY_CORE_OFF &&
    !window.__PERF_DG_OVERLAY_STROKES_OFF;
  window.__PERF_RUN_TAG = 'P3fEmptyNoNotes';
  try {
    window.__PERF_DISABLE_CHAIN_WORK = false;
    if (forceOverlays) {
      window.__PERF_DG_DISABLE_OVERLAYS = false;
      window.__PERF_DG_OVERLAY_CORE_OFF = false;
      window.__PERF_DG_OVERLAY_STROKES_OFF = false;
    }
    window.__PERF_FORCE_SEQUENCER_ALL = false;
  } catch {}
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const silenceNotes = makeDrawgridSilenceOnceScript({
    selector: '.toy-panel[data-toy="drawgrid"]',
    atMs: 200,
  });
  const step = composeSteps(silenceNotes, panZoom);
  try {
    await withTempAnchorDisabled(false, async () => {
      await runVariantPlaying(
        'P3f_drawgrid_playing_panzoom_no_notes_anchor_on',
        step,
        'Running P3f (playing pan/zoom, no notes, no chains, anchor ON)...'
      );
    });
  } finally {
    window.__PERF_RUN_TAG = prevTag;
    try { window.__PERF_DISABLE_CHAIN_WORK = prevDisableChainWork; } catch {}
    try {
      window.__PERF_DG_DISABLE_OVERLAYS = prevDisableOverlays;
      window.__PERF_DG_OVERLAY_CORE_OFF = prevOverlayCore;
      window.__PERF_DG_OVERLAY_STROKES_OFF = prevOverlayStrokes;
      window.__PERF_FORCE_SEQUENCER_ALL = prevForceSequencerAll;
    } catch {}
  }
}

async function runP3fEmptyChainNoNotes() {
  const prevTag = window.__PERF_RUN_TAG;
  const prevDisableOverlays = window.__PERF_DG_DISABLE_OVERLAYS;
  const prevOverlayCore = window.__PERF_DG_OVERLAY_CORE_OFF;
  const prevOverlayStrokes = window.__PERF_DG_OVERLAY_STROKES_OFF;
  const prevForceSequencerAll = window.__PERF_FORCE_SEQUENCER_ALL;
  const prevDisableChainWork = window.__PERF_DISABLE_CHAIN_WORK;
  const forceOverlays =
    !window.__PERF_DG_DISABLE_OVERLAYS &&
    !window.__PERF_DG_OVERLAY_CORE_OFF &&
    !window.__PERF_DG_OVERLAY_STROKES_OFF;
  window.__PERF_RUN_TAG = 'P3fEmptyChainNoNotes';
  try {
    window.__PERF_DISABLE_CHAIN_WORK = false;
    if (forceOverlays) {
      window.__PERF_DG_DISABLE_OVERLAYS = false;
      window.__PERF_DG_OVERLAY_CORE_OFF = false;
      window.__PERF_DG_OVERLAY_STROKES_OFF = false;
    }
    window.__PERF_FORCE_SEQUENCER_ALL = false;
  } catch {}
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const silenceNotes = makeDrawgridSilenceOnceScript({
    selector: '.toy-panel[data-toy="drawgrid"]',
    atMs: 200,
  });
  const linkChains = makeChainOnceScript({
    selector: '.toy-panel[data-toy="drawgrid"]',
    chainLength: 4,
    atMs: 500,
  });
  const step = composeSteps(silenceNotes, linkChains, panZoom);
  try {
    await withTempAnchorDisabled(false, async () => {
      await runVariantPlaying(
        'P3f_drawgrid_playing_panzoom_chain_no_notes_anchor_on',
        step,
        'Running P3f (playing pan/zoom, chained no notes, anchor ON)...'
      );
    });
  } finally {
    window.__PERF_RUN_TAG = prevTag;
    try { window.__PERF_DISABLE_CHAIN_WORK = prevDisableChainWork; } catch {}
    try {
      window.__PERF_DG_DISABLE_OVERLAYS = prevDisableOverlays;
      window.__PERF_DG_OVERLAY_CORE_OFF = prevOverlayCore;
      window.__PERF_DG_OVERLAY_STROKES_OFF = prevOverlayStrokes;
      window.__PERF_FORCE_SEQUENCER_ALL = prevForceSequencerAll;
    } catch {}
  }
}

async function runP3fMixedSomeEmpty() {
  const prevTag = window.__PERF_RUN_TAG;
  const prevDisableOverlays = window.__PERF_DG_DISABLE_OVERLAYS;
  const prevOverlayCore = window.__PERF_DG_OVERLAY_CORE_OFF;
  const prevOverlayStrokes = window.__PERF_DG_OVERLAY_STROKES_OFF;
  const prevForceSequencerAll = window.__PERF_FORCE_SEQUENCER_ALL;
  const prevDisableChainWork = window.__PERF_DISABLE_CHAIN_WORK;
  const forceOverlays =
    !window.__PERF_DG_DISABLE_OVERLAYS &&
    !window.__PERF_DG_OVERLAY_CORE_OFF &&
    !window.__PERF_DG_OVERLAY_STROKES_OFF;
  window.__PERF_RUN_TAG = 'P3fMixedSomeEmpty';
  try {
    window.__PERF_DISABLE_CHAIN_WORK = false;
    if (forceOverlays) {
      window.__PERF_DG_DISABLE_OVERLAYS = false;
      window.__PERF_DG_OVERLAY_CORE_OFF = false;
      window.__PERF_DG_OVERLAY_STROKES_OFF = false;
    }
    window.__PERF_FORCE_SEQUENCER_ALL = false;
  } catch {}
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeToyRandomiseOnceScript({
    selector: '.toy-panel[data-toy="drawgrid"]',
    atMs: 160,
    seed: 1337,
    useSeededRandom: true,
    eventNames: ['toy-random', 'toy-random-notes'],
  });
  const silenceSomeNotes = makeDrawgridSilenceOnceScript({
    selector: '.toy-panel[data-toy="drawgrid"]',
    atMs: 260,
    clearEvery: 4,
  });
  const linkChains = makeChainOnceScript({
    selector: '.toy-panel[data-toy="drawgrid"]',
    chainLength: 4,
    atMs: 520,
  });
  const step = composeSteps(randOnce, silenceSomeNotes, linkChains, panZoom);
  try {
    await withTempAnchorDisabled(false, async () => {
      await runVariantPlaying(
        'P3f_drawgrid_playing_panzoom_some_empty_anchor_on',
        step,
        'Running P3f (playing pan/zoom, mostly full + some empty, anchor ON)...'
      );
    });
  } finally {
    window.__PERF_RUN_TAG = prevTag;
    try { window.__PERF_DISABLE_CHAIN_WORK = prevDisableChainWork; } catch {}
    try {
      window.__PERF_DG_DISABLE_OVERLAYS = prevDisableOverlays;
      window.__PERF_DG_OVERLAY_CORE_OFF = prevOverlayCore;
      window.__PERF_DG_OVERLAY_STROKES_OFF = prevOverlayStrokes;
      window.__PERF_FORCE_SEQUENCER_ALL = prevForceSequencerAll;
    } catch {}
  }
}

async function runP3fNoPaint() {
  const prevTag = window.__PERF_RUN_TAG;
  window.__PERF_RUN_TAG = 'P3fNoPaint';
  try {
    await withNoPaint(async () => {
      await runP3f();
    });
  } finally {
    window.__PERF_RUN_TAG = prevTag;
  }
}

async function runP3fNoDom() {
  const prevTag = window.__PERF_RUN_TAG;
  const prevNoDom = window.__PERF_NO_DOM_UPDATES;
  window.__PERF_RUN_TAG = 'P3fNoDom';
  window.__PERF_NO_DOM_UPDATES = true;
  try {
    await runP3f();
  } finally {
    window.__PERF_RUN_TAG = prevTag;
    window.__PERF_NO_DOM_UPDATES = prevNoDom;
  }
}

async function runP3fNoGrid() {
  const prevTag = window.__PERF_RUN_TAG;
  const prevNoGrid = window.__PERF_DG_DISABLE_GRID;
  window.__PERF_RUN_TAG = 'P3fNoGrid';
  window.__PERF_DG_DISABLE_GRID = true;
  try {
    await runP3f();
  } finally {
    window.__PERF_RUN_TAG = prevTag;
    window.__PERF_DG_DISABLE_GRID = prevNoGrid;
  }
}

async function runP3fNoParticles() {
  const prevTag = window.__PERF_RUN_TAG;
  const prevNoParticles = window.__PERF_DG_DISABLE_PARTICLES;
  const prevParticleDbg = window.__PERF_PARTICLE_DBG;
  window.__PERF_RUN_TAG = 'P3fNoParticles';
  try {
    window.__PERF_DG_DISABLE_PARTICLES = true;
    window.__PERF_PARTICLE_DBG = true;
    await runP3f();
  } finally {
    window.__PERF_RUN_TAG = prevTag;
    window.__PERF_DG_DISABLE_PARTICLES = prevNoParticles;
    window.__PERF_PARTICLE_DBG = prevParticleDbg;
  }
}

async function runP3fNoOverlays() {
  const prevTag = window.__PERF_RUN_TAG;
  const prevNoOverlays = window.__PERF_DG_DISABLE_OVERLAYS;
  window.__PERF_RUN_TAG = 'P3fNoOverlays';
  window.__PERF_DG_DISABLE_OVERLAYS = true;
  try {
    await runP3f();
  } finally {
    window.__PERF_RUN_TAG = prevTag;
    window.__PERF_DG_DISABLE_OVERLAYS = prevNoOverlays;
  }
}

  async function runP3fNoOverlayStrokes() {
    const prevTag = window.__PERF_RUN_TAG;
    const prevNoOverlayStrokes = window.__PERF_DG_OVERLAY_STROKES_OFF;
    window.__PERF_RUN_TAG = 'P3fNoOverlayStrokes';
    window.__PERF_DG_OVERLAY_STROKES_OFF = true;
    try {
      await runP3f();
    } finally {
      window.__PERF_RUN_TAG = prevTag;
      window.__PERF_DG_OVERLAY_STROKES_OFF = prevNoOverlayStrokes;
    }
  }

  async function runP3fNoOverlayCore() {
    const prevTag = window.__PERF_RUN_TAG;
    const prevNoOverlayCore = window.__PERF_DG_OVERLAY_CORE_OFF;
    window.__PERF_RUN_TAG = 'P3fNoOverlayCore';
    window.__PERF_DG_OVERLAY_CORE_OFF = true;
    try {
      await runP3f();
    } finally {
      window.__PERF_RUN_TAG = prevTag;
      window.__PERF_DG_OVERLAY_CORE_OFF = prevNoOverlayCore;
    }
  }

  async function runP3fParticleProfile() {
    const prevTag = window.__PERF_RUN_TAG;
    const prevProfile = window.__PERF_PARTICLE_FIELD_PROFILE;
    window.__PERF_RUN_TAG = 'P3fParticleProfile';
    window.__PERF_PARTICLE_FIELD_PROFILE = true;
    try {
      await runP3f();
    } finally {
      window.__PERF_RUN_TAG = prevTag;
      window.__PERF_PARTICLE_FIELD_PROFILE = prevProfile;
    }
  }

  async function runP3fFlatLayers() {
  const prevTag = window.__PERF_RUN_TAG;
  const prevFlat = window.__PERF_DRAWGRID_FLAT_LAYERS;
  window.__PERF_RUN_TAG = 'P3fFlatLayers';
  window.__PERF_DRAWGRID_FLAT_LAYERS = true;
  try {
    await runP3f();
  } finally {
    window.__PERF_RUN_TAG = prevTag;
    window.__PERF_DRAWGRID_FLAT_LAYERS = prevFlat;
  }
}


async function runP3g() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);
  await withTempAnchorDisabled(false, async () => {
    await runVariant(
      'P3g_drawgrid_panzoom_rand_once_anchor_on',
      step,
      'Running P3g (pan/zoom + rand once, anchor ON)...'
    );
  });
}

async function runP3g2() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);
  await withTempAnchorDisabled(true, async () => {
    await runVariant(
      'P3g2_drawgrid_panzoom_rand_once_anchor_off',
      step,
      'Running P3g2 (pan/zoom + rand once, anchor OFF)...'
    );
  });
}
async function runP3h() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);
  await withTempAnchorDisabled(false, async () => {
    await withTempPerfParticles({ gestureDrawModulo: 1 }, async () => {
      await runVariantPlaying(
        'P3h_drawgrid_playing_panzoom_rand_once_anchor_on_gesture1',
        step,
        'Running P3h (playing pan/zoom + rand once, anchor ON, gesture x1)...'
      );
    });
  });
}

async function runP3h2() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);
  await withTempAnchorDisabled(false, async () => {
    await withTempPerfParticles({ gestureDrawModulo: 4 }, async () => {
      await runVariantPlaying(
        'P3h2_drawgrid_playing_panzoom_rand_once_anchor_on_gesture4',
        step,
        'Running P3h2 (playing pan/zoom + rand once, anchor ON, gesture x4)...'
      );
    });
  });
}
async function runP3i() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);
  await withTempAnchorDisabled(false, async () => {
    await withTempPerfParticles({ gestureDrawModulo: 1, gestureFieldModulo: 2 }, async () => {
      await runVariantPlaying(
        'P3i_drawgrid_playing_panzoom_rand_once_anchor_on_gesture1_field2',
        step,
        'Running P3i (playing pan/zoom + rand once, anchor ON, gesture x1, field x2)...'
      );
    });
  });
}

async function runP3i2() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);
  await withTempAnchorDisabled(false, async () => {
    await withTempPerfParticles({ gestureDrawModulo: 4, gestureFieldModulo: 2 }, async () => {
      await runVariantPlaying(
        'P3i2_drawgrid_playing_panzoom_rand_once_anchor_on_gesture4_field2',
        step,
        'Running P3i2 (playing pan/zoom + rand once, anchor ON, gesture x4, field x2)...'
      );
    });
  });
}
async function runP3j() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);
  await withTempAnchorDisabled(false, async () => {
    await withTempPerfParticles({ freezeUnfocusedDuringGesture: false }, async () => {
      await runVariantPlaying(
        'P3j_drawgrid_playing_panzoom_rand_once_anchor_on_freezeOff',
        step,
        'Running P3j (playing pan/zoom + rand once, anchor ON, freeze off)...'
      );
    });
  });
}

async function runP3j2() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);
  await withTempAnchorDisabled(true, async () => {
    await withTempPerfParticles({ freezeUnfocusedDuringGesture: false }, async () => {
      await runVariantPlaying(
        'P3j2_drawgrid_playing_panzoom_rand_once_anchor_off_freezeOff',
        step,
        'Running P3j2 (playing pan/zoom + rand once, anchor OFF, freeze off)...'
      );
    });
  });
}

async function runP3k() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const step = composeSteps(panZoom);
  try { buildParticleWorstCase({ toyType: 'drawgrid', rows: 0, cols: 0, spacing: 420 }); } catch {}
  await withTempAnchorEnabled(async () => {
    await runVariant(
      'P3k_anchor_only_panzoom_on',
      step,
      'Running P3k (anchor-only pan/zoom, anchor ON)...'
    );
  });
}

async function runP3k2() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const step = composeSteps(panZoom);
  try { buildParticleWorstCase({ toyType: 'drawgrid', rows: 0, cols: 0, spacing: 420 }); } catch {}
  await withTempAnchorDisabled(true, async () => {
    await runVariant(
      'P3k_anchor_only_panzoom_off',
      step,
      'Running P3k2 (anchor-only pan/zoom, anchor OFF)...'
    );
  });
}

async function runP3l() {
  const panZoom = makePanZoomCommitSpamScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
    commitEveryMs: 250,
  });
  const step = composeSteps(panZoom);
  await withTempAnchorEnabled(async () => {
    await runVariantPlaying(
      'P3l_drawgrid_playing_panzoom_commitspam_anchor_on',
      step,
      'Running P3l (playing pan/zoom commitspam, anchor ON)...'
    );
  });
}

async function runP3l2() {
  const panZoom = makePanZoomCommitSpamScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
    commitEveryMs: 250,
  });
  const step = composeSteps(panZoom);
  await withTempAnchorDisabled(true, async () => {
    await runVariantPlaying(
      'P3l2_drawgrid_playing_panzoom_commitspam_anchor_off',
      step,
      'Running P3l2 (playing pan/zoom commitspam, anchor OFF)...'
    );
  });
}

async function runP3lShort() {
  // Short probe variant for auto queues.
  const prevDur = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  try { window.__PERF_LAB_DURATION_MS = 12000; } catch {}
  try { window.__PERF_RUN_TAG = 'P3lShort'; } catch {}
  try {
    await runP3l();
  } finally {
    try { window.__PERF_LAB_DURATION_MS = prevDur; } catch {}
    try { window.__PERF_RUN_TAG = prevTag; } catch {}
  }
}

async function runP3l2Short() {
  // Short probe variant for auto queues.
  const prevDur = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  try { window.__PERF_LAB_DURATION_MS = 12000; } catch {}
  try { window.__PERF_RUN_TAG = 'P3l2Short'; } catch {}
  try {
    await runP3l2();
  } finally {
    try { window.__PERF_LAB_DURATION_MS = prevDur; } catch {}
    try { window.__PERF_RUN_TAG = prevTag; } catch {}
  }
}

async function runP3l2ShortGap900() {
  // Anchor-OFF commit-spam with stricter DrawGrid coalescing for A/B.
  const prevDur = window.__PERF_LAB_DURATION_MS;
  const prevTag = window.__PERF_RUN_TAG;
  const prevGap = window.__DG_TOY_ZOOM_COMMIT_MIN_GAP_MS_ANCHOR_OFF;
  try { window.__PERF_LAB_DURATION_MS = 12000; } catch {}
  try { window.__PERF_RUN_TAG = 'P3l2ShortGap900'; } catch {}
  try { window.__DG_TOY_ZOOM_COMMIT_MIN_GAP_MS_ANCHOR_OFF = 900; } catch {}
  try {
    await runP3l2();
  } finally {
    try { window.__DG_TOY_ZOOM_COMMIT_MIN_GAP_MS_ANCHOR_OFF = prevGap; } catch {}
    try { window.__PERF_LAB_DURATION_MS = prevDur; } catch {}
    try { window.__PERF_RUN_TAG = prevTag; } catch {}
  }
}


async function runP3l3() {
  const panZoom = makePanZoomCommitSpamScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
    commitEveryMs: 250,
    commitDelayMs: 0,
  });
  const step = composeSteps(panZoom);
  await withTempAnchorEnabled(async () => {
    await runVariantPlaying(
      'P3l3_drawgrid_playing_panzoom_commitspam_delay0',
      step,
      'Running P3l3 (playing pan/zoom commitspam, delay 0)...'
    );
  });
}

async function runP3l4() {
  const panZoom = makePanZoomCommitSpamScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
    commitEveryMs: 250,
    commitDelayMs: 80,
  });
  const step = composeSteps(panZoom);
  await withTempAnchorEnabled(async () => {
    await runVariantPlaying(
      'P3l4_drawgrid_playing_panzoom_commitspam_delay80',
      step,
      'Running P3l4 (playing pan/zoom commitspam, delay 80)...'
    );
  });
}
async function runP3l5() {
  const panZoom = makePanZoomCommitSpamScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
    commitEveryMs: 250,
    commitDelayMs: 80,
    commitMinGapMs: 250,
  });
  const step = composeSteps(panZoom);
  await withTempAnchorEnabled(async () => {
    await runVariantPlaying(
      'P3l5_drawgrid_playing_panzoom_commitspam_mingap250',
      step,
      'Running P3l5 (playing pan/zoom commitspam, min gap 250)...'
    );
  });
}

async function runP3l6() {
  const panZoom = makePanZoomCommitSpamScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
    commitEveryMs: 250,
    commitDelayMs: 80,
    commitMinGapMs: 500,
  });
  const step = composeSteps(panZoom);
  await withTempAnchorEnabled(async () => {
    await runVariantPlaying(
      'P3l6_drawgrid_playing_panzoom_commitspam_mingap500',
      step,
      'Running P3l6 (playing pan/zoom commitspam, min gap 500)...'
    );
  });
}async function runP3m() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);
  await withTempAnchorEnabled(async () => {
    await withTempPerfAnchor({ gestureModulo: 1 }, async () => {
      await runVariantPlaying(
        'P3m_anchor_gestureModulo1',
        step,
        'Running P3m (anchor gesture x1)...'
      );
    });
  });
}

async function runP3m2() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randOnce = makeDrawgridRandomiseOnceScript({ atMs: 250, seed: 1337, useSeededRandom: true });
  const step = composeSteps(panZoom, randOnce);
  await withTempAnchorEnabled(async () => {
    await withTempPerfAnchor({ gestureModulo: 4 }, async () => {
      await runVariantPlaying(
        'P3m2_anchor_gestureModulo4',
        step,
        'Running P3m2 (anchor gesture x4)...'
      );
    });
  });
}async function runP4a() {
  const step = () => {};
  await runVariantPlaying('P4a_chain_loopgrid_playing_static', step, 'Running P4a (playing static)...');
}

async function runP4b() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const prevForce = window.__PERF_FORCE_SEQUENCER_ALL;
  try {
    window.__PERF_FORCE_SEQUENCER_ALL = true;
    await runVariantPlaying('P4b_loopgrid_playing_panzoom', step, 'Running P4b (playing pan/zoom)...');
  } finally {
    window.__PERF_FORCE_SEQUENCER_ALL = prevForce;
  }
}

async function runP4o() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  window.__PERF_DISABLE_PULSES = true;
  console.log('[PerfLab] __PERF_DISABLE_PULSES =', window.__PERF_DISABLE_PULSES);
  try {
    await runVariantPlaying(
      'P4o_chain_loopgrid_playing_panzoom_no_pulses',
      step,
      'Running P4o (no border pulses)?O'
    );
    console.log('[PerfLab] P4o pulseCount', window.__PERF_PULSE_COUNT, 'outlineSyncCount', window.__PERF_OUTLINE_SYNC_COUNT);
  } finally {
    window.__PERF_DISABLE_PULSES = false;
  }
}

async function runP4p() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  // Hard-disable visuals
  window.__PERF_DISABLE_LOOPGRID_RENDER = true;
  window.__PERF_DISABLE_CHAINS = true;
  window.__PERF_DISABLE_TAP_DOTS = true;
  window.__PERF_DISABLE_OVERLAYS = true;
  window.__PERF_DISABLE_PULSES = true;

  await withTempPerfParticles({ skipUpdate: true, skipDraw: true }, async () => {
    try {
      await runVariantPlaying(
        'P4p_chain_loopgrid_playing_panzoom_audio_step_only',
        step,
        'Running P4p (audio+sequencer only)?O'
      );
    } finally {
      window.__PERF_DISABLE_LOOPGRID_RENDER = false;
      window.__PERF_DISABLE_CHAINS = false;
      window.__PERF_DISABLE_TAP_DOTS = false;
      window.__PERF_DISABLE_OVERLAYS = false;
      window.__PERF_DISABLE_PULSES = false;
    }
  });
}

async function runP4q() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  window.__PERF_DISABLE_CHAINS = true;
  try {
    await runVariantPlaying(
      'P4q_chain_loopgrid_playing_panzoom_no_chains',
      step,
      'Running P4q (no chains)...'
    );
  } finally {
    window.__PERF_DISABLE_CHAINS = false;
  }
}

async function runP4r() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  window.__PERF_DISABLE_TAP_DOTS = true;
  try {
    await runVariantPlaying(
      'P4r_chain_loopgrid_playing_panzoom_no_tap_dots',
      step,
      'Running P4r (no tap dots)...'
    );
  } finally {
    window.__PERF_DISABLE_TAP_DOTS = false;
  }
}

async function runP4s() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  window.__PERF_DISABLE_OVERLAYS = true;
  try {
    await runVariantPlaying(
      'P4s_chain_loopgrid_playing_panzoom_no_overlays',
      step,
      'Running P4s (no overlays)...'
    );
  } finally {
    window.__PERF_DISABLE_OVERLAYS = false;
  }
}

async function runP4t() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  window.__PERF_DISABLE_LOOPGRID_RENDER = true;
  try {
    await runVariantPlaying(
      'P4t_chain_loopgrid_playing_panzoom_no_loopgrid_render',
      step,
      'Running P4t (no loopgrid render)...'
    );
  } finally {
    window.__PERF_DISABLE_LOOPGRID_RENDER = false;
  }
}

async function runP4u() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  const prev = window.__PERF_LOOPGRID_GESTURE_RENDER_MOD;
  window.__PERF_LOOPGRID_GESTURE_RENDER_MOD = 2;
  const prevVerbose = window.__PERF_LAB_VERBOSE;
  window.__PERF_LAB_VERBOSE = true;
  window.__PERF_LOOPGRID_GESTURE_SKIP = 0;
  try {
    await runVariantPlaying(
      'P4u_chain_loopgrid_playing_panzoom_gesture_render_div2',
      step,
      'Running P4u (gesture render ??2)...'
    );
  } finally {
    window.__PERF_LOOPGRID_GESTURE_RENDER_MOD = prev;
    window.__PERF_LAB_VERBOSE = prevVerbose;
  }
}

async function runP4v() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  const prev = window.__PERF_LOOPGRID_GESTURE_RENDER_MOD;
  window.__PERF_LOOPGRID_GESTURE_RENDER_MOD = 4;
  const prevVerbose = window.__PERF_LAB_VERBOSE;
  window.__PERF_LAB_VERBOSE = true;
  window.__PERF_LOOPGRID_GESTURE_SKIP = 0;
  try {
    await runVariantPlaying(
      'P4v_chain_loopgrid_playing_panzoom_gesture_render_div4',
      step,
      'Running P4v (gesture render ??4)...'
    );
  } finally {
    window.__PERF_LOOPGRID_GESTURE_RENDER_MOD = prev;
    window.__PERF_LAB_VERBOSE = prevVerbose;
  }
}

async function runP4w() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  const prevMod = window.__PERF_LOOPGRID_GESTURE_RENDER_MOD;
  const prevTapDots = window.__PERF_DISABLE_TAP_DOTS;
  window.__PERF_LOOPGRID_GESTURE_RENDER_MOD = 4;
  window.__PERF_DISABLE_TAP_DOTS = true;
  const prevVerbose = window.__PERF_LAB_VERBOSE;
  window.__PERF_LAB_VERBOSE = true;
  window.__PERF_LOOPGRID_GESTURE_SKIP = 0;
  try {
    await runVariantPlaying(
      'P4w_chain_loopgrid_playing_panzoom_gesture_render_div4_no_tapdots',
      step,
      'Running P4w (gesture ??4 + no tap dots)...'
    );
  } finally {
    window.__PERF_LOOPGRID_GESTURE_RENDER_MOD = prevMod;
    window.__PERF_DISABLE_TAP_DOTS = prevTapDots;
    window.__PERF_LAB_VERBOSE = prevVerbose;
  }
}


async function runP4x() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  const prevMod = window.__PERF_LOOPGRID_GESTURE_RENDER_MOD;
  const prevTapDots = window.__PERF_DISABLE_TAP_DOTS;
  const prevChainCache = window.__PERF_LOOPGRID_CHAIN_CACHE;
  window.__PERF_LOOPGRID_GESTURE_RENDER_MOD = 4;
  window.__PERF_DISABLE_TAP_DOTS = true;
  window.__PERF_LOOPGRID_CHAIN_CACHE = true;

  const prevVerbose = window.__PERF_LAB_VERBOSE;
  window.__PERF_LAB_VERBOSE = true;
  window.__PERF_LOOPGRID_GESTURE_SKIP = 0;

  try {
    await runVariantPlaying(
      'P4x_chain_loopgrid_playing_panzoom_gesture_div4_no_tapdots_chain_cache',
      step,
      'Running P4x (gesture ?4 + no tap dots + chain cache)...'
    );
  } finally {
    window.__PERF_LOOPGRID_GESTURE_RENDER_MOD = prevMod;
    window.__PERF_DISABLE_TAP_DOTS = prevTapDots;
    window.__PERF_LOOPGRID_CHAIN_CACHE = prevChainCache;
    window.__PERF_LAB_VERBOSE = prevVerbose;
  }
}async function runP4e() {
  // Simple throttle: every other frame, skip heavy toy redraw hooks.
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  await withTempPerfParticles({ gestureDrawModulo: 2 }, async () => {
    await runVariantPlaying(
      'P4e_chain_loopgrid_playing_panzoom_toydraw_div2',
      step,
      'Running P4e (pan/zoom, toy draw ??2)...'
    );
  });
}

async function runP4c() {
  const step = () => {};
  await withTempPerfParticles({ skipDraw: true }, async () => {
    await runVariantPlaying(
      'P4c_chain_loopgrid_playing_static_no_particle_draw',
      step,
      'Running P4c (playing static, no particle draw)...'
    );
  });
}

async function runP4d() {
  const step = () => {};
  await withTempPerfParticles({ skipUpdate: true, skipDraw: true }, async () => {
    await runVariantPlaying(
      'P4d_chain_loopgrid_playing_static_no_particle_update_draw',
      step,
      'Running P4d (playing static, no particle update+draw)...'
    );
  });
}

async function runP4f() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  window.__PERF_FREEZE_ALL_UNFOCUSED = true;
  try {
    await runVariantPlaying(
      'P4f_chain_loopgrid_playing_panzoom_freeze_unfocused',
      step,
      'Running P4f (pan/zoom, freeze unfocused)...'
    );
  } finally {
    window.__PERF_FREEZE_ALL_UNFOCUSED = false;
  }
}

async function runP4g() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  window.__PERF_LOOPGRID_UNFOCUSED_MOD = 2;
  try {
    await runVariantPlaying(
      'P4g_chain_loopgrid_playing_panzoom_unfocused_div2',
      step,
      'Running P4g (unfocused ??2)...'
    );
  } finally {
    window.__PERF_LOOPGRID_UNFOCUSED_MOD = 0;
  }
}

async function runP4h2() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  window.__PERF_LOOPGRID_UNFOCUSED_MOD = 4;
  try {
    await runVariantPlaying(
      'P4h2_chain_loopgrid_playing_panzoom_unfocused_div4',
      step,
      'Running P4h2 (unfocused ??4)...'
    );
  } finally {
    window.__PERF_LOOPGRID_UNFOCUSED_MOD = 0;
  }
}

async function runP4i() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  window.__PERF_LOOPGRID_UNFOCUSED_MOD = 4;
  window.__PERF_LOOPGRID_UNFOCUSED_MODE = 'pulseOnly';
  try {
    await runVariantPlaying(
      'P4i_chain_loopgrid_playing_panzoom_unfocused_pulseOnly',
      step,
      'Running P4i (unfocused pulse-only)...'
    );
  } finally {
    window.__PERF_LOOPGRID_UNFOCUSED_MOD = 0;
    window.__PERF_LOOPGRID_UNFOCUSED_MODE = null;
  }
}

async function runP4j() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  window.__PERF_LOOPGRID_UNFOCUSED_MOD = 4;
  window.__PERF_LOOPGRID_UNFOCUSED_MODE = 'stepOnly';
  try {
    await runVariantPlaying(
      'P4j_chain_loopgrid_playing_panzoom_unfocused_stepOnly',
      step,
      'Running P4j (unfocused step-only)...'
    );
  } finally {
    window.__PERF_LOOPGRID_UNFOCUSED_MOD = 0;
    window.__PERF_LOOPGRID_UNFOCUSED_MODE = null;
  }
}

async function runP4k() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  await runVariantPlaying(
    'P4k_chain_loopgrid_playing_panzoom_no_zoom_tick_relayout',
    step,
    'Running P4k (no zoom-tick relayout)...'
  );
}

async function runP4m() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  window.__PERF_DISABLE_LOOPGRID_RENDER = true;
  try {
    await runVariantPlaying(
      'P4m_chain_loopgrid_playing_panzoom_no_visuals',
      step,
      'Running P4m (no loopgrid visuals)...'
    );
  } finally {
    window.__PERF_DISABLE_LOOPGRID_RENDER = false;
  }
}

async function runP4n() {
  const step = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 3000,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });

  window.__PERF_DISABLE_LOOPGRID_RENDER = true;
  window.__PERF_DISABLE_CHAINS = true;
  window.__PERF_DISABLE_TAP_DOTS = true;
  window.__PERF_DISABLE_OVERLAYS = true;

  try {
    await runVariantPlaying(
      'P4n_chain_loopgrid_playing_panzoom_no_chains_dots_overlays',
      step,
      'Running P4n (no chains/dots/overlays)?O'
    );
  } finally {
    window.__PERF_DISABLE_LOOPGRID_RENDER = false;
    window.__PERF_DISABLE_CHAINS = false;
    window.__PERF_DISABLE_TAP_DOTS = false;
    window.__PERF_DISABLE_OVERLAYS = false;
  }
}

async function runP5a() {
  const panZoom = makePanZoomScript({
    panPx: 2400,
    zoomMin: 0.40,
    zoomMax: 1.20,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randDraw = makeToyRandomiseOnceScript({
    selector: '.toy-panel[data-toy="drawgrid"]',
    atMs: 300,
    seed: 1337,
    useSeededRandom: true,
    eventNames: ['toy-random', 'toy-random-notes'],
    readyCheck: (panel) => !!panel?.__dgPerfWarmup,
    retryMs: 300,
    timeoutMs: 6000,
    repeatCount: 4,
    repeatEveryMs: 500,
  });
  const randLoop = makeToyRandomiseOnceScript({
    selector: '.toy-panel[data-toy="loopgrid"], .toy-panel[data-toy="loopgrid-drum"]',
    atMs: 300,
    seed: 1337,
    useSeededRandom: true,
    eventNames: ['toy-random', 'toy-random-notes'],
    readyCheck: (panel) => !!panel?.__simpleRhythmVisualState,
    retryMs: 300,
    timeoutMs: 6000,
    repeatCount: 3,
    repeatEveryMs: 500,
  });
  const step = composeSteps(panZoom, randDraw, randLoop);
  await runVariantPlaying(
    'P5a_mixed_draw_loopgrid_playing_panzoom_rand',
    step,
    'Running P5a (mixed draw + loopgrid, playing pan/zoom)...'
  );
}

async function runP5b() {
  await withTempPerfParticles({ gestureDrawModulo: 2 }, async () => {
    await runP5a();
  });
}

async function runP5c() {
  await withTempPerfParticles({ gestureFieldModulo: 2 }, async () => {
    await runP5a();
  });
}

async function runP6a() {
  const panZoom = makePanZoomScript({
    panPx: 2200,
    zoomMin: 0.45,
    zoomMax: 1.15,
    idleMs: 2500,
    panMs: 13500,
    zoomMs: 13500,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randDraw = makeToyRandomiseOnceScript({
    selector: '.toy-panel[data-toy="drawgrid"]',
    atMs: 300,
    seed: 1337,
    useSeededRandom: true,
    eventNames: ['toy-random', 'toy-random-notes'],
    readyCheck: (panel) => !!panel?.__dgPerfWarmup,
    retryMs: 300,
    timeoutMs: 6000,
    repeatCount: 4,
    repeatEveryMs: 500,
  });
  const randLoop = makeToyRandomiseOnceScript({
    selector: '.toy-panel[data-toy="loopgrid"], .toy-panel[data-toy="loopgrid-drum"]',
    atMs: 300,
    seed: 1337,
    useSeededRandom: true,
    eventNames: ['toy-random', 'toy-random-notes'],
    readyCheck: (panel) => !!panel?.__simpleRhythmVisualState,
    retryMs: 300,
    timeoutMs: 6000,
    repeatCount: 3,
    repeatEveryMs: 500,
  });
  // IMPORTANT: start the *scene* playing (not just the audio transport).
  // Some stress scenes only animate/step once the UI play state is active.
  // Without this, P6a can look "not playing" even though the transport is running.
  const ensurePlay = makeEnsureTransportScript({ atMs: 600 });
  const step = composeSteps(panZoom, randDraw, randLoop, ensurePlay);
  await runVariantPlaying(
    'P6a_avg_mix_playing_panzoom_rand',
    step,
    'Running P6a (avg mix, playing pan/zoom)...'
  );
}

async function runP6b() {
  const randDraw = makeToyRandomiseOnceScript({
    selector: '.toy-panel[data-toy="drawgrid"]',
    atMs: 300,
    seed: 1337,
    useSeededRandom: true,
    eventNames: ['toy-random', 'toy-random-notes'],
  });
  const randLoop = makeToyRandomiseOnceScript({
    selector: '.toy-panel[data-toy="loopgrid"], .toy-panel[data-toy="loopgrid-drum"]',
    atMs: 300,
    seed: 1337,
    useSeededRandom: true,
    eventNames: ['toy-random', 'toy-random-notes'],
  });
  const ensurePlay = makeEnsureTransportScript({ atMs: 600 });
  const step = composeSteps(randDraw, randLoop, ensurePlay);
  await runVariantPlaying(
    'P6b_avg_mix_playing_static_rand',
    step,
    'Running P6b (avg mix, playing static)...'
  );
}

async function runP6c() {
  const panZoom = makePanZoomScript({
    panPx: 2600,
    zoomMin: 0.2,
    zoomMax: 2.2,
    idleMs: 2000,
    panMs: 12000,
    zoomMs: 15000,
    overviewToggles: 0,
    overviewSpanMs: 0,
  });
  const randDraw = makeToyRandomiseOnceScript({
    selector: '.toy-panel[data-toy="drawgrid"]',
    atMs: 300,
    seed: 1337,
    useSeededRandom: true,
    eventNames: ['toy-random', 'toy-random-notes'],
  });
  const randLoop = makeToyRandomiseOnceScript({
    selector: '.toy-panel[data-toy="loopgrid"], .toy-panel[data-toy="loopgrid-drum"]',
    atMs: 300,
    seed: 1337,
    useSeededRandom: true,
    eventNames: ['toy-random', 'toy-random-notes'],
  });
  const ensurePlay = makeEnsureTransportScript({ atMs: 600 });
  const step = composeSteps(panZoom, randDraw, randLoop, ensurePlay);
  await runVariantPlaying(
    'P6c_avg_mix_playing_extreme_zoom',
    step,
    'Running P6c (avg mix, extreme zoom)...'
  );
}

async function runP6cOverview() {
  const panZoom = makePanZoomScript({
    panPx: 2600,
    zoomMin: 0.2,
    zoomMax: 2.2,
    idleMs: 2000,
    panMs: 12000,
    zoomMs: 15000,
    overviewToggles: 2,
    overviewSpanMs: 9000,
  });
  const randDraw = makeToyRandomiseOnceScript({
    selector: '.toy-panel[data-toy="drawgrid"]',
    atMs: 300,
    seed: 1337,
    useSeededRandom: true,
    eventNames: ['toy-random', 'toy-random-notes'],
  });
  const randLoop = makeToyRandomiseOnceScript({
    selector: '.toy-panel[data-toy="loopgrid"], .toy-panel[data-toy="loopgrid-drum"]',
    atMs: 300,
    seed: 1337,
    useSeededRandom: true,
    eventNames: ['toy-random', 'toy-random-notes'],
  });
  const ensurePlay = makeEnsureTransportScript({ atMs: 600 });
  const step = composeSteps(panZoom, randDraw, randLoop, ensurePlay);
  await runVariantPlaying(
    'P6c_avg_mix_playing_extreme_zoom_overview',
    step,
    'Running P6c (avg mix, extreme zoom + overview)...'
  );
}

async function runP6d() {
  await withTempPerfParticles({ gestureDrawModulo: 4, gestureFieldModulo: 4 }, async () => {
    await runP6c();
  });
}

async function runP6e() {
  const prev = window.__PERF_ZOOM_PROFILE;
  const prevField = window.__PERF_PARTICLE_FIELD_PROFILE;
  const prevSlow = window.__PERF_FRAME_PROF_SLOW_MS;
  const prevMax = window.__PERF_FRAME_PROF_MAX;
  window.__PERF_ZOOM_PROFILE = true;
  window.__PERF_FRAME_PROF_SLOW_MS = 0;
  window.__PERF_FRAME_PROF_MAX = 240;
  window.__PERF_PARTICLE_FIELD_PROFILE = true;
  try {
    await runP6d();
  } finally {
    window.__PERF_ZOOM_PROFILE = prev;
    window.__PERF_FRAME_PROF_SLOW_MS = prevSlow;
    window.__PERF_FRAME_PROF_MAX = prevMax;
    window.__PERF_PARTICLE_FIELD_PROFILE = prevField;
  }
}

async function runP6eOverview() {
  try { window.__PERF_RUN_TAG = 'overview'; } catch {}
  const prev = window.__PERF_ZOOM_PROFILE;
  const prevField = window.__PERF_PARTICLE_FIELD_PROFILE;
  const prevSlow = window.__PERF_FRAME_PROF_SLOW_MS;
  const prevMax = window.__PERF_FRAME_PROF_MAX;
  window.__PERF_ZOOM_PROFILE = true;
  window.__PERF_FRAME_PROF_SLOW_MS = 0;
  window.__PERF_FRAME_PROF_MAX = 240;
  window.__PERF_PARTICLE_FIELD_PROFILE = true;
  try {
    await withTempPerfParticles({ gestureDrawModulo: 4, gestureFieldModulo: 4 }, async () => {
      await runP6cOverview();
    });
  } finally {
    window.__PERF_ZOOM_PROFILE = prev;
    window.__PERF_FRAME_PROF_SLOW_MS = prevSlow;
    window.__PERF_FRAME_PROF_MAX = prevMax;
    window.__PERF_PARTICLE_FIELD_PROFILE = prevField;
  }
}

function installNoPaintPatch() {
  if (window.__PERF_NO_PAINT_PATCH) return;
  const proto = (typeof CanvasRenderingContext2D !== 'undefined') ? CanvasRenderingContext2D.prototype : null;
  if (!proto) return;
  const methods = [
    'clearRect', 'fillRect', 'strokeRect', 'beginPath', 'closePath',
    'moveTo', 'lineTo', 'rect', 'arc', 'arcTo', 'ellipse',
    'quadraticCurveTo', 'bezierCurveTo', 'fill', 'stroke',
    'drawImage', 'fillText', 'strokeText', 'clip',
    'save', 'restore', 'translate', 'scale', 'rotate',
    'setTransform', 'resetTransform'
  ];
  const patch = { methods: {} };
  for (const name of methods) {
    const orig = proto[name];
    if (typeof orig !== 'function') continue;
    patch.methods[name] = orig;
    proto[name] = function(...args) {
      if (window.__PERF_NO_PAINT) return;
      return orig.apply(this, args);
    };
  }
  window.__PERF_NO_PAINT_PATCH = patch;
}

function setNoPaintEnabled(enabled) {
  window.__PERF_NO_PAINT = !!enabled;
  if (window.__PERF_NO_PAINT) installNoPaintPatch();
}

async function withNoPaint(fn) {
  const prev = window.__PERF_NO_PAINT;
  window.__PERF_NO_PAINT_ACTIVE = true;
  setNoPaintEnabled(true);
  try { return await fn(); }
  finally {
    window.__PERF_NO_PAINT = prev;
    window.__PERF_NO_PAINT_ACTIVE = false;
  }
}

async function runP6eNoPaint() {
  const prevTag = window.__PERF_RUN_TAG;
  window.__PERF_RUN_TAG = 'P6eNoPaint';
  try {
    await withNoPaint(async () => {
      await runP6e();
    });
  } finally {
    window.__PERF_RUN_TAG = prevTag;
  }
}

async function runP6ePaintOnly() {
  const prevTag = window.__PERF_RUN_TAG;
  const prevPaintOnly = window.__PERF_PAINT_ONLY_ACTIVE;
  window.__PERF_RUN_TAG = 'P6ePaintOnly';
  window.__PERF_PAINT_ONLY_ACTIVE = true;
  try {
    await withTempPerfParticles({ skipUpdate: true, skipDraw: false }, async () => {
      await runP6e();
    });
  } finally {
    window.__PERF_RUN_TAG = prevTag;
    window.__PERF_PAINT_ONLY_ACTIVE = prevPaintOnly;
  }
}

async function runP6eNoDom() {
  const prevTag = window.__PERF_RUN_TAG;
  const prevNoDom = window.__PERF_NO_DOM_UPDATES;
  window.__PERF_RUN_TAG = 'P6eNoDom';
  window.__PERF_NO_DOM_UPDATES = true;
  try {
    await runP6e();
  } finally {
    window.__PERF_RUN_TAG = prevTag;
    window.__PERF_NO_DOM_UPDATES = prevNoDom;
  }
}




async function runQueue(list = []) {
  const items = Array.isArray(list) ? list : [list];
  const results = [];
  const executed = [];
  for (const item of items) {
    // Resolve by name, with defensive aliases so Auto-runs don't become no-ops
    // if someone loses an export during merges or a stale bundle is served.
    let name = (typeof item === 'string') ? item : null;
    let fn = (typeof item === 'function') ? item : (name ? window.__PerfLab?.[name] : null);

    if (typeof fn !== 'function' && name) {
      const ALIASES = {
        // Historical / merge-safe aliases:
        traceCanvasOnlyOn: 'traceOn',              // then force domInRaf OFF below
        runP3fShort: 'runP3f',
        runP3fNoOverlaysShort: 'runP3fNoOverlays',
        // Focus queue merge-safety (avoid silently skipping intended focus tests)
        runP3fMultiCanvasFocusShort: 'runP3fFocusShort',
      };
      const alt = ALIASES[name];
      if (alt && typeof window.__PerfLab?.[alt] === 'function') {
        console.warn('[PerfLab] missing test', name, '-> using alias', alt);
        fn = window.__PerfLab[alt];
        name = alt;
      }
    }

    if (typeof fn !== 'function') {
      const known = (() => {
        try { return Object.keys(window.__PerfLab || {}).sort(); } catch { return []; }
      })();
      console.warn('[PerfLab] missing test', item, { knownCount: known.length, known });
      continue;
    }

    executed.push((typeof item === 'string') ? item : (item.name || '<fn>'));
    const isBuild = (typeof item === 'string' && item.startsWith('build'));
    if (isBuild) {
      try { clearSceneViaSnapshot(); } catch {}
      lastResult = null;
    }

    // Special-case: if we fell back from traceCanvasOnlyOn -> traceOn,
    // enforce "canvas resize trace only" by disabling dom-in-raf trace.
    if (typeof item === 'string' && item === 'traceCanvasOnlyOn') {
      try {
        window.__PERF_TRACE = window.__PERF_TRACE || {};
        window.__PERF_TRACE.traceCanvasResize = true;
        window.__PERF_TRACE.traceDomInRaf = false;
      } catch {}
    }

    // Only push a result if this step actually produced a *new* one.
    // (Otherwise “toggle” steps like traceOff would duplicate the prior benchmark result.)
    const prevResult = lastResult;
    try { await fn(); } catch (err) { console.warn('[PerfLab] test failed', item, err); }
    if (!isBuild && lastResult && lastResult !== prevResult) results.push(lastResult);
  }
  // Capture what actually ran (not just what the config said).
  window.__PERF_LAB_EXECUTED_QUEUE = executed;
  lastResults = results;
  try { console.log('[PerfLab] queue results', results); } catch {}
  return results;
}
async function copyLast() {
  if (!lastResult) {
    setStatus('No results to copy');
    return;
  }
  const txt = JSON.stringify(lastResult, null, 2);
  try {
    await navigator.clipboard.writeText(txt);
    setStatus('Copied JSON to clipboard');
  } catch {
    setStatus('Clipboard failed (see console)');
    console.log(txt);
  }
}

// Hotkey: Ctrl+Shift+P (P = Perf)
window.addEventListener('keydown', (e) => {
  const isP = (String(e.key || '').toLowerCase() === 'p');
  if (!isP) return;
  if (!(e.ctrlKey && e.shiftKey)) return;
  e.preventDefault();
  toggle();
});

// Expose for manual console use
try {
  window.__PerfLab = {
    show,
    hide,
    toggle,
    warmupFirstAppearance,
    warmupSettle,
    buildP2,
    buildP2d,
    buildP3,
    buildP3Focus,
    buildP3FocusHeavy,
    buildP3Lite,
    buildP4,
    buildP4h,
    buildP5,
    buildP6,
    buildP7,
    buildBS0,
    runP2a,
    runP2b,
    runP2c,
    runP2d,
    runP3a,
    runP3b,
    runP3c,
    runP3d,
      runP3e,
      runP3e2,
    runP3f,
    runP3fShort,
    runP3fShort2,
    runP3fFocus,
    runP3fFocusShort,
    runP3fFocusShort2,
    runP3fMultiCanvasFocusShort,
    runP3fNoOverlaysFocusShort,
    runP3fNoParticlesFocusShort,
    runP3fTapDotsFocusShort,
    runP3fNoOverlaysShort,
    runP3fNoOverlaysShort2,
      runP3fNoParticlesShort,
    runP3fNoParticlesShort2,
    runP3fNoOverlayCoreShort,
    runP3fNoOverlayStrokesShort,
    runP3PauseDomProbe,
    runP3fPlayheadSeparateOff,
    runP3fPlayheadSeparateOn,
    runP3fPlayheadEvery4,
    runP3f2,
    runP3fEmptyNoNotes,
    runP3fEmptyChainNoNotes,
    runP3fMixedSomeEmpty,
    runP3fNoPaint,
    runP3fNoDom,
    runP3fNoGrid,
    runP3fNoParticles,
    runP3fNoOverlays,
    runP3fNoOverlayStrokes,
    runP3fNoOverlayCore,
    runP3fParticleProfile,
    runP3fFlatLayers,
    runP3g,
    runP3g2,
    runP3h,
    runP3h2,
    runP3i,
    runP3i2,
    runP3j,
    runP3j2,
    runP3k,
    runP3k2,
    runP3l,
    runP3l2,
    runP3lShort,
    runP3l2Short,
    runP3l2ShortGap900,
    runP3l3,
    runP3l4,
    runP3l5,
    runP3l6,
    runP3m,
    runP3m2,
    runP7a,
    runP7b,
    runBS0s1,
    runBS0s2,
    runBS0s3,
    runBS0s4,
    runBS0s5,
    runBS0s3MusicLabTriplet,
    runGunnerCombatProfilesDebug,
    runSeekerCombatProfilesDebug,
    runLaserSpinnerCombatProfilesDebug,
    runShapeCasterCombatProfilesDebug,
    runChargerCombatProfilesDebug,
    runConductorCombatProfilesDebug,
    runLaserVariantsDebug,
    runSymmetricLaserGroupDebug,
    runShapeCasterGunnerCombinationDebug,
    runShapeCasterSeekerCombinationDebug,
    runBS0BehaviorTaxonomyDebug,
    runBS0a,
    runBS0b,
    runQueue,
    runAuto,
    runP4a,
    runP4b,
    runP4o,
    runP4p,
    runP4q,
    runP4r,
    runP4s,
    runP4t,
    runP4u,
    runP4v,
    runP4w,
    runP4x,
    runP4e,
    runP4c,
    runP4d,
    runP4f,
    runP4g,
    runP4h2,
    runP4i,
    runP4j,
    runP4k,
    runP4m,
    runP4n,
    runP5a,
    runP5b,
    runP5c,
    runP6a,
    runP6b,
    runP6c,
    runP6d,
    runP6e,
    runP6cOverview,
    runP6eOverview,
    runP6eNoPaint,
    runP6ePaintOnly,
    runP6eNoDom,
    readAutoConfig,
    readAutoConfigFromFile,
    saveResultsBundle,
    postResultsBundle,
      // Demon trace toggles (so auto-queue can flip them deterministically)
      traceDprOn: async function traceDprOn() {
        try { window.__DG_REFRESH_SIZE_TRACE = true; } catch {}
        try { window.__DG_REFRESH_SIZE_TRACE_SAMPLE = false; } catch {}
        try { window.__DG_RESIZE_TRACE_SAMPLE = false; } catch {}
        try { window.__DG_EFFECTIVE_DPR_TRACE = true; } catch {}
        try { window.__FG_EFFECTIVE_DPR_TRACE = true; } catch {}
        // Ensure adaptive DPR is enabled during perf automation runs.
        try { window.__DG_ADAPTIVE_DPR_ENABLED = true; } catch {}
        try { window.__DG_ADAPTIVE_DPR_ALLOW_SINGLE = true; } catch {}
        // IMPORTANT: do not spam console during perf runs; buffer instead.
        try { window.__PERF_TRACE_TO_CONSOLE = false; } catch {}
        try { window.__PERF_TRACE_KEEP_BUFFER = true; } catch {}
        try { if (window.__PERF_TRACE_CLEAR) window.__PERF_TRACE_CLEAR(); } catch {}
        // Quiet size-trace by default (still captured in buffer via DG/FG hooks).
        try { window.__DG_REFRESH_SIZE_TRACE_THROTTLE_MS = 800; } catch {}
        try { window.__DG_REFRESH_SIZE_TRACE_LIMIT = 200; } catch {}
        // For focus runs where only one DrawGrid is visible, allow adaptive DPR to engage (if enabled).
        try { window.__DG_ADAPTIVE_DPR_ALLOW_SINGLE = true; } catch {}
        try {
          console.log('[PerfLab] DPR trace ENABLED', {
            __DG_REFRESH_SIZE_TRACE: !!window.__DG_REFRESH_SIZE_TRACE,
            __DG_EFFECTIVE_DPR_TRACE: !!window.__DG_EFFECTIVE_DPR_TRACE,
            __FG_EFFECTIVE_DPR_TRACE: !!window.__FG_EFFECTIVE_DPR_TRACE,
            __DG_ADAPTIVE_DPR_ENABLED: !!window.__DG_ADAPTIVE_DPR_ENABLED,
            __DG_ADAPTIVE_DPR_ALLOW_SINGLE: !!window.__DG_ADAPTIVE_DPR_ALLOW_SINGLE,
          });
        } catch {}
      },
      traceDprOff: async function traceDprOff() {
        try { window.__DG_REFRESH_SIZE_TRACE = false; } catch {}
        try { window.__DG_EFFECTIVE_DPR_TRACE = false; } catch {}
        try { window.__FG_EFFECTIVE_DPR_TRACE = false; } catch {}
        try { console.log('[PerfLab] DPR trace DISABLED'); } catch {}
        try { window.__PERF_TRACE_KEEP_BUFFER = false; } catch {}
      },

      // -------------------------------------------------------------------
      // DrawGrid tier automation helpers (for auto queues)
      // -------------------------------------------------------------------
      __applyDgForceTier: async function __applyDgForceTier(forceTier, reason = 'auto') {
        // Persist global override
        try { window.__DG_FORCE_TIER = (forceTier == null) ? null : (forceTier | 0); } catch {}

        // Push to all existing DrawGrid panels (use hook added in drawgrid)
        try {
          const panels = document.querySelectorAll('.toy-panel');
          for (const p of panels) {
            const fn = p && p.__dgSetQualityTier;
            if (typeof fn !== 'function') continue;
            if (forceTier == null) {
              try { delete p.__dgQualityTier; } catch {}
              try { delete p.__dgQualityTierReason; } catch {}
              try { delete p.__dgQualityTierSetMs; } catch {}
            } else {
              fn(forceTier | 0, reason);
            }
          }
        } catch {}
      },

      // -------------------------------------------------------------------
      // LoopGrid tier automation helpers (for auto queues)
      // -------------------------------------------------------------------
      __applyLgForceTier: async function __applyLgForceTier(forceTier, reason = 'auto') {
        // Persist global override
        try { window.__LG_FORCE_TIER = (forceTier == null) ? null : (forceTier | 0); } catch {}

        // Push to all existing LoopGrid panels by forcing a layout recompute.
        // This matters because LoopGrid’s DPR clamp is applied at its sizing truth-point.
        try {
          const panels = document.querySelectorAll('.toy-panel');
          for (const p of panels) {
            const st = p && p.__simpleRhythmVisualState;
            if (!st) continue;
            // Trigger redraw + re-layout (re-applies backing store sizing immediately)
            try { p.__loopgridNeedsRedraw = true; } catch {}
            const w = (st._cssW | 0);
            const h = (st._cssH | 0);
            if (w > 0 && h > 0 && typeof st.computeLayout === 'function') {
              try { st.computeLayout(w, h); } catch {}
            }
          }
        } catch {}
      },

      dgTierAutoOn: async function dgTierAutoOn() {
        try { window.__DG_TIER_AUTO = true; } catch {}
        try { __perfSetRunTagPart('dgAuto', 'dgAutoOn'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      dgTierAutoOff: async function dgTierAutoOff() {
        try { window.__DG_TIER_AUTO = false; } catch {}
        try { __perfSetRunTagPart('dgAuto', 'dgAutoOff'); } catch {}
        try { syncUiFromState(); } catch {}
      },

      dgForceTierAuto: async function dgForceTierAuto() {
        try { await window.__PerfLab.__applyDgForceTier(null, 'auto'); } catch {}
        try { __perfSetRunTagPart('dgTier', 'dgTierAuto'); } catch {}
      },
      dgForceTier3: async function dgForceTier3() {
        try { await window.__PerfLab.__applyDgForceTier(3, 'auto'); } catch {}
        try { __perfSetRunTagPart('dgTier', 'dgTier3'); } catch {}
      },
      dgForceTier2: async function dgForceTier2() {
        try { await window.__PerfLab.__applyDgForceTier(2, 'auto'); } catch {}
        try { __perfSetRunTagPart('dgTier', 'dgTier2'); } catch {}
      },
      dgForceTier1: async function dgForceTier1() {
        try { await window.__PerfLab.__applyDgForceTier(1, 'auto'); } catch {}
        try { __perfSetRunTagPart('dgTier', 'dgTier1'); } catch {}
      },
      dgForceTier0: async function dgForceTier0() {
        try { await window.__PerfLab.__applyDgForceTier(0, 'auto'); } catch {}
        try { __perfSetRunTagPart('dgTier', 'dgTier0'); } catch {}
      },
      dgForceTierEmergency: async function dgForceTierEmergency() {
        try { await window.__PerfLab.__applyDgForceTier(-1, 'auto'); } catch {}
        try { __perfSetRunTagPart('dgTier', 'dgTierEmergency'); } catch {}
      },
      lgForceTierAuto: async function lgForceTierAuto() {
        try { await window.__PerfLab.__applyLgForceTier(null, 'auto'); } catch {}
        try { __perfSetRunTagPart('lgTier', 'lgTierAuto'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      lgForceTier0: async function lgForceTier0() {
        try { await window.__PerfLab.__applyLgForceTier(0, 'auto'); } catch {}
        try { __perfSetRunTagPart('lgTier', 'lgTier0'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      lgForceTier1: async function lgForceTier1() {
        try { await window.__PerfLab.__applyLgForceTier(1, 'auto'); } catch {}
        try { __perfSetRunTagPart('lgTier', 'lgTier1'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      lgForceTier2: async function lgForceTier2() {
        try { await window.__PerfLab.__applyLgForceTier(2, 'auto'); } catch {}
        try { __perfSetRunTagPart('lgTier', 'lgTier2'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      lgForceTier3: async function lgForceTier3() {
        try { await window.__PerfLab.__applyLgForceTier(3, 'auto'); } catch {}
        try { __perfSetRunTagPart('lgTier', 'lgTier3'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      lgForceTier4: async function lgForceTier4() {
        try { await window.__PerfLab.__applyLgForceTier(4, 'auto'); } catch {}
        try { __perfSetRunTagPart('lgTier', 'lgTier4'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      dgAdaptiveOff: async function dgAdaptiveOff() {
        // Force DrawGrid adaptive DPR OFF (for A/B comparisons).
        try { window.__DG_ADAPTIVE_DPR_ENABLED = false; } catch {}
        try { __perfSetRunTagPart('dgAdaptive', 'dgAdaptiveOff'); } catch {}
        try { console.log('[PerfLab] DrawGrid adaptive DPR OFF'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      dgAdaptiveOn: async function dgAdaptiveOn() {
        // Force DrawGrid adaptive DPR ON (for A/B comparisons).
        try { window.__DG_ADAPTIVE_DPR_ENABLED = true; } catch {}
        // Allow engagement even with a single visible DrawGrid (focus runs).
        try { window.__DG_ADAPTIVE_DPR_ALLOW_SINGLE = true; } catch {}
        try { __perfSetRunTagPart('dgAdaptive', 'dgAdaptiveOn'); } catch {}
        try { console.log('[PerfLab] DrawGrid adaptive DPR ON'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      traceCanvasOnlyOn: async function traceCanvasOnlyOn() {
        window.__PERF_TRACE = window.__PERF_TRACE || {};
        window.__PERF_TRACE.traceCanvasResize = true;
        window.__PERF_TRACE.traceDomInRaf = false;
        try { window.__DG_RESIZE_TRACE_SAMPLE = false; } catch {}
        try { console.log('[PerfLab] traceCanvasResize ENABLED (domInRaf OFF)', { trace: window.__PERF_TRACE }); } catch {}
      },
      traceOn: async function traceOn() {
        window.__PERF_TRACE = window.__PERF_TRACE || {};
        window.__PERF_TRACE.traceCanvasResize = true;
        window.__PERF_TRACE.traceDomInRaf = true;
        try { console.log('[PerfLab] demon trace ENABLED', { trace: window.__PERF_TRACE }); } catch {}
      },
      traceOff: async function traceOff() {
        window.__PERF_TRACE = window.__PERF_TRACE || {};
        window.__PERF_TRACE.traceCanvasResize = false;
        window.__PERF_TRACE.traceDomInRaf = false;
        try { console.log('[PerfLab] demon trace DISABLED', { trace: window.__PERF_TRACE }); } catch {}
      },
      // Focus toggles: these MUST be exported so runQueue(AUTO_FOCUS_QUEUE) can resolve them by name.
      loopRenderOff: async function loopRenderOff() {
        try { window.__PERF_DISABLE_LOOPGRID_RENDER = true; } catch {}
        try { __perfSetRunTagPart('loopRender', 'loopRenderOff'); } catch {}
        try { console.log('[PerfLab] LoopGrid render: OFF'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      loopRenderOn: async function loopRenderOn() {
        try { window.__PERF_DISABLE_LOOPGRID_RENDER = false; } catch {}
        try { __perfSetRunTagPart('loopRender', 'loopRenderOn'); } catch {}
        try { console.log('[PerfLab] LoopGrid render: ON'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      chainsOff: async function chainsOff() {
        try { window.__PERF_DISABLE_CHAINS = true; } catch {}
        try { __perfSetRunTagPart('chains', 'chainsOff'); } catch {}
        try { console.log('[PerfLab] Chains: OFF'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      chainsOn: async function chainsOn() {
        try { window.__PERF_DISABLE_CHAINS = false; } catch {}
        try { __perfSetRunTagPart('chains', 'chainsOn'); } catch {}
        try { console.log('[PerfLab] Chains: ON'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      chainUiOff: async function chainUiOff() {
        try { window.__PERF_DISABLE_CHAIN_UI = true; } catch {}
        try { __perfSetRunTagPart('chainUi', 'chainUiOff'); } catch {}
        try { console.log('[PerfLab] Chain UI: OFF'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      chainUiOn: async function chainUiOn() {
        try { window.__PERF_DISABLE_CHAIN_UI = false; } catch {}
        try { __perfSetRunTagPart('chainUi', 'chainUiOn'); } catch {}
        try { console.log('[PerfLab] Chain UI: ON'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      connectorsOff: async function connectorsOff() {
        try { window.__PERF_DISABLE_CHAIN_CONNECTORS = true; } catch {}
        try { __perfSetRunTagPart('connectors', 'connectorsOff'); } catch {}
        try { console.log('[PerfLab] Chain connectors: OFF'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      connectorsOn: async function connectorsOn() {
        try { window.__PERF_DISABLE_CHAIN_CONNECTORS = false; } catch {}
        try { __perfSetRunTagPart('connectors', 'connectorsOn'); } catch {}
        try { console.log('[PerfLab] Chain connectors: ON'); } catch {}
        try { syncUiFromState(); } catch {}
      },
      getResults: () => lastResults,
      getBundle: () => lastBundle,
      clearResults: () => { lastResults = []; },
    };
} catch {}














try { scheduleAutoRun(); } catch {}

