import { normalizeCallResponseLane, chooseResponseNoteFromPool } from './beat-swarm-groups.js';

function normalizeLifecycleState(value, fallback = 'active') {
  const raw = String(value || '').trim().toLowerCase();
  if (raw === 'active') return 'active';
  if (raw === 'retiring') return 'retiring';
  if (raw === 'deemphasized' || raw === 'de_emphasized' || raw === 'de-emphasized') return 'deEmphasized';
  if (raw === 'inactiveforscheduling' || raw === 'inactive_for_scheduling' || raw === 'inactive-for-scheduling') return 'inactiveForScheduling';
  const fb = String(fallback || 'active').trim().toLowerCase();
  if (fb === 'retiring') return 'retiring';
  if (fb === 'deemphasized' || fb === 'de_emphasized' || fb === 'de-emphasized') return 'deEmphasized';
  if (fb.includes('inactive')) return 'inactiveForScheduling';
  return 'active';
}

function normalizeComposerProfileSourceType(value) {
  const normalized = String(value || '').trim().toLowerCase();
  if (!normalized) return '';
  return normalized;
}

function normalizePhraseNoteList(values, normalizeNoteName) {
  if (!Array.isArray(values) || !values.length) return [];
  const out = [];
  const seen = new Set();
  for (const v of values) {
    const note = normalizeNoteName(v);
    if (!note || seen.has(note)) continue;
    seen.add(note);
    out.push(note);
  }
  return out;
}

function getPhraseStepState(stepAbs = 0, phraseSteps = 4) {
  const steps = Math.max(2, Math.trunc(Number(phraseSteps) || 4));
  const abs = Math.max(0, Math.trunc(Number(stepAbs) || 0));
  const stepInPhrase = ((abs % steps) + steps) % steps;
  const stepsToEnd = Math.max(0, (steps - 1) - stepInPhrase);
  const nearPhraseEnd = stepsToEnd <= Math.max(1, Math.floor(steps * 0.25));
  const resolutionOpportunity = stepsToEnd === 0;
  return {
    phraseSteps: steps,
    stepInPhrase,
    stepsToEnd,
    nearPhraseEnd,
    resolutionOpportunity,
  };
}

function pickClosestPhraseTarget(noteName, targets, options = null) {
  const normalizeNoteName = typeof options?.normalizeNoteName === 'function'
    ? options.normalizeNoteName
    : ((n) => String(n || '').trim());
  const getNotePoolIndex = typeof options?.getNotePoolIndex === 'function'
    ? options.getNotePoolIndex
    : (() => -1);
  const note = normalizeNoteName(noteName);
  const candidateNotes = normalizePhraseNoteList(targets, normalizeNoteName);
  if (!candidateNotes.length) return '';
  const noteIdx = Math.max(-1, Math.trunc(Number(getNotePoolIndex(note)) || -1));
  if (noteIdx < 0) return candidateNotes[0];
  let picked = candidateNotes[0];
  let best = Number.POSITIVE_INFINITY;
  for (const candidate of candidateNotes) {
    const idx = Math.max(-1, Math.trunc(Number(getNotePoolIndex(candidate)) || -1));
    if (idx < 0) continue;
    const dist = Math.abs(idx - noteIdx);
    if (dist < best) {
      best = dist;
      picked = candidate;
    }
  }
  return picked;
}

export function chooseComposerGroupEnemyForNote(options = null) {
  const group = options?.group || null;
  const aliveMembers = Array.isArray(options?.aliveMembers) ? options.aliveMembers : [];
  const normalizeNoteName = typeof options?.normalizeNoteName === 'function' ? options.normalizeNoteName : ((n) => String(n || '').trim());
  const getFallbackNote = typeof options?.getFallbackNote === 'function' ? options.getFallbackNote : (() => '');
  const noteName = options?.noteName;
  const note = normalizeNoteName(noteName) || getFallbackNote();
  const aliveIds = new Set(aliveMembers.map((e) => Math.trunc(Number(e?.id) || 0)));
  const pinned = Math.trunc(Number(group?.noteToEnemyId?.get?.(note)) || 0);
  if (pinned > 0 && aliveIds.has(pinned)) {
    return aliveMembers.find((e) => Math.trunc(Number(e?.id) || 0) === pinned) || null;
  }
  if (!aliveMembers.length) return null;
  const picked = aliveMembers[Math.max(0, Math.min(aliveMembers.length - 1, Math.trunc(Math.random() * aliveMembers.length)))] || null;
  if (picked) group?.noteToEnemyId?.set?.(note, Math.trunc(Number(picked.id) || 0));
  return picked;
}

export function collectComposerGroupStepBeatEvents(options = null) {
  const events = [];
  if (!options?.active || options?.gameplayPaused) return events;
  if (options?.introLeadStabilizationActive === true) return events;

  const composerEnemyGroups = Array.isArray(options?.composerEnemyGroups) ? options.composerEnemyGroups : [];
  const hasIntroPercussionCarrier = composerEnemyGroups.some((g) => g && g.active && !g.retiring && g?.introPercussionCarrier === true);
  const hasSoloCarrier = composerEnemyGroups.some((g) => {
    if (!g || !g.active || g.retiring) return false;
    const soloCarrierType = String(g?.soloCarrierType || '').trim().toLowerCase();
    return soloCarrierType === 'rhythm';
  });
  const hasIntroSlotRhythmCarrier = composerEnemyGroups.some((g) => {
    if (!g || !g.active || g.retiring) return false;
    const profile = normalizeComposerProfileSourceType(g?.introSlotProfileSourceType || g?.musicProfileSourceType);
    return profile === 'spawner_rhythm_pulse'
      || profile === 'spawner_rhythm_backbeat'
      || profile === 'spawner_rhythm_motion';
  });
  const getCurrentPacingCaps = typeof options?.getCurrentPacingCaps === 'function' ? options.getCurrentPacingCaps : (() => ({ responseMode: 'none' }));
  const pacingCaps = getCurrentPacingCaps();
  const responseMode = String(pacingCaps?.responseMode || 'none');
  if ((responseMode === 'none' || responseMode === 'drawsnake') && !hasIntroPercussionCarrier && !hasSoloCarrier && !hasIntroSlotRhythmCarrier) return events;

  const constants = options?.constants && typeof options.constants === 'object' ? options.constants : {};
  const stepIndex = Math.trunc(Number(options?.stepIndex) || 0);
  const beatIndex = Math.trunc(Number(options?.beatIndex) || 0);
  const barIndex = Math.max(0, Math.trunc(Number(options?.barIndex) || 0));
  const stepAbs = Math.max(0, stepIndex);
  const stepsPerBar = Math.max(1, Math.trunc(Number(constants.stepsPerBar) || 8));
  const step = ((stepIndex % stepsPerBar) + stepsPerBar) % stepsPerBar;
  const performersMin = Math.max(1, Math.trunc(Number(constants.performersMin) || 1));
  const performersMax = Math.max(performersMin, Math.trunc(Number(constants.performersMax) || 2));

  const activeGroups = composerEnemyGroups.filter((g) => g && g.active && !g.retiring);
  const activePrimaryLoopLeadGroups = activeGroups.filter((g) => {
    if (!g) return false;
    const laneId = String(g?.musicLaneId || '').trim().toLowerCase();
    if (laneId !== 'primary_loop_lane') return false;
    const roleId = String(g?.role || options?.roles?.lead || 'lead').trim().toLowerCase();
    return roleId === String(options?.roles?.lead || 'lead').trim().toLowerCase();
  });
  const getCallResponseWindowSteps = typeof options?.getCallResponseWindowSteps === 'function' ? options.getCallResponseWindowSteps : (() => 1);
  const responseWindowSteps = Math.max(1, Math.trunc(Number(getCallResponseWindowSteps()) || 1));
  const isCallResponseLaneActive = typeof options?.isCallResponseLaneActive === 'function' ? options.isCallResponseLaneActive : (() => true);
  const callResponseRuntime = options?.callResponseRuntime && typeof options.callResponseRuntime === 'object' ? options.callResponseRuntime : {};
  const structureIntentRuntime = options?.structureIntentRuntime && typeof options.structureIntentRuntime === 'object'
    ? options.structureIntentRuntime
    : null;
  const directorLanePlan = options?.directorLanePlan && typeof options.directorLanePlan === 'object'
    ? options.directorLanePlan
    : null;
  const noteMusicSystemEvent = typeof options?.noteMusicSystemEvent === 'function' ? options.noteMusicSystemEvent : null;
  const noteIntroDebug = typeof options?.noteIntroDebug === 'function' ? options.noteIntroDebug : null;
  const directTriggerComposerCarrier = typeof options?.directTriggerComposerCarrier === 'function'
    ? options.directTriggerComposerCarrier
    : null;

  const getAliveEnemiesByIds = typeof options?.getAliveEnemiesByIds === 'function' ? options.getAliveEnemiesByIds : (() => []);
  const getFoundationLaneSnapshot = typeof options?.getFoundationLaneSnapshot === 'function'
    ? options.getFoundationLaneSnapshot
    : null;
  const clampNoteToDirectorPool = typeof options?.clampNoteToDirectorPool === 'function' ? options.clampNoteToDirectorPool : ((n) => String(n || ''));
  const clampNoteToDirectorRegisterTarget = typeof options?.clampNoteToDirectorRegisterTarget === 'function'
    ? options.clampNoteToDirectorRegisterTarget
    : ((n, i) => clampNoteToDirectorPool(n, i));
  const normalizeSwarmNoteName = typeof options?.normalizeSwarmNoteName === 'function' ? options.normalizeSwarmNoteName : ((n) => String(n || '').trim());
  const getRandomSwarmPentatonicNote = typeof options?.getRandomSwarmPentatonicNote === 'function' ? options.getRandomSwarmPentatonicNote : (() => 'C4');
  const getDirectorNotePool = typeof options?.getDirectorNotePool === 'function' ? options.getDirectorNotePool : (() => []);
  const getNotePoolIndex = typeof options?.getNotePoolIndex === 'function' ? options.getNotePoolIndex : (() => -1);
  const getPhraseLengthSteps = typeof options?.getPhraseLengthSteps === 'function' ? options.getPhraseLengthSteps : (() => 4);
  const normalizeSwarmRole = typeof options?.normalizeSwarmRole === 'function' ? options.normalizeSwarmRole : ((r, f) => String(r || f || '').trim().toLowerCase());
  const inferInstrumentLaneFromCatalogId = typeof options?.inferInstrumentLaneFromCatalogId === 'function'
    ? options.inferInstrumentLaneFromCatalogId
    : ((_, fallbackLane = 'lead') => String(fallbackLane || 'lead').trim().toLowerCase() || 'lead');
  const getIdForDisplayName = typeof options?.getIdForDisplayName === 'function'
    ? options.getIdForDisplayName
    : (() => '');
  const getSwarmRoleForEnemy = typeof options?.getSwarmRoleForEnemy === 'function' ? options.getSwarmRoleForEnemy : (() => String(options?.roles?.lead || 'lead'));
  const resolveSwarmRoleInstrumentId = typeof options?.resolveSwarmRoleInstrumentId === 'function' ? options.resolveSwarmRoleInstrumentId : ((_, fallback) => fallback);
  const resolveSwarmSoundInstrumentId = typeof options?.resolveSwarmSoundInstrumentId === 'function' ? options.resolveSwarmSoundInstrumentId : (() => 'tone');
  const createPerformedBeatEvent = typeof options?.createPerformedBeatEvent === 'function' ? options.createPerformedBeatEvent : ((evt) => evt);
  const chooseEnemyForNote = typeof options?.chooseEnemyForNote === 'function' ? options.chooseEnemyForNote : ((o) => chooseComposerGroupEnemyForNote(o));
  const roles = options?.roles && typeof options.roles === 'object' ? options.roles : {};
  const threat = options?.threat && typeof options.threat === 'object' ? options.threat : {};
  const clamp01 = (v) => Math.max(0, Math.min(1, Number(v) || 0));
  const styleProfile = options?.styleProfile && typeof options.styleProfile === 'object' ? options.styleProfile : {};
  const styleId = String(styleProfile?.id || '').trim().toLowerCase();
  const motifRepeatBias = Math.max(0, Math.min(1, Number(styleProfile?.motifRepeatBias) || 0));
  const leadLeapChance = Math.max(0, Math.min(1, Number(styleProfile?.leadLeapChance) || 1));
  const accentPitchVariance = Math.max(0, Math.min(1, Number(styleProfile?.accentPitchVariance) || 1));
  const laneDrivenFoundation = options?.laneDrivenFoundation === true;
  const laneDrivenPrimaryLoop = options?.laneDrivenPrimaryLoop === true;
  const answerLanePlan = directorLanePlan && typeof directorLanePlan === 'object'
    ? (directorLanePlan.answer || null)
    : null;
  const directorWantsAnswerGroup = answerLanePlan?.active === true
    && String(answerLanePlan?.preferredCarrier || '').trim().toLowerCase() === 'group';
  const answerLaneIntensity = Math.max(0, Number(answerLanePlan?.intensity) || 0);
  const primaryLoopLanePlan = directorLanePlan && typeof directorLanePlan === 'object'
    ? (directorLanePlan.primary_loop || null)
    : null;
  const strongLeadWindowActive = primaryLoopLanePlan?.active === true
    && Math.max(0, Number(primaryLoopLanePlan?.intensity) || 0) >= 0.66;
  const structureIntent = String(structureIntentRuntime?.intent || '').trim().toLowerCase();
  const preDropActive = structureIntentRuntime?.preDropActive === true;
  const minResponseDelaySteps = 2;
  const globalResponseCooldownSteps = directorWantsAnswerGroup
    ? (preDropActive ? 8 : (answerLaneIntensity >= 0.72 ? 5 : 6))
    : 0;
  const callAdmissionCooldownSteps = directorWantsAnswerGroup
    ? (preDropActive ? 12 : (answerLaneIntensity >= 0.72 ? 8 : 10))
    : 0;
  const responseWindowGraceSteps = 2;
  const responsePhraseSteps = 2;
  const responseLengthCap = preDropActive
    ? 1
    : (structureIntent === 'build' ? 3 : 4);
  const responseCadenceRestSteps = directorWantsAnswerGroup
    ? (preDropActive ? 2 : (strongLeadWindowActive ? 3 : 2))
    : 1;
  const callCadenceRestSteps = 1;
  const getPendingCallExpiry = (callStepAbs, targetLength) => {
    const lastCallStep = Math.max(-1, Math.trunc(Number(callStepAbs) || -1));
    if (lastCallStep < 0) return -1;
    const target = Math.max(1, Math.trunc(Number(targetLength) || 2));
    return lastCallStep + responseWindowSteps + responseWindowGraceSteps + Math.max(1, target);
  };
  const getGroupRegisterTarget = ({ lane = '', isBassRole = false, isPrimaryLoopOwnerGroup = false, isFoundationBufferGroup = false }) => {
    if (isBassRole || isFoundationBufferGroup) return 'low';
    if (isPrimaryLoopOwnerGroup) return 'mid';
    if (lane === 'response') return 'high';
    if (lane === 'call') return 'high';
    return 'mid';
  };

  for (const group of composerEnemyGroups) {
    if (!group || !group.active || group.retiring) continue;
    const lifecycleState = normalizeLifecycleState(group?.lifecycleState, 'active');
    if (lifecycleState === 'retiring') continue;
    const introPercussionCarrier = group?.introPercussionCarrier === true;
    const introStageCarrier = group?.introStageCarrier === true;
    const soloCarrierType = String(group?.soloCarrierType || '').trim().toLowerCase() === 'rhythm' ? 'rhythm' : '';
    const introSlotProfileSourceType = normalizeComposerProfileSourceType(group?.introSlotProfileSourceType);
    const introSlotIdentityLocked = group?.introSlotLock === true
      && Math.max(-1, Math.trunc(Number(group?.introSlotLockUntilBar) || -1)) >= barIndex;
    const introSlotIdentityActive = introSlotProfileSourceType === 'spawner_rhythm_pulse'
      || introSlotProfileSourceType === 'spawner_rhythm_backbeat'
      || introSlotProfileSourceType === 'spawner_rhythm_motion';
    const musicProfileSourceType = normalizeComposerProfileSourceType(introSlotIdentityActive
      ? (introSlotProfileSourceType || group?.musicProfileSourceType)
      : group?.musicProfileSourceType) || '';
    const soloRhythmCarrier = soloCarrierType === 'rhythm';
    const rhythmProfileCarrier = musicProfileSourceType === 'rhythm_lane'
      || musicProfileSourceType === 'rhythm_lane_backbeat'
      || musicProfileSourceType === 'spawner_rhythm_pulse'
      || musicProfileSourceType === 'spawner_rhythm_backbeat'
      || musicProfileSourceType === 'spawner_rhythm_motion';
    const rhythmPulseCarrier = musicProfileSourceType === 'spawner_rhythm_pulse';
    const rhythmBackbeatCarrier = musicProfileSourceType === 'spawner_rhythm_backbeat';
    const rhythmMotionCarrier = musicProfileSourceType === 'spawner_rhythm_motion';
    const slotRhythmCarrier = rhythmPulseCarrier || rhythmBackbeatCarrier || rhythmMotionCarrier;
    const melodyProfileCarrier = musicProfileSourceType === 'lead_melody';
    const answerOrnamentCarrier = musicProfileSourceType === 'answer_ornament';
    const rhythmPercussionCarrier = introPercussionCarrier || rhythmProfileCarrier;
    const isSoloCarrier = soloCarrierType === 'rhythm';
    const lockedIntroLane = introSlotIdentityActive
      ? normalizeCallResponseLane(group?.introSlotCallResponseLane || group?.callResponseLane, 'solo')
      : '';
    const lane = introSlotIdentityActive
      ? lockedIntroLane
      : (isSoloCarrier ? 'solo' : normalizeCallResponseLane(group?.callResponseLane, answerOrnamentCarrier ? 'response' : 'call'));
    const groupId = Math.max(0, Math.trunc(Number(group?.id) || 0));
    const noteIntroCollectorState = (phase, extra = null) => {
      if (!noteMusicSystemEvent || !slotRhythmCarrier || barIndex > 20) return;
      noteMusicSystemEvent('music_composer_group_state', {
        phase: String(phase || 'collector').trim().toLowerCase(),
        groupId,
        role: String(group?.role || '').trim().toLowerCase(),
        musicLaneId: String(group?.musicLaneId || group?.introSlotMusicLaneId || '').trim().toLowerCase(),
        instrumentId: String(group?.instrumentId || group?.introSlotInstrumentId || '').trim(),
        note: Array.isArray(group?.introSlotNotes) && group.introSlotNotes.length
          ? String(group.introSlotNotes[0] || '').trim()
          : (Array.isArray(group?.notes) && group.notes.length ? String(group.notes[0] || '').trim() : ''),
        reason: String(musicProfileSourceType || '').trim().toLowerCase(),
        stage: Array.isArray(group?.introSlotSteps) && group.introSlotSteps.length
          ? group.introSlotSteps.map((stepOn) => (stepOn ? '1' : '0')).join('')
          : (Array.isArray(group?.steps) ? group.steps.map((stepOn) => (stepOn ? '1' : '0')).join('') : ''),
        callResponseLane: String(lane || '').trim().toLowerCase(),
        lifecycleState,
        ...(extra && typeof extra === 'object' ? extra : {}),
      }, {
        beatIndex,
        stepIndex: stepAbs,
        barIndex,
      });
    };
    const noteEarlyCarrierTrace = (phase, extra = null) => {
      if (!noteMusicSystemEvent || barIndex > 20) return;
      if (!(slotRhythmCarrier || soloCarrierType === 'rhythm')) return;
      const aliveMembersNow = getAliveEnemiesByIds(group?.memberIds).filter((enemy) => String(enemy?.enemyType || '') === 'composer-group-member');
      const aliveMemberIds = aliveMembersNow
        .map((enemy) => Math.max(0, Math.trunc(Number(enemy?.id) || 0)))
        .filter((id) => id > 0);
      const visibleSoloEnemyIds = aliveMembersNow
        .filter((enemy) => {
          const memberSoloCarrierType = String(enemy?.soloCarrierType || '').trim().toLowerCase();
          const introCarrierBodyType = String(enemy?.introCarrierBodyType || '').trim().toLowerCase();
          return memberSoloCarrierType === 'rhythm' || introCarrierBodyType === 'solo';
        })
        .map((enemy) => Math.max(0, Math.trunc(Number(enemy?.id) || 0)))
        .filter((id) => id > 0);
      noteMusicSystemEvent('music_intro_carrier_trace', {
        phase: String(phase || '').trim().toLowerCase(),
        groupId,
        role: String(group?.role || '').trim().toLowerCase(),
        musicLaneId: String(group?.musicLaneId || group?.introSlotMusicLaneId || '').trim().toLowerCase(),
        slotProfile: String(musicProfileSourceType || '').trim().toLowerCase(),
        introSlotProfileSourceType,
        callResponseLane: String(lane || '').trim().toLowerCase(),
        soloCarrierType,
        introCarrierBodyType: String(group?.introCarrierBodyType || '').trim().toLowerCase(),
        introStageCarrier: group?.introStageCarrier === true,
        introSlotIdentityActive,
        introSlotIdentityLocked,
        aliveMemberIds,
        visibleSoloEnemyIds,
        ...(extra && typeof extra === 'object' ? extra : {}),
      }, {
        beatIndex,
        stepIndex: stepAbs,
        barIndex,
      });
    };
    const noteResponseDiagnostic = (reason, extra = null) => {
      if (lane !== 'response' || !noteMusicSystemEvent) return;
      noteMusicSystemEvent('music_call_response_response_group_state', {
        groupId,
        stepIndex: stepAbs,
        beatIndex,
        reason: String(reason || '').trim().toLowerCase(),
        callStepAbs: Math.max(-1, Math.trunc(Number(callResponseRuntime.lastCallStepAbs) || -1)),
        responseHoldUntilStepAbs: Math.max(-1, Math.trunc(Number(callResponseRuntime.responseHoldUntilStepAbs) || -1)),
        activeResponseGroupId: Math.max(0, Math.trunc(Number(callResponseRuntime.activeResponseGroupId) || 0)),
        lifecycleState,
        ...(extra && typeof extra === 'object' ? extra : {}),
      });
    };
    const noteCallDiagnostic = (reason, extra = null) => {
      if (lane !== 'call' || !noteMusicSystemEvent) return;
      noteMusicSystemEvent('music_call_response_call_group_state', {
        groupId,
        stepIndex: stepAbs,
        beatIndex,
        reason: String(reason || '').trim().toLowerCase(),
        callStepAbs: Math.max(-1, Math.trunc(Number(callResponseRuntime.lastCallStepAbs) || -1)),
        lastResponseStepAbs: Math.max(-1, Math.trunc(Number(callResponseRuntime.lastResponseStepAbs) || -1)),
        pendingCallExpiresStepAbs: Math.max(-1, Math.trunc(Number(callResponseRuntime.pendingCallExpiresStepAbs) || -1)),
        activeResponseGroupId: Math.max(0, Math.trunc(Number(callResponseRuntime.activeResponseGroupId) || 0)),
        lifecycleState,
        ...(extra && typeof extra === 'object' ? extra : {}),
      });
    };
    let continuingResponsePhrase = false;
    let responseOverrideHit = false;
    let hasLiveCallWindow = false;
    let sinceCall = -1;
    let laneActive = (isSoloCarrier || introPercussionCarrier || slotRhythmCarrier)
      ? true
      : isCallResponseLaneActive(lane, stepAbs, activeGroups.length);
    if (!isSoloCarrier && lane === 'response') {
      const lastCallStep = Math.max(-1, Math.trunc(Number(callResponseRuntime.lastCallStepAbs) || -1));
      sinceCall = lastCallStep >= 0 ? (stepAbs - lastCallStep) : -1;
      const pendingCallExpiresStepAbs = Math.max(
        Math.trunc(Number(callResponseRuntime.pendingCallExpiresStepAbs) || -1),
        getPendingCallExpiry(lastCallStep, callResponseRuntime.responsePhraseTargetLength)
      );
      continuingResponsePhrase = groupId > 0
        && groupId === Math.max(0, Math.trunc(Number(callResponseRuntime.activeResponseGroupId) || 0))
        && stepAbs <= Math.max(-1, Math.trunc(Number(callResponseRuntime.responseHoldUntilStepAbs) || -1));
      hasLiveCallWindow = lastCallStep >= 0 && sinceCall >= minResponseDelaySteps && stepAbs <= pendingCallExpiresStepAbs;
      if (!laneActive && (continuingResponsePhrase || hasLiveCallWindow)) laneActive = true;
      if (!laneActive && directorWantsAnswerGroup && hasLiveCallWindow) laneActive = true;
    }
    if (!laneActive) {
      noteIntroCollectorState('collector_suppressed', { admissionReason: 'lane_inactive' });
      noteEarlyCarrierTrace('suppressed', {
        branch: 'collector',
        admissionReason: 'lane_inactive',
      });
      if (slotRhythmCarrier) {
        const introSlotSuppressedPayload = {
          reason: 'lane_inactive',
          groupId,
          stepIndex: stepAbs,
          beatIndex,
          slotProfile: musicProfileSourceType,
          musicLaneId: String(group?.musicLaneId || '').trim().toLowerCase(),
          callResponseLane: lane,
        };
        if (noteIntroDebug) noteIntroDebug('intro_slot_rhythm_suppressed', introSlotSuppressedPayload);
        noteMusicSystemEvent?.('music_intro_slot_suppressed', introSlotSuppressedPayload, { beatIndex, stepIndex: stepAbs, barIndex });
      }
      noteCallDiagnostic('lane_inactive');
      noteResponseDiagnostic('lane_inactive', lane === 'response'
        ? {
          continuingResponsePhrase,
          hasLiveCallWindow,
        }
        : null);
      continue;
    }
    if (isSoloCarrier) {
      continuingResponsePhrase = false;
      responseOverrideHit = false;
      hasLiveCallWindow = false;
      sinceCall = -1;
    }
    if (!isSoloCarrier && !introPercussionCarrier && lane === 'call' && directorWantsAnswerGroup) {
      const responsePhraseActive = (
        Math.max(0, Math.trunc(Number(callResponseRuntime.activeResponseGroupId) || 0)) > 0
        && stepAbs <= Math.max(-1, Math.trunc(Number(callResponseRuntime.responseHoldUntilStepAbs) || -1))
      );
      if (responsePhraseActive) {
        noteCallDiagnostic('response_phrase_active');
        continue;
      }
    }
    if (lane === 'response') {
      if (!continuingResponsePhrase) {
        if (!hasLiveCallWindow) {
          noteResponseDiagnostic('no_call_window', {
            sinceCall,
            pendingCallExpiresStepAbs: Math.max(-1, Math.trunc(Number(callResponseRuntime.pendingCallExpiresStepAbs) || -1)),
          });
          continue;
        }
      }
      if (groupId > 0 && groupId === Math.max(0, Math.trunc(Number(callResponseRuntime.lastCallGroupId) || 0))) {
        noteResponseDiagnostic('same_group_as_call');
        continue;
      }
      const lastRespStep = Math.max(-1, Math.trunc(Number(callResponseRuntime.lastResponseStepAbs) || -1));
      const sameRespGroup = groupId > 0 && groupId === Math.max(0, Math.trunc(Number(callResponseRuntime.lastResponseGroupId) || 0));
      const responseWindowWithGrace = responseWindowSteps + responseWindowGraceSteps;
      if (
        !continuingResponsePhrase
        && globalResponseCooldownSteps > 0
        && lastRespStep >= 0
        && (stepAbs - lastRespStep) < globalResponseCooldownSteps
      ) {
        noteResponseDiagnostic('global_response_cooldown', {
          lastRespStep,
          sinceLastResponse: stepAbs - lastRespStep,
        });
        continue;
      }
      if (!continuingResponsePhrase && sameRespGroup && lastRespStep >= 0 && (stepAbs - lastRespStep) <= responseWindowWithGrace) {
        noteResponseDiagnostic('response_cooldown', { lastRespStep, sinceLastResponse: stepAbs - lastRespStep });
        continue;
      }
      const primaryLeadPresent = activePrimaryLoopLeadGroups.length > 0;
      const responseSupportOnlyGate = (
        primaryLeadPresent
        && strongLeadWindowActive
        && !continuingResponsePhrase
        && !responseOverrideHit
        && step !== 0
      );
      if (responseSupportOnlyGate) {
        noteResponseDiagnostic('support_only_gate', {
          stepInBar: step,
          primaryLeadPresent,
        });
        continue;
      }
      const responseProgressNow = Math.max(0, Math.trunc(Number(callResponseRuntime.responsePhraseProgress) || 0));
      const responseTargetNow = Math.max(1, Math.trunc(Number(callResponseRuntime.responsePhraseTargetLength) || 2));
      const sinceLastResponse = Math.max(
        -1,
        stepAbs - Math.max(-1, Math.trunc(Number(callResponseRuntime.lastResponseStepAbs) || -1))
      );
      responseOverrideHit = (
        !continuingResponsePhrase
        && (sinceCall === minResponseDelaySteps || sinceCall === (minResponseDelaySteps + 1))
      ) || (
        continuingResponsePhrase
        && responseProgressNow < responseTargetNow
        && sinceLastResponse >= responsePhraseSteps
        && sinceLastResponse <= (responsePhraseSteps + 1)
      );
    }

    const lockedIntroSteps = introSlotIdentityActive && Array.isArray(group?.introSlotSteps)
      ? group.introSlotSteps
      : null;
    if (slotRhythmCarrier && barIndex <= 20) {
      const introSlotStatePayload = {
        groupId,
        barIndex,
        beatIndex,
        stepIndex: stepAbs,
        lifecycleState,
        soloCarrierType,
        musicProfileSourceType,
        introSlotProfileSourceType,
        introSlotIdentityLocked,
        introSlotIdentityActive,
        callResponseLane: lane,
        musicLaneId: String(group?.musicLaneId || '').trim().toLowerCase(),
        introSlotMusicLaneId: String(group?.introSlotMusicLaneId || '').trim().toLowerCase(),
        liveSteps: Array.isArray(group?.steps) ? group.steps.map((v) => !!v) : [],
        introSteps: Array.isArray(group?.introSlotSteps) ? group.introSlotSteps.map((v) => !!v) : [],
        liveNotes: Array.isArray(group?.notes) ? group.notes.slice() : [],
        introNotes: Array.isArray(group?.introSlotNotes) ? group.introSlotNotes.slice() : [],
        memberCount: Array.isArray(group?.memberIds)
          ? group.memberIds.length
          : (group?.memberIds instanceof Set ? group.memberIds.size : 0),
      };
      if (noteIntroDebug) noteIntroDebug('intro_slot_state', introSlotStatePayload);
      noteMusicSystemEvent?.('music_intro_slot_state', introSlotStatePayload, { beatIndex, stepIndex: stepAbs, barIndex });
    }
    const stepActive = Array.isArray(lockedIntroSteps)
      ? !!lockedIntroSteps[step]
      : (Array.isArray(group.steps) && !!group.steps[step]);
    if (!stepActive && !responseOverrideHit) {
      noteIntroCollectorState('collector_suppressed', { admissionReason: 'step_inactive' });
      noteEarlyCarrierTrace('suppressed', {
        branch: 'collector',
        admissionReason: 'step_inactive',
      });
      if (slotRhythmCarrier) {
        const introSlotSuppressedPayload = {
          reason: 'step_inactive',
          groupId,
          stepIndex: stepAbs,
          beatIndex,
          slotProfile: musicProfileSourceType,
          musicLaneId: String(group?.musicLaneId || '').trim().toLowerCase(),
        };
        if (noteIntroDebug) noteIntroDebug('intro_slot_rhythm_suppressed', introSlotSuppressedPayload);
        noteMusicSystemEvent?.('music_intro_slot_suppressed', introSlotSuppressedPayload, { beatIndex, stepIndex: stepAbs, barIndex });
      }
      noteCallDiagnostic('step_inactive');
      noteResponseDiagnostic('step_inactive');
      continue;
    }
    const phraseRestUntilStepAbs = slotRhythmCarrier
      ? -1
      : Math.max(-1, Math.trunc(Number(group?.__bsPhraseRestUntilStep) || -1));
    if (phraseRestUntilStepAbs >= stepAbs) {
      noteIntroCollectorState('collector_suppressed', { admissionReason: 'post_cadence_rest' });
      noteEarlyCarrierTrace('suppressed', {
        branch: 'collector',
        admissionReason: 'post_cadence_rest',
        restUntilStepAbs: phraseRestUntilStepAbs,
      });
      if (slotRhythmCarrier) {
        const introSlotSuppressedPayload = {
          reason: 'post_cadence_rest',
          groupId,
          stepIndex: stepAbs,
          beatIndex,
          slotProfile: musicProfileSourceType,
          restUntilStepAbs: phraseRestUntilStepAbs,
        };
        if (noteIntroDebug) noteIntroDebug('intro_slot_rhythm_suppressed', introSlotSuppressedPayload);
        noteMusicSystemEvent?.('music_intro_slot_suppressed', introSlotSuppressedPayload, { beatIndex, stepIndex: stepAbs, barIndex });
      }
      if (introPercussionCarrier && noteIntroDebug) {
        noteIntroDebug('intro_percussion_suppressed', {
          reason: 'post_cadence_rest',
          groupId,
          stepIndex: stepAbs,
        });
      }
      noteCallDiagnostic('post_cadence_rest', { restUntilStepAbs: phraseRestUntilStepAbs });
      noteResponseDiagnostic('post_cadence_rest', { restUntilStepAbs: phraseRestUntilStepAbs });
      continue;
    }
    const aliveMembers = getAliveEnemiesByIds(group.memberIds).filter((e) => {
      if (String(e?.enemyType || '') !== 'composer-group-member') return false;
      if (e?.retreating !== true) return true;
      if (!isSoloCarrier) return false;
      const tailUntilStep = Math.max(0, Math.trunc(Number(e?.musicLoopTailUntilStep) || 0));
      return tailUntilStep >= stepAbs;
    });
    if (!aliveMembers.length) {
      const canGhostCarry = slotRhythmCarrier && introSlotIdentityActive;
      if (canGhostCarry) {
        const lockedRole = normalizeSwarmRole(
          group?.introSlotRole || group?.role || (rhythmPulseCarrier ? roles.bass : roles.accent),
          rhythmPulseCarrier ? roles.bass : roles.accent
        );
        const lockedLaneId = String(group?.introSlotMusicLaneId || group?.musicLaneId || '').trim().toLowerCase();
        const lockedInstrumentIdRaw = String(
          group?.introSlotInstrumentId
            || group?.instrumentId
            || group?.instrument
            || ''
        ).trim();
        const lockedInstrumentLane = inferInstrumentLaneFromCatalogId(lockedInstrumentIdRaw, '');
        const lockedResolvedRole = lockedInstrumentLane === 'bass'
          ? 'bass'
          : normalizeSwarmRole(lockedRole || roles.lead, roles.lead);
        const lockedInstrumentId = lockedInstrumentIdRaw || resolveSwarmRoleInstrumentId(
          lockedResolvedRole,
          resolveSwarmSoundInstrumentId('projectile') || 'tone'
        );
        const lockedNoteName = normalizeSwarmNoteName(
          Array.isArray(group?.introSlotNotes) && group.introSlotNotes.length
            ? group.introSlotNotes[0]
            : (Array.isArray(group?.notes) && group.notes.length ? group.notes[0] : '')
        ) || getRandomSwarmPentatonicNote();
        const lockedThreatClass = (() => {
          const t = String(group?.threatLevel || threat.full || 'full').trim().toLowerCase();
          if (t === String(threat.cosmetic || 'cosmetic')) return String(threat.cosmetic || 'cosmetic');
          if (t === String(threat.light || 'light')) return String(threat.light || 'light');
          return String(threat.full || 'full');
        })();
        const lockedMusicVoiceKey = rhythmPulseCarrier
          ? 'percussion_pulse'
          : (rhythmBackbeatCarrier ? 'percussion_backbeat' : (rhythmMotionCarrier ? 'percussion_motion' : ''));
        const lockedMusicLayer = rhythmPulseCarrier
          ? 'foundation'
          : (rhythmMotionCarrier ? 'sparkle' : 'loops');
        noteIntroCollectorState('collector_emit_strict', {
          actorId: 0,
          requestedNote: lockedNoteName,
          admissionReason: 'ghost_playback',
        });
        noteEarlyCarrierTrace('emit', {
          branch: 'ghost',
          performerEnemyIds: [],
          requestedNote: lockedNoteName,
          instrumentId: lockedInstrumentId,
          actionType: String(group?.introSlotActionType || group?.actionType || 'explosion') === 'explosion'
            ? 'composer-group-explosion'
            : 'composer-group-projectile',
        });
        events.push(createPerformedBeatEvent({
          actorId: 0,
          beatIndex,
          stepIndex: stepAbs,
          role: lockedInstrumentLane === 'bass' ? 'bass' : lockedResolvedRole,
          note: lockedNoteName,
          instrumentId: lockedInstrumentId,
          actionType: String(group?.introSlotActionType || group?.actionType || 'explosion') === 'explosion'
            ? 'composer-group-explosion'
            : 'composer-group-projectile',
          threatClass: lockedThreatClass,
          visualSyncType: 'group-pulse',
          payload: {
            groupId,
            ghostPlayback: true,
            groupEventSource: 'intro_slot_strict',
            continuityId: String(group?.continuityId || '').trim(),
            musicVoiceKey: lockedMusicVoiceKey,
            musicRole: lockedInstrumentLane === 'bass' ? 'bass' : lockedResolvedRole,
            musicLayer: lockedMusicLayer,
            musicProminence: 'full',
            introDrumProtected: rhythmBackbeatCarrier || rhythmMotionCarrier,
            soloCarrierType,
            musicLaneId: lockedLaneId,
            callResponseLane: lockedIntroLane || lane || 'solo',
            callResponseQualified: true,
            callResponsePhraseProgress: 0,
            musicRegister: rhythmPulseCarrier ? 'low' : 'mid',
            audioGain: 1,
            requestedNoteRaw: lockedNoteName,
            phraseGravityTarget: '',
            phraseGravityHit: false,
            phraseResolutionOpportunity: false,
            phraseResolutionHit: false,
          },
        }));
        const introSlotGhostPayload = {
          groupId,
          stepIndex: stepAbs,
          beatIndex,
          slotProfile: musicProfileSourceType,
          note: lockedNoteName,
          instrumentId: lockedInstrumentId,
          musicLaneId: lockedLaneId,
          callResponseLane: lockedIntroLane || lane || 'solo',
          reason: 'ghost_playback',
        };
        if (noteIntroDebug) noteIntroDebug('intro_slot_strict_emit', introSlotGhostPayload);
        noteMusicSystemEvent?.('music_intro_slot_strict_emit', introSlotGhostPayload, { beatIndex, stepIndex: stepAbs, barIndex });
        continue;
      }
      noteIntroCollectorState('collector_suppressed', { admissionReason: 'no_alive_members' });
      noteEarlyCarrierTrace('suppressed', {
        branch: 'collector',
        admissionReason: 'no_alive_members',
      });
      if (slotRhythmCarrier) {
        const introSlotSuppressedPayload = {
          reason: 'no_alive_members',
          groupId,
          stepIndex: stepAbs,
          beatIndex,
          slotProfile: musicProfileSourceType,
        };
        if (noteIntroDebug) noteIntroDebug('intro_slot_rhythm_suppressed', introSlotSuppressedPayload);
        noteMusicSystemEvent?.('music_intro_slot_suppressed', introSlotSuppressedPayload, { beatIndex, stepIndex: stepAbs, barIndex });
      }
      if (introPercussionCarrier && noteIntroDebug) {
        noteIntroDebug('intro_percussion_suppressed', {
          reason: 'no_alive_members',
          groupId,
          stepIndex: stepAbs,
        });
      }
      noteCallDiagnostic('no_alive_members');
      noteResponseDiagnostic('no_alive_members');
      continue;
    }

    if (introSlotIdentityActive && slotRhythmCarrier) {
      const lockedRole = normalizeSwarmRole(
        group?.introSlotRole || group?.role || (rhythmPulseCarrier ? roles.bass : roles.accent),
        rhythmPulseCarrier ? roles.bass : roles.accent
      );
      const lockedLaneId = String(group?.introSlotMusicLaneId || group?.musicLaneId || '').trim().toLowerCase();
      const lockedInstrumentIdRaw = String(
        group?.introSlotInstrumentId
          || group?.instrumentId
          || group?.instrument
          || aliveMembers[0]?.composerInstrument
          || aliveMembers[0]?.musicLaneInstrumentId
          || ''
      ).trim();
      const lockedInstrumentLane = inferInstrumentLaneFromCatalogId(lockedInstrumentIdRaw, '');
      const lockedResolvedRole = lockedInstrumentLane === 'bass'
        ? 'bass'
        : normalizeSwarmRole(lockedRole || getSwarmRoleForEnemy(aliveMembers[0], roles.lead), roles.lead);
      const lockedInstrumentId = lockedInstrumentIdRaw || resolveSwarmRoleInstrumentId(
        lockedResolvedRole,
        resolveSwarmSoundInstrumentId('projectile') || 'tone'
      );
      const lockedNoteName = normalizeSwarmNoteName(
        Array.isArray(group?.introSlotNotes) && group.introSlotNotes.length
          ? group.introSlotNotes[0]
          : (Array.isArray(group?.notes) && group.notes.length ? group.notes[0] : '')
      ) || getRandomSwarmPentatonicNote();
      const lockedPerformer = chooseEnemyForNote({
        group,
        noteName: lockedNoteName,
        aliveMembers,
        normalizeNoteName: normalizeSwarmNoteName,
        getFallbackNote: getRandomSwarmPentatonicNote,
      }) || aliveMembers[0] || null;
      if (!lockedPerformer) continue;
      noteIntroCollectorState('collector_emit_strict', {
        actorId: Math.max(0, Math.trunc(Number(lockedPerformer?.id) || 0)),
        requestedNote: lockedNoteName,
      });
      noteEarlyCarrierTrace('emit', {
        branch: 'strict',
        performerEnemyIds: [Math.max(0, Math.trunc(Number(lockedPerformer?.id) || 0))].filter((id) => id > 0),
        requestedNote: lockedNoteName,
        instrumentId: lockedInstrumentId,
        actionType: String(group?.introSlotActionType || group?.actionType || 'explosion') === 'explosion'
          ? 'composer-group-explosion'
          : 'composer-group-projectile',
      });
      const lockedThreatClass = (() => {
        const t = String(group?.threatLevel || threat.full || 'full').trim().toLowerCase();
        if (t === String(threat.cosmetic || 'cosmetic')) return String(threat.cosmetic || 'cosmetic');
        if (t === String(threat.light || 'light')) return String(threat.light || 'light');
        return String(threat.full || 'full');
      })();
      const lockedMusicVoiceKey = rhythmPulseCarrier
        ? 'percussion_pulse'
        : (rhythmBackbeatCarrier ? 'percussion_backbeat' : (rhythmMotionCarrier ? 'percussion_motion' : ''));
      const lockedMusicLayer = rhythmPulseCarrier
        ? 'foundation'
        : (rhythmMotionCarrier ? 'sparkle' : 'loops');
      const lockedProminence = 'full';
      group.__bsPhraseRestUntilStep = -1;
      events.push(createPerformedBeatEvent({
        actorId: Math.max(0, Math.trunc(Number(lockedPerformer?.id) || 0)),
        beatIndex,
        stepIndex: stepAbs,
        role: lockedInstrumentLane === 'bass' ? 'bass' : lockedResolvedRole,
        note: lockedNoteName,
        instrumentId: lockedInstrumentId,
        actionType: String(group?.introSlotActionType || group?.actionType || 'explosion') === 'explosion'
          ? 'composer-group-explosion'
          : 'composer-group-projectile',
        threatClass: lockedThreatClass,
        visualSyncType: 'group-pulse',
        payload: {
          groupId,
          groupEventSource: 'intro_slot_strict',
          continuityId: String(group?.continuityId || '').trim(),
          musicVoiceKey: lockedMusicVoiceKey,
          musicRole: lockedInstrumentLane === 'bass' ? 'bass' : lockedResolvedRole,
          musicLayer: lockedMusicLayer,
          musicProminence: lockedProminence,
          introDrumProtected: rhythmBackbeatCarrier || rhythmMotionCarrier,
          soloCarrierType,
          musicLaneId: lockedLaneId,
          callResponseLane: lockedIntroLane || lane || 'solo',
          callResponseQualified: true,
          callResponsePhraseProgress: 0,
          musicRegister: rhythmPulseCarrier ? 'low' : 'mid',
          audioGain: 1,
          requestedNoteRaw: lockedNoteName,
          phraseGravityTarget: '',
          phraseGravityHit: false,
          phraseResolutionOpportunity: false,
          phraseResolutionHit: false,
        },
      }));
      if (slotRhythmCarrier) {
        if (!(Math.trunc(Number(group?.introSlotFirstAudibleBeatIndex) || -1) >= 0)) {
          group.introSlotFirstAudibleBeatIndex = beatIndex;
        }
        const introSlotEmitPayload = {
          groupId,
          stepIndex: stepAbs,
          beatIndex,
          performerCount: 1,
          instrumentId: lockedInstrumentId,
          note: lockedNoteName,
          slotProfile: musicProfileSourceType,
          musicLaneId: lockedLaneId,
        };
        if (noteIntroDebug) noteIntroDebug('intro_slot_rhythm_emitted', introSlotEmitPayload);
        const introSlotStrictPayload = {
          groupId,
          stepIndex: stepAbs,
          beatIndex,
          slotProfile: musicProfileSourceType,
          note: lockedNoteName,
          instrumentId: lockedInstrumentId,
          musicLaneId: lockedLaneId,
          callResponseLane: lockedIntroLane || lane || 'solo',
        };
        if (noteIntroDebug) noteIntroDebug('intro_slot_strict_emit', introSlotStrictPayload);
        noteMusicSystemEvent?.('music_intro_slot_strict_emit', introSlotStrictPayload, { beatIndex, stepIndex: stepAbs, barIndex });
      }
      continue;
    }

    const groupRole = normalizeSwarmRole(
      introSlotIdentityActive ? (group?.introSlotRole || group?.role || roles.lead) : (group?.role || roles.lead),
      roles.lead
    );
    const isBassRole = groupRole === String(roles?.bass || 'bass');
    const groupLaneId = String(
      introSlotIdentityActive
        ? (group?.introSlotMusicLaneId || group?.musicLaneId || '')
        : (group?.musicLaneId || '')
    ).trim().toLowerCase();
    const isPrimaryLoopOwnerGroup = groupLaneId === 'primary_loop_lane';
    const isFoundationBufferGroup = String(group?.sectionId || '').trim().toLowerCase() === 'foundation-buffer';
    if (laneDrivenFoundation && isBassRole && !rhythmProfileCarrier) {
      noteCallDiagnostic('lane_driven_foundation');
      noteResponseDiagnostic('lane_driven_foundation');
      continue;
    }
    if (
      laneDrivenPrimaryLoop
      && lane !== 'response'
      && lane !== 'call'
      && groupRole === String(roles?.lead || 'lead')
      && groupLaneId === 'primary_loop_lane'
    ) {
      noteCallDiagnostic('lane_driven_primary_loop');
      noteResponseDiagnostic('lane_driven_primary_loop');
      continue;
    }
    const performerCount = (isBassRole || isFoundationBufferGroup || !isPrimaryLoopOwnerGroup || rhythmPercussionCarrier)
      ? 1
      : Math.max(performersMin, Math.min(performersMax, Math.trunc(Number(group.performers) || 1)));
    if ((isBassRole || rhythmPulseCarrier) && getFoundationLaneSnapshot && !(introSlotIdentityActive && rhythmPulseCarrier)) {
      const lane = getFoundationLaneSnapshot(stepAbs, barIndex);
      if (!lane?.isActiveStep) {
        noteIntroCollectorState('collector_suppressed', { admissionReason: 'foundation_step_inactive' });
        if (slotRhythmCarrier) {
          const introSlotSuppressedPayload = {
            reason: 'foundation_step_inactive',
            groupId,
            stepIndex: stepAbs,
            beatIndex,
            slotProfile: musicProfileSourceType,
            musicLaneId: String(group?.musicLaneId || '').trim().toLowerCase(),
          };
          if (noteIntroDebug) noteIntroDebug('intro_slot_rhythm_suppressed', introSlotSuppressedPayload);
          noteMusicSystemEvent?.('music_intro_slot_suppressed', introSlotSuppressedPayload, { beatIndex, stepIndex: stepAbs, barIndex });
        }
        noteCallDiagnostic('foundation_step_inactive');
        noteResponseDiagnostic('foundation_step_inactive');
        continue;
      }
    }
    const melodyRows = introSlotIdentityActive && Array.isArray(group?.introSlotRows)
      ? group.introSlotRows
      : (Array.isArray(group?.rows) ? group.rows : []);
    const melodyStepDriven = melodyProfileCarrier
      && groupLaneId === 'primary_loop_lane';
    const primaryLoopRescueStep = (
      !stepActive
      && !responseOverrideHit
      && isPrimaryLoopOwnerGroup
      && melodyStepDriven
      && lane === 'call'
      && barIndex >= 12
      && (step === 0 || step === Math.max(1, Math.trunc(stepsPerBar / 2)))
    );
    if (primaryLoopRescueStep) {
      noteCallDiagnostic('primary_loop_rescue_step', {
        stepInBar: step,
        stepsPerBar,
      });
    } else if (!stepActive && !responseOverrideHit) {
      noteIntroCollectorState('collector_suppressed', { admissionReason: 'step_inactive' });
      noteEarlyCarrierTrace('suppressed', {
        branch: 'collector',
        admissionReason: 'step_inactive',
      });
      if (slotRhythmCarrier) {
        const introSlotSuppressedPayload = {
          reason: 'step_inactive',
          groupId,
          stepIndex: stepAbs,
          beatIndex,
          slotProfile: musicProfileSourceType,
          musicLaneId: String(group?.musicLaneId || '').trim().toLowerCase(),
        };
        if (noteIntroDebug) noteIntroDebug('intro_slot_rhythm_suppressed', introSlotSuppressedPayload);
        noteMusicSystemEvent?.('music_intro_slot_suppressed', introSlotSuppressedPayload, { beatIndex, stepIndex: stepAbs, barIndex });
      }
      noteCallDiagnostic('step_inactive');
      noteResponseDiagnostic('step_inactive');
      continue;
    }
    const melodyProfileNote = melodyProfileCarrier && melodyRows.length
      ? (options?.getSwarmPentatonicNoteByIndex?.(Math.max(0, Math.trunc(Number(melodyRows[step] ?? melodyRows[0]) || 0)))
        || getRandomSwarmPentatonicNote())
      : '';
    const effectiveNotes = introSlotIdentityActive && Array.isArray(group?.introSlotNotes) && group.introSlotNotes.length
      ? group.introSlotNotes
      : (Array.isArray(group?.notes) ? group.notes : []);
    const notesLen = Math.max(1, effectiveNotes.length);
    const noteIdx = (isBassRole || rhythmPercussionCarrier || soloCarrierType === 'rhythm')
      ? 0
      : (melodyStepDriven
        ? (step % notesLen)
        : (Math.max(0, Math.trunc(Number(group.noteCursor) || 0)) % notesLen));
    const lockedIntroNote = introSlotIdentityActive && Array.isArray(group?.introSlotNotes) && group.introSlotNotes.length
      ? normalizeSwarmNoteName(group.introSlotNotes[0])
      : '';
    const stepDrivenNoteName = melodyStepDriven
      ? normalizeSwarmNoteName(effectiveNotes?.[step] || melodyProfileNote || effectiveNotes?.[noteIdx])
      : '';
    const noteNameBaseRaw = lockedIntroNote
      || normalizeSwarmNoteName(stepDrivenNoteName || melodyProfileNote || effectiveNotes?.[noteIdx])
      || getRandomSwarmPentatonicNote();
    const noteNameBase = (isBassRole || rhythmPercussionCarrier || soloCarrierType === 'rhythm')
      ? noteNameBaseRaw
      : clampNoteToDirectorPool(
        noteNameBaseRaw,
        stepAbs + noteIdx
      );
    const responsePool = getDirectorNotePool();
    const responseSeedNote = normalizeSwarmNoteName(
      chooseResponseNoteFromPool({
        callNote: callResponseRuntime.lastCallNote,
        fallbackNote: noteNameBaseRaw,
        stepAbs,
        notePool: responsePool,
        normalizeNoteName: normalizeSwarmNoteName,
      })
    ) || noteNameBaseRaw;
    let noteNameRaw = noteNameBaseRaw;
    if (lane === 'response') {
      const callNote = normalizeSwarmNoteName(callResponseRuntime.lastCallNote);
      const callIdx = callNote ? getNotePoolIndex(callNote) : -1;
      const seedIdx = getNotePoolIndex(responseSeedNote);
      const defaultDir = seedIdx >= 0 && callIdx >= 0 && seedIdx < callIdx ? -1 : 1;
      const responseDir = continuingResponsePhrase
        ? (Math.trunc(Number(callResponseRuntime.responseDirection) || defaultDir) || defaultDir)
        : defaultDir;
      const responseProgress = continuingResponsePhrase
        ? Math.max(0, Math.trunc(Number(callResponseRuntime.responsePhraseProgress) || 0))
        : 0;
      const responseTargetLength = continuingResponsePhrase
        ? Math.max(1, Math.trunc(Number(callResponseRuntime.responsePhraseTargetLength) || 2))
        : Math.max(1, Math.trunc(Number(callResponseRuntime.responsePhraseTargetLength) || 2));
      const responseOffsets = (() => {
        if (responseTargetLength <= 1) return [responseDir];
        if (responseTargetLength === 2) return [responseDir, 0];
        if (responseTargetLength === 3) return [responseDir, responseDir * 2, responseDir];
        return [responseDir, responseDir * 2, responseDir, 0];
      })();
      const responseIdx = callIdx >= 0
        ? (((callIdx + responseOffsets[Math.min(responseProgress, responseOffsets.length - 1)]) % responsePool.length) + responsePool.length) % responsePool.length
        : -1;
      noteNameRaw = responseIdx >= 0
        ? (normalizeSwarmNoteName(responsePool[responseIdx]) || responseSeedNote)
        : responseSeedNote;
    }
    const responsePhraseProgressForEvent = lane === 'response'
      ? (continuingResponsePhrase
        ? (Math.max(0, Math.trunc(Number(callResponseRuntime.responsePhraseProgress) || 0)) + 1)
        : 1)
      : 0;
    const registerTarget = getGroupRegisterTarget({
      lane,
      isBassRole,
      isPrimaryLoopOwnerGroup,
      isFoundationBufferGroup,
    });
    const noteName = (isBassRole || rhythmPercussionCarrier || soloCarrierType === 'rhythm')
      ? noteNameRaw
      : clampNoteToDirectorRegisterTarget(
        noteNameRaw,
        stepAbs + noteIdx + (lane === 'response' ? 1 : 0),
        registerTarget
      );
    const phraseStep = getPhraseStepState(
      stepAbs,
      melodyStepDriven ? Math.max(8, Math.trunc(Number(getPhraseLengthSteps(lane, group, stepAbs)) || 8)) : getPhraseLengthSteps(lane, group, stepAbs)
    );
    const phraseTargets = normalizePhraseNoteList([
      ...(Array.isArray(group?.resolutionTargets) ? group.resolutionTargets : []),
      group?.phraseRoot,
      group?.phraseFifth,
      ...(Array.isArray(group?.gravityNotes) ? group.gravityNotes : []),
    ], normalizeSwarmNoteName);
    const phraseGravityTargetBase = phraseStep.nearPhraseEnd
      ? pickClosestPhraseTarget(noteName, phraseTargets, {
        normalizeNoteName: normalizeSwarmNoteName,
        getNotePoolIndex,
      })
      : '';
    const phraseGravityTarget = phraseStep.resolutionOpportunity
      ? (normalizeSwarmNoteName(group?.phraseRoot) || phraseGravityTargetBase)
      : phraseGravityTargetBase;
    const gravityBiasChance = melodyStepDriven
      ? (phraseStep.resolutionOpportunity ? 0.3 : 0.12)
      : (phraseStep.resolutionOpportunity ? 0.92 : 0.54);
    const phraseGravityOpportunity = !!phraseGravityTarget && phraseStep.nearPhraseEnd;
    const gravityNoteNameRaw = (phraseGravityOpportunity && Math.random() < gravityBiasChance)
      ? phraseGravityTarget
      : noteNameRaw;
    const gravityNoteName = (isBassRole || rhythmPercussionCarrier || soloCarrierType === 'rhythm')
      ? gravityNoteNameRaw
      : clampNoteToDirectorRegisterTarget(
        gravityNoteNameRaw,
        stepAbs + noteIdx + (lane === 'response' ? 1 : 0),
        registerTarget
      );
    let styledNoteName = gravityNoteName;
    if (styleId === 'retro_shooter') {
      const prevNote = normalizeSwarmNoteName(group?.__bsLastComposerNote);
      const currentNote = normalizeSwarmNoteName(gravityNoteName);
      const roleForStyle = groupRole;
      const prevIdx = prevNote ? getNotePoolIndex(prevNote) : -1;
      const currIdx = currentNote ? getNotePoolIndex(currentNote) : -1;
      if (roleForStyle === String(roles?.bass || 'bass')) {
        styledNoteName = gravityNoteName;
      } else if (!phraseStep.resolutionOpportunity && prevNote && Math.random() < (melodyStepDriven ? (motifRepeatBias * 0.08) : (motifRepeatBias * 0.5))) {
        styledNoteName = prevNote;
      } else if (!melodyStepDriven && prevIdx >= 0 && currIdx >= 0 && Math.abs(currIdx - prevIdx) > 1 && Math.random() > leadLeapChance) {
        styledNoteName = prevNote;
      } else if (roleForStyle === String(roles?.accent || 'accent') && prevNote && Math.random() > accentPitchVariance) {
        styledNoteName = prevNote;
      }
    }
    if (phraseStep.resolutionOpportunity && phraseGravityOpportunity && !isBassRole && !rhythmPercussionCarrier && Math.random() < (melodyStepDriven ? 0.18 : 0.84)) {
      styledNoteName = clampNoteToDirectorRegisterTarget(
        phraseGravityTarget,
        stepAbs + noteIdx + (lane === 'response' ? 1 : 0),
        registerTarget
      );
    }
    const phraseGravityHit = phraseGravityOpportunity
      ? normalizeSwarmNoteName(styledNoteName) === normalizeSwarmNoteName(phraseGravityTarget)
      : false;
    const phraseResolutionOpportunity = phraseGravityOpportunity && phraseStep.resolutionOpportunity;
    const phraseResolutionHit = phraseResolutionOpportunity && phraseGravityHit;
    const localCadenceRestSteps = lane === 'response'
      ? responseCadenceRestSteps
      : callCadenceRestSteps;
    const postCadenceRestUntilStep = melodyStepDriven
      ? -1
      : (phraseStep.resolutionOpportunity
      ? (stepAbs + localCadenceRestSteps)
      : -1);
    if (!melodyStepDriven) {
      group.noteCursor = noteIdx + 1;
    }

    const performers = [];
    const usedEnemyIds = new Set();
    const primary = rhythmPercussionCarrier
      ? (aliveMembers[0] || null)
      : chooseEnemyForNote({
        group,
        noteName: styledNoteName,
        aliveMembers,
        normalizeNoteName: normalizeSwarmNoteName,
        getFallbackNote: getRandomSwarmPentatonicNote,
      });
    if (primary) {
      performers.push(primary);
      const primaryId = Math.trunc(Number(primary.id) || 0);
      if (primaryId > 0) usedEnemyIds.add(primaryId);
    }
    while (performers.length < performerCount) {
      const remaining = aliveMembers.filter((e) => !usedEnemyIds.has(Math.trunc(Number(e.id) || 0)));
      if (!remaining.length) break;
      const enemy = remaining[Math.max(0, Math.min(remaining.length - 1, Math.trunc(Math.random() * remaining.length)))] || null;
      if (!enemy) continue;
      const enemyId = Math.trunc(Number(enemy.id) || 0);
      if (!(enemyId > 0) || usedEnemyIds.has(enemyId)) continue;
      usedEnemyIds.add(enemyId);
      performers.push(enemy);
    }
    if (!performers.length) continue;
    noteIntroCollectorState('collector_emit_generic', {
      actorId: Math.max(0, Math.trunc(Number(performers[0]?.id) || 0)),
      requestedNote: styledNoteName,
    });
    noteResponseDiagnostic('emitted', {
      continuingResponsePhrase,
      responseOverrideHit,
      performerCount: performers.length,
    });

    const threatClass = (() => {
      const t = String(group?.threatLevel || threat.full || 'full').trim().toLowerCase();
      if (t === String(threat.cosmetic || 'cosmetic')) return String(threat.cosmetic || 'cosmetic');
      if (t === String(threat.light || 'light')) return String(threat.light || 'light');
      return String(threat.full || 'full');
    })();
    const lockedInstrumentId = String(
      (introPercussionCarrier
        ? (
          getIdForDisplayName('Bass Tone 3')
          || getIdForDisplayName('Bass Tone 4')
          || group?.instrumentId
          || ''
        )
        : group?.instrumentId)
        || performers[0]?.instrumentId
        || performers[0]?.musicInstrumentId
        || performers[0]?.composerInstrument
        || ''
    ).trim();
    const lockedLane = inferInstrumentLaneFromCatalogId(lockedInstrumentId, '');
    const resolvedRole = lockedLane === 'bass'
      ? 'bass'
      : normalizeSwarmRole(group?.role || getSwarmRoleForEnemy(performers[0], roles.lead), roles.lead);
    const instrumentId = lockedInstrumentId || resolveSwarmRoleInstrumentId(
      resolvedRole,
      resolveSwarmSoundInstrumentId('projectile') || 'tone'
    );
    const lifecycleAudioGain = lifecycleState === 'inactiveForScheduling'
      ? 0.35
      : (lifecycleState === 'deEmphasized' ? 0.52 : 1);
    const musicProminence = (() => {
      if (rhythmPercussionCarrier) return 'full';
      if (isSoloCarrier && soloCarrierType === 'rhythm') return 'full';
      if (melodyProfileCarrier || rhythmProfileCarrier) return 'full';
      if (isPrimaryLoopOwnerGroup) return 'full';
      if (isFoundationBufferGroup) return 'trace';
      if (isBassRole) return 'quiet';
      if (lane === 'response') return 'trace';
      return 'trace';
    })();
    const musicLayer = (() => {
      if (rhythmPulseCarrier || groupLaneId === 'foundation_lane') return 'foundation';
      if (rhythmMotionCarrier || groupLaneId === 'sparkle_lane') return 'sparkle';
      if (isBassRole) return 'foundation';
      return 'loops';
    })();
    const restrainedGroupGain = (() => {
      if (rhythmPercussionCarrier) return 1;
      if (isSoloCarrier) return 0.92;
      if (melodyProfileCarrier || rhythmProfileCarrier) return 0.92;
      if (isPrimaryLoopOwnerGroup) return 1;
      if (isFoundationBufferGroup) return 0.4;
      if (isBassRole) return 0.56;
      if (strongLeadWindowActive && directorWantsAnswerGroup) {
        if (lane === 'response') return 0.14;
        if (lane === 'call') return 0.18;
      }
      if (lane === 'response') return isPrimaryLoopOwnerGroup ? 0.24 : 0.22;
      return 0.46;
    })();
    const melodicCallGroup = (
      lane === 'call'
      && !isBassRole
      && !isFoundationBufferGroup
    );
    const suppressNonMelodicCallLane = (
      !rhythmPercussionCarrier
      && !isSoloCarrier
      && lane === 'call'
      && !melodicCallGroup
    );
    if (suppressNonMelodicCallLane) {
      noteCallDiagnostic('non_melodic_call_suppressed', {
        isBassRole,
        isFoundationBufferGroup,
      });
      continue;
    }
    const strongCallCandidate = melodicCallGroup
      ? (isPrimaryLoopOwnerGroup
        || phraseStep.stepInPhrase <= 2
        || phraseResolutionOpportunity
        || phraseGravityOpportunity
        || phraseResolutionHit
        || phraseGravityHit
        || phraseStep.stepInPhrase === Math.max(0, responsePhraseSteps - 1))
      : false;
    const answerWindowSelectiveCallGate = (
      !isSoloCarrier
      && lane === 'call'
      && directorWantsAnswerGroup
      && strongLeadWindowActive
      && melodicCallGroup
      && !isPrimaryLoopOwnerGroup
      && !phraseResolutionOpportunity
      && !phraseResolutionHit
      && !phraseGravityHit
      && phraseStep.stepInPhrase > 1
    );
    if (answerWindowSelectiveCallGate) {
      noteCallDiagnostic('answer_window_selective_call_gate', {
        stepInPhrase: Math.max(0, Math.trunc(Number(phraseStep?.stepInPhrase) || 0)),
        phraseGravityOpportunity,
        phraseResolutionOpportunity,
        phraseResolutionHit,
        phraseGravityHit,
      });
      continue;
    }
    const callAdmission = (() => {
      if (!strongCallCandidate) return { accepted: false, reason: 'not_strong_call' };
      const lastCallStep = Math.max(-1, Math.trunc(Number(callResponseRuntime.lastCallStepAbs) || -1));
      const pendingCallExpiresStepAbs = Math.max(
        Math.trunc(Number(callResponseRuntime.pendingCallExpiresStepAbs) || -1),
        getPendingCallExpiry(lastCallStep, callResponseRuntime.responsePhraseTargetLength)
      );
      const pendingResponse = (
        Math.max(0, Math.trunc(Number(callResponseRuntime.activeResponseGroupId) || 0)) > 0
        && stepAbs <= Math.max(-1, Math.trunc(Number(callResponseRuntime.responseHoldUntilStepAbs) || -1))
      );
      if (pendingResponse) return { accepted: false, reason: 'pending_response' };
      if (
        directorWantsAnswerGroup
        && callAdmissionCooldownSteps > 0
        && lastCallStep >= 0
        && (stepAbs - lastCallStep) < callAdmissionCooldownSteps
      ) {
        return { accepted: false, reason: 'call_cooldown' };
      }
      if (lastCallStep < 0) return { accepted: true, reason: 'accepted' };
      const answeredCurrentCall = Math.max(-1, Math.trunc(Number(callResponseRuntime.lastResponseStepAbs) || -1)) >= lastCallStep;
      if (!answeredCurrentCall && stepAbs <= pendingCallExpiresStepAbs) {
        return { accepted: false, reason: 'pending_call_exists' };
      }
      return { accepted: true, reason: 'accepted' };
    })();
    const acceptedStrongCall = callAdmission.accepted === true;
    const suppressInactiveSupportCall = (
      !isSoloCarrier
      && melodicCallGroup
      && !isPrimaryLoopOwnerGroup
      && !isFoundationBufferGroup
      && !isBassRole
      && (lifecycleState === 'inactiveForScheduling' || lifecycleState === 'deEmphasized')
      && !acceptedStrongCall
      && !phraseResolutionOpportunity
      && !phraseGravityOpportunity
      && phraseStep.stepInPhrase > 2
    );
    if (suppressInactiveSupportCall) {
      noteCallDiagnostic('inactive_support_suppressed', {
        strongCallCandidate,
        acceptedStrongCall,
        admissionReason: callAdmission.reason,
        stepInPhrase: Math.max(0, Math.trunc(Number(phraseStep?.stepInPhrase) || 0)),
      });
      noteResponseDiagnostic('inactive_support_suppressed');
      continue;
    }
    const suppressRedundantCallEmission = (
      !isSoloCarrier
      && melodicCallGroup
      && !isPrimaryLoopOwnerGroup
      && !acceptedStrongCall
      && (
        !strongCallCandidate
        || callAdmission.reason === 'pending_call_exists'
        || callAdmission.reason === 'pending_response'
        || callAdmission.reason === 'not_strong_call'
      )
    );
    if (suppressRedundantCallEmission) {
      noteCallDiagnostic('redundant_call_suppressed', {
        strongCallCandidate,
        acceptedStrongCall,
        admissionReason: callAdmission.reason,
        stepInPhrase: Math.max(0, Math.trunc(Number(phraseStep?.stepInPhrase) || 0)),
      });
      continue;
    }
    group.__bsPhraseRestUntilStep = slotRhythmCarrier
      ? -1
      : (phraseResolutionHit
        ? (stepAbs + localCadenceRestSteps)
        : Math.max(-1, postCadenceRestUntilStep));
    noteCallDiagnostic('emitted', {
      performerCount: performers.length,
      strongCallCandidate,
      acceptedStrongCall,
      admissionReason: callAdmission.reason,
      stepInPhrase: Math.max(0, Math.trunc(Number(phraseStep?.stepInPhrase) || 0)),
      phraseGravityOpportunity,
      phraseResolutionOpportunity,
      phraseGravityHit,
      phraseResolutionHit,
    });
    for (const enemy of performers) {
      events.push(createPerformedBeatEvent({
        actorId: Math.max(0, Math.trunc(Number(enemy?.id) || 0)),
        beatIndex,
        stepIndex: stepAbs,
        role: lockedLane === 'bass'
          ? 'bass'
          : normalizeSwarmRole(group?.role || getSwarmRoleForEnemy(enemy, roles.lead), roles.lead),
        note: styledNoteName,
        instrumentId,
        actionType: String(group.actionType || 'projectile') === 'explosion'
          ? 'composer-group-explosion'
          : 'composer-group-projectile',
        threatClass,
        visualSyncType: 'group-pulse',
        payload: {
          groupId,
          groupEventSource: slotRhythmCarrier
            ? 'intro_slot_generic'
            : (isFoundationBufferGroup ? 'foundation_buffer_generic' : 'composer_group_generic'),
          continuityId: String(group?.continuityId || '').trim(),
          musicLayer,
          musicProminence,
          soloCarrierType,
          musicLaneId: String(group?.musicLaneId || (isPrimaryLoopOwnerGroup ? 'primary_loop_lane' : '')).trim().toLowerCase(),
          callResponseLane: lane,
          callResponseQualified: lane === 'call' ? acceptedStrongCall : true,
          callResponsePhraseProgress: responsePhraseProgressForEvent,
          musicRegister: registerTarget,
          audioGain: rhythmPercussionCarrier
            ? 1
            : clamp01(Number(group?.musicParticipationGain == null ? 1 : group.musicParticipationGain) * lifecycleAudioGain * restrainedGroupGain),
          requestedNoteRaw: gravityNoteNameRaw,
          phraseGravityTarget,
          phraseGravityHit,
          phraseResolutionOpportunity,
          phraseResolutionHit,
        },
      }));
    }
    if ((introPercussionCarrier || isSoloCarrier) && noteIntroDebug) {
      noteIntroDebug(introPercussionCarrier ? 'intro_percussion_emitted' : 'solo_carrier_emitted', {
        groupId,
        stepIndex: stepAbs,
        performerCount: performers.length,
        instrumentId,
        note: styledNoteName,
        soloCarrierType,
      });
    }
    if (slotRhythmCarrier) {
      if (!(Math.trunc(Number(group?.introSlotFirstAudibleBeatIndex) || -1) >= 0)) {
        group.introSlotFirstAudibleBeatIndex = beatIndex;
      }
      const introSlotGenericEmitPayload = {
        groupId,
        stepIndex: stepAbs,
        beatIndex,
        performerCount: performers.length,
        instrumentId,
        note: styledNoteName,
        slotProfile: musicProfileSourceType,
        musicLaneId: String(group?.musicLaneId || '').trim().toLowerCase(),
      };
      if (noteIntroDebug) noteIntroDebug('intro_slot_rhythm_emitted', introSlotGenericEmitPayload);
      const introSlotGenericBranchPayload = {
        groupId,
        stepIndex: stepAbs,
        beatIndex,
        slotProfile: musicProfileSourceType,
        note: styledNoteName,
        instrumentId,
        musicLaneId: String(group?.musicLaneId || '').trim().toLowerCase(),
        callResponseLane: lane,
      };
      if (noteIntroDebug) noteIntroDebug('intro_slot_generic_emit', introSlotGenericBranchPayload);
      noteMusicSystemEvent?.('music_intro_slot_generic_emit', introSlotGenericBranchPayload, { beatIndex, stepIndex: stepAbs, barIndex });
    }
    noteEarlyCarrierTrace('emit', {
      branch: slotRhythmCarrier
        ? 'generic'
        : ((introPercussionCarrier || ((rhythmProfileCarrier || soloRhythmCarrier) && !slotRhythmCarrier)) ? 'direct_candidate' : 'generic'),
      performerEnemyIds: performers
        .map((enemy) => Math.max(0, Math.trunc(Number(enemy?.id) || 0)))
        .filter((id) => id > 0),
      performerCount: performers.length,
      requestedNote: styledNoteName,
      instrumentId,
      actionType: String(group.actionType || 'projectile') === 'explosion'
        ? 'composer-group-explosion'
        : 'composer-group-projectile',
      directTriggerEligible: !!(
        (introPercussionCarrier || (introSlotIdentityActive && (rhythmBackbeatCarrier || rhythmMotionCarrier)) || ((rhythmProfileCarrier || soloRhythmCarrier) && !slotRhythmCarrier))
        && directTriggerComposerCarrier
      ),
    });
    if ((introPercussionCarrier || (introSlotIdentityActive && (rhythmBackbeatCarrier || rhythmMotionCarrier)) || ((rhythmProfileCarrier || soloRhythmCarrier) && !slotRhythmCarrier)) && directTriggerComposerCarrier) {
      noteEarlyCarrierTrace('direct_trigger', {
        branch: 'direct_trigger',
        performerEnemyIds: performers
          .map((enemy) => Math.max(0, Math.trunc(Number(enemy?.id) || 0)))
          .filter((id) => id > 0),
        performerCount: performers.length,
        requestedNote: styledNoteName,
        instrumentId,
        actionType: String(group.actionType || 'projectile') === 'explosion'
          ? 'composer-group-explosion'
          : 'composer-group-projectile',
      });
      for (const enemy of performers) {
        try {
          directTriggerComposerCarrier({
            enemyId: Math.max(0, Math.trunc(Number(enemy?.id) || 0)),
            groupId,
            instrumentId,
            note: styledNoteName,
            audioGain: (introPercussionCarrier || rhythmProfileCarrier)
              ? 1
              : clamp01(Number(group?.musicParticipationGain == null ? 1 : group.musicParticipationGain) * lifecycleAudioGain * restrainedGroupGain),
            musicProminence,
            soloCarrierType,
            introPercussionCarrier,
          });
        } catch {}
      }
    }

    if (!isSoloCarrier && lane === 'call') {
      if (acceptedStrongCall) {
        const responseTargetLength = (() => {
          if (isPrimaryLoopOwnerGroup && phraseResolutionHit) return 4;
          if (phraseResolutionHit || phraseGravityHit || isPrimaryLoopOwnerGroup) return Math.random() < 0.35 ? 4 : 3;
          return Math.random() < 0.2 ? 1 : 2;
        })();
        const minimumDirectedResponseLength = directorWantsAnswerGroup
          ? (preDropActive ? 1 : (answerLaneIntensity >= 0.72 ? 3 : 2))
          : 1;
        const cappedResponseTargetLength = Math.max(
          minimumDirectedResponseLength,
          Math.min(responseLengthCap, responseTargetLength)
        );
        callResponseRuntime.lastCallStepAbs = stepAbs;
        callResponseRuntime.lastCallGroupId = groupId;
        callResponseRuntime.lastCallNote = styledNoteName;
        callResponseRuntime.pendingCallExpiresStepAbs = getPendingCallExpiry(stepAbs, cappedResponseTargetLength);
        callResponseRuntime.lastResponseNote = '';
        callResponseRuntime.activeResponseGroupId = 0;
        callResponseRuntime.responseHoldUntilStepAbs = -1;
        callResponseRuntime.responsePhraseProgress = 0;
        callResponseRuntime.responsePhraseTargetLength = cappedResponseTargetLength;
      }
    } else if (!isSoloCarrier) {
      const responseTargetLength = Math.max(1, Math.min(
        responseLengthCap,
        Math.trunc(Number(callResponseRuntime.responsePhraseTargetLength) || 2)
      ));
      callResponseRuntime.lastResponseStepAbs = stepAbs;
      callResponseRuntime.lastResponseGroupId = groupId;
      callResponseRuntime.lastResponseNote = normalizeSwarmNoteName(styledNoteName) || styledNoteName;
      callResponseRuntime.pendingCallExpiresStepAbs = -1;
      callResponseRuntime.activeResponseGroupId = groupId;
      callResponseRuntime.responseDirection = continuingResponsePhrase
        ? (Math.trunc(Number(callResponseRuntime.responseDirection) || 1) || 1)
        : (((getNotePoolIndex(callResponseRuntime.lastResponseNote) >= 0 && getNotePoolIndex(callResponseRuntime.lastCallNote) >= 0 && getNotePoolIndex(callResponseRuntime.lastResponseNote) < getNotePoolIndex(callResponseRuntime.lastCallNote)) ? -1 : 1) || 1);
      callResponseRuntime.responsePhraseProgress = continuingResponsePhrase
        ? (Math.max(0, Math.trunc(Number(callResponseRuntime.responsePhraseProgress) || 0)) + 1)
        : 1;
      callResponseRuntime.responseHoldUntilStepAbs = Math.max(
        stepAbs,
        Math.min(
          stepAbs + Math.max(0, (responseTargetLength - 1) * responsePhraseSteps),
          Math.max(stepAbs, Math.trunc(Number(callResponseRuntime.lastCallStepAbs) || stepAbs) + responseWindowSteps + responseWindowGraceSteps)
        )
      );
    }
    group.__bsLastComposerNote = normalizeSwarmNoteName(styledNoteName) || styledNoteName;
  }
  return events;
}
