// src/drawgrid/dg-back-sync.js
// Back-buffer synchronization for DrawGrid.

import {
  syncCanvasesCssSize,
  clampDprForBackingStore,
  createOverlayResizeGate,
  computeEffectiveDpr,
  resizeCanvasForDpr,
} from '../baseMusicToy/index.js';

export function createDgBackSync({ state, deps } = {}) {
  const s = state || {};
  const d = deps || {};
  // Cache gate instance (avoid per-frame allocations).
  let __overlayGate = null;
  let __overlayGateKey = '';

  function ensureBackVisualsFreshFromFront() {
    try {
      const paintScale = (Number.isFinite(s.paintDpr) && s.paintDpr > 0) ? s.paintDpr : 1;
      const logicalWidth = Math.max(1, s.cssW || ((s.frontCanvas?.width ?? 1) / paintScale));
      const logicalHeight = Math.max(1, s.cssH || ((s.frontCanvas?.height ?? 1) / paintScale));

      // Default all DOM-backed layers to paintScale, but allow "aux" layers (grid/nodes/ghost/tutorial/playhead/etc)
      // to reduce backing resolution when zoomed out or under frame-time pressure. This targets **raster/compositor**
      // cost ("frame.nonScript") without changing CSS size/layout.
      const deviceDpr = (Number.isFinite(window?.devicePixelRatio) && window.devicePixelRatio > 0) ? window.devicePixelRatio : 1;
      const toyScale = (Number.isFinite(s.panel?.__dgLastToyScale) && s.panel.__dgLastToyScale > 0) ? s.panel.__dgLastToyScale : 1;
      const visualMulRaw = d.__dgComputeVisualBackingMul(toyScale);
      const pressureMulRaw = d.__dgGetPressureDprMul();
      const globalDg = (typeof window !== 'undefined') ? window.__DRAWGRID_GLOBAL : null;
      const totalPanels = Math.max(
        Number.isFinite(globalDg?.totalCount) ? globalDg.totalCount : 0,
        Number.isFinite(globalDg?.visibleCount) ? globalDg.visibleCount : 0
      );
      const freezeNonPaintResizes = (typeof window !== 'undefined' && window.__DG_FREEZE_NONPAINT_RESIZES_HEAVY === false)
        ? false
        : (totalPanels >= 24);
      const isPrimaryFocused = !!(s.panel?.classList?.contains?.('toy-focused'));
      const freezeVisualDpr = totalPanels >= 24 && !isPrimaryFocused;
      const visualMul = freezeVisualDpr ? 1 : visualMulRaw;
      const freezePressureDpr = totalPanels >= 24;
      const pressureMul = freezePressureDpr ? 1 : pressureMulRaw;
      try { if (s.panel) s.panel.__dgPressureDprFrozen = !!freezePressureDpr; } catch {}
      try { if (s.panel) s.panel.__dgVisualDprFrozen = !!freezeVisualDpr; } catch {}
      const autoMul = d.__dgGetAutoQualityMul();

      // Tier hard clamp (pixels-first lever). We keep this deliberately generic:
      // - if the tier system publishes a maxDprMul, we use it
      // - otherwise we leave it unclamped (null)
      const tierMaxDprMul =
        (Number.isFinite(s.__dgTierMaxDprMul) && s.__dgTierMaxDprMul > 0) ? s.__dgTierMaxDprMul :
        (s.__dgTierProfile && Number.isFinite(s.__dgTierProfile.maxDprMul) && s.__dgTierProfile.maxDprMul > 0) ? s.__dgTierProfile.maxDprMul :
        null;
      const overlayTierMaxDprMul =
        (Number.isFinite(s.__dgOverlayTierMaxDprMul) && s.__dgOverlayTierMaxDprMul > 0) ? s.__dgOverlayTierMaxDprMul :
        (s.__dgTierProfile && Number.isFinite(s.__dgTierProfile.overlayMaxDprMul) && s.__dgTierProfile.overlayMaxDprMul > 0) ? s.__dgTierProfile.overlayMaxDprMul :
        tierMaxDprMul;

      // Aux layer DPR: never exceed paintScale, but can drop below it smoothly.
      const auxDprRaw = deviceDpr * visualMul * pressureMul * autoMul;
      const auxEd = computeEffectiveDpr({
        deviceDpr,
        rawDpr: auxDprRaw,
        maxDprMul: tierMaxDprMul,
      });
      const auxScale = clampDprForBackingStore({
        logicalW: logicalWidth,
        logicalH: logicalHeight,
        paintScale,
        rawDpr: auxEd.effectiveDpr,
        capFn: d.__dgCapDprForBackingStore,
        adaptivePaintDpr: s.__dgAdaptivePaintDpr,
      });

      // Overlay layer DPR: drop earlier/more aggressively under pressure.
      // IMPORTANT: do NOT reduce overlay DPR based on gesture state; only generic pressure.
      const overlayMinMul = (Number.isFinite(window.__DG_OVERLAY_PRESSURE_DPR_MIN_MUL) && window.__DG_OVERLAY_PRESSURE_DPR_MIN_MUL > 0)
        ? window.__DG_OVERLAY_PRESSURE_DPR_MIN_MUL
        : 0.45;
      const overlayBias = (Number.isFinite(window.__DG_OVERLAY_PRESSURE_DPR_BIAS) && window.__DG_OVERLAY_PRESSURE_DPR_BIAS > 0)
        ? window.__DG_OVERLAY_PRESSURE_DPR_BIAS
        : 0.85;
      const overlayPressureMul = (pressureMul < 0.999)
        ? Math.max(overlayMinMul, Math.min(1, pressureMul * overlayBias))
        : 1;
      const overlayDprRaw = deviceDpr * visualMul * overlayPressureMul * autoMul;
      const overlayEd = computeEffectiveDpr({
        deviceDpr,
        rawDpr: overlayDprRaw,
        maxDprMul: overlayTierMaxDprMul,
      });
      const overlayScale = clampDprForBackingStore({
        logicalW: logicalWidth,
        logicalH: logicalHeight,
        paintScale,
        rawDpr: overlayEd.effectiveDpr,
        capFn: d.__dgCapDprForBackingStore,
        adaptivePaintDpr: s.__dgAdaptivePaintDpr,
      });

      const overlayQuantPx = (Number.isFinite(window.__DG_OVERLAY_DPR_QUANT_PX) && window.__DG_OVERLAY_DPR_QUANT_PX >= 8)
        ? (window.__DG_OVERLAY_DPR_QUANT_PX|0)
        : 32;
      const overlayStableFrames = (Number.isFinite(window.__DG_OVERLAY_RESIZE_STABLE_FRAMES) && window.__DG_OVERLAY_RESIZE_STABLE_FRAMES >= 1)
        ? (window.__DG_OVERLAY_RESIZE_STABLE_FRAMES|0)
        : 6;

      // Shared overlay resize gate: quantize + stable-frame gating + big-jump immediate apply.
      // Cache instance to avoid allocations; behaviour is still per-canvas via pending fields.
      const gateKey = overlayQuantPx + '|' + overlayStableFrames;
      if (!__overlayGate || __overlayGateKey !== gateKey) {
        __overlayGate = createOverlayResizeGate({
          quantStepPx: overlayQuantPx,
          stableFrames: overlayStableFrames,
          bigJumpSteps: 2,
          // IMPORTANT: keep using DrawGrid's existing pending fields for perfect behaviour parity.
          cachePrefix: '__dg',
          stateKey: '__dg',
        });
        __overlayGateKey = gateKey;
      }
      const overlayGate = __overlayGate;

      const isOverlayLayer = (c) => (c === s.flashCanvas) || (c === s.flashBackCanvas) || (c === s.ghostCanvas) || (c === s.ghostBackCanvas) || (c === s.tutorialCanvas) || (c === s.tutorialBackCanvas) || (c === s.playheadCanvas);
      const isOverlayDormant = (c) => {
        try {
          if (!c || !c.style) return false;
          if (c.style.display !== 'none') return false;
          if (c === s.flashCanvas || c === s.flashBackCanvas) return !!s.panel.__dgFlashLayerEmpty;
          if (c === s.ghostCanvas || c === s.ghostBackCanvas) return !!s.panel.__dgGhostLayerEmpty;
          if (c === s.tutorialCanvas || c === s.tutorialBackCanvas) return !!s.panel.__dgTutorialLayerEmpty;
          if (c === s.playheadCanvas) return !!s.panel.__dgPlayheadLayerEmpty;
        } catch {}
        return false;
      };

      const styleCanvases = d.__dgListAllLayerEls();
      // Apply logical CSS size to all DOM-backed layers and keep cached CSS size authoritative.
      // This avoids repeated DOM reads and gives all DPR math a single source of truth.
      syncCanvasesCssSize(
        styleCanvases,
        logicalWidth,
        logicalHeight,
        { cachePrefix: '__bm', alsoCachePrefixes: ['__dg'] }
      );

      const allCanvases = d.__dgListManagedBackingEls();
      // Keep authoritative CSS size cached even for non-DOM canvases (back buffers).
      syncCanvasesCssSize(
        allCanvases,
        logicalWidth,
        logicalHeight,
        { cachePrefix: '__bm', alsoCachePrefixes: ['__dg'] }
      );

      // NOTE: avoid per-canvas getContext() calls here (can be surprisingly costly).
      // We only reset contexts we already hold references to.
      let resizedAny = false;

      const isPaintLayer = (c) => (c === s.frontCanvas) || (c === s.backCanvas) || (c === s.paint);

      for (const canvas of allCanvases) {
        // If an overlay layer is dormant (display:none + marked empty), do not resize it.
        // Resizing dormant overlays during pressure changes can create big realloc spikes
        // even though the layer isn't contributing any pixels this frame.
        if (isOverlayLayer(canvas) && isOverlayDormant(canvas)) {
          continue;
        }

        const dpr = isPaintLayer(canvas)
          ? paintScale
          : isOverlayLayer(canvas)
            ? overlayScale
            : auxScale;

        // Heavy multi-toy stabilization: once non-paint layers are allocated,
        // do not continuously resize them. Resize churn here can dominate compositor time.
        if (freezeNonPaintResizes && !isPaintLayer(canvas)) {
          const hasBacking = ((canvas.width | 0) > 0) && ((canvas.height | 0) > 0);
          if (hasBacking) {
            try { canvas.__dgBackingDpr = dpr; } catch {}
            continue;
          }
        }

        // Cache DPR used for this backing store (useful for debug and for ctx reset helpers).
        try { canvas.__dgBackingDpr = dpr; } catch {}

        if (!isOverlayLayer(canvas) && isPaintLayer(canvas)) {
          // Paint/front layers are not gated; keep pending counters clear.
          try { canvas.__dgPendingN = 0; } catch {}
        }

        {
          const oldW = canvas.width|0;
          const oldH = canvas.height|0;

          // Route all layers through the shared baseMusicToy truth-point.
          // Overlays pass a gate that quantizes + stable-gates resizes exactly as before.
          const r = resizeCanvasForDpr(canvas, null, logicalWidth, logicalHeight, {
            rawDpr: dpr,
            cachePrefix: '__bm',
            alsoCachePrefixes: ['__dg'],
            skipCssSync: true,
            gate: isOverlayLayer(canvas) ? overlayGate.gate : null,
          });

          // If the overlay gate decided "not yet", skip any post-resize bookkeeping.
          if (r && r.gated && r.resized === false && isOverlayLayer(canvas)) {
            continue;
          }

          const newW = canvas.width|0;
          const newH = canvas.height|0;

          if (oldW !== newW) {
            resizedAny = true;
            try { window.__PERF_DG_BACKING_RESIZE_COUNT = (window.__PERF_DG_BACKING_RESIZE_COUNT || 0) + 1; } catch {}
            if (isOverlayLayer(canvas)) { try { window.__PERF_DG_OVERLAY_RESIZE_COUNT = (window.__PERF_DG_OVERLAY_RESIZE_COUNT || 0) + 1; } catch {} }
          }
          if (oldH !== newH) {
            resizedAny = true;
            try { window.__PERF_DG_BACKING_RESIZE_COUNT = (window.__PERF_DG_BACKING_RESIZE_COUNT || 0) + 1; } catch {}
            if (isOverlayLayer(canvas)) { try { window.__PERF_DG_OVERLAY_RESIZE_COUNT = (window.__PERF_DG_OVERLAY_RESIZE_COUNT || 0) + 1; } catch {} }
          }
          // style width/height is already set via styleCanvases above
        }
      }
      if (resizedAny) {
        // Resizing clears grid/nodes backing stores; force a static redraw.
        s.panel.__dgGridHasPainted = false;
        try { d.markStaticDirty('sync-back-resize'); } catch {}
        s.__dgForceFullDrawNext = true;
      }

      // Reset known contexts after resize
      try { d.R.resetCtx(s.frontCtx); } catch {}
      try { d.R.resetCtx(s.backCtx); } catch {}
      try { d.R.resetCtx(s.gridFrontCtx); } catch {}
      try { d.R.resetCtx(s.gridBackCtx); } catch {}
      try { d.R.resetCtx(s.nodesFrontCtx); } catch {}
      try { d.R.resetCtx(s.nodesBackCtx); } catch {}
      try { d.R.resetCtx(s.flashFrontCtx); } catch {}
      try { d.R.resetCtx(s.flashBackCtx); } catch {}
      try { d.R.resetCtx(s.ghostFrontCtx); } catch {}
      try { d.R.resetCtx(s.ghostBackCtx); } catch {}
      try { d.R.resetCtx(s.tutorialFrontCtx); } catch {}
      try { d.R.resetCtx(s.tutorialBackCtx); } catch {}
      try { d.R.resetCtx(s.playheadFrontCtx); } catch {}

      const copyCtx = (srcCtx, dstCtx) => {
        if (!srcCtx || !dstCtx) return;
        if (srcCtx === dstCtx || srcCtx.canvas === dstCtx.canvas) return;
        if (s.DG_SINGLE_CANVAS && s.usingBackBuffers && (srcCtx === s.gridFrontCtx || srcCtx === s.nodesFrontCtx)) return;
        const dw = dstCtx.canvas?.width || 0;
        const dh = dstCtx.canvas?.height || 0;
        if (!dw || !dh) return;
        d.R.withDeviceSpace(dstCtx, () => {
          dstCtx.clearRect(0, 0, dw, dh);
          dstCtx.drawImage(
            srcCtx.canvas,
            0, 0, srcCtx.canvas.width, srcCtx.canvas.height,
            0, 0, dw, dh
          );
        });
      };

      if (!s.DG_SINGLE_CANVAS) {
        copyCtx(s.pctx, s.backCtx);
        copyCtx(s.gridFrontCtx, s.gridBackCtx);
        copyCtx(s.nodesFrontCtx, s.nodesBackCtx);
        copyCtx(s.flashFrontCtx, s.flashBackCtx);
        copyCtx(s.ghostFrontCtx, s.ghostBackCtx);
        copyCtx(s.tutorialFrontCtx, s.tutorialBackCtx);
      } else if (!s.usingBackBuffers) {
        // In single-canvas mode, backCtx must remain *paint-only*.
        // Copying from frontCtx (which includes grid/overlays) makes the grid
        // get composited twice, causing the "grid gets darker when zooming/panning".
        // Keep back updated via stroke redraws instead.
        try {
          if (s.backCtx && Array.isArray(s.strokes) && s.strokes.length > 0) {
            d.clearAndRedrawFromStrokes(s.backCtx, 'sync-back-from-strokes');
          }
        } catch {}
      }
    } catch {}
  }

  return {
    ensureBackVisualsFreshFromFront,
  };
}
