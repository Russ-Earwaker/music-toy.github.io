# Beat Swarm - Next Steps

## Current State

The core architecture is no longer the main problem.

Implemented infrastructure now includes:

- protected lane ownership for `foundation` and `primary_loop`
- continuity-preserving handoff with deferred phrase-boundary application
- shared spawner loop ownership
- timing split between music-authored and gameplay-authored events
- composition-group continuity buffering
- ownership, queue, and decision diagnostics
- protected-lane guardrails against heuristic drift

The current phase is not "invent the music system."
The current phase is:

> Musical clarity, delivery reliability, and perceptual stability

## Progress Snapshot

Recent work has materially improved the system:

- protected `foundation` and `primary_loop` ownership now survive handoff much more reliably
- phase-3 instrument churn is far lower than it was during the earlier sync/handoff bugs
- ghost-loop cleanup is in much better shape and no longer looks like a main clutter source
- call-and-answer is now alive, measurable, and no longer a blind-debug area
- Music Lab export now preserves the fields needed to inspect call/response behavior directly
- intro slot ownership is now functioning as real lane-owned music instead of a bespoke silent placeholder path
- the intro now successfully teaches:
  - one stable pulse first
  - then one additive second percussion layer
  - with a smoother handoff into general play

Current working baseline:

- delivery is acceptable again
- delayed replies are real and can sustain short fragments instead of only single-note answers
- foreground readability is improved overall, but still fragile when reply/support motion gets too assertive

So the remaining work is refinement, not rescue.

## Intro Status

Completed in this pass:

- [x] first intro carrier owns the pulse lane and is audible immediately
- [x] first intro pulse stays musically stable through the intro
- [x] second intro carrier joins later instead of spawning immediately
- [x] second intro carrier is now a distinct audible backbeat layer
- [x] intro pulse and backbeat survive execution as separate voices
- [x] intro-to-play handoff no longer immediately rewrites the opening pulse
- [x] intro slot carriers now behave as interchangeable music carriers rather than one-off hardcoded exceptions

Still to do for intro:

- [ ] replace the first large intro enemy body with a composer group while keeping the same pulse slot music
- [ ] randomize the second intro carrier body per run between composer group and large enemy while preserving its slot music
- [ ] make the intro retain its teaching structure but feel musically different each run
- [ ] ensure overall playthrough-to-playthrough musical identity is more varied and distinct

Important current rule:

> The director should choose the musical slot first, and enemy bodies should be swappable outputs for that slot.

That intro direction now works structurally for pulse and backbeat.
The next step is to swap bodies without losing musical continuity.

## Primary Problem: Delivery And Audibility

The remaining failures are mostly perceptual:

- created events are not always heard clearly
- important loops can still enter, speak once, then disappear perceptually
- volume can still shift too sharply over short windows
- some musical material is now over-preserved and becoming too recognizable

This means the next work should optimize for presentation, not more architectural complexity.

## Musicality Reconstruction Plan

We now have enough evidence that the current post-fix system is stable enough to hear clearly, but too structurally flat.

Current failure mode:

- the run tends to settle into `2` rhythm layers plus `1` melody layer
- the old layered richness that existed when snakes and spawners directly owned musical roles is mostly gone
- fallback and persistence logic are now good enough to keep things alive, but not rich enough to create varied arrangement on their own

Important truth:

> We did not lose all of the old musical content.
> We mostly lost the old structural mechanism that let multiple enemy families act like independent arrangers at the same time.

So the reconstruction plan is:

- do **not** return to literal snake/spawner lane ownership as the default model
- keep protected lane identity and modern handoff rules
- reintroduce the old richness intentionally as authored arrangement layers

### Reconstruction Goal

Rebuild the old sense of layered musicality without restoring the ownership bugs that came with it.

Target post-reconstruction texture:

- one stable foundation / pulse role
- one stable counter-rhythm role
- one stable lead role
- one explicit answer / ornament role
- optional sparkle / motion layer during the right sections

That means the intended baseline should become:

> `foundation + counter-rhythm + lead + answer/ornament`

instead of:

> `rhythm + rhythm + melody`

### Working Rule

Use old toy identity as **style input**, not **lane ownership**.

Examples:

- snake-like:
  - contour
  - register leaps
  - longer melodic phrases
  - legato or arc-shaped lead motion
- spawner-like:
  - pulse
  - syncopation
  - drum-machine repetition
  - additive groove layering

The point is:

- snakes and spawners should still influence the music
- but they should not have to own the musical lane in order to contribute that character

### Reconstruction Stages

#### Stage 1. Restore Structural Layer Count

Goal:

- stop capping the arrangement at the effective `2 rhythm + 1 melody` shape

Needed work:

- allow one real extra non-lead group beyond the current stable core
- make sure melody fallback does not hijack all later group creation
- preserve lead persistence without making lead the only privileged lane

Success condition:

- long runs can sustain at least one additional non-foundation, non-lead musical layer

#### Stage 2. Author Explicit Lane Roles

Goal:

- stop treating every extra group like generic rhythm support

Define explicit composer roles:

- `foundation_groove`
- `counter_rhythm`
- `lead_phrase`
- `answer_ornament`

Each role should have:

- its own phrase logic
- its own register expectations
- its own instrument expectations
- its own density limits

Success condition:

- the fourth layer sounds like an answer, ornament, or phrase comment, not just another rhythm loop

#### Stage 3. Reintroduce Toy Character As Style Modules

Goal:

- recover the musical personality we used to get “for free” from enemy ownership

Needed work:

- extract reusable snake-like melodic behaviors
- extract reusable spawner-like groove behaviors
- feed those into composer profile generation as style families

Success condition:

- sections feel like they carry distinct personalities again without requiring literal toy ownership

#### Stage 4. Make Sections Rearrange The Piece

Goal:

- make section changes sound like arrangement decisions, not just intensity changes

Needed work:

- section state should decide which role families are active
- support / answer / sparkle should enter and leave intentionally
- build / release / breakdown should change texture, not only energy numbers

Success condition:

- a `3m` run sounds like it moves through recognisable arrangement states

#### Stage 5. Rebuild Long-Run Variation

Goal:

- stop the piece from becoming static once it finds one working texture

Needed work:

- rotate role families over phrase epochs
- allow answer and ornament lanes to swap behavior more freely than protected owners
- vary phrase density and contour without destabilising the main idea

Success condition:

- the run stays legible, but does not feel locked to one texture for minutes at a time

### Immediate Implementation Order

The next concrete work under this reconstruction plan should be:

1. make the extra post-lead group explicitly `answer/ornament` instead of generic response fill
2. give that role its own profile generator and register limits
3. widen section logic so `support`, `answer`, and `sparkle` can be intentionally active together in the right windows
4. bring back stronger snake-like and spawner-like style families as generator inputs
5. tune long-run entry/exit rules so melody persistence does not flatten the rest of the arrangement

### Anti-Regression Rule

Do not reintroduce the old layering by undoing protected-lane ownership and handoff fixes.

Specifically:

- do not make snakes the default lead owner again
- do not make spawners the default rhythm owner again
- do not rely on enemy-type churn to create musical variation

Reconstruction should add:

- explicit arrangement roles
- explicit section behavior
- explicit style modules

not:

- accidental richness caused by unstable ownership

## Metrics Review

Useful existing signals to preserve:

- ownership continuity health
- deferred ownership queue health
- protected-lane inferred/missing claim counts
- spawner pipeline mismatches
- gameplay-authored vs music-authored event balance

Useful live signals now in use:

- `protectedLoopAudibility`
- `foregroundClarityScore`
- `simultaneousVoiceCount`
- `ghostLoopCount`
- `suppressedEventCount`
- `groupParticipationRate`
- `callCount`
- `responsePairs`
- `responseRate`
- `audibleResponseRate`
- `avgResponseSize`

## Remaining Priorities

### 1. Mix Hierarchy And Protected Audibility

Target behavior:

- foundation remains clearly trackable
- one foreground idea is legible
- support and sparkle sit underneath instead of competing
- visible gameplay cues should usually have matching audible cues

Biases to strengthen:

- foundation should not collapse below support in dense bars
- player fire should not bury protected loops
- fresh loop entries should remain audible long enough to be learned

This is a tuning/system-shaping task, not a new mixer architecture.

### 2. Ghost Loop Scope Correction

Ghost continuation is useful, but only as phrase completion.

Correct scope:

- finish the current phrase
- do not start a new phrase
- do not persist as a long-term invisible owner
- do not stack multiple ghosts unnecessarily

Goal:

- preserve musical truth without adding invisible clutter

### 3. Phrase Lock And Foreground Clarity

The system should keep important ideas stable long enough to register.

Needed behavior:

- foreground loops hold long enough to be understood
- competing replacements do not constantly interrupt them
- support material may still evolve around the locked idea

This should be implemented as controlled persistence, not rigidity.

### 4. Anti-Repetition And Generative Base

Some material, especially drawsnake phrases, is now too recognizable across sessions.

Direction:

- lean more on seeded variation than authored chunks
- use contour variation, pitch-pool movement, and mutation
- reduce exact phrase reuse
- preserve call/response and motif logic without sounding pre-baked

### 5. Density And Collision Control

The mix still needs better behavior when many valid events coincide.

Keep suppressing:

- same-note same-role duplicates
- same-register melodic pileups
- redundant accents

Keep allowing:

- layered percussion
- bass plus one readable lead
- limited support when it stays out of the main register

### 6. Spawner Group Refinement

Shared spawner ownership already exists.
The remaining work is refinement:

- validate that one group behaves like one loop owner
- keep one audio event per intended step
- ensure all visible members react consistently
- prevent per-member identity drift

Goal:

- spawners behave like one readable drum machine, not loosely synced individuals

### 7. Composition-Group Restraint

Composition groups should remain a continuity tool, not become the dominant musical source.

They should:

- complete phrases
- bridge ownership loss
- support gameplay-driven music

They should not:

- replace gameplay ownership by default
- dominate the foreground unnecessarily

### 8. Base Palette And Scoped Instrument Influence

The default musical identity should come from one stable base palette.

For the current game, that means:

- `beat-swarm-shmup` is the default gameplay layer
- normal enemies and ordinary music generation should draw from that base by default
- special-case identities should be additive and scoped, not global

Needed behavior:

- ordinary gameplay keeps one coherent shmup identity
- special enemies can carry a distinct instrumental influence without broadening the whole base pool
- bosses or rare encounters can temporarily own a stronger override when that is musically intentional

Examples:

- a piano enemy may force piano-capable call/answer or support material for itself
- a boss may temporarily force a broader foreground-capable override
- normal spawners and snakes should still fall back to the shmup base layer

The important rule:

- do not solve uniqueness by making the default pool stylistically incoherent
- solve it with scoped event or encounter overrides layered on top of the base palette

Current status:

- the first runtime hook exists
- a scoped `PIANO` debug-spawn test worked
- so the technical direction is validated

Current priority:

- lower than the active pacing / structure work
- do not keep expanding this ad hoc
- come back once the gameplay-facing special-enemy design is ready

Implementation direction:

- keep `beat-swarm-shmup` as the base gameplay palette
- add a per-enemy / per-encounter override hook such as:
  - `music_palette_override`
  - `instrument_influence`
  - `forced_music_identity`
- keep overrides constrained to the owning enemy, group, or encounter unless explicitly promoted to a global moment

Next time this is resumed, the work should start with design questions:

- which special enemies get overrides
- which overrides are support-only vs foreground-capable
- when an override is allowed to claim protected ownership
- how long an override is allowed to shape the mix before handing back to the base palette

### 9. Long-Horizon Musical Pacing

The system now makes better local decisions, but it still needs better flow over longer stretches of play.

Target behavior over time:

- phrases should arrive in waves, not as a flat constant density
- sections should have clearer rise, release, and recovery
- special moments like beat drops should feel prepared and earned
- longer runs should sound intentionally shaped, not just locally correct

Examples of desired pacing behavior:

- temporary thinning before a drop
- a more obvious return of foundation after sparse moments
- stronger contrast between normal combat and higher-pressure encounters
- longer phrase-energy arcs across multiple bars, not only step-level density changes

This is not just a mix task.
It is a maintenance and generation pacing task:

- when to add or remove groups
- when to widen or narrow density
- when to privilege continuity vs interruption
- when to allow a structural drop or restatement

Goal:

> The music should feel like it is going somewhere over time,
> not only making reasonable decisions in the current bar.

Related detailed plan:

- [beat-swarm-percussion-build-up-plan.md](/d:/Desktop/music-toy/music-toy.github.io/beat-swarm-percussion-build-up-plan.md)
- [beat-swarm-musical-structure-plan.md](/d:/Desktop/music-toy/music-toy.github.io/beat-swarm-musical-structure-plan.md)
- [beat-swarm-musicality-gaps-plan.md](/d:/Desktop/music-toy/music-toy.github.io/beat-swarm-musicality-gaps-plan.md)

That plan should drive the percussion-specific part of long-horizon pacing:

- groove layers instead of one mutating drum loop
- build-up by addition and removal of layers
- longer pulse stability
- explicit section rise, peak, and release behavior

The structure plan should drive the higher-level part:

- recurring motifs and returns
- explicit sections
- energy curves
- drop and release moments
- payoff over longer runs

The musicality-gaps plan should track the remaining non-structural musical ingredients:

- harmony
- tension and release
- silence / negative space
- cadence and phrase landing
- stronger register and instrument identity consistency

### 10. Controlled Instrument Introduction

The base palette is healthier now, but new timbres are still arriving too quickly in some runs.

That creates two problems:

- the player does not get enough time to learn the current instrumental identity
- several "never heard before" sounds can arrive close together and feel overwhelming instead of intentional

Target behavior:

- the base gameplay palette should introduce new instruments more slowly
- one new foreground-capable timbre should be easier to notice and learn before another arrives
- novelty should come in staged moments, not as continuous churn

Needed behavior:

- track recently heard instruments over a meaningful recent window
- apply a novelty budget so only a small number of truly new instruments may enter within the same stretch
- prefer reusing already-established instruments before opening another unfamiliar one
- strongly avoid introducing multiple never-heard-before foreground candidates at the same time
- once a new instrument is introduced, let it persist long enough to become legible before rotating again

Working rule:

> A new instrument should feel like an arrival, not like another random replacement.

Implementation direction:

- add a recent-heard / first-heard memory window
- separate "eligible" from "novel right now"
- cap simultaneous first-hear events, especially for `foreground` and `support`
- allow accents and scoped overrides to be looser than protected owners, but still not chaotic

This work should sit below the current pacing / structure push, but above any broad palette expansion.

### 11. Sample Leveling And Loudness Control

The project now has useful sample-analysis outputs, and they should inform backlog work on loudness consistency.

Relevant sources:

- [sample-analysis-suggestions.csv](/d:/Desktop/music-toy/music-toy.github.io/tools/output/sample-analysis-suggestions.csv)
- [sample-analysis-debug.csv](/d:/Desktop/music-toy/music-toy.github.io/tools/output/sample-analysis-debug.csv)
- [samples.csv](/d:/Desktop/music-toy/music-toy.github.io/samples.csv)

Why this matters:

- some samples are still materially hotter or quieter than others
- that pushes perceived mix balance around before Beat Swarm logic even starts doing its own gain shaping
- "too_hot" and "quiet" samples can make runtime tuning look worse than it really is

Target behavior:

- sample loudness should start from a more even authoring baseline
- the `volume` column in `samples.csv` should become the human-facing place to store per-sample level intent
- runtime balance work should build on that baseline instead of compensating for large raw sample mismatches

Backlog tasks:

- review `suggested_volume_peak_dbfs`, `suggested_volume_rms_dbfs`, and `volume_classification`
- identify clear outliers first, especially `too_hot` and `quiet`
- define a small target leveling policy for arcade/shmup samples
- populate or validate `samples.csv -> volume` from that policy
- keep unpitched percussion and pitched sustained material on separate expectations where necessary

Important rule:

> Use the analysis outputs as guidance and triage, not blind truth.

The debug and suggestion files are strong enough to find obvious problems:

- clipped / near-clipped drums and accents
- unusually quiet tonal samples
- likely inconsistent source gain between otherwise similar sounds

But they should still be checked by ear before finalizing the level written into `samples.csv`.

### 12. Sample Pitch Import And Base-Note Accuracy

The sample-analysis outputs should also drive base-note and octave authoring, not only loudness triage.

Relevant sources:

- [sample-analysis-suggestions.csv](/d:/Desktop/music-toy/music-toy.github.io/tools/output/sample-analysis-suggestions.csv)
- [sample-analysis-debug.csv](/d:/Desktop/music-toy/music-toy.github.io/tools/output/sample-analysis-debug.csv)
- [samples.csv](/d:/Desktop/music-toy/music-toy.github.io/samples.csv)

Why this matters:

- some samples are not rooted on `C`
- the project needs to preserve those real note centers instead of silently forcing everything toward `C`
- wrong base note or octave data will undermine harmony, cadence, and register ownership work
- but shared toys still need a stable playback anchor so switching instruments does not silently change the played note

Target behavior:

- pitched samples should import their detected base note and octave when the analysis confidence is good enough
- non-`C` notes should be preserved as first-class metadata, not treated like an error
- unpitched or low-confidence samples should stay unresolved until reviewed, not get fake note data
- raw detected pitch should be kept separate from the playback anchor used by toys when those two meanings differ

Backlog tasks:

- use `suggested_base_note`, `suggested_base_oct`, `pitch_confidence`, and `analysis_status`
- import non-`C` note centers and octaves into `samples.csv`
- distinguish clearly between:
  - confidently pitched tonal samples
  - weak / ambiguous tonal samples
  - unpitched percussion and noise sources
- add a conservative confidence threshold before auto-writing note data
- keep manual override available when the analysis is musically wrong even if it is technically confident

Important rule:

> Preserve true pitch centers when known; leave them blank when not known.

The goal is not to normalize everything to `C`.
The goal is to let `samples.csv` record both:

- the real source pitch center when known
- and the shared playback anchor when toys need stable note behavior across instrument changes

### 13. Player Weapon Loop As Musical Material

The player's current weapon sound loop should become part of the piece, not just an external combat layer sitting on top of it.

Why this matters:

- the player is the most persistent actor in the session
- weapon fire is one of the most repeated sounds the player hears
- if the weapon loop is musically disconnected, it fights the score instead of reinforcing it

Target behavior:

- the currently equipped weapon should feel like part of the active musical texture
- weapon loop identity should fit the current base palette and section feel
- weapon changes should read like deliberate musical changes, not random extra noise
- player loop behavior should support the piece without constantly stealing protected foreground ownership

Backlog tasks:

- define the player's weapon loop as a first-class musical layer with clear role limits
- decide when player weapon sound is:
  - rhythmic foundation support
  - foreground reinforcement
  - accent-only punctuation
- align player loop note choice, rhythm density, and register with current harmony / structure intent where possible
- make section behavior affect player-loop presentation too:
  - restrained in `drop`
  - supportive in `build`
  - more assertive in `drive` or `peak` when appropriate
- ensure weapon swaps hand off musically instead of abruptly breaking the active texture

Important rule:

> The player weapon loop should belong to the music system, not merely coexist with it.

Design constraint:

- this should integrate with the piece while preserving gameplay readability and weapon feel
- player-owned sound should usually reinforce the track, not replace the protected main idea unless explicitly designed to do so

### 14. Legacy `composition` Sample Role Cleanup

There are still samples in [samples.csv](/d:/Desktop/music-toy/music-toy.github.io/samples.csv) with `combatRole=composition`, but there is no current live `recommended_toys=composition` runtime path.

Current truth:

- these rows are effectively dormant in the current codebase unless they are also selected through other live role metadata
- that makes them ambiguous authoring state, not clearly active content

Backlog tasks:

- decide whether these legacy `composition` rows should be:
  - retagged into live Beat Swarm/sample metadata roles
  - reserved for a future dedicated runtime or toy path
  - explicitly documented as dormant legacy content
- review the current affected support/pad/arp samples and decide whether they are actually:
  - `support`
  - `answer_source`
  - `motion`
  - or non-runtime library content
- avoid silent cleanup that changes sample behavior accidentally; document the current dormant state first

Important rule:

> Do not leave legacy tags in a half-live state if they no longer correspond to any real runtime path.

### 15. Unified Beat Swarm Director

The current system has enough moving parts now that a more deliberate director layer is justified.

Why this matters:

- music lanes, carrier assignment, enemy spawning, and gameplay pacing are tightly related now
- current behavior is still split across:
  - lane ownership logic
  - singleton-group sync
  - carrier spawn/replace logic
  - section and groove planners
- that split makes it harder to guarantee that:
  - a musical lane keeps its identity
  - a replacement enemy inherits the correct role
  - difficulty ramp and arrangement ramp reinforce each other

Target behavior:

- one director should own the intended active musical lanes
- one director should also own how gameplay carriers are allocated to those lanes
- enemy spawn pressure and combat pacing should be able to rise/fall alongside the music on purpose
- musical progress and gameplay progress should feel linked, not coincidental

Director responsibilities:

- decide which lanes are active:
  - `foundation`
  - `secondary_loop`
  - `primary_loop`
  - `sparkle`
  - later support / answer / special layers
- decide which carrier type should serve each lane:
  - spawner
  - drawsnake
  - composer group
  - ghost/tail continuation
- own replacement policy when a carrier dies
- own section/density/difficulty ramp targets together instead of separately
- expose explicit handoff policy rather than relying on scattered local heuristics

Backlog tasks:

- define a single runtime director state that represents:
  - active lanes
  - desired carrier counts
  - current combat pressure
  - current musical pressure
- move lane activation and carrier assignment decisions behind that director state
- make spawn requests lane-aware instead of only enemy-type-aware
- add a pacing model where gameplay difficulty and musical density can co-ramp or intentionally diverge
- make carrier replacement preserve lane identity by default
- keep local systems as executors of director decisions, not independent policy owners

Important rule:

> The director should decide what the piece and encounter need; carriers and groups should execute that plan.

Design constraint:

- this should not become a giant rewrite before the current lane work stabilizes
- treat it as the next architectural phase once the present slot/lane bugs are under control
- use the current debugging lessons as input to its design, especially around:
  - carrier replacement
  - lane identity persistence
  - gameplay readability
  - difficulty/music co-pacing

Related detailed plan:

- [beat-swarm-enemy-director-plan.md](/d:/Desktop/music-toy/music-toy.github.io/beat-swarm-enemy-director-plan.md)

Follow-up direction under that plan:

- add future low-count `solo carrier` enemies that can hold a full rhythm or melody lane on their own
- use them when the director needs lane continuity without flooding the battlefield with many specials

## Working Rule

Use this as the tuning principle:

> If a note cannot be clearly heard or understood, it should not compete for authority.

That does not always mean "drop it."
It can also mean:

- defer it
- demote it
- soften it
- keep it visual-only

## Priority Order

1. Mix hierarchy and protected audibility
2. Ghost loop scope correction
3. Phrase lock and foreground clarity
4. Anti-repetition and generative base
5. Density and collision control
6. Spawner group refinement
7. Composition-group restraint
8. Base palette and scoped instrument influence
9. Long-horizon musical pacing
10. Controlled instrument introduction
11. Sample leveling and loudness control
12. Sample pitch import and base-note accuracy

## Direction

Stop preserving everything equally.
Present the right things clearly.

---

## Sample Metadata Migration

### Goal

Move `samples.csv` from mostly sound-family tagging toward a small musical-role and behavior model, without breaking existing palette, theme, or legacy runtime paths.

This matters because the current problems are mostly about:

- hierarchy
- audibility
- protected-loop eligibility
- call/answer eligibility
- support restraint

not simple instrument-family browsing.

### Migration Principles

- do not remove legacy tags yet
- add new metadata alongside old metadata
- keep runtime fallback paths safe
- keep the taxonomy small and reliable
- prefer conservative inference over false certainty

### Proposed Metadata

Required:

- `music_role`
  - `foundation`
  - `foreground`
  - `support`
  - `accent`
- `music_behavior`
  - `loop`
  - `oneshot`
  - `short`
  - `sustain`
  - `rhythmic`
  - `melodic`
- `runtime_family`
  - optional browsing / compatibility family such as `bass`, `percussion`, `lead`, `fx`, `synth`
- `needs_review`
  - marks rows where inference is uncertain

Optional:

- `music_eligibility`
  - small runtime-facing eligibility flags such as:
  - `protected_loop`
  - `call_source`
  - `answer_source`
  - `accent_only`

### Important Documentation Requirement

Each new metadata category must be clearly described inside or alongside `samples.csv`.

This is not only for runtime migration.
It also needs to work as guidance for future sound creation and sound sourcing.

For every new field, the project should explain:

- what the category means musically
- what it is for in Beat Swarm/runtime selection
- what it is not for
- example sample types that fit it
- example sample types that should not be tagged that way

That note is important because `samples.csv` is also going to be used as a human-facing guide when making or finding new sounds.

### Suggested Phases

1. Preserve all existing columns and tags.
2. Add the new metadata columns without changing runtime behavior.
3. Build a deterministic migration script that infers new fields conservatively and marks uncertain rows.
4. Add compatibility helpers so code can prefer new metadata and safely fall back to legacy data.
5. Manually review the Beat Swarm-critical sample set first.
6. Migrate Beat Swarm runtime decisions to prefer the new metadata.
7. Add validation/reporting for bad or conflicting metadata.
8. Only later reduce legacy-tag influence.

### Why This Is Valuable

Done well, this gives Beat Swarm a better basis for deciding:

- what must stay audible
- what may own a protected loop
- what should act as support
- what should stay brief
- what is appropriate for call-and-answer

without exploding the tag system into a large taxonomy.

---

## Call-and-Answer System - Current State

The call-and-answer system is now functioning technically and beginning to work musically, but it still needs hierarchy control.

### Observed Behaviour

- The system now generates valid delayed call/response pairs and Music Lab can measure them reliably
- Reply size is no longer stuck at single-note answers in every run
- The remaining failure mode is not "no response exists"
- The remaining failure mode is that response/support material can still become too present and muddy the foreground

### Key Problems

1. **Calls still need admission discipline**

This was previously a major problem.
It has been reduced, but still needs watching when density rises.

2. **Responses still need better hierarchy**

Reply size and phrase shape have improved.
The main risk now is replies reading like a second lead instead of support.

3. **Timing was too immediate**

This has improved materially.
Delayed replies now happen; immediate stitching is no longer the main issue.

4. **Mix/masking still matters**

Responses can still become either too hidden or too assertive depending on density.
The current risk is support motion muddying the main foreground line.

5. **Metrics are finally usable**

We now have usable measures for response rate, audible response rate, and average response size.
The next task is using those metrics to keep replies subordinate while preserving their recognisability.

---

### Result

> The system can now produce a real "statement -> space -> reply" pattern,
> but it still needs better hierarchy so the reply reads as support rather than a competing lead.

---

### Required Direction

Call-and-answer should stay phrase-based and ownership-driven:

- Only strong musical events should create calls
- Responses should stay in the **short phrase fragment (2-4 note)** range
- Responses should preserve **rhythm or contour identity**
- Responses should arrive with space, not immediate stitching
- Responses should remain clearly subordinate when a real foreground loop is already active

---

### Goal

> The player should clearly hear:
>
> - one idea speak
> - a moment of space
> - a recognisable reply

instead of layered note chatter.

---
