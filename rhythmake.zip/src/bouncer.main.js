import { patternLearningStartTick } from './pattern-learning-anchor.js';
import { panelTransportBindings } from './panel-transport.js';
import { admittedToyVisual } from './playback-visual-events.js';
// c:\Users\Russ_\Desktop\music-toy\music-toy.github.io\src\bouncer.main.js
import { getToyLifecycle, mountToySurface } from './baseMusicToy/index.js';
import { makeEdgeControllers, drawEdgeBondLines, handleEdgeControllerEdit, mapControllersByEdge, randomizeControllers, drawEdgeDecorations } from './bouncer-edges.js';
import { stepBouncer } from './bouncer-step.js';
import { noteList } from './utils.js';
import { TICKS_PER_BAR, TICKS_PER_BEAT, audioTimeToTick, ensureAudioContext, getLoopInfo, getTransportState, setToyMuted, isRunning, tickToAudioTime } from './audio-core.js';
import { triggerInstrument } from './audio-samples.js';
import { randomizeRects, EDGE_PAD as EDGE, hitRect, whichThirdRect, drawThirdsGuides } from './toyhelpers.js';
import { drawBlocksSection } from './ripplesynth-blocks.js';
// board scale via rect baseline (rippler-style)
import { createImpactFX } from './bouncer-impact.js';
import { installVolumeUI } from './baseToy/volume-ui.js';
import { createBouncerDraw } from './bouncer-render.js';
import { installAdvancedCubeUI } from './bouncer-adv-ui.js';
import { installBouncerInteractions } from './bouncer-interactions.js';
import { createBouncerParticles } from './bouncer-particles.js';
import { getPoliteDensityForToy } from './polite-random.js';
import { buildPentatonicPalette, processVisQ as processVisQBouncer } from './bouncer-actions.js';
import { updateLaunchBaseline, getLaunchDiag } from './bouncer-geom.js';
import { installSpeedUI } from './bouncer-speed-ui.js';
import { installQuantUI } from './bouncer-quant-ui.js';
import { installBouncerOSD } from './bouncer-osd.js';
import { circleRectHit } from './bouncer-helpers.js';
import { activatePlaybackInstance, deactivatePlaybackInstance, ensurePlaybackInstance, getPlaybackInstance, getPlaybackLocalTick, removePlaybackInstance } from './playback-instances.js';
import { bouncerEventsInWindow, getBouncerReplayCompletionTick, interpolateBouncerTrajectory, nextBouncerRecordingStartTick, normalizeBouncerPattern, normalizeBouncerTrajectory, quantizeBouncerOffsetTick, recordBouncerTrajectorySample } from './bouncer-transport.js';
import { bumpToyAudioGen } from './toy-audio.js';
import { createBouncerVisualEventQueue } from './bouncer-visual-events.js';
import { acceptBouncerPendingHit, clearBouncerPendingHit, clearBouncerPendingHits } from './bouncer-pending-hit.js';
import {
  BOUNCER_LOGICAL_HEIGHT,
  BOUNCER_LOGICAL_WIDTH,
  bouncerClientToLogical,
  getBouncerRenderTransform,
} from './bouncer-viewport-space.js';
const noteValue = (list, idx)=> list[Math.max(0, Math.min(list.length-1, (idx|0)))];
const BOUNCER_BARS_PER_LIFE = 1;
const MAX_SPEED = 700, LAUNCH_K = 0.9;
const BASE_BLOCK_SIZE = 44, BASE_CANNON_R = 10, BASE_BALL_R = 7;

const DBG_RESPAWN = ()=> window.BOUNCER_RESPAWN_DBG;

export function createBouncer(selector){
  const shell = (typeof selector==='string') ? document.querySelector(selector) : selector; if (!shell) return null;
  const panel = shell.closest('.toy-panel') || shell;
  const { isRunning, getLoopInfo, getTransportState, audioTimeToTick, tickToAudioTime } = panelTransportBindings(panel);
  // Prevent double-initialization, which can cause duplicate draw loops and event listeners.
  if (panel.__bouncer_main_instance) return panel.__bouncer_main_instance;
  const lifecycle = getToyLifecycle(panel);
  // Prevent double-initialization, which can cause duplicate draw loops and event listeners.
  // Enable OSD + quant debug by default (can be turned off later)
  try{ if (!panel.dataset.debug) panel.dataset.debug = '1'; }catch{}
  try{ window.BOUNCER_QUANT_DBG = true; }catch{}
  let instrument = (panel.dataset.instrument || 'retro_square'); lifecycle.listen(panel, 'toy-instrument', (e)=>{ instrument = (e?.detail?.value)||instrument; });
  let speedFactor = parseFloat((panel?.dataset?.speed)||'1.60'); // +60% faster default // 0.60 = calmer default
  const toyId = panel.id || panel.dataset.toyid || `bouncer-${Math.random().toString(36).slice(2, 8)}`;
  try { panel.dataset.toyid = toyId; } catch {}
  panel.__audioToyId = toyId;
  const initialTransport = getTransportState();
  if (isRunning()) activatePlaybackInstance(panel.id, initialTransport.currentTick, { loopLengthTicks: TICKS_PER_BAR, quantize: true });
  else ensurePlaybackInstance(panel.id, { active: true, startTick: 0, loopLengthTicks: TICKS_PER_BAR });

  // --- Persistence hooks ---
  // Define these early so they are available for pending state application.
  panel.__getBouncerSnapshot = () => {
    try{
      const loopRec=visQ.loopRec;
      const blocksSnap = Array.isArray(blocks) ? blocks.map(b=> b ? ({ x: Math.round(b.x||0), y: Math.round(b.y||0), w: Math.round(b.w||b.size||BASE_BLOCK_SIZE), h: Math.round(b.h||b.size||BASE_BLOCK_SIZE), active: !!b.active, noteIndex: (b.noteIndex|0) }) : null) : [];
      const edgesSnap = Array.isArray(edgeControllers) ? edgeControllers.map(c=> c ? ({ x: Math.round(c.x||0), y: Math.round(c.y||0), w: Math.round(c.w||BASE_BLOCK_SIZE), h: Math.round(c.h||BASE_BLOCK_SIZE), active: !!c.active, noteIndex: (c.noteIndex|0), edge: c.edge }) : null) : [];
      const speed = (typeof __getSpeed === 'function') ? __getSpeed() : (parseFloat(panel.dataset.speed||'')||undefined);
      const quantDiv = (typeof __getQuantDiv === 'function') ? __getQuantDiv() : (parseFloat(panel.dataset.quantDiv||panel.dataset.quant||'')||undefined);
      const ac = ensureAudioContext();
      const now = ac ? ac.currentTime : 0;
      const ballSnap = (ball && typeof ball==='object') ? ({ x: Math.round(ball.x||0), y: Math.round(ball.y||0), vx: Number(ball.vx||0), vy: Number(ball.vy||0), r: Number(ball.r||ballR()), flightTimeRemaining: (ball.flightEnd != null) ? Math.max(0, ball.flightEnd - now) : undefined }) : null;
      const lastLaunchSnap = (lastLaunch && typeof lastLaunch==='object') ? ({ x: Math.round(lastLaunch.x||0), y: Math.round(lastLaunch.y||0), vx: Number(lastLaunch.vx||0), vy: Number(lastLaunch.vy||0) }) : null;
      const nextLaunchAtRemaining = (nextLaunchAt != null) ? Math.max(0, nextLaunchAt - now) : undefined;
      if (DBG_RESPAWN()) console.log('[BNC_DBG] getSnapshot', {
        now: now.toFixed(3),
        flightEnd: ball?.flightEnd?.toFixed(3),
        flightTimeRemaining: ballSnap?.flightTimeRemaining?.toFixed(3),
        nextLaunchAt: nextLaunchAt?.toFixed(3),
        nextLaunchAtRemaining: nextLaunchAtRemaining?.toFixed(3),
      });
      const loopRecSnap = {
        mode: loopRec.mode,
        pattern: normalizeBouncerPattern(loopRec.pattern),
        trajectory: normalizeBouncerTrajectory(loopRec.trajectory),
        signature: loopRec.signature,
      };
      if (DBG_RESPAWN()) console.log('[BNC_DBG] getSnapshot: Saving loopRec', { mode: loopRecSnap.mode, patternLen: loopRecSnap.pattern.length, signature: loopRecSnap.signature?.slice(0,30) });
      return { instrument, speed, quantDiv, blocks: blocksSnap, edges: edgesSnap, ball: ballSnap, lastLaunch: lastLaunchSnap, nextLaunchAtRemaining, handleFx: handle._fx, handleFy: handle._fy, loopRec: loopRecSnap };
    }catch(e){ return { instrument }; }
  };
  panel.__applyBouncerSnapshot = (st)=>{
    try{
      const loopRec=visQ.loopRec;
      if (!st || typeof st !== 'object') return;
      if (st.instrument){
        instrument = st.instrument;
        panel.dataset.instrument = st.instrument;
        panel.dataset.instrumentPersisted = '1';
        try{ panel.dispatchEvent(new CustomEvent('toy:instrument', { detail:{ name: st.instrument, value: st.instrument }, bubbles:true })); }catch{}
      } else {
        delete panel.dataset.instrumentPersisted;
      }
      if (DBG_RESPAWN()) console.log('[BNC_DBG] applySnapshot: Received state', {
        ballFlightTimeRemaining: st.ball?.flightTimeRemaining,
        nextLaunchAtRemaining: st.nextLaunchAtRemaining,
      });
      if (typeof st.speed === 'number'){
        try{ panel.dataset.speed = String(st.speed); const r = panel.querySelector('.bouncer-speed-ctrl input[type="range"]'); if (r){ r.value = String(st.speed); r.dispatchEvent(new Event('input', { bubbles:true })); } }catch{}
      }
      if (typeof st.quantDiv !== 'undefined'){
        try{ panel.dataset.quantDiv = String(st.quantDiv); const sel = panel.querySelector('.bouncer-quant-ctrl select'); if (sel){ sel.value = String(st.quantDiv); sel.dispatchEvent(new Event('change', { bubbles:true })); } }catch{}
      }
      // Blocks
      if (Array.isArray(st.blocks) && Array.isArray(blocks)){
        for (let i=0;i<Math.min(blocks.length, st.blocks.length); i++){
          const src = st.blocks[i]; const dst = blocks[i]; if (!src || !dst) continue;
          dst.x = Math.round(src.x||dst.x); dst.y = Math.round(src.y||dst.y);
          dst.w = Math.round(src.w||dst.w); dst.h = Math.round(src.h||dst.h);
          dst.active = !!src.active; dst.noteIndex = (src.noteIndex|0);
        }
        try{ syncBlockAnchors(); }catch{}
      }
      // Edge controllers
      try{ ensureEdgeControllers(physW(), physH()); }catch{}
      if (Array.isArray(st.edges) && Array.isArray(edgeControllers)){
        const mapByEdge = (arr)=>{ const m={}; try{ arr.forEach((c,i)=>{ if (c && c.edge) m[c.edge]= {c,i}; });
    }catch{} return m; };
        const srcMap = mapByEdge(st.edges);
        const dstMap = mapByEdge(edgeControllers);
        const keys = ['left','right','top','bot'];
        keys.forEach(k=>{
          const src = srcMap[k]?.c; const dst = dstMap[k]?.c; if (!src || !dst) return;
          dst.x = Math.round(src.x||dst.x); dst.y = Math.round(src.y||dst.y);
          dst.w = Math.round(src.w||dst.w); dst.h = Math.round(src.h||dst.h);
          dst.active = !!src.active; dst.noteIndex = (src.noteIndex|0);
        });
    }
      // Handle spawn handle position
      try{
        if (typeof st.handleFx === 'number') handle._fx = Math.max(0, Math.min(1, st.handleFx));
        if (typeof st.handleFy === 'number') handle._fy = Math.max(0, Math.min(1, st.handleFy));
        const w = physW(), h = physH();
        if (w>0 && h>0){
          handle.x = Math.round(EDGE + (handle._fx ?? 0.5) * Math.max(1, w-EDGE*2));
          handle.y = Math.round(EDGE + (handle._fy ?? 0.5) * Math.max(1, h-EDGE*2));
        }
      }catch{}

      // Loop recorder state
      try{
        if (st.loopRec && typeof st.loopRec === 'object') {
          if (DBG_RESPAWN()) console.log('[BNC_DBG] applySnapshot: Restoring loopRec', { mode: st.loopRec.mode, patternLen: st.loopRec.pattern?.length, signature: st.loopRec.signature?.slice(0,30) });
          if (st.loopRec.mode) loopRec.mode = st.loopRec.mode;
          if (Array.isArray(st.loopRec.pattern)) loopRec.pattern = normalizeBouncerPattern(st.loopRec.pattern);
          if (Array.isArray(st.loopRec.trajectory)) loopRec.trajectory = normalizeBouncerTrajectory(st.loopRec.trajectory);
          if (loopRec.mode === 'replay' && loopRec.trajectory.length < 2) {
            loopRec.mode = 'record';
            loopRec.signature = '';
          }
          loopRec.signature = st.loopRec.signature || '';
          // Reset runtime-only state that shouldn't be persisted
          loopRec.lastBarIndex = -1; loopRec.scheduledBarIndex = -999; loopRec.seen = new Set();
        }
      }catch{}

      // Ball + lastLaunch
      try{
        if (st.ball && typeof st.ball==='object'){
          // Defer calculating absolute end time until transport resumes.
          ball = { x: Number(st.ball.x||0), y: Number(st.ball.y||0), vx: Number(st.ball.vx||0), vy: Number(st.ball.vy||0), r: Number(st.ball.r||ballR()), active:true, flightTimeRemaining: st.ball.flightTimeRemaining, flightEnd: undefined };
        }
        if (st.lastLaunch && typeof st.lastLaunch==='object'){
          lastLaunch = { x: Number(st.lastLaunch.x||0), y: Number(st.lastLaunch.y||0), vx: Number(st.lastLaunch.vx||0), vy: Number(st.lastLaunch.vy||0) };
        }
        if (typeof st.nextLaunchAtRemaining === 'number') {
          nextLaunchAtRemaining = st.nextLaunchAtRemaining;
          nextLaunchAt = null; // Clear absolute time
        }
        // Imported replay belongs to the geometry and launch just restored.
        // A persisted signature may describe a different viewport size.
        if(loopRec.mode === 'replay' && loopRec.trajectory.length >= 2)
          loopRec.signature = stateSignature();
        if (DBG_RESPAWN()) console.log('[BNC_DBG] applySnapshot: Applied state', {
            ballFlightTimeRemaining: ball?.flightTimeRemaining,
            nextLaunchAtRemaining: nextLaunchAtRemaining,
            nextLaunchAt: nextLaunchAt
        });
    }catch{}

    }catch(e){ try{ console.warn('[bouncer] apply snapshot failed', e); }catch{} }
  };

  // Apply pending snapshots after recorder, geometry and launch state exist.
  const canvas = document.createElement('canvas');
  canvas.className = 'bouncer-canvas';
  const surface = mountToySurface(panel, canvas);
  const host = surface.host;
  const resizeCanvasForDPR = (_canvas, ctx) => surface.resize(ctx);

  if (host && getComputedStyle(host).position === 'static') {
    host.style.position = 'relative';
  }
  let swipeLabel = host.querySelector('.bouncer-swipe-label');
  if (!swipeLabel) {
    swipeLabel = document.createElement('div');
    swipeLabel.className = 'toy-action-label bouncer-swipe-label';
    swipeLabel.textContent = 'SWIPE';
    host.appendChild(swipeLabel);
  }

  const applySwipePrompt = () => {
    const rect = host.getBoundingClientRect();

    // Compensate for board zoom so SWIPE stays the same relative size to the toy
    let scale = 1;
    try {
      const board = document.getElementById('board');
      if (board) {
        const tf = (getComputedStyle(board).transform || getComputedStyle(board).webkitTransform || '');
        if (tf && tf !== 'none') {
          const m = tf.match(/matrix\(([^)]+)\)/);
          if (m) {
            const parts = m[1].split(',');
            if (parts.length >= 2) {
              const a = parseFloat(parts[0]);
              const b = parseFloat(parts[1]);
              const s = Math.sqrt(a * a + b * b);
              if (Number.isFinite(s) && s > 0) scale = s;
            }
          }
        }
      }
    } catch {}

    const unscaledMin = Math.min(rect.width || 0, rect.height || 0) / (scale || 1);
    const minSide = unscaledMin;
    const sizePx = minSide > 0 ? Math.max(36, Math.floor(minSide * 0.25)) : 48;
    swipeLabel.style.fontSize = sizePx + 'px';
    swipeLabel.style.opacity = host.dataset.bouncerPromptDismissed === '1' ? '0' : '0.55';
  };
  applySwipePrompt();
  if (!host.__bouncerPromptRO && typeof ResizeObserver !== 'undefined') {
    try {
      const ro = new ResizeObserver(() => applySwipePrompt());
      ro.observe(host);
      host.__bouncerPromptRO = ro;
      lifecycle.addCleanup(() => { ro.disconnect(); delete host.__bouncerPromptRO; });
    } catch {}
  }

  if (!canvas.__bouncerPromptHooked) {
    const dismiss = () => {
      if (host.dataset.bouncerPromptDismissed === '1') return;
      host.dataset.bouncerPromptDismissed = '1';
      swipeLabel.style.opacity = '0';
    };
    lifecycle.listen(canvas, 'pointerdown', dismiss);
    lifecycle.listen(canvas, 'pointermove', dismiss);
    canvas.__bouncerPromptHooked = true;
  }

  try{ canvas.removeAttribute('data-lock-scale'); canvas.style.transform=''; }catch{};
  // Ensure a footer exists and volume UI is installed (matches routing via data-toyid)
  try{
    let footer = panel.querySelector('.toy-footer');
    if (!footer){ footer = document.createElement('div'); footer.className = 'toy-footer'; panel.appendChild(footer); }
    installVolumeUI(footer);
  }catch{}
  const ctx = canvas.getContext('2d', { alpha:false });
  // The legacy sizing helper has been removed. The new toy-layout-manager.js
  // handles canvas sizing automatically. This dummy object prevents runtime
  // errors from any remaining legacy debug code that might reference it.
  const sizing = { scale: 1, setZoom: () => {} };

  // Simulation is permanently authored in a 300x300 toy-local space.
  // Panel size, board transforms, and DPR affect presentation only.
  const physW = () => BOUNCER_LOGICAL_WIDTH;
  const physH = () => BOUNCER_LOGICAL_HEIGHT;
  function lockPhysWorld() {}
  
  function renderScale(){
    const transform = getBouncerRenderTransform({
      displayWidth: canvas.clientWidth || BOUNCER_LOGICAL_WIDTH,
      displayHeight: canvas.clientHeight || BOUNCER_LOGICAL_HEIGHT,
      backingWidth: canvas.width || canvas.clientWidth || BOUNCER_LOGICAL_WIDTH,
      backingHeight: canvas.height || canvas.clientHeight || BOUNCER_LOGICAL_HEIGHT,
    });
    return { sx: transform.scaleX, sy: transform.scaleY, tx: transform.offsetX, ty: transform.offsetY };
  }
  function toWorld(pt){
    const { sx, sy, tx, ty } = renderScale();
    return { x: (pt.x - tx) / (sx || 1), y: (pt.y - ty) / (sy || 1) };
  }
  const clientToLogical = (point) => bouncerClientToLogical(canvas, point);
// On-screen debug (set panel.dataset.debug='1' to enable)
  const __osd = document.createElement('div');
  __osd.style.cssText='position:absolute;left:6px;top:6px;padding:0;background:transparent;color:#fff;font:12px/1.3 monospace;z-index:10;border-radius:4px;display:none;pointer-events:none';
  // Do not append OSD text by default anymore; header flash serves as the visual clock.
  function __tickOSD(){
    // Always compute quant tick and flash header; keep OSD hidden
    __osd.style.display = 'none';
    try {
      if (window.BOUNCER_QUANT_DBG) {
        const li = (typeof getLoopInfo==='function') ? getLoopInfo() : null;
        // Read quant divisor robustly: live <select> value > getter > dataset > default
        let div = NaN;
        try{
          const sel = panel.querySelector('.bouncer-quant-ctrl select');
          if (sel) { const vv = parseFloat(sel.value); if (Number.isFinite(vv)) div = vv; }
        }catch{}
        if (!Number.isFinite(div)){
          try{ const v2 = (__getQuantDiv && __getQuantDiv()); if (Number.isFinite(v2)) div = v2; }catch{}
        }
        if (!Number.isFinite(div)){
          const ds = parseFloat(panel.dataset.quantDiv || panel.dataset.quant || '');
          if (Number.isFinite(ds)) div = ds;
        }
        if (!Number.isFinite(div)) div = 4;
        const beatLen = li ? li.beatLen : 0;
        const grid = (div>0 && beatLen) ? (beatLen/div) : 0;
        const now = (typeof ensureAudioContext==='function') ? ensureAudioContext().currentTime : 0;
        const rel = li ? Math.max(0, now - li.loopStartTime) : 0;
        const k = grid>0 ? Math.ceil((rel+1e-6)/grid) : -1;
        // Flash quant dot next to dropdown on quant tick
        if (!window.__bouncerLastQuantTick) window.__bouncerLastQuantTick = new WeakMap();
        const last = window.__bouncerLastQuantTick.get(panel) ?? -1;
        if (k !== last && k >= 0) {
          window.__bouncerLastQuantTick.set(panel, k);
          const dot = panel.querySelector('.bouncer-quant-ctrl .bouncer-quant-dot');
          if (dot && dot.animate){
            dot.animate([
              { transform:'scale(1)', background:'rgba(255,255,255,0.35)', boxShadow:'0 0 0 0 rgba(255,255,255,0.0)' },
              { transform:'scale(1.35)', background:'#fff', boxShadow:'0 0 10px 4px rgba(255,255,255,0.65)' },
              { transform:'scale(1)', background:'rgba(255,255,255,0.35)', boxShadow:'0 0 0 0 rgba(255,255,255,0.0)' }
            ], { duration: Math.max(140, Math.min(260, (grid||0.2)*700 )), easing: 'ease-out' });
    }
        }
      }
    } catch {}
    lifecycle.requestFrame(__tickOSD);
  }
  lifecycle.requestFrame(__tickOSD); /*OSD_DEBUG*/

  const __getSpeed = installSpeedUI(panel, sizing, parseFloat((panel?.dataset?.speed)||'1.60'));
  // Default quant to 1/2 (div=2) if not provided
  try{ if (!panel.dataset.quantDiv && !panel.dataset.quant) panel.dataset.quantDiv = '2'; }catch{}
  const __getQuantDiv = installQuantUI(panel, parseFloat(panel?.dataset?.quantDiv||panel?.dataset?.quant||'2'));
  // apply speed changes to queued launch
  let __speedCache = (__getSpeed?__getSpeed():1);
  lifecycle.listen(panel, 'toy-speed', (e)=>{ const ns = (e && e.detail && Number(e.detail.value)) ? e.detail.value : (__getSpeed?__getSpeed():1); const os = __speedCache || 1; const ratio = os ? (ns/os) : 1; __speedCache = ns; try{ if (lastLaunch && Number.isFinite(ratio) && ratio>0){ lastLaunch.vx *= ratio; lastLaunch.vy *= ratio; } }catch{} });

  // When quantization changes, reset the loop to start a new recording.
  // This prevents the old pattern from replaying with mismatched timing.
  lifecycle.listen(panel, 'bouncer:quant', () => {
    const loopRec=visQ.loopRec;
    if (loopRec) {
      // Immediately clear the old pattern and switch to record mode.
      // This prevents the old notes from replaying with the new timing.
      // The signature is also invalidated to ensure a clean slate on the next bar.
      loopRec.pattern.length = 0;
      loopRec.trajectory.length = 0;
      clearAllPendingHits();
      replayVisualEvents.clear();
      bumpToyAudioGen(toyId, 'bouncer-state-change');
      loopRec.mode = 'record';
      loopRec.signature = ''; // Guarantees onNewBar will confirm the reset.
      clearAllPendingHits();
      replayVisualEvents.clear();
      bumpToyAudioGen(toyId, 'bouncer-quant-change');
      loopRec.pendingRecordTick = nextBouncerRecordingStartTick(getTransportState().currentTick, TICKS_PER_BAR);
      panel.__seqRev = (panel.__seqRev || 0) + 1;
      panel.__forceSchedulerReset = true;
    }
  });

  const worldW = physW;
  const worldH = physH;
  const blockSize = () => BASE_BLOCK_SIZE;
  const ballR = () => BASE_BALL_R;
  // background particles (polite density)
  const particles = createBouncerParticles(physW, physH, { count: getPoliteDensityForToy(panel, 240, 640) });


  // interaction state
  let handle = { x: physW()*0.22, y: physH()*0.5, userPlaced: false, vx: 0, vy: 0 };
  handle._fx = 0.22; handle._fy = 0.5;
  let draggingHandle=false, dragStart=null, dragCurr=null;
  let draggingBlock=false, dragBlockRef=null, dragOffset={dx:0,dy:0};
  let zoomDragCand=null, zoomDragStart=null, zoomTapT=null;
  let tapCand=null, tapStart=null, tapMoved=false;
  let lastLaunch=null, launchPhase=0, nextLaunchAt=null, prevNow=0, ball=null, __unmuteAt = 0, __resumeHandled = false,
      nextLaunchAtRemaining = null, wasRunning = null;
  // __resumeHandled and wasRunning are no longer needed for ball state restoration.
  // The presence of ball.flightTimeRemaining is the sole indicator.
  function stateSignature(){
    try{
      const parts = [];
      // blocks (position/size/active/noteIndex)
      if (Array.isArray(blocks)){
        for (let i=0;i<blocks.length;i++){
          const b=blocks[i]; if (!b) continue;
          parts.push(i, Math.round(b.x), Math.round(b.y), Math.round(b.w||b.size||36), Math.round(b.h||b.size||36), b.active?1:0, b.noteIndex|0);
        }
      }
      if (Array.isArray(edgeControllers)) {
        for (let i = 0; i < edgeControllers.length; i += 1) {
          const c = edgeControllers[i]; if (!c) continue;
          parts.push('edge', i, c.edge, Math.round(c.x), Math.round(c.y), c.active ? 1 : 0, c.noteIndex | 0);
        }
      }
      // launch vector/pos
      const L = lastLaunch || {};
      parts.push('launch', Math.round(L.x||0), Math.round(L.y||0), Math.round((L.vx||0)*100), Math.round((L.vy||0)*100));
      return parts.join(',');
    }catch{ return 'sig_err'; }
  }
  function barIndexOfTime(li, t){ return Math.floor(Math.max(0, t - li.loopStartTime) / li.barLen); }
  function barStartOfIndex(li, k){ return li.loopStartTime + k * li.barLen; }
  function onNewBar(li, k){
    const loopRec = visQ.loopRec; // Always use the instance-specific loopRec
    const sig = stateSignature();
    const changed = (sig !== loopRec.signature);
    if (DBG_RESPAWN()) console.log(`[BNC_DBG] onNewBar (k=${k}): mode=${loopRec.mode}, changed=${changed}, patternLen=${loopRec.pattern.length}, sig=${sig.slice(0,30)}...`);

    if (changed){
      loopRec.signature = sig;
      loopRec.mode = 'record';
         if ((globalThis.BOUNCER_DBG_LEVEL|0)>=1) console.log('[bouncer-rec] loop reset: state changed; recording new bar');
      loopRec.pattern.length = 0;
      loopRec.trajectory.length = 0;
      loopRec.recordingStartTick = nextBouncerRecordingStartTick(getTransportState().currentTick, TICKS_PER_BAR);
      loopRec.recordingStartTick = patternLearningStartTick(panel, getPlaybackInstance(panel.id),
        getTransportState().currentTick, loopRec.recordingStartTick);
      const instance = panel.__sequenceDefinitionId ? getPlaybackInstance(panel.id)
        : activatePlaybackInstance(panel.id, loopRec.recordingStartTick, { loopLengthTicks: TICKS_PER_BAR, quantize: false, retrigger: true });
      if (!panel.__sequenceDefinitionId) loopRec.recordingStartTick = instance.startTick;
      // The learned physics body is deliberately not reused. Re-arm the authored
      // launch at the new recording boundary so the replacement pass is complete.
      ball = null;
      nextLaunchAt = lastLaunch ? tickToAudioTime(loopRec.recordingStartTick) : null;
      panel.__seqRev = (panel.__seqRev || 0) + 1;
      panel.__forceSchedulerReset = true;
    } else {
      // If the state hasn't changed, we're done recording. Switch to replay mode
      // if we aren't already in it.
      if (loopRec.mode !== 'replay' && k > 0) {
        // Only switch to replay if a pattern was actually recorded.
        if (loopRec.pattern.length > 0 || loopRec.trajectory.length > 1) {
          loopRec.mode = 'replay';
          // The physics learning pass is this chain link's first turn. Hand off
          // now; the learned pattern/trajectory replays when the chain returns.
          // Standalone Bouncers simply continue into replay on the same timeline.
          if (!panel.__sequenceDefinitionId && (panel.dataset.prevToyId || panel.dataset.nextToyId) && panel.dataset.chainActive === 'true') {
            const completedTick = loopRec.recordingStartTick + TICKS_PER_BAR;
            panel.dispatchEvent(new CustomEvent('chain:next', {
              bubbles: true,
              detail: { completedAt: tickToAudioTime(completedTick) },
            }));
          }
          panel.__forceSchedulerReset = true;
          if ((globalThis.BOUNCER_DBG_LEVEL|0)>=1) console.log('[bouncer-rec] loop recorded — switching to replay (events:', loopRec.pattern.length, ')');
        }
      }
    }
    loopRec.lastBarIndex = k;
    loopRec.scheduledBarIndex = -999;


    loopRec.seen = new Set();
    if (DBG_RESPAWN() || (window && window.BOUNCER_LOOP_DBG)){
      if ((globalThis.BOUNCER_DBG_LEVEL|0)>=1) console.log('[bouncer-rec] new bar', k, 'mode', loopRec.mode, 'changed', changed, 'patLen', loopRec.pattern.length);
    }
  }
  // Spawn debounce to prevent multiple spawns on a single release
  let __spawnLastAt = 0;
  const __spawnCooldown = 0.08; // seconds
  let lastCanvasW=0, lastCanvasH=0;
  // Debug OSD (toggle with globalThis.BOUNCER_DIAG = true)
  try{ installBouncerOSD(panel, sizing, (()=>speedFactor), ()=>ball, ()=>getLaunchDiag?.()); }catch{}
; let lastScale = sizing.scale||1;

  // edge controllers + flash
  let edgeControllers = []; const edgeFlash = { left:0, right:0, top:0, bot:0 };
  function flashEdge(which){ const m = mapControllersByEdge(edgeControllers), c = m && m[which]; if (!c || !c.active) return; if (edgeFlash[which]!==undefined) edgeFlash[which]=1.0; }

  // blocks
  const N_BLOCKS = 4;
  let blocks = Array.from({length:N_BLOCKS}, ()=>({ x:EDGE, y:EDGE, w:blockSize(), h:blockSize(), noteIndex:0, active:true, flash:0, lastHitAT:0 }));
  function syncBlockAnchors(targetBlocks = blocks) {
    for (const block of targetBlocks) {
      if (!block) continue;
      block._fx = block.x / BOUNCER_LOGICAL_WIDTH;
      block._fy = block.y / BOUNCER_LOGICAL_HEIGHT;
      block._fw = block.w / BOUNCER_LOGICAL_WIDTH;
      block._fh = block.h / BOUNCER_LOGICAL_HEIGHT;
    }
  }

  let previewState = null;
  function cloneBlock(src) { return src ? { ...src } : null; }
  function cloneEdgeController(src) { return src ? { ...src } : null; }
  function cloneHandleState(src) {
    if (!src) return { x: 0, y: 0, vx: 0, vy: 0, userPlaced: false };
    return {
      x: Number(src.x || 0),
      y: Number(src.y || 0),
      vx: Number(src.vx || 0),
      vy: Number(src.vy || 0),
      userPlaced: !!src.userPlaced,
      _fx: typeof src._fx === 'number' ? src._fx : undefined,
      _fy: typeof src._fy === 'number' ? src._fy : undefined,
    };
  }

  function ensurePreviewState() {
    if (!previewState) {
      previewState = {
        blocks: blocks.map(cloneBlock),
        edgeControllers: edgeControllers.map(cloneEdgeController),
      };
      try { panel.classList.add('toy-preview-pending'); } catch {}
    }
    return previewState;
  }

  function clearPreviewState() {
    previewState = null;
    try { panel.classList.remove('toy-preview-pending'); } catch {}
  }

  function hasPreviewState() { return !!previewState; }
  function getPreviewState() { return previewState; }
  function markPreviewUpdated() { if (previewState) try { panel.classList.add('toy-preview-pending'); } catch {} }

  

  function updatePreviewBlock(idx, mutator) {
    if (typeof idx !== 'number' || idx < 0) return;
    const preview = ensurePreviewState();
    if (!preview.blocks[idx]) preview.blocks[idx] = cloneBlock(blocks[idx]);
    if (!preview.blocks[idx]) return;
    const original = blocks[idx];
    mutator(preview.blocks[idx], original);
    markPreviewUpdated();
  }

  function updatePreviewEdge(edge, mutator) {
    if (!edge) return;
    const preview = ensurePreviewState();
    const idx = edgeControllers.indexOf(edge);
    if (idx === -1) return;
    if (!preview.edgeControllers[idx]) preview.edgeControllers[idx] = cloneEdgeController(edgeControllers[idx]);
    if (!preview.edgeControllers[idx]) return;
    mutator(preview.edgeControllers[idx], edgeControllers[idx]);
    markPreviewUpdated();
  }

  function commitHandleLaunch() {
    lastLaunch = { x: handle.x, y: handle.y, vx: handle.vx, vy: handle.vy };
    ball = null;
    nextLaunchAt = null;
    // The launch and the recorded trajectory are one authored pattern. A new
    // spawner must not keep replaying the previous shot while cubes have moved.
    const recorder = visQ.loopRec;
    recorder.signature = '';
    recorder.mode = 'record';
    recorder.isInvalid = false;
    recorder.pattern.length = 0;
    recorder.trajectory.length = 0;
    recorder.lastBarIndex = -1;
    panel.__seqRev = (panel.__seqRev || 0) + 1;
    panel.__forceSchedulerReset = true;
  }

  function applyPreviewState() {
    if (!previewState) return;
    if (Array.isArray(previewState.blocks)) {
      previewState.blocks.forEach((src, idx) => {
        const dst = blocks[idx];
        if (src && dst) Object.assign(dst, src);
      });
    }
    if (Array.isArray(previewState.edgeControllers)) {
      previewState.edgeControllers.forEach((src, idx) => {
        const dst = edgeControllers[idx];
        if (src && dst) Object.assign(dst, src);
      });
    }
    if (previewState.handle) {
      Object.assign(handle, previewState.handle);
      handle.userPlaced = !!previewState.handle.userPlaced;
      commitHandleLaunch();
    }
    clearPreviewState();
    try { syncBlockAnchors(); } catch {}
  }

  function isBouncerChained() {
    return !!(panel.dataset.nextToyId || panel.dataset.prevToyId);
  }

  function shouldDeferChanges() {
    const isChainedFollower = !!panel.dataset.prevToyId;
    if (!isChainedFollower && !panel.__sequenceDefinitionId) {
      return false;
    }
    if (typeof isRunning === 'function' && !isRunning()) {
      return false;
    }
    return panel.dataset.chainActive === 'true';
  }

  const isAdvanced = ()=> panel.classList.contains('toy-zoomed') || !!panel.closest('#zoom-overlay');
  function hitTest(x,y){
    for (let i=0;i<blocks.length;i++){ const b=blocks[i]; if (x>=b.x && x<b.x+b.w && y>=b.y && y<b.y+b.h) return i; }
    return -1;
  }
  const advUI = installAdvancedCubeUI(panel, canvas, {
    isAdvanced, toWorld, clientToLogical, getBlocks: ()=> blocks, noteList, onChange: ()=>{}, hitTest
  });

  // visQ is a carrier for the loop recorder state, passed to the physics/render steps.
  // It must be a new object for each toy instance to prevent state bleeding.
  let visQ = { loopRec: { mode: 'record', pattern: [], trajectory: [], signature: '', recordingStartTick: 0, lastBarIndex: -1, scheduledBarIndex: -999, seen: new Set() } };
  const fx = createImpactFX();
  const replayVisualEvents = createBouncerVisualEventQueue();
  const resolveReplayEdgeControllerIndex = (event) => {
    if (event?.edgeControllerIndex != null) return event.edgeControllerIndex;
    if (event?.edgeName == null) return null;
    const edge = { L: 'left', R: 'right', T: 'top', B: 'bot' }[event.edgeName] || event.edgeName;
    const index = edgeControllers.findIndex(item => item?.edge === edge);
    return index >= 0 ? index : null;
  };
  const resolveImpactSource = (event) => {
    if (event?.blockIndex != null) return blocks[event.blockIndex] || null;
    const edgeIndex = resolveReplayEdgeControllerIndex(event);
    return edgeIndex == null ? null : edgeControllers[edgeIndex] || null;
  };
  const clearAllPendingHits = () => clearBouncerPendingHits([...blocks, ...edgeControllers]);
  panel.__applyPlaybackVisual = event => {
    const source=resolveImpactSource(event);
    if(source){source.__playbackFlash=1;clearBouncerPendingHit(source,event.eventId);}
    panel.__pulseHighlight=1;
  };
  lifecycle.listen(panel,'toy:transport-seek',()=>{
    replayVisualEvents.clear();clearAllPendingHits();replayCompletionInstanceId=null;
    for(const source of [...blocks,...edgeControllers])if(source)delete source.__playbackFlash;
    ball=null;nextLaunchAt=null;nextLaunchAtRemaining=null;
  });
  const replayPendingEventId = (event, fireTick, playbackInstanceId) => {
    const source = event?.blockIndex != null ? `block:${event.blockIndex}`
      : event?.edgeControllerIndex != null ? `edge:${event.edgeControllerIndex}` : `edge-name:${event?.edgeName}`;
    return `${playbackInstanceId || panel.id}:${source}:${fireTick}`;
  };
  let pendingHitSequence = 0;
  const queueImpactVisual = (event, audioTime, playbackInstanceId = null, kind = 'note') => {
    replayVisualEvents.enqueue({
      audioTime,
      playbackInstanceId,
      blockIndex: event?.blockIndex,
      edgeControllerIndex: resolveReplayEdgeControllerIndex(event),
      kind,
      impactTick: event?.impactTick,
      fireTick: event?.fireTick,
      eventId: event?.eventId,
    });
  };

// --- anchor-based sizing for blocks & handle (fractions of world size) ---


  // seed positions + palette
  (function seed(){
    const w=physW(), h=physH(); const bx=Math.round(w*0.2), by=Math.round(h*0.2), bw=Math.round(w*0.6), bh=Math.round(h*0.6);
    const pal = buildPentatonicPalette(noteList, 'C4', 'minor', 1);
    for (let i=0;i<blocks.length;i++) blocks[i].noteIndex = pal[i % pal.length];
    randomizeRects(blocks, {x:bx,y:by,w:bw,h:bh}, EDGE);
    try{ syncBlockAnchors(); }catch{}
  })();

  function ensureEdgeControllers(w,h){
    if (!edgeControllers.length){
      edgeControllers = makeEdgeControllers(w, h, blockSize(), EDGE, noteList);
    }else{
      const s=blockSize(), half=s/2; const map=mapControllersByEdge(edgeControllers);
      if (map.left ){ map.left .x=EDGE;        map.left .y=h/2-half; map.left .w=s; map.left .h=s; }
      if (map.right){ map.right.x=w-EDGE-s;   map.right.y=h/2-half; map.right.w=s; map.right.h=s; }
      if (map.top  ){ map.top  .x=w/2-half;   map.top  .y=EDGE;     map.top  .w=s; map.top  .h=s; }
      if (map.bot  ){ map.bot  .x=w/2-half;   map.bot  .y=h-EDGE-s; map.bot  .w=s; map.bot  .h=s; }
    }
  }

  // toy controls
  function velFrom(hx, hy, px, py){
    let dx = (px - hx), dy = (py - hy);
    let len = Math.hypot(dx, dy) || 1;
    let ux = dx/len, uy = dy/len;
    if (len < 3){ ux = 0; uy = -1; }
    const speed = (typeof __getSpeed === 'function') ? __getSpeed() : 1;
    const BASE = 4.8;
    const v = BASE * speed;
    return { vx: ux * v, vy: uy * v };
  }

  
  function doRandom(options = {}) {
    if (!options.previewTarget && shouldDeferChanges()) {
      clearPreviewState();
      const preview = ensurePreviewState();
      preview.blocks = blocks.map(cloneBlock);
      preview.edgeControllers = edgeControllers.map(cloneEdgeController);
      preview.handle = cloneHandleState(handle);
      doRandom({ previewTarget: preview });
      return;
    }

    if (!options.previewTarget && hasPreviewState()) {
      clearPreviewState();
    }

    const previewTarget = options.previewTarget;
    const usingPreview = !!previewTarget;

    const targetBlocks = usingPreview ? previewTarget.blocks : blocks;
    const targetEdges = usingPreview ? previewTarget.edgeControllers : edgeControllers;
    const targetHandle = usingPreview ? previewTarget.handle : handle;

    doRandomCubes(targetBlocks, { skipAnchorSync: usingPreview });
    doRandomNotes(targetEdges, targetBlocks);

    const w = physW(), h = physH();
    const r = ballR();
    const spawnableW = w - 2 * (EDGE + r + 4);
    const spawnableH = h - 2 * (EDGE + r + 4);
    let x, y, attempts = 0;
    const collidables = [...targetBlocks, ...targetEdges].filter(b => b && b.active !== false);

    do {
      x = (EDGE + r + 4) + Math.random() * spawnableW;
      y = (EDGE + r + 4) + Math.random() * spawnableH;
      attempts++;
      if (attempts > 100) {
        console.warn('[bouncer] Could not find a clear spawn point after 100 attempts.');
        break;
      }
    } while (collidables.some(b => circleRectHit(x, y, r, b)));

    const angle = Math.random() * Math.PI * 2;
    const endX = x + Math.cos(angle) * 10;
    const endY = y + Math.sin(angle) * 10;
    const { vx, vy } = velFrom(x, y, endX, endY);

    targetHandle.x = x;
    targetHandle.y = y;
    targetHandle.userPlaced = true;
    targetHandle.vx = vx;
    targetHandle.vy = vy;

    if (w > EDGE * 2 && h > EDGE * 2) {
      targetHandle._fx = (x - EDGE) / (w - EDGE * 2);
      targetHandle._fy = (y - EDGE) / (h - EDGE * 2);
    }

    if (usingPreview) {
      markPreviewUpdated();
      return;
    }

    const isChainedFollower = !!panel.dataset.prevToyId;
    if (shouldDeferChanges()) {
      return;
    }

    if (isChainedFollower || panel.__sequenceDefinitionId) {
      commitHandleLaunch();
    } else {
      if (panel.dataset.nextToyId) {
        panel.dispatchEvent(new CustomEvent('chain:set-active', { bubbles: true }));
      }
      spawnBallFrom({ x, y, vx, vy, r: ballR() });
    }
  }

  function doRandomCubes(targetBlocks = blocks, { skipAnchorSync = false } = {}) {
    const pr = Number(panel?.dataset?.priority || '1') || 1;
    const density = getPoliteDensityForToy(toyId, 1, pr);
    const N = targetBlocks.length;
    const w = physW(), h = physH();
    const baseBW = Math.round(w * 0.6), baseBH = Math.round(h * 0.6);
    const K = Math.max(1, Math.min(N, Math.round(1 + density * (N - 1))));
    const areaScale = 0.5 + 0.5 * density;
    const bw = Math.max(EDGE * 4, Math.round(baseBW * areaScale));
    const bh = Math.max(EDGE * 4, Math.round(baseBH * areaScale));
    const bx = Math.round((w - bw) / 2);
    const by = Math.round((h - bh) / 2);

    randomizeRects(targetBlocks, { x: bx, y: by, w: bw, h: bh }, EDGE);
    if (!skipAnchorSync) {
      try { syncBlockAnchors(targetBlocks); } catch {}
    }

    let picks = [];
    if (K >= N) {
      picks = Array.from({ length: N }, (_, i) => i);
    } else {
      const uniq = [];
      while (uniq.length < K) {
        const rIdx = (Math.random() * N) | 0;
        if (!uniq.includes(rIdx)) uniq.push(rIdx);
      }
      picks = uniq;
    }

    for (let i = 0; i < N; i++) { if (targetBlocks[i]) targetBlocks[i].active = false; }
    for (const i of picks) { if (targetBlocks[i]) targetBlocks[i].active = true; }
  }

  function doRandomNotes(targetEdges = edgeControllers, targetBlocks = blocks) {
    randomizeControllers(targetEdges, noteList);
    const pal = buildPentatonicPalette(noteList, 'C4', 'minor', 1);
    for (let i = pal.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pal[i], pal[j]] = [pal[j], pal[i]];
    }
    for (let i = 0; i < targetBlocks.length; i++) {
      if (targetBlocks[i]) targetBlocks[i].noteIndex = pal[i % pal.length];
    }
  }
  
  function doReset(){
    ball = null; lastLaunch = null;
    visQ.loopRec.pattern.length = 0;
    visQ.loopRec.trajectory.length = 0;
    visQ.loopRec.mode = 'record';
    visQ.loopRec.signature = '';
    clearAllPendingHits();
    replayVisualEvents.clear();
    bumpToyAudioGen(toyId, 'bouncer-reset');
    handle.userPlaced = false;
    handle.vx = 0; handle.vy = 0;
    try { for (const b of blocks){ b.flash = 0; } } catch {}
    try { for (const c of edgeControllers){ c.flash = 0; c.lastHitAT = 0; } } catch {}

    // If this is the head of a chain, reset all downstream toys.
    const isHeadOfChain = !panel.dataset.prevToyId && panel.dataset.nextToyId;
    if (isHeadOfChain) {
      let nextId = panel.dataset.nextToyId;
      let currentPanel = panel;
      while (nextId) {
        const nextPanel = document.getElementById(nextId);
        if (!nextPanel) break;
        nextPanel.dispatchEvent(new CustomEvent('toy-reset', { bubbles: true }));
        currentPanel = nextPanel;
        nextId = currentPanel.dataset.nextToyId;
      }
      // After resetting all followers, make the head active again.
      panel.dispatchEvent(new CustomEvent('chain:set-active', { bubbles: true }));
    }
  }

  function doSoftReset() {
    // This reset is for when a chain is restarted. It should stop the current
    // ball and prevent respawning from old data, but it must NOT clear
    // the user's deliberate placement of the spawner handle.
    ball = null;
    lastLaunch = null;
    nextLaunchAt = null;
    visQ.loopRec.pattern.length = 0;
    visQ.loopRec.trajectory.length = 0;
    visQ.loopRec.mode = 'record';
  }

  lifecycle.listen(panel, 'toy-random', doRandom);
  lifecycle.listen(panel, 'toy-random-cubes', doRandomCubes);
  lifecycle.listen(panel, 'toy-random-notes', doRandomNotes);
  lifecycle.listen(panel, 'toy-reset', doReset);
  lifecycle.listen(panel, 'toy-clear', doReset);
  lifecycle.listen(panel, 'chain:stop', doSoftReset);
  lifecycle.listen(panel, 'toy-zoom', (e)=>{ try{ sizing.setZoom && sizing.setZoom(!!(e?.detail?.zoomed)); updateSpeedVisibility && updateSpeedVisibility(); }catch{} });

  
  // Block geometry is already expressed in the fixed logical surface. Resize
  // changes projection only, so it must not reconstruct physics geometry.
  // Handle position from anchors
  try{
    const w = physW(), h = physH();
    const hfx = (typeof handle._fx==='number') ? handle._fx : (w? handle.x/w : 0.22); if (globalThis.BOUNCER_DEBUG){ console.log('[bouncer] handle anchors', {hfx, hfy:handle._fy, w, h});
    } /*HANDLE_DBG*/
    const hfy = (typeof handle._fy==='number') ? handle._fy : (h? handle.y/h : 0.5);
    handle.x = Math.round(EDGE + hfx * Math.max(1, w - EDGE*2));
    handle.y = Math.round(EDGE + hfy * Math.max(1, h - EDGE*2));
  }catch{}
  // Rebuild/position edge controllers to current world
  try{ ensureEdgeControllers(physW(), physH()); }catch{}
  // Update ball radius and keep inside frame, but do not translate by fx/fy
  try{
    if (ball){
        try{
    // fixed-physics: do not scale current ball position or velocity on resize
    // (we keep ball.x/ball.y/vx/vy as-is to preserve timing across modes)
    // Update spawn baseline as a fallback
    
  }catch{}
 ball.r = ballR();
      const br = ball.r;
      const eL = EDGE + br, eT = EDGE + br, eR = physW() - EDGE - br, eB = physH() - EDGE - br;
      if (ball.x < eL) ball.x = eL;
      if (ball.y < eT) ball.y = eT;
      if (ball.x > eR) ball.x = eR;
      if (ball.y > eB) ball.y = eB;
    }
  }catch{}

  
  // interactions moved to bouncer-adv-ui.js
  // basic ball control helpers (restored after split)
  function spawnBallFrom(L, opts = {}, S_ref = null) {
    const loopRec = visQ.loopRec; // Always use the instance-specific loopRec
    const isRespawn = !!opts.isRespawn;
    const ac = (typeof ensureAudioContext === 'function') ? ensureAudioContext() : null;
    const nowT = Number.isFinite(opts.startAt) ? opts.startAt : (ac ? ac.currentTime : 0);
    if (!isRespawn) {
      // The authored launch is definition state and must be visible to the
      // signature captured below. Capturing before this assignment makes the
      // next render frame falsely invalidate the recording.
      lastLaunch = { vx: L.vx, vy: L.vy, x: L.x, y: L.y };
    }
    if (DBG_RESPAWN()) console.log(`[BNC_DBG] spawnBallFrom (isRespawn: ${isRespawn}) at ${nowT.toFixed(3)}`);

    // User launches start a fresh recording; automatic respawns keep replaying it.
    if (!isRespawn && !Number.isFinite(opts.startAt) && !panel.dataset.prevToyId && panel.dataset.nextToyId) {
        panel.dispatchEvent(new CustomEvent('chain:restart', { bubbles: true }));
    }
    if (!isRespawn) {
        if (DBG_RESPAWN()) console.log(`[BNC_DBG] Resetting loop recorder due to new ball (isRespawn: ${isRespawn})`);

        // A new authored launch invalidates any flashes waiting on the previous
        // recording's AudioContext timeline.
        replayVisualEvents.clear();
        clearAllPendingHits();
        bumpToyAudioGen(toyId, 'bouncer-new-launch');

        // Clear the old pattern and scheduling state together, retaining the shared
        // recorder object. Record mode suppresses replay while the new shot is
        // captured; a stale invalid flag must not silence its later repetitions.
        // AudioContext time keeps advancing before the transport has ever
        // played. A stopped/paused launch belongs at the retained transport
        // position, not at an extrapolated audio-context tick.
        const launchTick = Number.isFinite(opts.startAt) ? audioTimeToTick(opts.startAt) : getTransportState().currentTick;
        const instance = panel.__sequenceDefinitionId ? getPlaybackInstance(panel.id)
          : activatePlaybackInstance(panel.id, launchTick, { loopLengthTicks: TICKS_PER_BAR, quantize: false, retrigger: true });
        const recordingStartTick = panel.__sequenceDefinitionId ? launchTick : instance.startTick;
        Object.assign(loopRec, { signature: '', mode: 'record', isInvalid: false, pattern: [], trajectory: [], recordingStartTick, anchorStartTime: nowT, lastBarIndex: -1, scheduledBarIndex: -999, scheduledKeys: new Set(), seen: new Set() });
        panel.__seqRev = (panel.__seqRev || 0) + 1;
        panel.__forceSchedulerReset = true;
        try {
            loopRec.signature = stateSignature();
            // Record relative to the local spawn time to ensure the full bar is captured.
            loopRec.anchorStartTime = nowT;
        } catch {}
    }

    const o = { x:L.x, y:L.y, vx:L.vx, vy:L.vy, r: ballR() };

    // The replay trajectory needs an authored seam at local tick zero. Waiting
    // for the first render/physics frame leaves its first sample several ticks
    // late, so interpolation can wrap from the end of the recording to a
    // different starting position (or appear to pause at the seam).
    if (loopRec.mode === 'record' && Array.isArray(loopRec.trajectory) && loopRec.trajectory.length === 0) {
      const spawnTick = getTransportState().currentTick;
      const offsetTick = Math.round(spawnTick - Number(loopRec.recordingStartTick || 0));
      if (offsetTick >= 0 && offsetTick < TICKS_PER_BAR) {
        loopRec.trajectory.push({ offsetTick, x: o.x, y: o.y, r: o.r });
      }
    }

    // If not called from within the physics step (i.e., no state object is passed),
    // this is a manual launch. We must update the module-scoped `ball` variable
    // directly so it appears immediately.
    if (!S_ref) {
        ball = o;
    }

    // If paused, defer setting flight time until the first physics step.
    if (typeof isRunning === 'function' && !isRunning()) {
        o.pendingFlightTime = true;
    } else {
        // Set the flight time for the new ball (applies to both launches and respawns).
        try {
          const li = (typeof getLoopInfo==='function') ? getLoopInfo() : null;
          const ac = (typeof ensureAudioContext==='function') ? ensureAudioContext() : null;
          const now = nowT;
          let life = 2.0; // Default lifetime of 2 seconds as a fallback.
          if (li && Number.isFinite(li.barLen) && li.barLen > 0){
            life = li.barLen * BOUNCER_BARS_PER_LIFE;
          }
          nextLaunchAt = now + life;
          if (o) {
            o.flightEnd = nextLaunchAt;
            o.spawnTime = now;
          }
          if (DBG_RESPAWN()) console.log(`[BNC_DBG] spawnBallFrom: Set nextLaunchAt to ${nextLaunchAt.toFixed(3)} (life: ${life.toFixed(3)})`);
        }catch(e){
          if (DBG_RESPAWN()) console.error('[BNC_DBG] Error in spawnBallFrom while setting flightEnd:', e);
        }
    }

    if (!isRespawn) {
        try { fx.onLaunch && fx.onLaunch(L.x, L.y); } catch {}
    }
    // If a state object was passed, update its nextLaunchAt property directly
    // to prevent applyFromStep from overwriting the new value.
    if (S_ref && typeof S_ref === 'object') {
      S_ref.nextLaunchAt = nextLaunchAt;
    }
    if (DBG_RESPAWN()) console.log('[BNC_DBG] spawnBallFrom: Returning new ball object', { flightEnd: o?.flightEnd?.toFixed(3) });
    return o;
  }
function setNextLaunchAt(t){ nextLaunchAt = t; }
  function setBallOut(o){ ball = o; }

    const __aim = { active:false, sx:0, sy:0, cx:0, cy:0 };
// Persistent per-step state for physics (dedupe & spawn windows)
let __justSpawnedUntil = 0;


  function __setAim(a){ try{ if (a && typeof a==='object'){ Object.assign(__aim, a); } }catch(e){} }

  function updateLastLaunch(L) {
    if (!L) return;
    lastLaunch = {
        x: L.x,
        y: L.y,
        vx: L.vx,
        vy: L.vy,
    };
  }

  const installInteractions = () => {
    const interactions = installBouncerInteractions({
      panel,
      setAim: __setAim,
      canvas,
      sizing,
      toWorld,
      clientToLogical,
      EDGE,
      physW,
      physH,
      ballR,
      __getSpeed,
      blocks,
      edgeControllers,
      handle,
      spawnBallFrom,
      setNextLaunchAt,
      setBallOut,
      instrument: () => instrument,
      toyId,
      noteList,
      velFrom,
      syncBlockAnchors,
      isAdvanced: () => panel.classList.contains('toy-zoomed'),
      preview: {
        shouldDefer: shouldDeferChanges,
        updateBlock: updatePreviewBlock,
        updateEdge: updatePreviewEdge,
        clear: clearPreviewState,
        getState: getPreviewState,
        has: hasPreviewState,
        updateLastLaunch: updateLastLaunch,
      },
    });
    lifecycle.addCleanup(() => interactions.dispose());
    };

  lockPhysWorld();

  const buildStateForStep = (now, prevNow)=>{ // now is current AudioContext.currentTime
    // Physics reports raw impact time; this layer owns the single tick-domain quantization.

    const triggerPhysAware = (i,n,t,meta)=>{
      const loopRec = visQ.loopRec;
      if (loopRec?.mode === 'replay') return false;
      try {
        if (loopRec?.mode === 'record') {
          const ac = ensureAudioContext ? ensureAudioContext() : null;
          const impactAudioTime = Number.isFinite(Number(meta?.impactAudioTime)) ? Number(meta.impactAudioTime)
            : ((typeof t === 'number') ? t : (ac?.currentTime || 0));
          const impactTick = audioTimeToTick(impactAudioTime);
          if (panel.__sequenceDefinitionId && (panel.dataset.chainActive !== 'true' || impactTick >= panel.__chainTurnEndTick)) return false;
          const recordingStartTick = Number.isFinite(loopRec.recordingStartTick)
            ? loopRec.recordingStartTick : getPlaybackInstance(panel.id)?.startTick || 0;
          if (impactTick < recordingStartTick) return false;
          const offsetTick = quantizeBouncerOffsetTick(impactTick, recordingStartTick, __getQuantDiv(), {
            ticksPerBeat: TICKS_PER_BEAT, loopLengthTicks: TICKS_PER_BAR,
          });
          const fireTick = recordingStartTick + offsetTick;
          const impactOffsetTick = Math.max(0, Math.min(TICKS_PER_BAR - 1, impactTick - recordingStartTick));
          const source = resolveImpactSource(meta);
          const eventId = `${panel.id}:hit:${++pendingHitSequence}`;
          if (!acceptBouncerPendingHit(source, { impactTick, fireTick, eventId })) return false;

          const scheduledT = Math.max(ac ? ac.currentTime + 0.0008 : 0, tickToAudioTime(fireTick));
          triggerInstrument(i || instrument, n, scheduledT, toyId, {
            context:getPlaybackInstance(panel.id)?.context,eventTick:fireTick,
            onPlaybackScheduled:admission=>admittedToyVisual(panel,{...meta,eventId,fireTick},admission,audioTimeToTick),
          });

          if (Array.isArray(loopRec.pattern)) {
            const event = { note: n, offsetTick, impactOffsetTick, impactTick, fireTick, eventId };
            if (meta?.blockIndex != null) event.blockIndex = meta.blockIndex;
            if (meta?.edgeControllerIndex != null) event.edgeControllerIndex = meta.edgeControllerIndex;
            if (meta?.edgeName != null) event.edgeName = meta.edgeName;
            loopRec.pattern.push(event);
            panel.__seqRev = (panel.__seqRev || 0) + 1;
          }
          return true;
        }
      } catch(e) { return false; }
      try { triggerInstrument(i||instrument, n, (typeof t==='number'?t:undefined), toyId); return true; } catch(e) { return false; }
    };
    const S = {
      panel,
      now,
      lastAT: prevNow || 0,
      EDGE,
      worldW, worldH,
      physW, physH,
      renderScale,
      ensureAudioContext,
      onNewBar,
      mapControllersByEdge,
      flashEdge,
      blocks,
      edgeControllers,
      instrument,
      noteList,
      noteValue,
      getLoopInfo,
      getTransportState,
      ballR,
      handle,
      toyId,
      setToyMuted,
      __unmuteAt,
      lastLaunch,
      nextLaunchAt,
      nextLaunchAtRemaining,
      spawnBallFrom, // The triggerInstrument passed to stepBouncer now accepts a meta object
      triggerInstrument: (i,n,t,meta)=>{ try{ if (window && window.BOUNCER_FORCE_RAW){   return triggerInstrument(i||instrument, n, t, toyId); } }catch{} return triggerPhysAware(i,n,t,meta);},
      triggerInstrumentRaw: (i,n,t)=>triggerInstrument(i||instrument, n, t, toyId),
      getQuantDiv: ()=>{ try{ const v = __getQuantDiv ? __getQuantDiv() : 4; return (Number.isFinite(v)? v : 4); }catch(_){ return 4; } },
      BOUNCER_BARS_PER_LIFE,
      setNextLaunchAt: (t)=>{ nextLaunchAt = t; },
      setBallOut: (o)=>{ ball = o; },
      fx,
      __justSpawnedUntil
    };
    S.deferImpactVisuals = true;
    S.visQ = visQ;
    S.ball = ball; // Use the module-scoped `ball` directly.
    if (DBG_RESPAWN()) {
      console.log('[BNC_DBG] buildStateForStep: Ball state pre-step', { flightEnd: S.ball?.flightEnd?.toFixed(3) });
    }
    return S;
  };

  const applyFromStep = (S)=>{
    if (S){
      visQ = S.visQ || visQ;
      if ('ball' in S) ball = S.ball;
      if ('lastLaunch' in S && S.lastLaunch) lastLaunch = S.lastLaunch;
      // Overwrite nextLaunchAt: spawnBallFrom updates S.nextLaunchAt, and we need to persist it for the next frame.
      if ('nextLaunchAt' in S) {
        const changed = nextLaunchAt !== S.nextLaunchAt;
        const oldVal = nextLaunchAt;
        nextLaunchAt = S.nextLaunchAt;
        if (DBG_RESPAWN() && changed) {
            console.log(`[BNC_DBG] applyFromStep: Updated nextLaunchAt from ${oldVal?.toFixed(3)} to ${nextLaunchAt?.toFixed(3)}`);
        }
      }
      if (typeof S.__justSpawnedUntil === 'number') __justSpawnedUntil = S.__justSpawnedUntil;
      if ('nextLaunchAtRemaining' in S) {
        nextLaunchAtRemaining = S.nextLaunchAtRemaining;
      }
      if (typeof S.__unmuteAt === 'number') __unmuteAt = S.__unmuteAt;
      if (DBG_RESPAWN()) {
        console.log('[BNC_DBG] applyFromStep: Ball state is now', { flightEnd: ball?.flightEnd?.toFixed(3) });
    }
    }
  };

  const captureTrajectorySample = () => {
    const loopRec = visQ.loopRec;
    if (loopRec.mode !== 'record') return false;
    return recordBouncerTrajectorySample(loopRec.trajectory, ball, getTransportState().currentTick, loopRec.recordingStartTick, TICKS_PER_BAR);
  };
  const getDisplayBall = () => {
    const loopRec = visQ.loopRec;
    if (loopRec.mode !== 'replay') return ball;
    const instance = getPlaybackInstance(panel.id);
    const localTick = getPlaybackLocalTick(instance, getTransportState().currentTick);
    if (localTick == null) return null;
    const replayBall = interpolateBouncerTrajectory(loopRec.trajectory, localTick, TICKS_PER_BAR);
    return replayBall ? { ...replayBall, r: replayBall.r || ballR(), active: true } : null;
  };
  panel.__getBouncerReplayPosition = getDisplayBall;
  lifecycle.addCleanup(()=>{delete panel.__getBouncerReplayPosition;delete panel.__applyPlaybackVisual;});
  let replayCompletionInstanceId = null;
  const advanceReplayLifecycle = (transportTick = getTransportState().currentTick) => {
    if (panel.__sequenceDefinitionId) return false;
    const instance = getPlaybackInstance(panel.id);
    const completionTick = getBouncerReplayCompletionTick({
      recorder: visQ.loopRec,
      instance,
      currentTick: transportTick,
      isChained: !!(panel.dataset.prevToyId || panel.dataset.nextToyId),
      isChainActive: panel.dataset.chainActive === 'true',
      completedInstanceId: replayCompletionInstanceId,
    });
    if (completionTick == null) return false;
    replayCompletionInstanceId = instance.id;
    panel.dispatchEvent(new CustomEvent('chain:next', {
      bubbles: true,
      detail: { completedAt: tickToAudioTime(completionTick) },
    }));
    return true;
  };
  panel.__advanceBouncerReplayLifecycle = advanceReplayLifecycle;
  panel.__sequenceTurnEnded = () => {
    const recorder = visQ.loopRec;
    if (recorder.mode === 'record' && !recorder.isInvalid && (recorder.pattern.length || recorder.trajectory.length > 1)) {
      recorder.mode = 'replay';
    }
  };
  lifecycle.addCleanup(() => { delete panel.__sequenceTurnEnded; });
  lifecycle.addCleanup(() => { delete panel.__advanceBouncerReplayLifecycle; });

  // draw loop moved to bouncer-render.js
const draw = createBouncerDraw({ getAim: ()=>__aim,  lockPhysWorld, 
  panel, canvas, ctx, sizing, resizeCanvasForDPR, renderScale, physW, physH, EDGE,
  ensureEdgeControllers: (w,h)=>ensureEdgeControllers(w,h), edgeControllers,
  blockSize, particles, blocks, handle, drawEdgeBondLines, ensureAudioContext, noteList, drawBlocksSection,
  drawEdgeDecorations, edgeFlash,
  getPreviewState,
  applyPreviewState,
  stepBouncer,
  spawnBallFrom,
  getBall: getDisplayBall,
  captureTrajectorySample,
  advanceReplayLifecycle,
  drainScheduledReplayVisuals: (audioTime) => {
    const instance = getPlaybackInstance(panel.id);
    const due = replayVisualEvents.drain(audioTime, instance?.active ? instance.id : '__inactive__', {
      isUpcomingInstance: id => panel.__isSequencePlaybackInstanceUpcoming?.(id, getTransportState().currentTick) || false,
    });
    for (const event of due) {
      const source = resolveImpactSource(event);
      if (event.kind === 'impact') acceptBouncerPendingHit(source, event);
      else clearBouncerPendingHit(source, event.eventId);
    }
    return due;
  },
  rescale: () => {},
  updateLaunchBaseline,
  buildStateForStep, installInteractions, getLastLaunch: ()=>lastLaunch,
  isLearning:()=>visQ.loopRec.mode==='record'&&!!lastLaunch,
  applyFromStep,
  velFrom,
  ballR,
  BOUNCER_BARS_PER_LIFE,
  setBallOut, setNextLaunchAt,
  getLoopInfo, getTransportState
});

// The `draw` function is now self-starting from within `createBouncerDraw`.
// This call is no longer needed and could cause a duplicate render loop.


  function onLoop(_loopStart){} // no-op
  const instanceApi = { dispose: lifecycle.dispose, onLoop, reset: doReset, setInstrument: (n)=>{ instrument = n || instrument; }, element: canvas };

  // Apply any pending snapshot provided before init
  try{
    const pending = panel.__pendingBouncerState;
    if (pending && typeof panel.__applyBouncerSnapshot === 'function'){
      panel.__applyBouncerSnapshot(pending);
      delete panel.__pendingBouncerState;
    }
  }catch{}
  // The bouncer's render loop now drives its own physics when active.
  // The main scheduler's step is only for grid-based toys.
  panel.__sequencerStep = () => {};
  panel.__sequencerEventsInWindow = (fromTick, toTick, instance) => {
    const loopRec = visQ.loopRec;
    // null means the learning pass is not schedulable yet. Returning [] here
    // would consume the window and make the first replay omit its early notes.
    if (loopRec.mode !== 'replay' || loopRec.isInvalid) {
      return null;
    }
    return bouncerEventsInWindow({ instance, pattern: loopRec.pattern, blocks, edgeControllers, fromTick, toTick, includeImpactCues: true });
  };
  panel.__sequencerScheduleEvent = (event, audioTime, metadata = {}) => {
    if (event?.visualOnly === 'impact') {
      const fireTick = metadata.eventTick - event.offsetTick + event.fireOffsetTick;
      const eventId = replayPendingEventId(event, fireTick, metadata.playbackInstanceId);
      queueImpactVisual({ ...event, impactTick: metadata.eventTick, fireTick, eventId }, audioTime, metadata.playbackInstanceId || null, 'impact');
      return;
    }
    if (!event?.note) return;
    const eventId = replayPendingEventId(event, metadata.eventTick, metadata.playbackInstanceId);
    triggerInstrument(instrument, event.note, audioTime, toyId, {
      onPlaybackScheduled:admission=>admittedToyVisual(panel,{...event,eventId,fireTick:metadata.eventTick},admission,audioTimeToTick),
    });
  };
  const activateAtTransport = ({ retrigger = false } = {}) => {
    const state = getTransportState();
    const previous = getPlaybackInstance(panel.id);
    const instance = activatePlaybackInstance(panel.id, state.currentTick, { loopLengthTicks: TICKS_PER_BAR, quantize: state.state === 'playing', retrigger });
    if (instance !== previous) { clearAllPendingHits(); replayVisualEvents.clear(); bumpToyAudioGen(toyId, retrigger ? 'bouncer-retrigger' : 'bouncer-activate'); panel.__forceSchedulerReset = true; }
    return instance;
  };
  panel.__bouncerPlayback = {
    get instance(){ return getPlaybackInstance(panel.id); },
    activate: () => activateAtTransport(),
    retrigger: () => activateAtTransport({ retrigger: true }),
    deactivate: () => { replayVisualEvents.clear(); clearAllPendingHits(); const instance = deactivatePlaybackInstance(panel.id); bumpToyAudioGen(toyId, 'bouncer-deactivate'); panel.__forceSchedulerReset = true; return instance; },
  };
  panel.__bouncerPlaybackState = () => visQ.loopRec;
  lifecycle.listen(panel, 'toy:start', () => panel.__bouncerPlayback.activate());
  lifecycle.listen(panel, 'toy:retrigger', () => panel.__bouncerPlayback.retrigger());
  lifecycle.listen(panel, 'toy:deactivate', () => panel.__bouncerPlayback.deactivate());
  lifecycle.addCleanup(() => { replayVisualEvents.clear(); deactivatePlaybackInstance(panel.id); removePlaybackInstance(panel.id); });
  panel.__bouncer_main_instance = instanceApi;
  return instanceApi;
}
