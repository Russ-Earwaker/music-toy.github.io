import {stepBouncer} from './bouncer-step.js';
import {midiToName} from './note-helpers.js';
import {BOUNCER_LOGICAL_WIDTH as BW,BOUNCER_LOGICAL_HEIGHT as BH} from './bouncer-viewport-space.js';

export const clamp01=n=>Math.max(0,Math.min(1,n));
export const paintRow=y=>Math.min(11,Math.floor(clamp01(y)*12));
export const paintNote=y=>midiToName(59-paintRow(y));
// DrawGrid's ordinary eight columns are one bar. Interpolate sparse pointer
// samples so a fast stroke still leaves its contour in every crossed column.
export function paintSource(strokes){
 const list=Array.from({length:8},()=>[]);
 const put=p=>{const col=Math.min(7,Math.floor(clamp01(p.x)*8)),row=paintRow(p.y);if(!list[col].includes(row))list[col].push(row);};
 for(const stroke of strokes){
  stroke.points.forEach((p,i)=>{const a=stroke.points[i-1]||p,n=Math.max(1,Math.ceil(Math.abs(p.x-a.x)*32));for(let j=0;j<=n;j++)put({x:a.x+(p.x-a.x)*j/n,y:a.y+(p.y-a.y)*j/n});});
 }
 return {steps:8,autotune:false,instrument:'PIANO',strokes:strokes.map(s=>({color:'#75e1d0',ptsN:s.points.map(p=>({nx:p.x,ny:p.y}))})),nodes:{list,active:list.map(r=>!!r.length),disabled:list.map(()=>[])},manualOverrides:list};
}
export function drumSource(taps,barMs){
 const steps=Array(32).fill(false);
 for(const tap of taps)steps[Math.round((tap.t%barMs)/barMs*32)%32]=true;
 return {instrument:'DRUM KICK',steps,noteIndices:Array(32).fill(12)};
}
// Rippler already stores exact offsets within its ordinary bar, independently
// of the slot used to index them. Retain the original timing to one tick.
export function rippleSource(taps,barMs,base,noteList){
 const blocks=base.blocks.map(b=>({...b,active:false})),steps=Array.from({length:8},()=>[]);
 taps.forEach(tap=>{const idx=Math.min(blocks.length-1,Math.floor(tap.y*blocks.length));
  blocks[idx]={...blocks[idx],nx:tap.x,ny:tap.y,active:true,noteIndex:noteList.indexOf(paintNote((idx+.5)/blocks.length))};
  const offsetTick=Math.round((tap.t%barMs)/barMs*384)%384;
  steps[Math.floor(offsetTick/48)].push({idx,offsetTick});
 });
 const last=taps.at(-1)||{x:.5,y:.5};
 return {...base,instrument:'RETRO TRIANGLE',quantDiv:0,blocks,steps,generator:{nx:last.x,ny:last.y,placed:true}};
}
// Run the existing swept-collision Bouncer integrator at a fixed 120 Hz.
// Its native replay snapshot is both our preview and the canonical source.
export function ballSource(start,end,barMs){
 const duration=barMs/1000,pattern=[],trajectory=[],notes=['C3','D#3','F3','G3'],edges=['left','right','top','bot'];
 const launch={x:30+start.x*(BW-60),y:30+start.y*(BH-60),vx:(end.x-start.x)*18,vy:(end.y-start.y)*18};
 if(Math.hypot(launch.vx,launch.vy)<4){launch.vx=9;launch.vy=-7;}
 const controllers=edges.map((edge,i)=>({edge,active:true,noteIndex:i}));
 let tick=0;
 const state={EDGE:16,physW:()=>BW,physH:()=>BH,ballR:()=>12,ball:{...launch,r:12},blocks:[],edgeControllers:[],noteValue:true,noteList:notes,instrument:'PIANO',lastAT:1,
  mapControllersByEdge:()=>Object.fromEntries(controllers.map(c=>[c.edge,c])),
  triggerInstrument:(instrument,note,at,meta)=>{pattern.push({note,offsetTick:tick,...meta});return true;}};
 for(let i=0;i<Math.ceil(duration*120);i++){
  tick=Math.min(383,Math.round(i/(duration*120)*384));stepBouncer(state,1+i/120);
  trajectory.push({offsetTick:tick,x:state.ball.x,y:state.ball.y,r:12});
 }
 // The launch itself is audible, including a throw that reaches no wall.
 pattern.unshift({note:'C3',offsetTick:0});
 return {instrument:'PIANO',quantDiv:0,lastLaunch:launch,handleFx:start.x,handleFy:start.y,loopRec:{mode:'replay',pattern,trajectory,signature:''}};
}
