import {paintSource,drumSource,rippleSource,ballSource,paintNote,clamp01} from './free-play-sources.js';
import {interpolateBouncerTrajectory} from './bouncer-transport.js';
import {noteList} from './utils.js';
import {BOUNCER_LOGICAL_WIDTH as BW,BOUNCER_LOGICAL_HEIGHT as BH} from './bouncer-viewport-space.js';

export function installFreePlay(api){
 const entry=document.createElement('button');entry.className='free-play-entry';entry.textContent='Free Play';document.body.append(entry);
 const scene=document.createElement('section');scene.className='free-play';scene.hidden=true;scene.setAttribute('aria-label','Free Play');
 scene.innerHTML=`<header><div><strong>Rhythmake</strong><span>Free Play</span></div><button data-exit>Back to graph</button></header>
 <nav aria-label="Play tools">${['Paint','Ball','Ripple','Drum'].map(t=>`<button data-tool="${t}" aria-pressed="${t==='Paint'}">${t}</button>`).join('')}</nav>
 <div class="free-play-surface"><canvas aria-label="Play area. Draw, throw a ball, or tap using the selected tool." tabindex="0"></canvas><p class="free-play-hint">Paint a sound. Throw a ball. Follow your curiosity.</p></div>
 <footer><button data-reset>Clear</button><div><button data-make>Make Music</button><button data-see hidden>See How It Works</button></div><button data-stop hidden>Pause</button><p role="status">Choose a tool and play.</p></footer>`;
 document.body.append(scene);
 const canvas=scene.querySelector('canvas'),ctx=canvas.getContext('2d'),status=scene.querySelector('[role=status]'),make=scene.querySelector('[data-make]'),see=scene.querySelector('[data-see]'),stop=scene.querySelector('[data-stop]'),hint=scene.querySelector('.free-play-hint');
 let tool='Paint',active=false,busy=false,origin=0,serial=0,result=null,gesture=null,frame=null,session=newSession(),previews=[],flashes=[];
 const obscured=new Map();
 function obscure(el){if(el!==scene&&!['SCRIPT','STYLE','LINK'].includes(el.tagName)&&!obscured.has(el)){obscured.set(el,el.inert);el.inert=true;}}
 new MutationObserver(records=>{if(active)for(const record of records)for(const node of record.addedNodes)if(node.nodeType===1)obscure(node);}).observe(document.body,{childList:true});
 function newSession(){return {id:`free-play:${Date.now()}:${++serial||1}`,strokes:[],balls:[],ripples:[],taps:[],sources:{}};}
 function time(){return performance.now()-origin;}
 function point(e){const r=canvas.getBoundingClientRect();return {x:clamp01((e.clientX-r.left)/r.width),y:clamp01((e.clientY-r.top)/r.height),t:time()};}
 function feedback(type,p){flashes.push({...p,type,at:performance.now()});}
 function sound(instrument,note){api.sound(instrument,note);}
 function enter(){if(active)return;active=true;origin ||= performance.now();scene.hidden=false;for(const el of document.body.children)obscure(el);document.body.classList.add('free-play-active');api.enter();resize();draw();}
 function exit(){active=false;scene.hidden=true;for(const [el,inert]of obscured)el.inert=inert;obscured.clear();document.body.classList.remove('free-play-active');cancelAnimationFrame(frame);gesture=null;}
 entry.onclick=enter;scene.querySelector('[data-exit]').onclick=exit;
 scene.querySelectorAll('[data-tool]').forEach(b=>b.onclick=()=>{tool=b.dataset.tool;scene.querySelectorAll('[data-tool]').forEach(q=>q.setAttribute('aria-pressed',String(q===b)));status.textContent=tool==='Ball'?'Drag and release to throw.':tool==='Paint'?'Draw anywhere to hear your line.':'Tap anywhere to play.';});
 canvas.addEventListener('pointerdown',e=>{
  if(busy||gesture)return;e.preventDefault();api.unlock();canvas.setPointerCapture(e.pointerId);hint.hidden=true;
  const p=point(e);gesture={type:tool,pointerId:e.pointerId,points:[p],start:p,lastSound:p.t};
  if(tool==='Paint'){session.strokes.push(gesture);sound('PIANO',paintNote(p.y));}
  if(tool==='Ripple'){session.ripples.push(p);feedback('Ripple',p);sound('RETRO TRIANGLE',paintNote((Math.floor(p.y*8)+.5)/8));}
  if(tool==='Drum'){session.taps.push(p);feedback('Drum',p);sound('DRUM KICK','C4');}
  status.textContent='Your playground is taking shape.';
 });
 canvas.addEventListener('pointermove',e=>{if(!gesture||gesture.pointerId!==e.pointerId)return;const p=point(e);gesture.points.push(p);
  if(gesture.type==='Paint'&&p.t-gesture.lastSound>65){sound('PIANO',paintNote(p.y));gesture.lastSound=p.t;}
 });
 function finish(e,cancel=false){if(!gesture||gesture.pointerId!==e.pointerId)return;
  if(!cancel&&gesture.type==='Ball'){
   const end=point(e),state=ballSource(gesture.start,end,api.barMs()),ball={type:'Ball',t:gesture.start.t,start:gesture.start,end,state,key:`ball:${session.balls.length}`};
   session.balls.push(ball);previews.push({ball,at:performance.now(),cursor:0});
  }gesture=null;
 }
 canvas.addEventListener('pointerup',e=>finish(e));canvas.addEventListener('pointercancel',e=>finish(e,true));canvas.addEventListener('lostpointercapture',()=>{gesture=null;});
 async function clear(){if(busy)return;api.clear();session=newSession();origin=performance.now();result=null;gesture=null;previews=[];flashes=[];see.hidden=stop.hidden=true;hint.hidden=false;status.textContent='A fresh playground. Choose a tool and play.';}
 scene.querySelector('[data-reset]').onclick=clear;
 make.onclick=async()=>{
  if(busy)return;busy=true;make.disabled=true;scene.querySelector('[data-reset]').disabled=true;gesture=null;previews=[];status.textContent='Making music…';
  try{
   const barMs=api.barMs(),sources=[];
   if(session.strokes.length)sources.push({key:'paint',type:'drawgrid',state:paintSource(session.strokes)});
   for(const ball of session.balls)sources.push({key:ball.key,type:'bouncer',state:ball.state});
   if(session.ripples.length)sources.push({key:'ripple',type:'rippler',state:base=>rippleSource(session.ripples,barMs,base,noteList)});
   if(session.taps.length)sources.push({key:'drum',type:'loopgrid',state:drumSource(session.taps,barMs)});
   // An empty session gets a tiny ordinary seed; Auto-Arrange supplies support.
   if(!sources.length)sources.push({key:'drum',type:'loopgrid',state:drumSource([{t:0}],barMs)});
   result=await api.make(session,sources);see.hidden=stop.hidden=false;stop.textContent='Pause';status.textContent='Your music is playing. Keep exploring.';
  }catch(error){status.textContent=`Could not make music: ${error.message}. Your play is still here.`;}
  finally{busy=false;make.disabled=false;scene.querySelector('[data-reset]').disabled=false;}
 };
 see.onclick=()=>{if(result){exit();api.reveal(result);}};
 stop.onclick=()=>{const playing=api.toggle();stop.textContent=playing?'Pause':'Play';status.textContent=playing?'Your music is playing.':'Music paused.';};
 function resize(){const r=canvas.getBoundingClientRect(),dpr=window.devicePixelRatio||1;canvas.width=Math.max(1,Math.round(r.width*dpr));canvas.height=Math.max(1,Math.round(r.height*dpr));ctx.setTransform(dpr,0,0,dpr,0,0);}
 new ResizeObserver(()=>{if(active)resize();}).observe(canvas);
 function path(points,w,h){ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x*w,p.y*h):ctx.moveTo(p.x*w,p.y*h));ctx.stroke();}
 function circle(p,r,color,w,h){ctx.beginPath();ctx.arc(p.x*w,p.y*h,r,0,Math.PI*2);ctx.strokeStyle=color;ctx.stroke();}
 function draw(){
  if(!active)return;const {width:w,height:h}=canvas.getBoundingClientRect(),now=performance.now();ctx.clearRect(0,0,w,h);ctx.lineCap='round';ctx.lineJoin='round';ctx.lineWidth=5;ctx.strokeStyle='#75e1d0';
  for(const stroke of session.strokes)path(stroke.points,w,h);
  if(gesture?.type==='Ball'){ctx.strokeStyle='#ffc67d';ctx.lineWidth=2;path(gesture.points,w,h);}
  for(const preview of previews){const elapsed=now-preview.at,localTick=elapsed/api.barMs()*384;
   while(preview.cursor<preview.ball.state.loopRec.pattern.length&&preview.ball.state.loopRec.pattern[preview.cursor].offsetTick<=localTick){const ev=preview.ball.state.loopRec.pattern[preview.cursor++];sound('PIANO',ev.note);}
   if(localTick<384){const p=interpolateBouncerTrajectory(preview.ball.state.loopRec.trajectory,localTick);circle({x:p.x/BW,y:p.y/BH},12,'#ffc67d',w,h);}
  }
  previews=previews.filter(p=>now-p.at<api.barMs());
  for(const ball of session.balls){if(previews.some(p=>p.ball===ball))continue;const tick=result?api.localTick(session.sources[ball.key]):0,p=interpolateBouncerTrajectory(ball.state.loopRec.trajectory,tick??0);circle({x:p.x/BW,y:p.y/BH},12,'#ffc67d',w,h);}
  ctx.lineWidth=2;
  for(const p of session.ripples)circle(p,8,'#a99dff66',w,h);
  for(const p of session.taps)circle(p,14,'#ff92b655',w,h);
  for(const f of flashes){const age=(now-f.at)/1000;ctx.globalAlpha=Math.max(0,1-age);circle(f,10+age*(f.type==='Ripple'?150:65),f.type==='Drum'?'#ff92b6':f.type==='Paint'?'#75e1d0':'#a99dff',w,h);}
  ctx.globalAlpha=1;flashes=flashes.filter(f=>now-f.at<1000);frame=requestAnimationFrame(draw);
 }
 api.onNote((key,event)=>{
  if(!active)return;
  if(key==='paint')feedback('Paint',{x:((event.col??0)+.5)/8,y:((event.row??5)+.5)/12});
  if(key==='ripple')for(const p of session.ripples)feedback('Ripple',p);
  if(key==='drum')for(const p of session.taps)feedback('Drum',p);
 });
 for(const type of ['scene:new','scene:load'])window.addEventListener(type,()=>{exit();session=newSession();result=null;origin=0;previews=[];api.forget();});
 return {enter,getSession:()=>session};
}
