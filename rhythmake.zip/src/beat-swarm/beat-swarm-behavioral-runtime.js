function clamp01(value) {
  return Math.max(0, Math.min(1, Number(value) || 0));
}

function normalizeArchetype(value = '') {
  return String(value || '').trim().toLowerCase();
}

function normalizeBehaviorClass(value = '') {
  return String(value || '').trim().toLowerCase();
}

function normalizeActivationMode(value = '') {
  return String(value || '').trim().toLowerCase();
}

const LOGICAL_WIDTH = 1600;
const LOGICAL_HEIGHT = 900;
const LOGICAL_INSET = 24;

function logicalPointToWorld(helpers, point) {
  const logicalToWorld = typeof helpers?.logicalToWorld === 'function' ? helpers.logicalToWorld : null;
  if (!logicalToWorld) return null;
  const world = logicalToWorld(point);
  return world && Number.isFinite(world.x) && Number.isFinite(world.y) ? world : null;
}

function logicalLengthToWorld(helpers, length) {
  const start = logicalPointToWorld(helpers, { x: 0, y: 0 });
  const end = logicalPointToWorld(helpers, { x: Number(length) || 0, y: 0 });
  return start && end ? Math.hypot(end.x - start.x, end.y - start.y) : Number(length) || 0;
}

function buildInactiveRuntime(enemyLike = null) {
  const enemy = enemyLike && typeof enemyLike === 'object' ? enemyLike : {};
  return Object.freeze({
    archetype: normalizeArchetype(enemy?.behavioralFormationArchetype || 'none'),
    behaviorClass: normalizeBehaviorClass(enemy?.behavioralFormationClass || 'none'),
    activationMode: normalizeActivationMode(enemy?.behavioralFormationActivationMode || 'inactive'),
    active: enemy?.behavioralFormationActive === true,
    intensity: clamp01(enemy?.behavioralFormationIntensity),
    singleBehaviorId: String(enemy?.singleBehaviorId || '').trim().toLowerCase(),
    groupBehaviorId: String(enemy?.groupBehaviorId || '').trim().toLowerCase(),
    eventBehaviorId: String(enemy?.eventBehaviorId || '').trim().toLowerCase(),
    behaviorPriority: String(enemy?.behaviorPriority || '').trim().toLowerCase(),
    behaviorWindow: String(enemy?.behaviorWindow || '').trim().toLowerCase(),
    behaviorSource: String(enemy?.behaviorSource || '').trim().toLowerCase(),
    singleBehaviorWindow: String(enemy?.singleBehaviorWindow || '').trim().toLowerCase(),
    groupBehaviorWindow: String(enemy?.groupBehaviorWindow || '').trim().toLowerCase(),
    eventBehaviorWindow: String(enemy?.eventBehaviorWindow || '').trim().toLowerCase(),
    slotIndex: Math.max(0, Math.trunc(Number(enemy?.formationMemberIndex) || 0)),
    slotCount: Math.max(1, Math.trunc(Number(enemy?.formationMemberCount) || 1)),
    leaderEnemyId: 0,
    leaderBias: 0,
    followDistanceWorld: 0,
    lateralOffsetWorld: 0,
    curvatureBias: 0,
    targetWorld: null,
  });
}

function buildWindingChainRuntime(enemyLike = null, helpers = null) {
  const enemy = enemyLike && typeof enemyLike === 'object' ? enemyLike : {};
  const slotIndex = Math.max(0, Math.trunc(Number(enemy?.formationMemberIndex) || 0));
  const slotCount = Math.max(1, Math.trunc(Number(enemy?.formationMemberCount) || 1));
  const centeredIndex = slotIndex - ((slotCount - 1) * 0.5);
  const laneSide = centeredIndex === 0 ? 0 : (centeredIndex < 0 ? -1 : 1);
  const targetWorld = logicalPointToWorld(helpers, {
    x: Math.max(LOGICAL_INSET, Math.min(LOGICAL_WIDTH - LOGICAL_INSET, (LOGICAL_WIDTH * 0.5) + (centeredIndex * (LOGICAL_WIDTH * 0.045)))),
    y: Math.max(LOGICAL_INSET, Math.min(LOGICAL_HEIGHT - LOGICAL_INSET, (LOGICAL_HEIGHT * 0.22) + (Math.abs(centeredIndex) * (LOGICAL_HEIGHT * 0.035)))),
  });
  return Object.freeze({
    archetype: 'winding_chain',
    behaviorClass: 'follow_the_leader',
    activationMode: normalizeActivationMode(enemy?.behavioralFormationActivationMode || 'opt_in'),
    active: enemy?.behavioralFormationActive === true,
    intensity: clamp01(enemy?.behavioralFormationIntensity || 0.55),
    singleBehaviorId: String(enemy?.singleBehaviorId || '').trim().toLowerCase(),
    groupBehaviorId: String(enemy?.groupBehaviorId || '').trim().toLowerCase(),
    eventBehaviorId: String(enemy?.eventBehaviorId || '').trim().toLowerCase(),
    behaviorPriority: String(enemy?.behaviorPriority || '').trim().toLowerCase(),
    behaviorWindow: String(enemy?.behaviorWindow || '').trim().toLowerCase(),
    behaviorSource: String(enemy?.behaviorSource || '').trim().toLowerCase(),
    singleBehaviorWindow: String(enemy?.singleBehaviorWindow || '').trim().toLowerCase(),
    groupBehaviorWindow: String(enemy?.groupBehaviorWindow || '').trim().toLowerCase(),
    eventBehaviorWindow: String(enemy?.eventBehaviorWindow || '').trim().toLowerCase(),
    slotIndex,
    slotCount,
    leaderEnemyId: slotIndex === 0 ? Math.max(0, Math.trunc(Number(enemy?.id) || 0)) : 0,
    leaderBias: slotIndex === 0 ? 1 : 0,
    followDistanceWorld: logicalLengthToWorld(helpers, Math.max(44, Math.round(LOGICAL_WIDTH * 0.032))),
    lateralOffsetWorld: laneSide * logicalLengthToWorld(helpers, Math.max(12, Math.round(LOGICAL_WIDTH * 0.008))),
    curvatureBias: centeredIndex * 0.18,
    speedMultiplier: enemy?.behavioralFormationActive === true ? 1.75 : 1,
    pathOscillationAmplitude: Math.max(0.18, Math.min(0.72, 0.3 + (clamp01(enemy?.behavioralFormationIntensity || 0.55) * 0.45))),
    pathOscillationHz: 0.55,
    velocityBlend: enemy?.behavioralFormationActive === true ? 0.34 : 0.12,
    targetWorld: targetWorld && Number.isFinite(targetWorld.x) && Number.isFinite(targetWorld.y)
      ? { x: Number(targetWorld.x) || 0, y: Number(targetWorld.y) || 0 }
      : null,
  });
}

function buildAdvancingLineRuntime(enemyLike = null, helpers = null) {
  const enemy = enemyLike && typeof enemyLike === 'object' ? enemyLike : {};
  const slotIndex = Math.max(0, Math.trunc(Number(enemy?.formationMemberIndex) || 0));
  const slotCount = Math.max(1, Math.trunc(Number(enemy?.formationMemberCount) || 1));
  const centeredIndex = slotIndex - ((slotCount - 1) * 0.5);
  const laneSide = centeredIndex === 0 ? 0 : (centeredIndex < 0 ? -1 : 1);
  const targetWorld = logicalPointToWorld(helpers, {
    x: Math.max(LOGICAL_INSET, Math.min(LOGICAL_WIDTH - LOGICAL_INSET, (LOGICAL_WIDTH * 0.5) + (centeredIndex * (LOGICAL_WIDTH * 0.055)))),
    y: LOGICAL_HEIGHT * 0.5,
  });
  return Object.freeze({
    archetype: 'advancing_line',
    behaviorClass: 'follow_the_leader',
    activationMode: normalizeActivationMode(enemy?.behavioralFormationActivationMode || 'opt_in'),
    active: enemy?.behavioralFormationActive === true,
    intensity: clamp01(enemy?.behavioralFormationIntensity || 0.6),
    singleBehaviorId: String(enemy?.singleBehaviorId || '').trim().toLowerCase(),
    groupBehaviorId: String(enemy?.groupBehaviorId || '').trim().toLowerCase(),
    eventBehaviorId: String(enemy?.eventBehaviorId || '').trim().toLowerCase(),
    behaviorPriority: String(enemy?.behaviorPriority || '').trim().toLowerCase(),
    behaviorWindow: String(enemy?.behaviorWindow || '').trim().toLowerCase(),
    behaviorSource: String(enemy?.behaviorSource || '').trim().toLowerCase(),
    singleBehaviorWindow: String(enemy?.singleBehaviorWindow || '').trim().toLowerCase(),
    groupBehaviorWindow: String(enemy?.groupBehaviorWindow || '').trim().toLowerCase(),
    eventBehaviorWindow: String(enemy?.eventBehaviorWindow || '').trim().toLowerCase(),
    slotIndex,
    slotCount,
    leaderEnemyId: slotIndex === 0 ? Math.max(0, Math.trunc(Number(enemy?.id) || 0)) : 0,
    leaderBias: slotIndex === 0 ? 1 : 0,
    followDistanceWorld: logicalLengthToWorld(helpers, Math.max(44, Math.round(LOGICAL_WIDTH * 0.03))),
    lateralOffsetWorld: laneSide * logicalLengthToWorld(helpers, Math.max(4, Math.round(LOGICAL_HEIGHT * 0.01))),
    curvatureBias: centeredIndex * 0.04,
    speedMultiplier: enemy?.behavioralFormationActive === true ? 1.58 : 1,
    pathOscillationAmplitude: Math.max(0.24, Math.min(0.95, 0.34 + (clamp01(enemy?.behavioralFormationIntensity || 0.6) * 0.42))),
    pathOscillationHz: 0.48,
    velocityBlend: enemy?.behavioralFormationActive === true ? 0.3 : 0.12,
    targetWorld: targetWorld && Number.isFinite(targetWorld.x) && Number.isFinite(targetWorld.y)
      ? { x: Number(targetWorld.x) || 0, y: Number(targetWorld.y) || 0 }
      : null,
  });
}

function buildPairedDanceRuntime(enemyLike = null, helpers = null) {
  const enemy = enemyLike && typeof enemyLike === 'object' ? enemyLike : {};
  const slotIndex = Math.max(0, Math.trunc(Number(enemy?.formationMemberIndex) || 0));
  const slotCount = Math.max(1, Math.trunc(Number(enemy?.formationMemberCount) || 1));
  const centeredIndex = slotIndex - ((slotCount - 1) * 0.5);
  const targetWorld = logicalPointToWorld(helpers, {
    x: Math.max(LOGICAL_INSET, Math.min(LOGICAL_WIDTH - LOGICAL_INSET, (LOGICAL_WIDTH * 0.5) + (centeredIndex * (LOGICAL_WIDTH * 0.05)))),
    y: Math.max(LOGICAL_INSET, Math.min(LOGICAL_HEIGHT - LOGICAL_INSET, (LOGICAL_HEIGHT * 0.54) + ((slotIndex % 2 === 0 ? -1 : 1) * (LOGICAL_HEIGHT * 0.03)))),
  });
  return Object.freeze({
    archetype: 'paired_dance',
    behaviorClass: 'paired_motion',
    activationMode: normalizeActivationMode(enemy?.behavioralFormationActivationMode || 'opt_in'),
    active: enemy?.behavioralFormationActive === true,
    intensity: clamp01(enemy?.behavioralFormationIntensity || 0.7),
    singleBehaviorId: String(enemy?.singleBehaviorId || '').trim().toLowerCase(),
    groupBehaviorId: String(enemy?.groupBehaviorId || '').trim().toLowerCase(),
    eventBehaviorId: String(enemy?.eventBehaviorId || '').trim().toLowerCase(),
    behaviorPriority: String(enemy?.behaviorPriority || '').trim().toLowerCase(),
    behaviorWindow: String(enemy?.behaviorWindow || '').trim().toLowerCase(),
    behaviorSource: String(enemy?.behaviorSource || '').trim().toLowerCase(),
    singleBehaviorWindow: String(enemy?.singleBehaviorWindow || '').trim().toLowerCase(),
    groupBehaviorWindow: String(enemy?.groupBehaviorWindow || '').trim().toLowerCase(),
    eventBehaviorWindow: String(enemy?.eventBehaviorWindow || '').trim().toLowerCase(),
    slotIndex,
    slotCount,
    leaderEnemyId: 0,
    leaderBias: 0,
    followDistanceWorld: 0,
    lateralOffsetWorld: 0,
    curvatureBias: centeredIndex * 0.06,
    speedMultiplier: enemy?.behavioralFormationActive === true ? 1.45 : 1,
    pathOscillationAmplitude: Math.max(0.35, Math.min(0.95, 0.42 + (clamp01(enemy?.behavioralFormationIntensity || 0.7) * 0.32))),
    pathOscillationHz: 0.18,
    velocityBlend: enemy?.behavioralFormationActive === true ? 0.34 : 0.12,
    targetWorld: targetWorld && Number.isFinite(targetWorld.x) && Number.isFinite(targetWorld.y)
      ? { x: Number(targetWorld.x) || 0, y: Number(targetWorld.y) || 0 }
      : null,
  });
}

export function buildBeatSwarmBehavioralFormationEnemyRuntime(options = null) {
  const opts = options && typeof options === 'object' ? options : {};
  const enemy = opts.enemy && typeof opts.enemy === 'object' ? opts.enemy : null;
  const helpers = opts.helpers && typeof opts.helpers === 'object' ? opts.helpers : null;
  if (!enemy) return buildInactiveRuntime(null);
  const archetype = normalizeArchetype(enemy?.behavioralFormationArchetype || 'none');
  if (archetype === 'winding_chain') {
    return buildWindingChainRuntime(enemy, helpers);
  }
  if (archetype === 'advancing_line') {
    return buildAdvancingLineRuntime(enemy, helpers);
  }
  if (archetype === 'paired_dance') {
    return buildPairedDanceRuntime(enemy, helpers);
  }
  return buildInactiveRuntime(enemy);
}
