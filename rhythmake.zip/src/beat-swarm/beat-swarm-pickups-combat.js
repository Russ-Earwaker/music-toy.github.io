import { createWorldLogicalCollision } from './beat-swarm-logical-collision.js';

let projectileCollisionFrameCursor = 0;

export function createBeatSwarmProjectileRemovalDiagnostic({
  projectile = null,
  reason = 'unknown',
  logicalPosition = null,
  screenPosition = null,
  logicalBounds = null,
  lifetimeMarginLogical = 0,
  presentationScale = 1,
} = {}) {
  return Object.freeze({
    removalReason: String(reason || 'unknown'),
    kind: String(projectile?.kind || 'standard'),
    logicalPosition: logicalPosition ? Object.freeze({ x: Number(logicalPosition.x) || 0, y: Number(logicalPosition.y) || 0 }) : null,
    worldPosition: Object.freeze({ x: Number(projectile?.wx) || 0, y: Number(projectile?.wy) || 0 }),
    projectedScreenPosition: screenPosition ? Object.freeze({ x: Number(screenPosition.x) || 0, y: Number(screenPosition.y) || 0 }) : null,
    logicalGameplayBounds: logicalBounds || null,
    activeLifetimeMarginLogical: Math.max(0, Number(lifetimeMarginLogical) || 0),
    enteredGameplay: projectile?.enteredGameplay === true || projectile?.hasEnteredScreen === true,
    presentationScale: Math.max(0.001, Number(presentationScale) || 1),
    ttl: Number(projectile?.ttl) || 0,
  });
}

export function getBeatSwarmProjectileViewportRemovalReason({
  usesTtlDespawn = false,
  isOutsideLifetimeBounds = false,
  enteredGameplay = false,
  ttl = 0,
} = {}) {
  if (usesTtlDespawn) return Number(ttl) <= 0 ? 'ttl_complete' : null;
  return isOutsideLifetimeBounds && (enteredGameplay || Number(ttl) <= 0)
    ? 'logical_viewport_retirement'
    : null;
}

export function updateBeatSwarmPickupsAndCombatRuntime(options = null) {
  const constants = options?.constants && typeof options.constants === 'object' ? options.constants : {};
  const helpers = options?.helpers && typeof options.helpers === 'object' ? options.helpers : {};
  const state = options?.state && typeof options.state === 'object' ? options.state : {};
  const getPerfNow = typeof helpers.getPerfNow === 'function'
    ? helpers.getPerfNow
    : (() => (globalThis.performance?.now?.() ?? Date.now()));
  const recordPerfSample = typeof helpers.recordPerfSample === 'function'
    ? helpers.recordPerfSample
    : null;
  const withPerfSample = (name, fn) => {
    if (typeof fn !== 'function') return undefined;
    const startedAt = getPerfNow();
    try {
      return fn();
    } finally {
      const durationMs = Math.max(0, getPerfNow() - startedAt);
      recordPerfSample?.(name, durationMs);
    }
  };
  const profileProjectileDetail = globalThis.__BEAT_SWARM_PROJECTILE_DETAIL_PERF === true;
  const withProjectileDetailPerf = (name, fn) => (
    profileProjectileDetail ? withPerfSample(name, fn) : fn()
  );

  const pickups = Array.isArray(state.pickups) ? state.pickups : [];
  const projectiles = Array.isArray(state.projectiles) ? state.projectiles : [];
  const effects = Array.isArray(state.effects) ? state.effects : [];
  const enemies = Array.isArray(state.enemies) ? state.enemies : [];
  const equippedWeapons = state.equippedWeapons instanceof Set ? state.equippedWeapons : new Set();
  const currentBeatIndex = Math.max(0, Math.trunc(Number(state.currentBeatIndex) || 0));
  const suppressWeaponRuntime = state.suppressWeaponRuntime === true;
  const dt = Math.max(0, Number(state.dt) || 0);
  const enemyById = new Map();
  const enemySpatialBuckets = new Map();
  const enemySpatialCellSize = 180;
  const makeEnemyCellKey = (x, y) => {
    const cx = Math.floor((Number(x) || 0) / enemySpatialCellSize);
    const cy = Math.floor((Number(y) || 0) / enemySpatialCellSize);
    return `${cx},${cy}`;
  };
  for (let i = 0; i < enemies.length; i++) {
    const enemy = enemies[i];
    const enemyId = Math.trunc(Number(enemy?.id) || 0);
    if (enemyId > 0) enemyById.set(enemyId, enemy);
    const key = makeEnemyCellKey(enemy?.wx, enemy?.wy);
    const bucket = enemySpatialBuckets.get(key);
    if (bucket) bucket.push(enemy);
    else enemySpatialBuckets.set(key, [enemy]);
  }
  const getEnemyById = (enemyId) => {
    const id = Math.trunc(Number(enemyId) || 0);
    if (!(id > 0)) return null;
    return enemyById.get(id) || null;
  };
  const forEachNearbyEnemy = (worldX, worldY, radiusWorld, visitor) => {
    const radius = Math.max(enemySpatialCellSize, Number(radiusWorld) || 0);
    const minCellX = Math.floor(((Number(worldX) || 0) - radius) / enemySpatialCellSize);
    const maxCellX = Math.floor(((Number(worldX) || 0) + radius) / enemySpatialCellSize);
    const minCellY = Math.floor(((Number(worldY) || 0) - radius) / enemySpatialCellSize);
    const maxCellY = Math.floor(((Number(worldY) || 0) + radius) / enemySpatialCellSize);
    for (let cy = minCellY; cy <= maxCellY; cy++) {
      for (let cx = minCellX; cx <= maxCellX; cx++) {
        const bucket = enemySpatialBuckets.get(`${cx},${cy}`);
        if (!bucket) continue;
        for (let i = 0; i < bucket.length; i++) {
          if (visitor(bucket[i]) === true) return true;
        }
      }
    }
    return false;
  };
  const getNearestEnemyLocal = (worldX, worldY, excludeEnemyId = null, searchRadiusWorld = enemySpatialCellSize * 2.5) => {
    const exId = Number.isFinite(excludeEnemyId) ? Math.trunc(excludeEnemyId) : null;
    let best = null;
    let bestD2 = Infinity;
    const foundNearby = forEachNearbyEnemy(worldX, worldY, searchRadiusWorld, (enemy) => {
      const enemyId = Math.trunc(Number(enemy?.id) || 0);
      if (exId !== null && enemyId === exId) return false;
      const dx = (Number(enemy?.wx) || 0) - (Number(worldX) || 0);
      const dy = (Number(enemy?.wy) || 0) - (Number(worldY) || 0);
      const d2 = (dx * dx) + (dy * dy);
      if (d2 < bestD2) {
        bestD2 = d2;
        best = enemy;
      }
      return false;
    });
    if (best || foundNearby) return best;
    for (let i = 0; i < enemies.length; i++) {
      const enemy = enemies[i];
      const enemyId = Math.trunc(Number(enemy?.id) || 0);
      if (exId !== null && enemyId === exId) continue;
      const dx = (Number(enemy?.wx) || 0) - (Number(worldX) || 0);
      const dy = (Number(enemy?.wy) || 0) - (Number(worldY) || 0);
      const d2 = (dx * dx) + (dy * dy);
      if (d2 < bestD2) {
        bestD2 = d2;
        best = enemy;
      }
    }
    return best;
  };

  const centerWorld = helpers.getViewportCenterWorld?.() || { x: 0, y: 0 };
  const z = helpers.getZoomState?.();
  const scale = Number.isFinite(z?.targetScale) ? z.targetScale : (Number.isFinite(z?.currentScale) ? z.currentScale : 1);
  const presentationScale = Math.max(0.001, Number(helpers.getPresentationScale?.()) || 1);
  const collectRadiusLogical = Math.max(0, Number(constants.pickupCollectRadiusLogical) || 0);
  const projectileHitRadiusLogical = Math.max(0, Number(constants.projectileHitRadiusLogical) || 0);
  const collision = createWorldLogicalCollision(helpers.worldToLogical);
  const projectileOffscreenPad = Math.max(16, Number(constants.projectileDespawnOffscreenPadPx) || 72);
  const maxProjectileCount = Math.max(32, Math.trunc(Number(constants.maxProjectileCount) || 128));
  const maxProjectileCollisionsPerFrame = Math.max(16, Math.trunc(Number(constants.maxProjectileCollisionsPerFrame) || 96));
  const maxEffectCount = Math.max(32, Math.trunc(Number(constants.maxEffectCount) || 160));
  const recordProjectileRemoval = (projectile, reason) => {
    helpers.recordProjectileRemovalDiagnostic?.(createBeatSwarmProjectileRemovalDiagnostic({
      projectile,
      reason,
      logicalPosition: helpers.worldToLogical?.({ x: Number(projectile?.wx) || 0, y: Number(projectile?.wy) || 0 }),
      screenPosition: helpers.worldToScreen?.({ x: Number(projectile?.wx) || 0, y: Number(projectile?.wy) || 0 }),
      logicalBounds: helpers.getLogicalGameplayBounds?.() || null,
      lifetimeMarginLogical: projectileOffscreenPad,
      presentationScale,
    }));
  };

  withPerfSample('pickupsCombat.updateHelpers', () => {
    helpers.updateHelpers?.(dt, centerWorld, scale);
  });

  withPerfSample('pickupsCombat.pickups', () => {
    for (let i = pickups.length - 1; i >= 0; i--) {
      const p = pickups[i];
      if (collision.pointWithinRadius(p, centerWorld, collectRadiusLogical)) {
        equippedWeapons.add(p.weaponId);
        helpers.ensureDefaultWeaponFromLegacy?.(p.weaponId);
        try { p.el?.remove?.(); } catch {}
        pickups.splice(i, 1);
        continue;
      }
      const s = helpers.worldToScreen?.({ x: p.wx, y: p.wy });
      if (!s || !Number.isFinite(s.x) || !Number.isFinite(s.y)) continue;
      p.el.style.transform = `translate(${s.x}px, ${s.y}px) scale(${presentationScale})`;
    }
  });

  withPerfSample('pickupsCombat.projectiles', () => {
    if (projectiles.length > maxProjectileCount) {
      const dropCount = projectiles.length - maxProjectileCount;
      const droppedProjectiles = projectiles.splice(0, dropCount);
      for (let i = 0; i < droppedProjectiles.length; i++) {
        recordProjectileRemoval(droppedProjectiles[i], 'projectile_cap');
        try { droppedProjectiles[i]?.el?.remove?.(); } catch {}
      }
    }
    const projectileCountAtFrameStart = Math.max(0, projectiles.length);
    const collisionStride = Math.max(1, Math.ceil(projectileCountAtFrameStart / maxProjectileCollisionsPerFrame));
    const collisionPhase = projectileCollisionFrameCursor % collisionStride;
    projectileCollisionFrameCursor = (projectileCollisionFrameCursor + 1) % 1000000;
    for (let i = projectiles.length - 1; i >= 0; i--) {
      const p = projectiles[i];
      p.ttl -= dt;
      p.collisionGraceT = Math.max(0, Number(p.collisionGraceT) - dt);
      const isBoomerang = String(p.kind || 'standard') === 'boomerang';
      const isHoming = String(p.kind || 'standard') === 'homing-missile';
      const isHostileHoming = String(p.kind || '') === 'hostile-red' && p.hostileHoming === true;
      const useTtlDespawn = isBoomerang || isHoming || isHostileHoming;
      withProjectileDetailPerf('pickupsCombat.projectiles.motion', () => {
        if (isBoomerang) {
          p.boomTheta = (Number(p.boomTheta) || 0) + ((Number(p.boomOmega) || 0) * dt);
          const c = Math.cos(p.boomTheta || 0);
          const s = Math.sin(p.boomTheta || 0);
          const r = Math.max(1, Number(p.boomRadius) || Number(constants.projectileBoomerangRadiusWorld) || 0);
          const dirX = Number(p.boomDirX) || 0;
          const dirY = Number(p.boomDirY) || 0;
          const perpX = Number(p.boomPerpX) || 0;
          const perpY = Number(p.boomPerpY) || 0;
          p.wx = (Number(p.boomCenterX) || 0) + (dirX * (1 + c) * r) + (perpX * s * r);
          p.wy = (Number(p.boomCenterY) || 0) + (dirY * (1 + c) * r) + (perpY * s * r);
        } else if (isHostileHoming) {
          const desired = helpers.normalizeDir?.(centerWorld.x - p.wx, centerWorld.y - p.wy, p.vx, p.vy) || { x: 0, y: 0 };
          const current = helpers.normalizeDir?.(p.vx, p.vy, desired.x, desired.y) || desired;
          const steer = Math.max(0, Math.min(1, (Number(p.hostileHomingTurnRate) || 1.4) * dt));
          const direction = helpers.normalizeDir?.(
            (current.x * (1 - steer)) + (desired.x * steer),
            (current.y * (1 - steer)) + (desired.y * steer),
            desired.x,
            desired.y,
          ) || desired;
          const speed = Math.max(120, Number(p.hostileHomingSpeed) || Math.hypot(Number(p.vx) || 0, Number(p.vy) || 0));
          p.vx = direction.x * speed;
          p.vy = direction.y * speed;
          p.wx += p.vx * dt;
          p.wy += p.vy * dt;
        } else if (isHoming) {
          let stateName = String(p.homingState || 'orbit');
          const orbitRadius = Math.max(20, Number(p.orbitRadius) || Number(constants.projectileHomingOrbitRadiusWorld) || 0);
          const orbitAngVel = Number(p.orbitAngVel) || Number(constants.projectileHomingOrbitAngVel) || 0;
          const nearestNow = getNearestEnemyLocal(p.wx, p.wy, p.ignoreEnemyId) || helpers.getNearestEnemy?.(p.wx, p.wy, p.ignoreEnemyId);
          if (stateName === 'orbit' && nearestNow) {
            const dx = nearestNow.wx - p.wx;
            const dy = nearestNow.wy - p.wy;
            const acquireRange = Number(constants.projectileHomingAcquireRangeWorld) || 0;
            if ((dx * dx + dy * dy) <= (acquireRange * acquireRange)) {
              stateName = 'seek';
              p.targetEnemyId = Math.trunc(Number(nearestNow.id) || 0) || null;
            }
          }
          if (stateName === 'seek') {
            let target = null;
            if (Number.isFinite(p.targetEnemyId)) target = getEnemyById(p.targetEnemyId);
            if (!target) target = getNearestEnemyLocal(p.wx, p.wy, p.ignoreEnemyId) || helpers.getNearestEnemy?.(p.wx, p.wy, p.ignoreEnemyId);
            if (!target) {
              stateName = 'return';
              p.targetEnemyId = null;
            } else {
              p.targetEnemyId = Math.trunc(Number(target.id) || 0) || null;
              const desired = helpers.normalizeDir?.(target.wx - p.wx, target.wy - p.wy, p.vx, p.vy) || { x: 0, y: 0 };
              const cur = helpers.normalizeDir?.(p.vx, p.vy, desired.x, desired.y) || desired;
              const steer = Math.max(0, Math.min(1, (Number(constants.projectileHomingTurnRate) || 0) * dt));
              const nd = helpers.normalizeDir?.(
                (cur.x * (1 - steer)) + (desired.x * steer),
                (cur.y * (1 - steer)) + (desired.y * steer),
                desired.x,
                desired.y
              ) || desired;
              p.vx = nd.x * (Number(constants.projectileHomingSpeed) || 0);
              p.vy = nd.y * (Number(constants.projectileHomingSpeed) || 0);
              p.wx += p.vx * dt;
              p.wy += p.vy * dt;
            }
          }
          if (stateName === 'return') {
            const desired = helpers.normalizeDir?.(centerWorld.x - p.wx, centerWorld.y - p.wy, p.vx, p.vy) || { x: 0, y: 0 };
            const cur = helpers.normalizeDir?.(p.vx, p.vy, desired.x, desired.y) || desired;
            const steer = Math.max(0, Math.min(1, ((Number(constants.projectileHomingTurnRate) || 0) * 1.2) * dt));
            const nd = helpers.normalizeDir?.(
              (cur.x * (1 - steer)) + (desired.x * steer),
              (cur.y * (1 - steer)) + (desired.y * steer),
              desired.x,
              desired.y
            ) || desired;
            p.vx = nd.x * (Number(constants.projectileHomingSpeed) || 0);
            p.vy = nd.y * (Number(constants.projectileHomingSpeed) || 0);
            p.wx += p.vx * dt;
            p.wy += p.vy * dt;
            const dx = p.wx - centerWorld.x;
            const dy = p.wy - centerWorld.y;
            const snapDist = Number(constants.projectileHomingReturnSnapDistWorld) || 0;
            if ((dx * dx + dy * dy) <= (snapDist * snapDist)) {
              stateName = 'orbit';
              const d = helpers.normalizeDir?.(dx, dy, 1, 0) || { x: 1, y: 0 };
              p.orbitAngle = Math.atan2(d.y, d.x);
              p.vx = 0;
              p.vy = 0;
            }
          }
          if (stateName === 'orbit') {
            const phaseCatchup = Math.max(
              0.2,
              Math.min(
                1,
                (Math.max(0, (Number(p.orbitRadius) || orbitRadius)) / Math.max(1, Math.hypot((p.wx - centerWorld.x), (p.wy - centerWorld.y))))
              )
            );
            p.orbitAngle = (Number(p.orbitAngle) || 0) + (orbitAngVel * dt * phaseCatchup);
            const targetX = centerWorld.x + (Math.cos(p.orbitAngle) * orbitRadius);
            const targetY = centerWorld.y + (Math.sin(p.orbitAngle) * orbitRadius);
            const toTx = targetX - p.wx;
            const toTy = targetY - p.wy;
            const toDist = Math.hypot(toTx, toTy) || 0.0001;
            const desired = helpers.normalizeDir?.(targetX - p.wx, targetY - p.wy, 1, 0) || { x: 0, y: 0 };
            const cur = helpers.normalizeDir?.(p.vx, p.vy, desired.x, desired.y) || desired;
            const steer = Math.max(0, Math.min(1, (Number(constants.projectileHomingOrbitTurnRate) || 0) * dt));
            const nd = helpers.normalizeDir?.(
              (cur.x * (1 - steer)) + (desired.x * steer),
              (cur.y * (1 - steer)) + (desired.y * steer),
              desired.x,
              desired.y
            ) || desired;
            const speedN = Math.max(0.2, Math.min(1, toDist / Math.max(1, orbitRadius)));
            const chaseSpeed = (Number(constants.projectileHomingOrbitChaseSpeed) || 0) * speedN;
            p.vx = nd.x * chaseSpeed;
            p.vy = nd.y * chaseSpeed;
            p.wx += p.vx * dt;
            p.wy += p.vy * dt;
          }
          p.homingState = stateName;
        } else {
          p.wx += p.vx * dt;
          p.wy += p.vy * dt;
        }
      });
      let hit = false;
      if (String(p?.kind || '') === 'hostile-red' && p?.hostileToEnemies === false) {
        const hostileHitRadius = projectileHitRadiusLogical * Math.max(1.25, Number(p?.hostileVisualScale) || 1);
        if (collision.pointWithinRadius(p, centerWorld, hostileHitRadius)) {
          helpers.applyPlayerHit?.({
            sourceType: 'projectile',
            travelDirection: { x: Number(p.vx) || 0, y: Number(p.vy) || 0 },
            sourcePosition: { x: Number(p.wx) || 0, y: Number(p.wy) || 0 },
            playerPosition: centerWorld,
            damage: Math.max(0.1, Number(p.damage) || 1),
            knockbackStrength: 800,
          });
          hit = true;
        }
      }
      withProjectileDetailPerf('pickupsCombat.projectiles.collision', () => {
        if (collisionStride > 1 && (i % collisionStride) !== collisionPhase) return;
        const allowCollision = !(Number(p.collisionGraceT) > 0);
        const collisionRadiusWorld = Math.max(projectileHitRadiusLogical * 3, enemySpatialCellSize);
        forEachNearbyEnemy(p.wx, p.wy, collisionRadiusWorld, (e) => {
          if (!allowCollision) return true;
          if (p?.hostileToEnemies === false) return false;
          const enemyId = Math.trunc(Number(e.id) || 0);
          if (Number.isFinite(p.ignoreEnemyId) && Math.trunc(p.ignoreEnemyId) === enemyId) return false;
          const enemyType = String(e?.enemyType || '');
          let hitPoint = null;
          if (enemyType === 'drawsnake') {
            hitPoint = helpers.getDrawSnakeProjectileImpactPoint?.(e, p, projectileHitRadiusLogical);
          } else {
            const enemyExtraRadiusLogical = Math.max(0, Number(e?.projectileHitRadiusLogical) || 0);
            const effR = projectileHitRadiusLogical + enemyExtraRadiusLogical;
            if (collision.pointWithinRadius(e, p, effR)) hitPoint = { x: e.wx, y: e.wy };
          }
          if (hitPoint) {
            if (isBoomerang) {
              if (!(p.hitEnemyIds instanceof Set)) p.hitEnemyIds = new Set();
              if (enemyId > 0 && p.hitEnemyIds.has(enemyId)) return false;
              if (enemyId > 0) p.hitEnemyIds.add(enemyId);
            }
            helpers.withDamageSoundStage?.(p.chainStageIndex, () => helpers.damageEnemy?.(e, p.damage));
            if (Array.isArray(p.nextStages) && p.nextStages.length) {
              const stages = helpers.sanitizeWeaponStages?.(p.nextStages) || [];
              const nextBeat = Number.isFinite(p.nextBeatIndex)
                ? Math.max(Math.trunc(p.nextBeatIndex), Math.max(0, currentBeatIndex) + 1)
                : (Math.max(0, currentBeatIndex) + 1);
              const chainCtx = {
                ...(p.chainContext && typeof p.chainContext === 'object' ? p.chainContext : null),
                origin: { x: p.wx, y: p.wy },
                impactPoint: hitPoint,
                weaponSlotIndex: Number.isFinite(p.chainWeaponSlotIndex) ? Math.trunc(p.chainWeaponSlotIndex) : null,
                stageIndex: Number.isFinite(p.chainStageIndex) ? Math.trunc(p.chainStageIndex) : null,
                impactEnemyId: enemyId > 0 ? enemyId : null,
                sourceEnemyId: enemyId > 0 ? enemyId : null,
                damageScale: Math.max(0.05, Number(p.chainDamageScale) || 1),
              };
              helpers.queueWeaponChain?.(nextBeat, stages, chainCtx);
            }
            if (!isBoomerang) {
              hit = true;
              return true;
            }
          }
          return false;
        });
      });
      const preProjectionRemovalReason = hit
        ? 'collision'
        : getBeatSwarmProjectileViewportRemovalReason({ usesTtlDespawn: useTtlDespawn, ttl: p.ttl });
      if (preProjectionRemovalReason) {
        recordProjectileRemoval(p, preProjectionRemovalReason);
        if (String(p?.kind || '') === 'hostile-red' && Array.isArray(state.pooledHostileRedProjectiles) && p?.el instanceof HTMLElement) {
          try { p.el.remove(); } catch {}
          p.el.style.transform = 'translate(-9999px, -9999px)';
          if (state.pooledHostileRedProjectiles.length < 256) state.pooledHostileRedProjectiles.push(p.el);
          if (Array.isArray(state.pooledHostileRedProjectileStates) && state.pooledHostileRedProjectileStates.length < 256) {
            if (p.hitEnemyIds instanceof Set) p.hitEnemyIds.clear();
            if (Array.isArray(p.nextStages)) p.nextStages.length = 0;
            state.pooledHostileRedProjectileStates.push(p);
          }
        } else {
          try { p.el?.remove?.(); } catch {}
        }
        projectiles.splice(i, 1);
        continue;
      }
      const s = helpers.worldToScreen?.({ x: p.wx, y: p.wy });
      if (!s || !Number.isFinite(s.x) || !Number.isFinite(s.y)) {
        if (p?.el) p.el.style.transform = 'translate(-9999px, -9999px)';
        continue;
      }
      const projectileWorld = { x: Number(p.wx) || 0, y: Number(p.wy) || 0 };
      if (helpers.isWorldPointInsideGameplay?.(projectileWorld, 0) === true) {
        p.enteredGameplay = true;
        p.hasEnteredScreen = true;
      }
      const isOffscreen = helpers.isWorldPointInsideGameplay?.(
        projectileWorld, projectileOffscreenPad,
      ) === false;
      const viewportRemovalReason = getBeatSwarmProjectileViewportRemovalReason({
        usesTtlDespawn: useTtlDespawn,
        isOutsideLifetimeBounds: isOffscreen,
        enteredGameplay: p.enteredGameplay === true || p.hasEnteredScreen === true,
        ttl: p.ttl,
      });
      if (viewportRemovalReason) {
        recordProjectileRemoval(p, viewportRemovalReason);
        if (String(p?.kind || '') === 'hostile-red' && Array.isArray(state.pooledHostileRedProjectiles) && p?.el instanceof HTMLElement) {
          try { p.el.remove(); } catch {}
          p.el.style.transform = 'translate(-9999px, -9999px)';
          if (state.pooledHostileRedProjectiles.length < 256) state.pooledHostileRedProjectiles.push(p.el);
          if (Array.isArray(state.pooledHostileRedProjectileStates) && state.pooledHostileRedProjectileStates.length < 256) {
            if (p.hitEnemyIds instanceof Set) p.hitEnemyIds.clear();
            if (Array.isArray(p.nextStages)) p.nextStages.length = 0;
            state.pooledHostileRedProjectileStates.push(p);
          }
        } else {
          try { p.el?.remove?.(); } catch {}
        }
        projectiles.splice(i, 1);
        continue;
      }
      withPerfSample('pickupsCombat.projectiles.dom', () => {
        if (isBoomerang) {
          const deg = ((Number(p.boomTheta) || 0) * (180 / Math.PI) * (Number(constants.projectileBoomerangSpinMult) || 1)) + 180;
          p.el.style.transform = `translate(${s.x}px, ${s.y}px) rotate(${deg.toFixed(2)}deg) scale(${presentationScale})`;
        } else {
          p.el.style.transform = `translate(${s.x}px, ${s.y}px) scale(${presentationScale})`;
        }
      });
    }
  });

  withPerfSample('pickupsCombat.effects', () => {
    if (effects.length > maxEffectCount) {
      const dropCount = effects.length - maxEffectCount;
      const droppedEffects = effects.splice(0, dropCount);
      for (let i = 0; i < droppedEffects.length; i++) {
        const droppedFx = droppedEffects[i];
        if (droppedFx?.kind === 'wind-push') {
          helpers.noteMusicSystemEvent?.('enemy_wind_push_visual_status', {
            phase: 'removed_before_completion',
            enemyId: Math.max(0, Math.trunc(Number(droppedFx.sourceEnemyId) || 0)),
            removalReason: 'shared_effect_cap',
            visualFrameCount: Math.max(0, Math.trunc(Number(droppedFx.visualFrameCount) || 0)),
            onscreenVisualFrameCount: Math.max(0, Math.trunc(Number(droppedFx.onscreenVisualFrameCount) || 0)),
          }, { beatIndex: currentBeatIndex, stepIndex: 0 });
        }
        try { droppedEffects[i]?.el?.remove?.(); } catch {}
      }
    }
    for (let i = effects.length - 1; i >= 0; i--) {
      const fx = effects[i];
      fx.ttl -= dt;
      if (fx.kind === 'explosion-prime' && fx.ttl <= 0) {
      const chainEventId = Number.isFinite(fx.chainEventId) ? Math.trunc(fx.chainEventId) : null;
      const pendingStillExists = chainEventId ? helpers.hasPendingWeaponChainEventById?.(chainEventId) === true : false;
      if (!pendingStillExists) {
        const detonationPoint = fx.at && Number.isFinite(fx.at.x) && Number.isFinite(fx.at.y)
          ? { x: Number(fx.at.x) || 0, y: Number(fx.at.y) || 0 }
          : (fx.fallbackAt && Number.isFinite(fx.fallbackAt.x) && Number.isFinite(fx.fallbackAt.y)
            ? { x: Number(fx.fallbackAt.x) || 0, y: Number(fx.fallbackAt.y) || 0 }
            : null);
        if (detonationPoint) {
          helpers.applyAoeAt?.(
            detonationPoint,
            'explosion',
            currentBeatIndex,
            Number.isFinite(fx.weaponSlotIndex) ? Math.trunc(fx.weaponSlotIndex) : null,
            Number.isFinite(fx.anchorEnemyId) ? Math.trunc(fx.anchorEnemyId) : null,
            Number.isFinite(fx.stageIndex) ? Math.trunc(fx.stageIndex) : null,
            Math.max(0.05, Number(fx.damageScale) || 1),
            chainEventId
          );
          helpers.noteMusicSystemEvent?.('weapon_explosion_failsafe_detonated', {
            chainEventId: chainEventId || 0,
            weaponSlotIndex: Number.isFinite(fx.weaponSlotIndex) ? Math.trunc(fx.weaponSlotIndex) : -1,
            impactEnemyId: Number.isFinite(fx.anchorEnemyId) ? Math.trunc(fx.anchorEnemyId) : 0,
            scheduledBeatIndex: currentBeatIndex,
            damageScale: Math.max(0.05, Number(fx.damageScale) || 1),
            detonationSource: 'prime_ttl_expired',
          }, { beatIndex: currentBeatIndex, stepIndex: 0 });
        }
      }
    }
      if (fx.ttl <= 0) {
        if (fx.kind === 'wind-push') {
          helpers.noteMusicSystemEvent?.('enemy_wind_push_visual_status', {
            phase: 'completed',
            enemyId: Math.max(0, Math.trunc(Number(fx.sourceEnemyId) || 0)),
            removalReason: 'ttl_complete',
            visualFrameCount: Math.max(0, Math.trunc(Number(fx.visualFrameCount) || 0)),
            onscreenVisualFrameCount: Math.max(0, Math.trunc(Number(fx.onscreenVisualFrameCount) || 0)),
            everIntersectedViewport: Number(fx.onscreenVisualFrameCount) > 0,
          }, { beatIndex: currentBeatIndex, stepIndex: 0 });
        }
        try { fx.el?.remove?.(); } catch {}
        effects.splice(i, 1);
        continue;
      }
      if (fx.kind === 'laser' || fx.kind === 'beam') {
        let removedDuringBeamUpdate = false;
        withPerfSample('pickupsCombat.effects.beams', () => {
          if (fx.kind === 'beam') {
            if (Number.isFinite(fx.sourceEnemyId)) {
              const srcAlive = !!getEnemyById(fx.sourceEnemyId);
              if (!srcAlive) {
                const pendingDeath = helpers.getPendingEnemyDeathByEnemyId?.(fx.sourceEnemyId);
                if (!pendingDeath) {
                  try { fx.el?.remove?.(); } catch {}
                  effects.splice(i, 1);
                  removedDuringBeamUpdate = true;
                  return;
                } else {
                  fx.from = { x: Number(pendingDeath.wx) || 0, y: Number(pendingDeath.wy) || 0 };
                }
              } else {
                fx.sourceGoneTtl = null;
                const src = getEnemyById(fx.sourceEnemyId);
                if (src) fx.from = { x: Number(src.wx) || 0, y: Number(src.wy) || 0 };
              }
            }
            let target = null;
            if (Number.isFinite(fx.targetEnemyId)) {
              target = getEnemyById(fx.targetEnemyId);
            }
            if (!target) {
              target = getNearestEnemyLocal(fx.from?.x || 0, fx.from?.y || 0, fx.sourceEnemyId) || helpers.getNearestEnemy?.(fx.from?.x || 0, fx.from?.y || 0, fx.sourceEnemyId);
              fx.targetEnemyId = Number.isFinite(target?.id) ? Math.trunc(target.id) : null;
            }
            if (target) {
              fx.to = { x: target.wx, y: target.wy };
              helpers.damageEnemy?.(target, Math.max(0, Number(fx.damagePerSec) || 0) * dt);
            }
          } else if (fx.kind === 'laser') {
            if (Number.isFinite(fx.sourceEnemyId)) {
              const src = getEnemyById(fx.sourceEnemyId);
              if (src) {
                fx.from = { x: Number(src.wx) || 0, y: Number(src.wy) || 0 };
              } else {
                const pendingDeath = helpers.getPendingEnemyDeathByEnemyId?.(fx.sourceEnemyId);
                if (pendingDeath) fx.from = { x: Number(pendingDeath.wx) || 0, y: Number(pendingDeath.wy) || 0 };
              }
            }
            if (Number.isFinite(fx.targetEnemyId)) {
              const trg = getEnemyById(fx.targetEnemyId);
              if (trg) fx.to = { x: Number(trg.wx) || 0, y: Number(trg.wy) || 0 };
            }
          }
          const a = helpers.worldToScreen?.({ x: fx.from.x, y: fx.from.y });
          const b = helpers.worldToScreen?.({ x: fx.to.x, y: fx.to.y });
          if (!a || !b) return;
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const len = Math.max(1, Math.hypot(dx, dy));
          const ang = Math.atan2(dy, dx) * (180 / Math.PI);
          fx.el.style.width = `${len}px`;
          fx.el.style.height = `${Math.max(1, 5 * presentationScale).toFixed(2)}px`;
          fx.el.style.transform = `translate(${a.x}px, ${a.y}px) rotate(${ang}deg)`;
          if (fx.kind === 'beam') {
            fx.el.style.opacity = '1';
          } else {
            fx.el.style.opacity = `${Math.max(0, Math.min(1, fx.ttl / (Number(constants.laserTtl) || 1)))}`;
          }
        });
        if (removedDuringBeamUpdate) continue;
      } else {
        let removedDuringExplosionUpdate = false;
        withPerfSample('pickupsCombat.effects.explosions', () => {
          const basePxRadius = Math.max(18 * presentationScale, (Number(fx.radiusWorld) || Number(constants.explosionRadiusWorld) || 0) * Math.max(0.001, scale || 1) * presentationScale);
          let radiusScale = 1;
          let opacity = Math.max(0, Math.min(1, fx.ttl / (Number(constants.explosionTtl) || 1)));
          let brightness = 1;
          if (fx.kind === 'pinball-shockwave') {
            const center = {
              x: Number(fx.at?.x) || 0,
              y: Number(fx.at?.y) || 0,
            };
            const previousRadius = Math.max(0, Number(fx.previousRadiusWorld) || 0);
            const currentRadius = Math.max(previousRadius, (Number(fx.currentRadiusWorld) || 0) + (Math.max(0, Number(fx.expandSpeedWorld) || 0) * dt));
            const maxRadius = Math.max(1, Number(fx.radiusWorld) || currentRadius);
            const ringWidth = Math.max(32, Number(fx.ringWidthWorld) || 170);
            fx.previousRadiusWorld = previousRadius;
            fx.currentRadiusWorld = currentRadius;
            if (!(fx.hitEnemyIds instanceof Set)) fx.hitEnemyIds = new Set();
            let consideredEnemies = 0;
            let closestEnemyDistanceToRing = Infinity;
            let frameHitCount = 0;
            const spawnShockwaveHitFx = (enemy, source = 'radius') => {
              if (!enemy || enemy.__bsRemoved || enemy.hp <= 0) return false;
              const enemyId = Math.trunc(Number(enemy.id) || 0);
              const impactAt = { x: Number(enemy.wx) || 0, y: Number(enemy.wy) || 0 };
              try {
                const impactEl = document.createElement('div');
                impactEl.className = 'beat-swarm-fx-pinball-shockwave-hit is-debug-visible';
                impactEl.style.transform = 'translate(-9999px, -9999px)';
                enemyLayerEl?.appendChild?.(impactEl);
                effects.push({
                  kind: 'pinball-shockwave-hit',
                  ttl: 0.6,
                  duration: 0.6,
                  at: impactAt,
                  radiusWorld: Math.max(150, (Number(constants.explosionRadiusWorld) || 180) * 0.9),
                  el: impactEl,
                });
                helpers.noteMusicSystemEvent?.('pinball_shockwave_enemy_hit_fx_spawned', {
                  enemyId,
                  source,
                  hitCount: fx.hitEnemyIds.size,
                  currentRadiusWorld: currentRadius,
                  previousRadiusWorld: previousRadius,
                  impactX: impactAt.x,
                  impactY: impactAt.y,
                }, { beatIndex: currentBeatIndex, stepIndex: 0 });
                try {
                  const dbg = globalThis.__beatSwarmPinballShockwaveDebug && typeof globalThis.__beatSwarmPinballShockwaveDebug === 'object'
                    ? globalThis.__beatSwarmPinballShockwaveDebug
                    : {};
                  dbg.lastHit = {
                    enemyId,
                    source,
                    hitCount: fx.hitEnemyIds.size,
                    currentRadiusWorld: currentRadius,
                    previousRadiusWorld: previousRadius,
                    impactX: impactAt.x,
                    impactY: impactAt.y,
                    at: Date.now(),
                  };
                  dbg.totalHits = Math.max(0, Math.trunc(Number(dbg.totalHits) || 0)) + 1;
                  globalThis.__beatSwarmPinballShockwaveDebug = dbg;
                  if (globalThis.__beatSwarmPinballShockwaveConsole === true) {
                    console.info('[PinballShockwave] enemy hit', dbg.lastHit);
                  }
                } catch {}
                return true;
              } catch {
                return false;
              }
            };
            for (const enemy of enemies.slice()) {
              if (!enemy || enemy.__bsRemoved || enemy.hp <= 0) continue;
              consideredEnemies += 1;
              const enemyId = Math.trunc(Number(enemy.id) || 0);
              if (enemyId > 0 && fx.hitEnemyIds.has(enemyId)) continue;
              const enemyLogical = helpers.worldToLogical?.(enemy) || enemy;
              const centerLogical = helpers.worldToLogical?.(center) || center;
              const dx = (Number(enemyLogical.x) || 0) - centerLogical.x;
              const dy = (Number(enemyLogical.y) || 0) - centerLogical.y;
              const dist = Math.hypot(dx, dy);
              closestEnemyDistanceToRing = Math.min(closestEnemyDistanceToRing, Math.abs(dist - currentRadius));
              // Once the expanding wave has reached an enemy, register the hit.
              // The hitEnemyIds set keeps this one-shot, so we do not need a narrow
              // frame-band test that can miss fast-moving enemies or sparse frames.
              if (dist > currentRadius + ringWidth) continue;
              frameHitCount += 1;
              const dir = helpers.normalizeDir?.(dx, dy, 1, 0) || { x: 1, y: 0 };
              const impactAt = { x: Number(enemy.wx) || 0, y: Number(enemy.wy) || 0 };
              enemy.vx = (Number(enemy.vx) || 0) + ((Number(dir.x) || 0) * Math.max(0, Number(fx.pushPower) || 0));
              enemy.vy = (Number(enemy.vy) || 0) + ((Number(dir.y) || 0) * Math.max(0, Number(fx.pushPower) || 0));
              if (enemyId > 0) fx.hitEnemyIds.add(enemyId);
              spawnShockwaveHitFx(enemy, 'radius');
              helpers.damageEnemy?.(enemy, Math.max(0, Number(fx.damage) || 0));
            }
            if (frameHitCount <= 0 && fx.debugFallbackUsed !== true && currentRadius > Math.max(220, ringWidth)) {
              let fallbackEnemy = null;
              let fallbackD2 = Infinity;
              for (const enemy of enemies.slice()) {
                if (!enemy || enemy.__bsRemoved || enemy.hp <= 0) continue;
                const enemyId = Math.trunc(Number(enemy.id) || 0);
                if (enemyId > 0 && fx.hitEnemyIds.has(enemyId)) continue;
                const dx = (Number(enemy.wx) || 0) - center.x;
                const dy = (Number(enemy.wy) || 0) - center.y;
                const d2 = (dx * dx) + (dy * dy);
                if (d2 < fallbackD2) {
                  fallbackD2 = d2;
                  fallbackEnemy = enemy;
                }
              }
              if (fallbackEnemy) {
                const enemyId = Math.trunc(Number(fallbackEnemy.id) || 0);
                const dx = (Number(fallbackEnemy.wx) || 0) - center.x;
                const dy = (Number(fallbackEnemy.wy) || 0) - center.y;
                const dir = helpers.normalizeDir?.(dx, dy, 1, 0) || { x: 1, y: 0 };
                fallbackEnemy.vx = (Number(fallbackEnemy.vx) || 0) + ((Number(dir.x) || 0) * Math.max(0, Number(fx.pushPower) || 0));
                fallbackEnemy.vy = (Number(fallbackEnemy.vy) || 0) + ((Number(dir.y) || 0) * Math.max(0, Number(fx.pushPower) || 0));
                if (enemyId > 0) fx.hitEnemyIds.add(enemyId);
                fx.debugFallbackUsed = true;
                frameHitCount += 1;
                spawnShockwaveHitFx(fallbackEnemy, 'nearest_fallback');
                helpers.damageEnemy?.(fallbackEnemy, Math.max(0, Number(fx.damage) || 0));
              }
            }
            try {
              const dbg = globalThis.__beatSwarmPinballShockwaveDebug && typeof globalThis.__beatSwarmPinballShockwaveDebug === 'object'
                ? globalThis.__beatSwarmPinballShockwaveDebug
                : {};
              dbg.active = true;
              dbg.lastFrame = {
                consideredEnemies,
                frameHitCount,
                totalRecordedHits: fx.hitEnemyIds.size,
                currentRadiusWorld: currentRadius,
                previousRadiusWorld: previousRadius,
                maxRadiusWorld: maxRadius,
                ringWidthWorld: ringWidth,
                closestEnemyDistanceToRing: Number.isFinite(closestEnemyDistanceToRing) ? closestEnemyDistanceToRing : null,
                centerX: center.x,
                centerY: center.y,
                at: Date.now(),
              };
              globalThis.__beatSwarmPinballShockwaveDebug = dbg;
            } catch {}
            fx.previousRadiusWorld = currentRadius;
            if (currentRadius >= maxRadius) {
              try { fx.el?.remove?.(); } catch {}
              effects.splice(i, 1);
              removedDuringExplosionUpdate = true;
              return;
            }
            radiusScale = currentRadius / maxRadius;
            opacity = 1;
          } else if (fx.kind === 'explosion-prime') {
        const anchorId = Number.isFinite(fx.anchorEnemyId) ? Math.trunc(fx.anchorEnemyId) : null;
        if (anchorId) {
          const anchorEnemy = getEnemyById(anchorId);
          if (anchorEnemy) {
            fx.at = { x: Number(anchorEnemy.wx) || 0, y: Number(anchorEnemy.wy) || 0 };
          } else {
            const pendingDeath = helpers.getPendingEnemyDeathByEnemyId?.(anchorId);
            if (pendingDeath) {
              fx.at = { x: Number(pendingDeath.wx) || 0, y: Number(pendingDeath.wy) || 0 };
            } else {
              const chainEventId = Number.isFinite(fx.chainEventId) ? Math.trunc(fx.chainEventId) : null;
              const pendingStillExists = chainEventId ? helpers.hasPendingWeaponChainEventById?.(chainEventId) === true : false;
              if (!pendingStillExists) {
                const detonationPoint = fx.fallbackAt && Number.isFinite(fx.fallbackAt.x) && Number.isFinite(fx.fallbackAt.y)
                  ? { x: Number(fx.fallbackAt.x) || 0, y: Number(fx.fallbackAt.y) || 0 }
                  : null;
                if (detonationPoint) {
                  helpers.applyAoeAt?.(
                    detonationPoint,
                    'explosion',
                    currentBeatIndex,
                    Number.isFinite(fx.weaponSlotIndex) ? Math.trunc(fx.weaponSlotIndex) : null,
                    anchorId,
                    Number.isFinite(fx.stageIndex) ? Math.trunc(fx.stageIndex) : null,
                    Math.max(0.05, Number(fx.damageScale) || 1),
                    chainEventId
                  );
                  helpers.noteMusicSystemEvent?.('weapon_explosion_failsafe_detonated', {
                    chainEventId: chainEventId || 0,
                    weaponSlotIndex: Number.isFinite(fx.weaponSlotIndex) ? Math.trunc(fx.weaponSlotIndex) : -1,
                    impactEnemyId: anchorId || 0,
                    scheduledBeatIndex: currentBeatIndex,
                    damageScale: Math.max(0.05, Number(fx.damageScale) || 1),
                    detonationSource: 'prime_anchor_lost',
                  }, { beatIndex: currentBeatIndex, stepIndex: 0 });
                }
              }
              try { fx.el?.remove?.(); } catch {}
              effects.splice(i, 1);
              removedDuringExplosionUpdate = true;
              return;
            }
          }
        }
            const total = Math.max(0.05, Number(fx.duration) || (helpers.getGameplayBeatLen?.() || 0.05));
            const elapsedN = Math.max(0, Math.min(1, 1 - (fx.ttl / total)));
            const eased = 1 - ((1 - elapsedN) * (1 - elapsedN));
            radiusScale = 0.04 + (((Number(constants.explosionPrimeMaxScale) || 1) - 0.04) * eased);
            opacity = 0.22 + (0.34 * eased);
          } else if (fx.kind === 'explosion' || fx.kind === 'hostile-explosion') {
            const total = Math.max(0.05, Number(fx.duration) || helpers.getGameplayBeatLen?.() || 0.5);
            const elapsedN = Math.max(0, Math.min(1, 1 - (fx.ttl / total)));
            const flashN = Math.max(0, 1 - (elapsedN / 0.16));
            radiusScale = 0.72 + (0.28 * (1 - Math.pow(1 - elapsedN, 3)));
            opacity = Math.max(0, Math.pow(1 - elapsedN, 0.62));
            brightness = 1 + (flashN * 1.5);
          } else if (fx.kind === 'music-explosion') {
            const total = Math.max(0.1, Number(fx.duration) || Number(constants.explosionTtl) || 0.72);
            const elapsedN = Math.max(0, Math.min(1, 1 - (fx.ttl / total)));
            const attackN = Math.min(1, elapsedN / 0.08);
            const decayN = Math.max(0, (elapsedN - 0.08) / 0.92);
            radiusScale = 0.18 + (0.82 * (1 - ((1 - attackN) * (1 - attackN)))) + (0.12 * decayN);
            opacity = elapsedN <= 0.08 ? 1 : Math.pow(1 - decayN, 0.72);
          } else if (fx.kind === 'wind-push') {
            const total = Math.max(0.1, Number(fx.duration) || 0.72);
            const elapsedN = Math.max(0, Math.min(1, 1 - (fx.ttl / total)));
            const eased = 1 - Math.pow(1 - elapsedN, 3);
            radiusScale = 0.12 + (0.88 * eased);
            opacity = Math.max(0, Math.pow(1 - elapsedN, 0.7));
          } else if (fx.kind === 'pinball-shockwave-hit') {
            if (Number(fx.startDelay) > 0) {
              fx.startDelay = Math.max(0, (Number(fx.startDelay) || 0) - dt);
              if (fx.startDelay > 0) {
                try {
                  fx.el.style.opacity = '0';
                  fx.el.style.transform = 'translate(-9999px, -9999px)';
                } catch {}
                return;
              } else {
                fx.ttl = Math.max(0.05, Number(fx.duration) || 0.6);
                const target = Number.isFinite(Number(fx.targetEnemyId)) ? getEnemyById(fx.targetEnemyId) : null;
                if (target && target.__bsRemoved !== true && !(Number(target.hp) <= 0)) {
                  fx.at = { x: Number(target.wx) || 0, y: Number(target.wy) || 0 };
                  const dx = (Number(target.wx) || 0) - (Number(fx.sourceCenter?.x) || 0);
                  const dy = (Number(target.wy) || 0) - (Number(fx.sourceCenter?.y) || 0);
                  const dir = helpers.normalizeDir?.(dx, dy, 1, 0) || { x: 1, y: 0 };
                  target.vx = (Number(target.vx) || 0) + ((Number(dir.x) || 0) * Math.max(0, Number(fx.shockwavePushPower) || 0));
                  target.vy = (Number(target.vy) || 0) + ((Number(dir.y) || 0) * Math.max(0, Number(fx.shockwavePushPower) || 0));
                  helpers.damageEnemy?.(target, Math.max(0, Number(fx.shockwaveDamage) || 0));
                  helpers.noteMusicSystemEvent?.('pinball_shockwave_enemy_hit_fx_spawned', {
                    enemyId: Math.trunc(Number(fx.targetEnemyId) || 0),
                    source: String(fx.source || 'scheduled_shockwave_snapshot'),
                    impactX: Number(fx.at?.x) || 0,
                    impactY: Number(fx.at?.y) || 0,
                  }, { beatIndex: currentBeatIndex, stepIndex: 0 });
                }
              }
            }
            const total = Math.max(0.05, Number(fx.duration) || 0.24);
            const elapsedN = Math.max(0, Math.min(1, 1 - (fx.ttl / total)));
            radiusScale = 0.34 + (0.9 * (1 - ((1 - elapsedN) * (1 - elapsedN))));
            opacity = Math.max(0.18, Math.pow(1 - elapsedN, 0.34));
          }
          const c = helpers.worldToScreen?.({ x: Number(fx.at?.x) || 0, y: Number(fx.at?.y) || 0 });
          if (!c) {
            if (fx.kind === 'wind-push' && fx.visualStatusReported !== true) {
              fx.visualStatusReported = true;
              helpers.noteMusicSystemEvent?.('enemy_wind_push_visual_status', {
                phase: 'display_failed',
                enemyId: Math.max(0, Math.trunc(Number(fx.sourceEnemyId) || 0)),
                visualElementCreated: !!fx.el,
                visualAttached: fx.el?.isConnected === true,
                effectRegistered: true,
                sourceEnemyAlive: !!getEnemyById(fx.sourceEnemyId),
                failureReason: 'world_to_screen_failed',
              }, { beatIndex: currentBeatIndex, stepIndex: 0 });
            }
            return;
          }
          if (fx.kind === 'wind-push' && !fx.el) {
            if (fx.visualStatusReported !== true) {
              fx.visualStatusReported = true;
              helpers.noteMusicSystemEvent?.('enemy_wind_push_visual_status', {
                phase: 'display_failed',
                enemyId: Math.max(0, Math.trunc(Number(fx.sourceEnemyId) || 0)),
                visualElementCreated: false,
                visualAttached: false,
                effectRegistered: true,
                sourceEnemyAlive: !!getEnemyById(fx.sourceEnemyId),
                failureReason: 'visual_dom_missing',
              }, { beatIndex: currentBeatIndex, stepIndex: 0 });
            }
            return;
          }
          const pxRadius = basePxRadius * radiusScale;
          const pxSize = pxRadius * 2;
          const viewportWidth = Math.max(1, Number(globalThis.window?.innerWidth) || 0);
          const viewportHeight = Math.max(1, Number(globalThis.window?.innerHeight) || 0);
          const centerOnscreen = c.x >= 0 && c.x <= viewportWidth && c.y >= 0 && c.y <= viewportHeight;
          const waveIntersectsViewport = (
            c.x + pxRadius >= 0
            && c.x - pxRadius <= viewportWidth
            && c.y + pxRadius >= 0
            && c.y - pxRadius <= viewportHeight
          );
          if (fx.kind === 'wind-push') {
            fx.visualFrameCount = Math.max(0, Math.trunc(Number(fx.visualFrameCount) || 0)) + 1;
            if (waveIntersectsViewport) {
              fx.onscreenVisualFrameCount = Math.max(0, Math.trunc(Number(fx.onscreenVisualFrameCount) || 0)) + 1;
            }
          }
          fx.el.style.width = `${pxSize}px`;
          fx.el.style.height = `${pxSize}px`;
          fx.el.style.marginLeft = `${-pxRadius}px`;
          fx.el.style.marginTop = `${-pxRadius}px`;
          fx.el.style.transform = `translate(${c.x}px, ${c.y}px)`;
          fx.el.style.opacity = `${opacity}`;
          fx.el.style.filter = `brightness(${brightness.toFixed(3)})`;
          if (fx.kind === 'wind-push' && fx.visualStatusReported !== true) {
            fx.visualStatusReported = true;
            const visualAttached = fx.el?.isConnected === true || !!fx.el?.parentNode;
            helpers.noteMusicSystemEvent?.('enemy_wind_push_visual_status', {
              phase: visualAttached ? 'first_displayed_frame' : 'display_failed',
              enemyId: Math.max(0, Math.trunc(Number(fx.sourceEnemyId) || 0)),
              visualElementCreated: true,
              visualAttached,
              effectRegistered: true,
              sourceEnemyAlive: !!getEnemyById(fx.sourceEnemyId),
              failureReason: visualAttached ? '' : 'visual_dom_detached_before_display',
              radiusPx: Number(pxRadius.toFixed(2)),
              opacity: Number(opacity.toFixed(3)),
              centerX: Number(c.x.toFixed(2)),
              centerY: Number(c.y.toFixed(2)),
              centerOnscreen,
              waveIntersectsViewport,
            }, { beatIndex: currentBeatIndex, stepIndex: 0 });
          }
        });
        if (removedDuringExplosionUpdate) continue;
      }
    }
  });

  withPerfSample('pickupsCombat.energyGravity', () => {
    helpers.updateEnergyGravityRuntime?.(dt, centerWorld, scale);
  });
  if (!suppressWeaponRuntime) {
    withPerfSample('pickupsCombat.weaponRuntime', () => {
      helpers.updateBeatWeapons?.(centerWorld);
    });
  }
  withPerfSample('pickupsCombat.soundFlush', () => {
    helpers.flushSwarmSoundEventsForBeat?.(currentBeatIndex);
  });
}
