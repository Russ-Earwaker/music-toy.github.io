# Free Play first playable prototype

Implemented and checked on 18 October 2026. Enter using **Free Play** at the top of the normal app. Play with Paint, Ball, Ripple, or Drum, then press **Make Music**. The playground stays open. **See How It Works** reveals the actual generated graph.

## 1. Architecture

`src/free-play.js` owns the presentation, normalized pointer samples, immediate audition, and lightweight session. `src/free-play-sources.js` converts those samples directly into existing toy snapshots. The integration at the end of `src/main.js` creates/reuses ordinary toy panels, applies their normal persistence adapters, and invokes the existing Auto-Arranger.

Each playground session receives a separate ordinary Heartbeat on its first Make Music. An optional Heartbeat argument to Auto-Arrange restricts its inputs and previous arrangement lookup to that domain. Existing graph compositions remain intact. There is no new composition engine, arrangement compiler, or arranged-audio scheduler.

Capture remains in memory. After Make Music, the normal graph, definitions, linked copies, and Heartbeat persist through existing autosave. Reload restores that graph; it starts a fresh Free Play gesture session.

## 2. Simplified UI

Free Play presents four touch-friendly tool buttons, a large canvas, Make Music, Clear, Back to graph, and playback pause/resume after generation. See How It Works appears after success. Normal menus, Arrange, logic creation, cables, sockets, palette, and advanced controls are covered, hidden, and made inert while Free Play is active. They remain available in graph mode.

## 3. Paint conversion

Pointer-down immediately auditions a piano note; drawing continues auditioning at a maximum of roughly 15 notes per second. Horizontal position maps to the ordinary one-bar eight-column DrawGrid. Vertical position maps to its twelve chromatic rows, B3 at the top through C3 at the bottom. Sparse samples are interpolated across crossed columns. Nodes and normalized original strokes are both retained. The normal melody-phrase builder preserves the authored first bar and develops supporting bars.

## 4. Ball conversion

A drag/release specifies launch position and velocity. The existing swept-collision `stepBouncer` physics runs at a deterministic 120 Hz in the native 300 × 300 logical world. The preview plays the launch and wall impacts while displaying that trajectory. Each throw becomes its own normal Bouncer source containing `lastLaunch` and native `loopRec.pattern`/`trajectory` replay data. The native snapshot adapter refreshes a restored replay's geometry signature so the first bar does not erase it as a geometry change.

## 5. Ripple conversion

A tap immediately creates a visible ring and auditions a pitched tone. Eight vertical bands map to normal Rippler block identities. Normalized positions, active blocks, generator position, and native per-event tick offsets are restored through the Rippler snapshot adapter. Playback uses the existing Rippler event provider.

## 6. Drum conversion

Canvas taps immediately audition the kick and show a pulse. Recorded times become a normal LoopGrid source with 32 subdivisions of a bar. Persistence and restoration retain the subdivision count, including linked copies. `dense-rhythm-grid.js` exposes every step for inspection/toggling in graph mode instead of hiding steps beyond the legacy eight-cube canvas. Arranged drum flashes use the existing admitted-playback visual queue.

## 7. Quantisation policy

| Interaction | Direct play | Structured source |
| --- | --- | --- |
| Paint | Immediate, no visible grid | Horizontal position into eight eighth-note columns; vertical position into twelve chromatic rows. Multiple rows in a column are retained. |
| Ball | Launch and collision preview | One bar of native replay; collision times rounded to one of 384 ticks, with no additional rhythmic snap. |
| Ripple | Immediate tap | Timing wraps into one bar and rounds to the nearest native tick; eight slots index events while exact offsets determine playback. |
| Drum | Immediate tap | Timing wraps into one bar and rounds to the nearest 32nd-note slot: maximum displacement 31.25 ms at 120 BPM. |

Raw gesture/tap timing remains in the session. This first prototype folds long tap performances into a bar. Drum taps landing on the same slot merge. Rippler taps sharing both a block band and indexing slot coalesce under its existing Set/Map representation. It does not yet preserve arbitrary long unquantised performances.

## 8. Make Music and Auto-Arrange

Make Music pauses the session's Heartbeat, creates/reuses captured source panels, applies normal snapshots, and updates shared definitions. It calls the same `g_autoArranger.arrange({heartbeatId})` used by graph mode, waits for linked-view hydration, places the resulting graph, seeks the session Heartbeat to zero, and plays it.

Existing role classification, missing-part generation, phrase development, bounded texture lanes, and connected arrangement recipe remain in charge. An empty playground supplies a minimal ordinary kick seed and uses the same gap filling. Additional suitable sources occupy the normal B-section texture lanes; the existing four-bar capacity still applies.

## 9. Playground after arrangement

The canvas retains original strokes and tap marks. Paint highlights, ripple rings, and drum pulses follow admitted playback events from the ordinary graph. Balls interpolate captured native trajectories using the active linked occurrence's Heartbeat phase. Supporting sources contribute audio without graph UI. All four interaction types were observed receiving playback-driven visual feedback.

Repeated Make Music reuses source identities and the previous arrangement. Clear cancels previews, pauses the session Heartbeat, and removes that domain's toys, linked views, and structures. See How It Works exits the playground, restores graph controls, reveals authored/supporting sources, and frames the actual arrangement.

## 10. Verification

Browser: Chrome, local test origin. Actual pointer gestures and UI clicks were used. The opt-in `?freePlayProof` observer exposes capture counts, canonical snapshots, transport state, admitted auditions, playback visual counts, and errors as visible QA output. Evidence: `resources/debug-output/free-play/browser-proof.json`.

| Case | Observed result |
| --- | --- |
| Paint only | Immediate auditions, original contour in DrawGrid nodes, generated rhythm/accompaniment, playing Heartbeat. |
| Ball only | Immediate launch/impact preview; six captured hits and 240 trajectory samples in native replay; support added. Final mixed run also verified the native logical-world version with eight hits. |
| Ripple only | Three taps retained as native tick offsets; support added; arrangement played. |
| Drum only | Three irregular taps retained in distinct 32-step slots; support added. Reload restored all 32 inspectable steps. |
| Paint + Ball + Drum | All three source identities included, no unused contributions; accompaniment/support generated. |
| Mixed, repeated Make Music | Same authored source identities; no additional missing-role generation; arrangement replaced successfully. |
| All four tools | All four source identities retained. Fourteen immediate audio admissions; playback visual events observed for Paint, Drum, Ball, and Ripple; no recorded browser errors. |
| Empty session | Minimal seed plus generated melody/accompaniment; playback succeeded. |
| Clear and reveal | Clear returned a new scene to zero toys/structures. With another arrangement present, its 15 toys and 14 structures remained. Graph reveal restored normal controls. |
| Touch layout | Inspected at 390 × 844; four tools, canvas, primary/secondary actions and transport remained usable. |

Automated checks: **78 passed**, covering gesture conversion, deterministic native Bouncer capture, Auto-Arrange input/robustness behavior, Heartbeat isolation and repeat generation, linked toys, transport ownership, and Bouncer timing. JavaScript syntax checks and `git diff --check` also passed.

Audio admission and transport playback were verified programmatically. Subjective listening quality and physical iOS/Android touch/audio behavior still need a human/device check. Detailed generated-arrangement animation, advanced Free Play editing, String, Blocks, sub-boards, and Variation remain parked.
