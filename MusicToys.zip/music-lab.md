Beat Swarm — Music Lab Diagnostic System
Purpose

Create a Music Lab diagnostic system similar to the existing Perf Lab.

Goal:

Record musical events and produce metrics that help evaluate:

melodic coherence

rhythmic structure

system behaviour

palette stability

This tool is for development analysis, not player gameplay.

1. Create Music Lab Module

Create new module:

src/beat-swarm-music-lab.js

Responsibilities:

capture musical events
store session timeline
compute metrics
export JSON report
2. Hook Event Logging

Hook into:

createPerformedBeatEvent()
director.enqueueBeatEvent()
executePerformedBeatEvent()

Log each event.

3. Event Data Format

Each logged event should include:

timestamp
barIndex
beatIndex
stepIndex
actorId
groupId
role
note
instrumentId
actionType
threatClass
pacingState
paletteId
themeId
sourceSystem

Example sourceSystem:

player
spawner
drawsnake
group
death
4. Session Timeline

Maintain a timeline array:

musicSession.events[]
musicSession.paletteChanges[]
musicSession.pacingChanges[]

Allow export:

exportMusicLabSession()
5. Core Metrics

Compute metrics every N bars.

Metric 1 — Note Pool Compliance

Measure:

notes inside pool
notes clamped

Output:

poolComplianceRate

Goal:

systems choose good notes before clamping.

Metric 2 — Interval Profile

Measure pitch jumps between consecutive notes.

Buckets:

repeat
step
small leap
large leap

Output distribution.

Lead melodies should favour:

repeat / step / small leap
Metric 3 — Motif Reuse

Detect repeating sequences.

Examples:

2-note patterns
3-note patterns
4-note patterns

Output:

motifReuseRate
Metric 4 — Role Balance

Count events per role per bar.

Roles:

bass
lead
accent
motion

Output:

roleDistribution

Goal:

Avoid accent overwhelming lead.

Metric 5 — Threat Balance

Count events by threat class.

fullThreat
lightThreat
cosmetic

Output per beat and per bar.

Goal:

maintain design rule:

everyone plays, few attack.

Metric 6 — Call-Response Detection

Detect patterns:

group A event
group B response within N steps

Output:

responsePairs
responseRate
Metric 7 — Palette Stability

Track:

bars since palette change
role instrument changes
theme changes

Output:

paletteContinuityScore
Metric 8 — Death Density

Track:

death events per beat
death clusters

Goal:

avoid melody being drowned by deaths.

Metric 9 — Player Masking

Measure:

enemy events occurring same beat as player shot

Output:

playerMaskingRate

Goal:

player weapon remains audible.

6. Summary Report

At session end produce:

musicSessionSummary

Example output:

notePoolCompliance: 92%
motifReuse: 34%
leadIntervalSmoothness: good
roleBalance: acceptable
responseRate: 0.41
paletteContinuity: stable
playerMasking: low
7. Debug HUD

Optional debug display:

current palette
events per bar
role distribution
motif reuse indicator
8. Export Format

Export JSON similar to Perf Lab:

music-lab-results.json

Contains:

eventTimeline
metrics
sessionSummary
9. Usage

Used for:

system tuning
AI debugging
music system regression checks
playtest analysis
Success Criteria

Music Lab is working when developers can quickly answer:

are melodies repeating?

are intervals reasonable?

are enemies overwhelming the mix?

is the palette stable?

are call-responses happening?

10. Regression Workflow

Recommended workflow:

1. Open Perf Lab -> Music tab.
2. Click:
   Music Lab: Enable
3. Play a run.
4. Click:
   Music Lab: Save to resources
5. Analyze saved sessions:

node tools/music-lab-analyze.mjs

For baseline setup across multiple captures:

node tools/music-lab-analyze.mjs --all

Optional JSON output:

node tools/music-lab-analyze.mjs --all --json

11. Default Thresholds (Initial)

Use these as initial pass/fail gates:

notePoolCompliance >= 0.85
intervalSmoothShare >= 0.70
motifReuseRate >= 0.18
responseRate >= 0.20
paletteContinuityScore >= 0.55
playerMaskingRate <= 0.35

Notes:

These are development defaults, not final balance targets.
After collecting 3-5 sessions, update thresholds to your measured baseline ranges.
