// AutoQualityController.js
// Centralised quality signal for particles and other scalable visuals.
// - FPS-based with hysteresis (prevents oscillation)
// - Memory pressure acts as a hard clamp
// - Emergency mode (very low FPS) forces aggressive reduction immediately

import { getMemoryPressureLevel } from '../particles/ParticleQuality.js';

const AUTO_QUALITY_ENABLED = true;

// Rolling window config
const SAMPLE_WINDOW_MS = 2500;
const MIN_SAMPLES = 20;

// Thresholds (frame time in ms)
const DOWN_P95_MS = 22.0;     // ~45fps
const UP_P95_MS = 16.8;       // ~60fps
const EMERGENCY_P95_MS = 40.0;// ~25fps

// Hysteresis timings
const DOWN_HOLD_MS = 900;
const UP_HOLD_MS = 3500;
const EMERGENCY_HOLD_MS = 250;

// Rate of change
const STEP_DOWN = 0.08;
const STEP_UP = 0.04;

// Clamp range
const MIN_SCALE = 0.25;
const MAX_SCALE = 1.0;

let _samples = []; // {t, dt}
let _lastT = 0;

let _scale = 1.0;
let _downBadSince = 0;
let _upGoodSince = 0;
let _emergencySince = 0;

let _debugLast = 0;

function nowMs() {
  return (performance?.now?.() ?? Date.now());
}

function pruneSamples(tNow) {
  const tMin = tNow - SAMPLE_WINDOW_MS;
  while (_samples.length && _samples[0].t < tMin) _samples.shift();
}

function percentile(arr, p) {
  if (!arr.length) return 0;
  const a = arr.slice().sort((x, y) => x - y);
  const idx = Math.min(a.length - 1, Math.max(0, Math.floor((a.length - 1) * p)));
  return a[idx];
}

export function autoQualityOnFrame() {
  if (!AUTO_QUALITY_ENABLED) return;
  const t = nowMs();
  if (_lastT) {
    const dt = Math.max(0, Math.min(200, t - _lastT));
    _samples.push({ t, dt });
    pruneSamples(t);
  }
  _lastT = t;

  if (_samples.length < MIN_SAMPLES) return;

  const dts = _samples.map(s => s.dt);
  const p95 = percentile(dts, 0.95);

  // Track quality conditions with hysteresis
  if (p95 >= EMERGENCY_P95_MS) {
    if (!_emergencySince) _emergencySince = t;
  } else {
    _emergencySince = 0;
  }

  if (p95 >= DOWN_P95_MS) {
    if (!_downBadSince) _downBadSince = t;
    _upGoodSince = 0;
  } else if (p95 <= UP_P95_MS) {
    if (!_upGoodSince) _upGoodSince = t;
    _downBadSince = 0;
  } else {
    // In the deadband; decay timers so we don't accidentally fire transitions
    _downBadSince = 0;
    _upGoodSince = 0;
  }

  const memLevel = getMemoryPressureLevel?.() ?? 0; // 0 ok, 1 warn, 2 critical

  // Emergency mode: clamp fast and hard
  if (_emergencySince && (t - _emergencySince) >= EMERGENCY_HOLD_MS) {
    _scale = Math.max(MIN_SCALE, _scale - (STEP_DOWN * 2.5));
  } else if (_downBadSince && (t - _downBadSince) >= DOWN_HOLD_MS) {
    _scale = Math.max(MIN_SCALE, _scale - STEP_DOWN);
    _downBadSince = t; // step again after hold window
  } else if (_upGoodSince && (t - _upGoodSince) >= UP_HOLD_MS) {
    _scale = Math.min(MAX_SCALE, _scale + STEP_UP);
    _upGoodSince = t;
  }

  // Memory pressure clamp (hard safety)
  let memClamp = 1.0;
  if (memLevel >= 2) memClamp = 0.5;
  else if (memLevel >= 1) memClamp = 0.75;

  // Apply clamp (but keep internal scale so we can recover smoothly)
  const effective = Math.max(MIN_SCALE, Math.min(MAX_SCALE, _scale * memClamp));

  // Optional debug
  if (window.__SHOW_QUALITY) {
    if (!_debugLast || (t - _debugLast) > 500) {
      _debugLast = t;
      console.log('[quality]', { p95: Math.round(p95 * 10) / 10, memLevel, scale: Math.round(effective * 100) / 100 });
    }
  }

  window.__AUTO_QUALITY_EFFECTIVE = effective;
}

export function getAutoQualityScale() {
  // Default full quality until we have enough samples to justify changes.
  const v = window.__AUTO_QUALITY_EFFECTIVE;
  if (typeof v === 'number' && isFinite(v)) return v;
  return 1.0;
}

