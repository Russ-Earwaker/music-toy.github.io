const DEFAULT_BEATS_PER_BAR = 4;
const DEFAULT_METRICS_EVERY_BARS = 4;

function clampInt(value, fallback = 0, min = 0) {
  const n = Math.trunc(Number(value));
  if (!Number.isFinite(n)) return Math.max(min, Math.trunc(Number(fallback) || 0));
  return Math.max(min, n);
}

function nowMs() {
  try {
    if (typeof performance !== 'undefined' && typeof performance.now === 'function') {
      return Number(performance.now()) || Date.now();
    }
  } catch {}
  return Date.now();
}

function cloneJson(value) {
  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return null;
  }
}

function normalizeSourceSystem(sourceSystem, actionType = '') {
  const src = String(sourceSystem || '').trim().toLowerCase();
  if (src) return src;
  const action = String(actionType || '').trim().toLowerCase();
  if (action === 'player-weapon-step') return 'player';
  if (action.startsWith('spawner-')) return 'spawner';
  if (action.startsWith('drawsnake-')) return 'drawsnake';
  if (action.startsWith('composer-group-')) return 'group';
  if (action.startsWith('enemy-death-')) return 'death';
  return 'unknown';
}

function toMidi(noteName) {
  const raw = String(noteName || '').trim();
  if (!raw) return null;
  const m = /^([A-Ga-g])([#b]?)(-?\d+)?$/.exec(raw);
  if (!m) return null;
  const base = String(m[1] || '').toUpperCase();
  const accidental = String(m[2] || '');
  const octave = clampInt(m[3], 4, -3);
  const semitoneBase = (
    base === 'C' ? 0
      : base === 'D' ? 2
        : base === 'E' ? 4
          : base === 'F' ? 5
            : base === 'G' ? 7
              : base === 'A' ? 9
                : 11
  );
  const accidentalDelta = accidental === '#' ? 1 : (accidental === 'b' ? -1 : 0);
  return ((octave + 1) * 12) + semitoneBase + accidentalDelta;
}

function makeEventRecord(event, phase, context, beatsPerBar) {
  const ev = event && typeof event === 'object' ? event : {};
  const beatIndex = clampInt(ev.beatIndex, 0, 0);
  const stepIndex = clampInt(ev.stepIndex, 0, 0);
  const barIndex = context?.barIndex != null
    ? clampInt(context.barIndex, Math.floor(beatIndex / Math.max(1, beatsPerBar)), 0)
    : Math.floor(beatIndex / Math.max(1, beatsPerBar));
  const actionType = String(ev.actionType || '').trim();
  const payload = ev?.payload && typeof ev.payload === 'object' ? ev.payload : {};
  const requestedNote = String(context?.requestedNote ?? ev.note ?? '').trim();
  const resolvedNote = String(context?.resolvedNote ?? requestedNote).trim();
  const noteWasClamped = context?.noteWasClamped === true;
  const sourceSystem = normalizeSourceSystem(context?.sourceSystem, actionType);
  const playerAudible = context?.playerAudible === true;
  return {
    tMs: nowMs(),
    phase: String(phase || '').trim() || 'queued',
    eventId: clampInt(ev.eventId, 0, 0),
    timestamp: Date.now(),
    barIndex,
    beatIndex,
    stepIndex,
    actorId: clampInt(ev.actorId, 0, 0),
    groupId: clampInt(context?.groupId ?? payload.groupId, 0, 0),
    role: String(ev.role || '').trim().toLowerCase(),
    note: requestedNote,
    noteResolved: resolvedNote,
    noteWasClamped,
    instrumentId: String(ev.instrumentId || '').trim(),
    actionType,
    threatClass: String(ev.threatClass || '').trim().toLowerCase(),
    pacingState: String(context?.pacingState || '').trim().toLowerCase(),
    paletteId: String(context?.paletteId || '').trim(),
    themeId: String(context?.themeId || '').trim(),
    sourceSystem,
    playerAudible,
    visualSyncType: String(ev.visualSyncType || '').trim(),
  };
}

function isAudibleEvent(eventLike) {
  const ev = eventLike && typeof eventLike === 'object' ? eventLike : {};
  const source = String(ev?.sourceSystem || '').trim().toLowerCase();
  const action = String(ev?.actionType || '').trim().toLowerCase();
  const note = String(ev?.noteResolved || ev?.note || '').trim();
  if (source === 'player') return ev?.playerAudible === true;
  if (action === 'spawner-flash') return false;
  if (action === 'player-weapon-step') return false;
  if (note) return true;
  if (action === 'enemy-death-accent') return true;
  return false;
}

function collectRoleBalance(events) {
  const perBar = Object.create(null);
  const totals = Object.create(null);
  let totalEvents = 0;
  for (const ev of events) {
    const role = String(ev?.role || '').trim().toLowerCase();
    if (!role) continue;
    const barKey = String(clampInt(ev?.barIndex, 0, 0));
    if (!perBar[barKey]) perBar[barKey] = Object.create(null);
    perBar[barKey][role] = clampInt(perBar[barKey][role], 0, 0) + 1;
    totals[role] = clampInt(totals[role], 0, 0) + 1;
    totalEvents += 1;
  }
  const distribution = Object.create(null);
  for (const key of Object.keys(totals)) {
    distribution[key] = totalEvents > 0 ? (totals[key] / totalEvents) : 0;
  }
  return { perBar, totals, distribution, totalEvents };
}

function collectThreatBalance(events) {
  const perBeat = Object.create(null);
  const perBar = Object.create(null);
  for (const ev of events) {
    const cls = String(ev?.threatClass || '').trim().toLowerCase() || 'unknown';
    const beatKey = String(clampInt(ev?.beatIndex, 0, 0));
    const barKey = String(clampInt(ev?.barIndex, 0, 0));
    if (!perBeat[beatKey]) perBeat[beatKey] = Object.create(null);
    if (!perBar[barKey]) perBar[barKey] = Object.create(null);
    perBeat[beatKey][cls] = clampInt(perBeat[beatKey][cls], 0, 0) + 1;
    perBar[barKey][cls] = clampInt(perBar[barKey][cls], 0, 0) + 1;
  }
  return { perBeat, perBar };
}

function collectIntervalProfile(events) {
  const melodic = events
    .filter((ev) => String(ev?.noteResolved || ev?.note || '').trim().length > 0)
    .sort((a, b) => clampInt(a?.timestamp, 0, 0) - clampInt(b?.timestamp, 0, 0));
  const buckets = { repeat: 0, step: 0, smallLeap: 0, largeLeap: 0 };
  let previousMidi = null;
  let compared = 0;
  for (const ev of melodic) {
    const midi = toMidi(ev.noteResolved || ev.note);
    if (midi == null) continue;
    if (previousMidi != null) {
      const delta = Math.abs(midi - previousMidi);
      if (delta === 0) buckets.repeat += 1;
      else if (delta <= 2) buckets.step += 1;
      else if (delta <= 5) buckets.smallLeap += 1;
      else buckets.largeLeap += 1;
      compared += 1;
    }
    previousMidi = midi;
  }
  const smoothShare = compared > 0
    ? (buckets.repeat + buckets.step + buckets.smallLeap) / compared
    : 0;
  return { buckets, compared, smoothShare };
}

function collectDeathDensity(events) {
  const perBeat = Object.create(null);
  const perBar = Object.create(null);
  for (const ev of events) {
    const action = String(ev?.actionType || '').trim().toLowerCase();
    if (action !== 'enemy-death-accent') continue;
    const beatKey = String(clampInt(ev?.beatIndex, 0, 0));
    const barKey = String(clampInt(ev?.barIndex, 0, 0));
    perBeat[beatKey] = clampInt(perBeat[beatKey], 0, 0) + 1;
    perBar[barKey] = clampInt(perBar[barKey], 0, 0) + 1;
  }
  let clusterBeats = 0;
  for (const beatKey of Object.keys(perBeat)) {
    if (clampInt(perBeat[beatKey], 0, 0) >= 2) clusterBeats += 1;
  }
  return { perBeat, perBar, clusterBeats };
}

function collectPlayerMasking(events) {
  const playerAudibleKeys = new Set();
  for (const ev of events) {
    if (String(ev?.sourceSystem || '') !== 'player') continue;
    if (!isAudibleEvent(ev)) continue;
    playerAudibleKeys.add(`${clampInt(ev?.beatIndex, 0, 0)}:${clampInt(ev?.stepIndex, 0, 0)}`);
  }
  let enemyAudibleEvents = 0;
  let maskedEnemyEvents = 0;
  for (const ev of events) {
    const src = String(ev?.sourceSystem || '').trim().toLowerCase();
    if (src === 'player') continue;
    if (!isAudibleEvent(ev)) continue;
    enemyAudibleEvents += 1;
    const key = `${clampInt(ev?.beatIndex, 0, 0)}:${clampInt(ev?.stepIndex, 0, 0)}`;
    if (playerAudibleKeys.has(key)) maskedEnemyEvents += 1;
  }
  return {
    playerAudibleSteps: playerAudibleKeys.size,
    enemyEvents: enemyAudibleEvents,
    maskedEnemyEvents,
    playerMaskingRate: enemyAudibleEvents > 0 ? (maskedEnemyEvents / enemyAudibleEvents) : 0,
  };
}

function collectNotePoolCompliance(events) {
  let considered = 0;
  let clamped = 0;
  for (const ev of events) {
    const requested = String(ev?.note || '').trim();
    const resolved = String(ev?.noteResolved || '').trim();
    if (!requested || !resolved) continue;
    considered += 1;
    if (ev?.noteWasClamped === true || requested !== resolved) clamped += 1;
  }
  const insidePool = Math.max(0, considered - clamped);
  return {
    considered,
    clamped,
    insidePool,
    poolComplianceRate: considered > 0 ? (insidePool / considered) : 1,
  };
}

function collectMotifReuse(events) {
  const melodic = events
    .filter((ev) => String(ev?.noteResolved || ev?.note || '').trim().length > 0)
    .sort((a, b) => clampInt(a?.timestamp, 0, 0) - clampInt(b?.timestamp, 0, 0))
    .map((ev) => String(ev?.noteResolved || ev?.note || '').trim())
    .filter((n) => n.length > 0);
  const motifCounts = {
    n2: Object.create(null),
    n3: Object.create(null),
    n4: Object.create(null),
  };
  const repeatedByN = { n2: 0, n3: 0, n4: 0 };
  const windowsByN = { n2: 0, n3: 0, n4: 0 };

  const pushWindow = (size, key) => {
    if (!key) return;
    const bucket = size === 2 ? motifCounts.n2 : (size === 3 ? motifCounts.n3 : motifCounts.n4);
    const winKey = size === 2 ? 'n2' : (size === 3 ? 'n3' : 'n4');
    bucket[key] = clampInt(bucket[key], 0, 0) + 1;
    windowsByN[winKey] += 1;
  };

  for (let i = 0; i < melodic.length; i++) {
    if ((i + 2) <= melodic.length) pushWindow(2, melodic.slice(i, i + 2).join('|'));
    if ((i + 3) <= melodic.length) pushWindow(3, melodic.slice(i, i + 3).join('|'));
    if ((i + 4) <= melodic.length) pushWindow(4, melodic.slice(i, i + 4).join('|'));
  }

  for (const k of Object.keys(motifCounts.n2)) if (motifCounts.n2[k] > 1) repeatedByN.n2 += motifCounts.n2[k] - 1;
  for (const k of Object.keys(motifCounts.n3)) if (motifCounts.n3[k] > 1) repeatedByN.n3 += motifCounts.n3[k] - 1;
  for (const k of Object.keys(motifCounts.n4)) if (motifCounts.n4[k] > 1) repeatedByN.n4 += motifCounts.n4[k] - 1;

  const totalWindows = windowsByN.n2 + windowsByN.n3 + windowsByN.n4;
  const repeatedWindows = repeatedByN.n2 + repeatedByN.n3 + repeatedByN.n4;
  const motifReuseRate = totalWindows > 0 ? (repeatedWindows / totalWindows) : 0;

  return {
    windowsByN,
    repeatedByN,
    uniqueMotifsByN: {
      n2: Object.keys(motifCounts.n2).length,
      n3: Object.keys(motifCounts.n3).length,
      n4: Object.keys(motifCounts.n4).length,
    },
    motifReuseRate,
  };
}

function toAbsStepIndex(eventLike, stepsPerBeat = 8) {
  const ev = eventLike && typeof eventLike === 'object' ? eventLike : {};
  const beat = clampInt(ev?.beatIndex, 0, 0);
  const step = clampInt(ev?.stepIndex, 0, 0);
  return (beat * Math.max(1, clampInt(stepsPerBeat, 8, 1))) + step;
}

function collectCallResponse(events, options = null) {
  const responseWindowSteps = Math.max(1, clampInt(options?.responseWindowSteps, 8, 1));
  const actionable = events
    .filter((ev) => {
      const src = String(ev?.sourceSystem || '').trim().toLowerCase();
      if (src === 'player' || src === 'death' || src === 'unknown') return false;
      return true;
    })
    .sort((a, b) => clampInt(a?.timestamp, 0, 0) - clampInt(b?.timestamp, 0, 0));

  let responsePairs = 0;
  let callCount = 0;
  const pairExamples = [];

  const actorKey = (ev) => {
    const gid = clampInt(ev?.groupId, 0, 0);
    if (gid > 0) return `group:${gid}`;
    const aid = clampInt(ev?.actorId, 0, 0);
    if (aid > 0) return `actor:${aid}`;
    return `src:${String(ev?.sourceSystem || 'unknown')}`;
  };

  for (let i = 0; i < actionable.length; i++) {
    const call = actionable[i];
    callCount += 1;
    const callActor = actorKey(call);
    const callStep = toAbsStepIndex(call, options?.stepsPerBeat || 8);
    let matched = false;
    for (let j = i + 1; j < actionable.length; j++) {
      const resp = actionable[j];
      const respStep = toAbsStepIndex(resp, options?.stepsPerBeat || 8);
      const delta = respStep - callStep;
      if (delta <= 0) continue;
      if (delta > responseWindowSteps) break;
      if (actorKey(resp) === callActor) continue;
      responsePairs += 1;
      matched = true;
      if (pairExamples.length < 24) {
        pairExamples.push({
          call: {
            beatIndex: clampInt(call?.beatIndex, 0, 0),
            stepIndex: clampInt(call?.stepIndex, 0, 0),
            sourceSystem: String(call?.sourceSystem || ''),
            actorId: clampInt(call?.actorId, 0, 0),
            groupId: clampInt(call?.groupId, 0, 0),
          },
          response: {
            beatIndex: clampInt(resp?.beatIndex, 0, 0),
            stepIndex: clampInt(resp?.stepIndex, 0, 0),
            sourceSystem: String(resp?.sourceSystem || ''),
            actorId: clampInt(resp?.actorId, 0, 0),
            groupId: clampInt(resp?.groupId, 0, 0),
          },
          deltaSteps: delta,
        });
      }
      break;
    }
    if (!matched) continue;
  }

  return {
    callCount,
    responsePairs,
    responseRate: callCount > 0 ? (responsePairs / callCount) : 0,
    responseWindowSteps,
    pairExamples,
  };
}

function collectPaletteContinuity(session, maxBarIndex) {
  const paletteChanges = (Array.isArray(session?.paletteChanges) ? session.paletteChanges : [])
    .filter((e) => clampInt(e?.barIndex, 0, 0) <= maxBarIndex);
  const barsSinceLastPaletteChange = (() => {
    if (!paletteChanges.length) return maxBarIndex + 1;
    const lastBar = clampInt(paletteChanges[paletteChanges.length - 1]?.barIndex, 0, 0);
    return Math.max(0, maxBarIndex - lastBar);
  })();
  let themeChanges = 0;
  let roleInstrumentChanges = 0;
  for (let i = 1; i < paletteChanges.length; i++) {
    const prev = paletteChanges[i - 1] || {};
    const cur = paletteChanges[i] || {};
    if (String(prev.themeId || '') !== String(cur.themeId || '')) themeChanges += 1;
    const prevRoles = prev?.roles && typeof prev.roles === 'object' ? prev.roles : {};
    const curRoles = cur?.roles && typeof cur.roles === 'object' ? cur.roles : {};
    const roleKeys = new Set([...Object.keys(prevRoles), ...Object.keys(curRoles)]);
    for (const roleKey of roleKeys) {
      if (String(prevRoles[roleKey] || '') !== String(curRoles[roleKey] || '')) roleInstrumentChanges += 1;
    }
  }
  if (paletteChanges.length <= 1) {
    return {
      paletteChanges: paletteChanges.length,
      barsSinceLastPaletteChange,
      avgBarsBetweenChanges: maxBarIndex + 1,
      themeChanges,
      roleInstrumentChanges,
      paletteContinuityScore: 1,
    };
  }
  let spanTotal = 0;
  let spanCount = 0;
  for (let i = 1; i < paletteChanges.length; i++) {
    const prevBar = clampInt(paletteChanges[i - 1]?.barIndex, 0, 0);
    const curBar = clampInt(paletteChanges[i]?.barIndex, 0, 0);
    if (curBar < prevBar) continue;
    spanTotal += (curBar - prevBar);
    spanCount += 1;
  }
  const avgBarsBetweenChanges = spanCount > 0 ? (spanTotal / spanCount) : (maxBarIndex + 1);
  const spacingScore = Math.max(0, Math.min(1, avgBarsBetweenChanges / 32));
  const themePenalty = Math.min(0.35, themeChanges * 0.12);
  const rolePenalty = Math.min(0.35, roleInstrumentChanges * 0.02);
  const paletteContinuityScore = Math.max(0, Math.min(1, spacingScore - themePenalty - rolePenalty));
  return {
    paletteChanges: paletteChanges.length,
    barsSinceLastPaletteChange,
    avgBarsBetweenChanges,
    themeChanges,
    roleInstrumentChanges,
    paletteContinuityScore,
  };
}

function computeSummary(metrics) {
  const smooth = Number(metrics?.intervalProfile?.smoothShare) || 0;
  const maxRoleShare = Object.values(metrics?.roleBalance?.distribution || {}).reduce((m, v) => Math.max(m, Number(v) || 0), 0);
  const masking = Number(metrics?.playerMasking?.playerMaskingRate) || 0;
  const continuity = Number(metrics?.paletteContinuity?.paletteContinuityScore) || 0;
  const motifReuse = Number(metrics?.motifReuse?.motifReuseRate) || 0;
  const responseRate = Number(metrics?.callResponse?.responseRate) || 0;
  return {
    notePoolCompliance: `${Math.round((Number(metrics?.notePoolCompliance?.poolComplianceRate) || 0) * 100)}%`,
    motifReuse: `${Math.round(motifReuse * 100)}%`,
    leadIntervalSmoothness: smooth >= 0.8 ? 'good' : (smooth >= 0.62 ? 'acceptable' : 'rough'),
    roleBalance: maxRoleShare <= 0.58 ? 'acceptable' : 'skewed',
    responseRate: Number(responseRate.toFixed(3)),
    paletteContinuity: continuity >= 0.6 ? 'stable' : 'volatile',
    playerMasking: masking <= 0.25 ? 'low' : (masking <= 0.45 ? 'moderate' : 'high'),
  };
}

function computeMetricsForEvents(session, executedEvents, maxBarIndex) {
  const roleBalance = collectRoleBalance(executedEvents);
  const threatBalance = collectThreatBalance(executedEvents);
  const intervalProfile = collectIntervalProfile(executedEvents);
  const deathDensity = collectDeathDensity(executedEvents);
  const playerMasking = collectPlayerMasking(executedEvents);
  const notePoolCompliance = collectNotePoolCompliance(executedEvents);
  const motifReuse = collectMotifReuse(executedEvents);
  const callResponse = collectCallResponse(executedEvents, {
    responseWindowSteps: 8,
    stepsPerBeat: 8,
  });
  const paletteContinuity = collectPaletteContinuity(session, maxBarIndex);
  const metrics = {
    notePoolCompliance,
    intervalProfile,
    motifReuse,
    roleBalance,
    threatBalance,
    callResponse,
    deathDensity,
    playerMasking,
    paletteContinuity,
  };
  return {
    metrics,
    sessionSummary: computeSummary(metrics),
  };
}

export function createBeatSwarmMusicLab(options = null) {
  const beatsPerBar = Math.max(1, clampInt(options?.beatsPerBar, DEFAULT_BEATS_PER_BAR, 1));
  const metricsEveryBars = Math.max(1, clampInt(options?.metricsEveryBars, DEFAULT_METRICS_EVERY_BARS, 1));
  let enabled = true;
  let sessionSeq = 1;
  let session = null;
  let lastMetricsBar = -1;

  function ensureSession(context = null) {
    if (session) return session;
    const nowIso = new Date().toISOString();
    session = {
      sessionId: `music-lab-${nowIso}-${sessionSeq}`,
      startedAtIso: nowIso,
      startedAtMs: nowMs(),
      sequence: sessionSeq,
      context: context && typeof context === 'object' ? { ...context } : {},
      beatsPerBar,
      metricsEveryBars,
      events: [],
      paletteChanges: [],
      pacingChanges: [],
      metricsHistory: [],
      metrics: null,
      sessionSummary: null,
      endedAtIso: null,
    };
    sessionSeq += 1;
    lastMetricsBar = -1;
    return session;
  }

  function recordMetricsCheckpoint(barIndex) {
    const s = ensureSession();
    const bar = clampInt(barIndex, 0, 0);
    if (bar < 0) return;
    if (lastMetricsBar >= 0 && bar < (lastMetricsBar + metricsEveryBars)) return;
    const executed = s.events.filter((e) => e?.phase === 'executed' && clampInt(e?.barIndex, 0, 0) <= bar);
    const bundle = computeMetricsForEvents(s, executed, bar);
    s.metricsHistory.push({
      barIndex: bar,
      tMs: nowMs(),
      metrics: bundle.metrics,
      sessionSummary: bundle.sessionSummary,
    });
    lastMetricsBar = bar;
  }

  function resetSession(context = null) {
    session = null;
    lastMetricsBar = -1;
    return ensureSession(context);
  }

  function logEvent(event, phase, context = null) {
    if (!enabled) return null;
    const s = ensureSession(context);
    const rec = makeEventRecord(event, phase, context, beatsPerBar);
    s.events.push(rec);
    recordMetricsCheckpoint(rec.barIndex);
    return rec;
  }

  function logQueuedEvent(event, context = null) {
    return logEvent(event, 'queued', context);
  }

  function logExecutedEvent(event, context = null) {
    return logEvent(event, 'executed', context);
  }

  function notePaletteChange(next, context = null) {
    if (!enabled) return null;
    const s = ensureSession(context);
    const snap = next && typeof next === 'object' ? next : {};
    const rec = {
      tMs: nowMs(),
      timestamp: Date.now(),
      barIndex: clampInt(context?.barIndex, 0, 0),
      paletteId: String(snap?.id || '').trim(),
      paletteIndex: clampInt(snap?.paletteIndex, 0, 0),
      themeId: String(snap?.theme || '').trim(),
      roles: snap?.roles && typeof snap.roles === 'object' ? { ...snap.roles } : {},
    };
    s.paletteChanges.push(rec);
    recordMetricsCheckpoint(rec.barIndex);
    return rec;
  }

  function notePacingChange(next, context = null) {
    if (!enabled) return null;
    const s = ensureSession(context);
    const snap = next && typeof next === 'object' ? next : {};
    const rec = {
      tMs: nowMs(),
      timestamp: Date.now(),
      barIndex: clampInt(context?.barIndex, 0, 0),
      state: String(snap?.state || '').trim(),
      stateStartBar: clampInt(snap?.stateStartBar, 0, 0),
      responseMode: String(snap?.responseMode || '').trim(),
      cycle: clampInt(snap?.cycle, 0, 0),
    };
    s.pacingChanges.push(rec);
    recordMetricsCheckpoint(rec.barIndex);
    return rec;
  }

  function exportSession() {
    const s = ensureSession();
    let maxBar = 0;
    for (const ev of s.events) maxBar = Math.max(maxBar, clampInt(ev?.barIndex, 0, 0));
    const executed = s.events.filter((e) => e?.phase === 'executed');
    const bundle = computeMetricsForEvents(s, executed, maxBar);
    s.metrics = bundle.metrics;
    s.sessionSummary = bundle.sessionSummary;
    s.endedAtIso = new Date().toISOString();
    return cloneJson({
      sessionId: s.sessionId,
      startedAtIso: s.startedAtIso,
      endedAtIso: s.endedAtIso,
      beatsPerBar: s.beatsPerBar,
      metricsEveryBars: s.metricsEveryBars,
      eventTimeline: s.events,
      paletteChanges: s.paletteChanges,
      pacingChanges: s.pacingChanges,
      metricsHistory: s.metricsHistory,
      metrics: s.metrics,
      sessionSummary: s.sessionSummary,
    });
  }

  function downloadSession(fileName = 'music-lab-results.json') {
    const payload = exportSession();
    if (!payload) return false;
    try {
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = String(fileName || 'music-lab-results.json').trim() || 'music-lab-results.json';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      return true;
    } catch {
      return false;
    }
  }

  function setEnabled(next = true) {
    enabled = !!next;
    return enabled;
  }

  function getSessionSnapshot() {
    const s = ensureSession();
    return cloneJson(s);
  }

  return {
    resetSession,
    logQueuedEvent,
    logExecutedEvent,
    notePaletteChange,
    notePacingChange,
    exportSession,
    downloadSession,
    setEnabled,
    getSessionSnapshot,
  };
}
