// src/ripplesynth-audio.js — audio-specific helpers for RippleSynth
// TODO: migrate ripple scheduling and instrument trigger wrappers here.
// Export nothing for now to avoid breaking imports. Add functions as we refactor.
