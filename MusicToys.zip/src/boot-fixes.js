// src/boot-fixes.js — Minimal stabilizer (safe & scoped)
(function(){
  // This script has been disabled to prevent conflicts with the new layout system.
})();