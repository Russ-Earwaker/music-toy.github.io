// grid-zoom-fix.js — optional helper (safe stub if already fixed elsewhere)
(function(){ console.log('[grid-zoom-fix] loaded'); })();
