(function(){
  // This script has been disabled to prevent conflicts with the new layout system.
})();
