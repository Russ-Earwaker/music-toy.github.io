// bouncer-zoom-fix.js — stub (no-op, lets toy manage DPR)
(function(){ console.log('[bouncer-zoom-fix] stub loaded'); })();
