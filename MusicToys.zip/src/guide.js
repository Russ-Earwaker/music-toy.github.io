import { makeDebugLogger } from './debug-flags.js';

const guideInfoLog = makeDebugLogger('mt_debug_logs', 'info');

const GUIDE_TOGGLE_CLASS = 'guide-launcher';
const GUIDE_OPEN_CLASS = 'is-open';
const GUIDE_BUTTON_LABEL = 'GUIDE';
const GUIDE_TASK_LABEL = 'TAP ME';

let hostRef = null;
let toggleRef = null;
let panelsRef = null;
let lastApi = null;
const goalExpansionState = new Map();
let highlighterRef = null;
let highlightNextTask = false;
let openFirstGoalNextRender = false;
const GUIDE_TASK_TAP_ACK_KEY = 'guide:task-tap-ack';
const GUIDE_BUTTON_TAP_ACK_KEY = 'guide:button-tap-ack';
let activeGoalId = null;
let goalPickerRef = null;
let moreGoalsButtonRef = null;
let lastGuideContext = null;
let buttonsWrapRef = null;
let lastActiveTaskSelectionId = null;
let highlighterTarget = null;
let lastRenderedGuideTaskId = null;
let lastRenderedGuideTaskIndex = 0;
let lastRenderedGuideGoalId = null;
let guideTaskSwapInProgress = false;
let guideTaskSwapTimer = 0;
let pendingGuideRender = null;
let userSelectedGoalId = null;
let lastCollectedRewards = null;

function getHighlighterHost() {
  if (typeof document === 'undefined') return null;
  return document.querySelector('.topbar-menu-wrap')
    || document.querySelector('.app-topbar')
    || document.getElementById('topbar')
    || null;
}

function setActiveGoal(goalId) {
  const prev = activeGoalId || null;
  activeGoalId = goalId || null;
  if (prev !== activeGoalId && typeof window !== 'undefined') {
    try {
      window.dispatchEvent(
        new CustomEvent('guide:active-goal-change', { detail: { previous: prev, next: activeGoalId } })
      );
    } catch {}
  }
  try {
    if (typeof window !== 'undefined') {
      window.__guideActiveGoal = activeGoalId;
    }
  } catch {}
}

function getActiveGoal(goals, { completedGoals = new Set(), claimedRewards = new Set() } = {}) {
  const list = Array.isArray(goals) ? goals : [];
  if (!list.length) return null;
  if (activeGoalId) {
    const match = list.find(goal => {
      if (!goal || !goal.id) return false;
      if (goal.id !== activeGoalId) return false;
      // Allow already-completed/claimed goals to be reselected intentionally
      return true;
    });
    if (match) return match;
  }
  // Prefer goals that are completed but not claimed before moving on
  const pendingReward = list.find(goal => goal && goal.id && completedGoals.has(goal.id) && !claimedRewards.has(goal.id));
  if (pendingReward) return pendingReward;
  return list.find(goal => {
    if (!goal || !goal.id) return false;
    if (completedGoals.has(goal.id)) return false;
    if (claimedRewards.has(goal.id)) return false;
    return !(goal.isClaimed || goal.claimed || goal.completed);
  }) || list[0];
}

function closeGoalPicker() {
  if (goalPickerRef && goalPickerRef.isConnected) {
    goalPickerRef.remove();
  }
  goalPickerRef = null;
}

function openGoalPicker(context) {
  closeGoalPicker();
  const ctx = context || lastGuideContext || {};
  let goals = Array.isArray(ctx.goals) ? ctx.goals : [];
  const api = ctx.api || lastApi || (typeof window !== 'undefined' ? window.TutorialGoalsAPI : null);
  if ((!goals.length || !api) && api?.getGoals) {
    try { goals = api.getGoals() || goals; } catch {}
  }
  if (!goals.length || !api?.createPanel) return;

  const toSet = (value) =>
    (value instanceof Set
      ? new Set(value)
      : new Set(Array.isArray(value) ? value : []));

  const progress = api?.getGuideProgress?.() || {};
  const completedTasks = ctx.completedTasks || toSet(progress.completedTasks || []);
  const completedGoals = ctx.completedGoals || toSet(progress.completedGoals || []);
  const claimedRewards = ctx.claimedRewards || toSet(progress.claimedRewards || []);
  const pendingRewards = ctx.pendingRewards || new Set(
    [...completedGoals].filter((id) => !claimedRewards.has(id))
  );

  goalPickerRef = document.createElement('div');
  goalPickerRef.className = 'guide-goal-picker';

  const backdrop = document.createElement('div');
  backdrop.className = 'guide-goal-picker__backdrop';
  goalPickerRef.appendChild(backdrop);

  const sheet = document.createElement('div');
  sheet.className = 'guide-goal-picker__sheet';
  goalPickerRef.appendChild(sheet);

  const header = document.createElement('div');
  header.className = 'guide-goal-picker__header';
  header.textContent = 'Goals';
  sheet.appendChild(header);

  const list = document.createElement('div');
  list.className = 'guide-goal-picker__list';
  sheet.appendChild(list);

  goals.forEach((goal, index) => {
    const panel = api.createPanel?.() || document.createElement('div');
    panel.classList.add('guide-goal-picker-item');
    panel.style.display = 'block';
    panel.style.visibility = 'visible';
    panel.style.position = 'relative';
    panel.style.left = '0';
    panel.style.top = '0';
    panel.style.transform = 'none';
    panel.style.opacity = '1';
    panel.style.width = '100%';
    panel.style.maxWidth = '100%';

    try {
      const goalTasks = Array.isArray(goal.tasks) ? goal.tasks : [];
      let activeTaskId = null;
      for (const task of goalTasks) {
        const taskId = task?.id;
        if (!taskId) continue;
        if (!completedTasks.has(taskId)) {
          activeTaskId = taskId;
          break;
        }
      }
      api.populatePanel?.(panel, goal, {
        taskIndex: 0,
        showClaimButton: false,
        activeTaskId,
        completedTaskIds: completedTasks || new Set(),
        completedGoals: completedGoals || new Set(),
        claimedRewards: claimedRewards || new Set(),
        pendingRewards: pendingRewards || new Set(),
      });
    } catch (err) {
      console.warn('[guide] populatePanel picker failed', err);
    }

    let headerEl = panel.querySelector('.tutorial-goals-header');
    if (!headerEl) {
      headerEl = document.createElement('div');
      headerEl.className = 'tutorial-goals-header';
      headerEl.textContent = goal?.title || 'Goal';
      panel.prepend(headerEl);
    }

    const bodyWrapper = document.createElement('div');
    const bodyContent = [];
    const tasks = panel.querySelector('.tutorial-goals-tasklist');
    const progressEl = panel.querySelector('.goal-progress');
    const reward = panel.querySelector('.tutorial-goals-reward');
    if (tasks) bodyContent.push(tasks);
    if (progressEl) bodyContent.push(progressEl);
    if (reward) bodyContent.push(reward);
    bodyWrapper.className = 'goal-body-wrapper';
    bodyContent.forEach(el => bodyWrapper.appendChild(el));
    if (!panel.contains(bodyWrapper)) panel.appendChild(bodyWrapper);
    bodyWrapper.style.display = 'none';

    panel.classList.add('is-collapsed', 'guide-goal-picker-card');
    headerEl.style.cursor = 'pointer';

    const activate = () => {
      if (claimedRewards.has(goal?.id)) {
        // Starting a fresh replay session for this goal:
        try {
          if (typeof window !== 'undefined') {
            const raw = (window.__guideReplayTasks && Array.isArray(window.__guideReplayTasks))
              ? window.__guideReplayTasks
              : [];
            const next = new Map(raw.map(([g, list]) => [g, new Set(list || [])]));
            next.set(goal.id, new Set());
            window.__guideReplayTasks = Array.from(next.entries()).map(
              ([g, set]) => [g, Array.from(set)]
            );
          }
        } catch {}
      }

      if (goal?.id) setActiveGoal(goal.id);
      userSelectedGoalId = goal?.id || null;
      if (highlighterRef) highlighterRef.classList.remove('is-visible');
      highlightNextTask = false;
      closeGoalPicker();
      openFirstGoalNextRender = true;
      if (lastApi) renderGuide(lastApi, { source: 'goal-picker-select' });
      if (hostRef && panelsRef) {
        hostRef.classList.add(GUIDE_OPEN_CLASS);
        panelsRef.style.display = 'block';
        panelsRef.classList.add('is-visible');
      }
    };

    headerEl.addEventListener('click', activate);
    list.appendChild(panel);
  });

  document.body.appendChild(goalPickerRef);
  const clickOutside = (ev) => {
    if (!goalPickerRef) return;
    if (!goalPickerRef.contains(ev.target)) {
      closeGoalPicker();
    }
  };
  backdrop.addEventListener('click', closeGoalPicker);
  document.addEventListener('mousedown', clickOutside, { once: true });
}

function showHighlighterForElement(el) {
  if (!highlighterRef || !el) return false;
  attachHighlighter();
  const rect = el.getBoundingClientRect();
  if (!rect || !Number.isFinite(rect.top) || !Number.isFinite(rect.right)) return false;
  highlighterRef.style.left = `${rect.right}px`;
  highlighterRef.style.top = `${rect.top + rect.height / 2}px`;
  highlighterRef.classList.add('is-visible');
  highlighterTarget = el;
  return true;
}

function shouldShowGuideTapHighlighter() {
  try {
    const topbarMenu = document.getElementById('topbar-menu');
    const menuOpen = topbarMenu && !topbarMenu.hasAttribute('hidden');
    if (menuOpen) return false;
    if (readGuideButtonAcknowledged()) return false;

    const api = lastApi;
    if (!api) return false;
    const goals = api.getGoals?.() || [];
    if (!Array.isArray(goals) || goals.length === 0) return false;
    const firstGoal = goals[0];
    if (!firstGoal || !firstGoal.id) return false;
    const firstTask = Array.isArray(firstGoal.tasks) ? firstGoal.tasks[0] : null;
    if (!firstTask || !firstTask.id) return false;
    return true;
  } catch {
    return false;
  }
}

function shouldShowTaskTapHighlighter() {
  try {
    if (readGuideTaskAcknowledged()) return false;
    const api = lastApi;
    if (!api) return false;
    const goals = api.getGoals?.() || [];
    if (!Array.isArray(goals) || goals.length === 0) return false;
    const firstGoal = goals[0];
    if (!firstGoal || !firstGoal.id) return false;
    const firstTask = Array.isArray(firstGoal.tasks) ? firstGoal.tasks[0] : null;
    if (!firstTask || !firstTask.id) return false;
    const progress = api.getGuideProgress?.() || {};
    const completedGoals = new Set(progress.completedGoals || []);
    const claimedRewards = new Set(progress.claimedRewards || []);
    const completedTasks = new Set(progress.completedTasks || []);
    const activeGoal = getActiveGoal(goals, { completedGoals, claimedRewards });
    if (!activeGoal || activeGoal.id !== firstGoal.id) return false;
    if (completedTasks.has(firstTask.id)) return false;
    return true;
  } catch {
    return false;
  }
}

function setHighlighterLabel(text) {
  if (!highlighterRef) return;
  const label = highlighterRef.querySelector('.guide-task-highlighter-text');
  if (!label) return;
  if (label.textContent !== text) label.textContent = text;
}

function showHighlighterForGuide() {
  ensureHost();
  if (!toggleRef || !toggleRef.isConnected) return false;
  if (!shouldShowGuideTapHighlighter()) return false;
  setHighlighterLabel(GUIDE_BUTTON_LABEL);
  return showHighlighterForElement(toggleRef);
}

function showHighlighterForFirstTask() {
  if (!panelsRef) return false;
  if (!shouldShowTaskTapHighlighter()) return false;
  const firstTaskId = getFirstGoalFirstTaskId();
  if (!firstTaskId) return false;
  const firstTaskEl = panelsRef.querySelector(`.goal-task[data-task-id="${firstTaskId}"]`);
  if (!firstTaskEl) return false;
  setHighlighterLabel(GUIDE_TASK_LABEL);
  return showHighlighterForElement(firstTaskEl);
}

function attachHighlighter() {
  if (!highlighterRef) return;
  const host = getHighlighterHost();
  if (!host) return;
  if (highlighterRef.parentElement !== host) host.appendChild(highlighterRef);
}

function ensureHighlighter() {
  const existing = Array.from(document.querySelectorAll('.guide-task-highlighter'));
  if (existing.length > 0) {
    highlighterRef = existing[0];
    for (let i = 1; i < existing.length; i += 1) {
      existing[i].remove();
    }
  }
  if (!highlighterRef) {
    highlighterRef = document.createElement('div');
    highlighterRef.className = 'guide-task-highlighter';
    highlighterRef.innerHTML = `
      <div class="guide-task-highlighter-arrow"></div>
      <div class="guide-task-highlighter-text">${GUIDE_BUTTON_LABEL}</div>
    `;
  }
  attachHighlighter();
  updateHighlighterTapState();
}

function readGuideTaskAcknowledged() {
  if (typeof window === 'undefined' || !window.localStorage) return false;
  try {
    return !!window.localStorage.getItem(GUIDE_TASK_TAP_ACK_KEY);
  } catch {
    return false;
  }
}

function readGuideButtonAcknowledged() {
  if (typeof window === 'undefined' || !window.localStorage) return false;
  try {
    return !!window.localStorage.getItem(GUIDE_BUTTON_TAP_ACK_KEY);
  } catch {
    return false;
  }
}

function setGuideTaskAcknowledged(value) {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    if (value) {
      window.localStorage.setItem(GUIDE_TASK_TAP_ACK_KEY, '1');
    } else {
      window.localStorage.removeItem(GUIDE_TASK_TAP_ACK_KEY);
    }
  } catch {}
}

function setGuideButtonAcknowledged(value) {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    if (value) {
      window.localStorage.setItem(GUIDE_BUTTON_TAP_ACK_KEY, '1');
    } else {
      window.localStorage.removeItem(GUIDE_BUTTON_TAP_ACK_KEY);
    }
  } catch {}
}

function updateHighlighterTapState() {
  if (!highlighterRef) return;
  const shouldHide = readGuideTaskAcknowledged();
  highlighterRef.classList.toggle('guide-task-highlighter--tap-hidden', shouldHide);
}

function addGuidePulse() { try { window.dispatchEvent(new CustomEvent('guide:request-pulse')); } catch (e) { console.warn('guide:request-pulse failed', e); } }

function removeGuidePulse() { try { window.dispatchEvent(new CustomEvent('guide:cancel-pulse')); } catch (e) { console.warn('guide:cancel-pulse failed', e); } }

function isPlaceAToyIntroActive(api) {
  try {
    const goals = api?.getGoals?.() || [];
    if (!Array.isArray(goals)) return false;
    const activeGoal = goals.find((goal) => goal && (goal.active || goal.isActive || goal.isCurrent));
    if (!activeGoal) return false;
    const title = String(activeGoal.title || '').toLowerCase();
    if (!title.includes('place a toy')) return false;
    const tasks = Array.isArray(activeGoal.tasks) ? activeGoal.tasks : [];
    if (!tasks.length) return false;
    const firstTask = tasks[0];
    return !!firstTask && !firstTask.completed;
  } catch {
    return false;
  }
}

function ensureStyles() {
  if (!document.getElementById('tutorial-styles')) {
    const link = document.createElement('link');
    link.id = 'tutorial-styles';
    link.rel = 'stylesheet';
    link.href = 'src/tutorial.css';
    document.head.appendChild(link);
  }
  if (!document.getElementById('guide-styles')) {
    const guideLink = document.createElement('link');
    guideLink.id = 'guide-styles';
    guideLink.rel = 'stylesheet';
    guideLink.href = 'src/guide.css';
    document.head.appendChild(guideLink);
  }
}

function ensureHost() {
  if (hostRef && panelsRef && toggleRef) {
    attachHighlighter();
    return hostRef;
  }

  hostRef = document.querySelector(`.${GUIDE_TOGGLE_CLASS}`) || document.createElement('div');
  hostRef.className = GUIDE_TOGGLE_CLASS;

  ensureHighlighter();

  if (!buttonsWrapRef || !buttonsWrapRef.isConnected) {
    buttonsWrapRef = document.createElement('div');
    buttonsWrapRef.className = 'guide-launcher-buttons';
    hostRef.appendChild(buttonsWrapRef);
  }

  if (!panelsRef || !panelsRef.isConnected) {
    panelsRef = document.querySelector('.guide-panels-container') || document.createElement('div');
    panelsRef.className = 'guide-panels-container';
    hostRef.appendChild(panelsRef);
  }

  if (!toggleRef || !toggleRef.isConnected) {
    toggleRef = document.createElement('button');
    toggleRef.type = 'button';
    toggleRef.className = 'c-btn guide-toggle';
    toggleRef.id = 'guide-button';
    toggleRef.title = 'Guide';
    toggleRef.dataset.helpLabel = 'Guide';
    toggleRef.dataset.helpPosition = 'top';
    toggleRef.setAttribute('aria-label', 'Guide');
    toggleRef.innerHTML = '<div class="c-btn-outer"></div><div class="c-btn-glow"></div><div class="c-btn-core"></div>';
    buttonsWrapRef.appendChild(toggleRef);
  } else {
    toggleRef.classList.add('c-btn');
    if (toggleRef.parentElement !== buttonsWrapRef) {
      buttonsWrapRef.appendChild(toggleRef);
    }
  }
  toggleRef.id = 'guide-button';
  toggleRef.title = 'Guide';
  if (!toggleRef.dataset.helpLabel) toggleRef.dataset.helpLabel = 'Guide';
  if (!toggleRef.dataset.helpPosition) toggleRef.dataset.helpPosition = 'top';
  toggleRef.setAttribute('aria-label', 'Guide');
  const toggleCore = toggleRef.querySelector('.c-btn-core');
  if (toggleCore) {
    toggleCore.style.setProperty('--c-btn-icon-url', "url('./assets/UI/T_Guide.png')");
  }

  if (!moreGoalsButtonRef || !moreGoalsButtonRef.isConnected) {
    moreGoalsButtonRef = document.createElement('button');
    moreGoalsButtonRef.type = 'button';
    moreGoalsButtonRef.className = 'c-btn guide-more-goals';
    moreGoalsButtonRef.style.display = 'none';
    moreGoalsButtonRef.title = 'More goals';
    moreGoalsButtonRef.dataset.helpLabel = 'Goal select menu';
    moreGoalsButtonRef.dataset.helpPosition = 'right';
    moreGoalsButtonRef.setAttribute('aria-label', 'More goals');
    moreGoalsButtonRef.innerHTML = '<div class="c-btn-outer"></div><div class="c-btn-glow"></div><div class="c-btn-core"></div>';
    buttonsWrapRef.appendChild(moreGoalsButtonRef);
  }
  const moreCore = moreGoalsButtonRef?.querySelector('.c-btn-core');
  if (moreCore) {
    moreCore.style.setProperty('--c-btn-icon-url', "url('./assets/UI/T_3Dots.png')");
  }
  if (moreGoalsButtonRef && !moreGoalsButtonRef.dataset.helpLabel) {
    moreGoalsButtonRef.dataset.helpLabel = 'Goal select menu';
  }
  if (moreGoalsButtonRef && !moreGoalsButtonRef.dataset.helpPosition) {
    moreGoalsButtonRef.dataset.helpPosition = 'right';
  }

  if (!toggleRef.__guideBound) {
    toggleRef.addEventListener('click', () => {
      const willOpen = !hostRef.classList.contains(GUIDE_OPEN_CLASS);
      hostRef.classList.toggle(GUIDE_OPEN_CLASS, willOpen);
      panelsRef.style.display = willOpen ? 'block' : 'none';
      panelsRef.classList.toggle('is-visible', willOpen);
      if (moreGoalsButtonRef) {
        moreGoalsButtonRef.style.display = willOpen ? '' : 'none';
      }
      if (willOpen) {
        highlightNextTask = false;
        setTimeout(() => {
          if (!showHighlighterForFirstTask() && highlighterRef) {
            highlighterRef.classList.remove('is-visible');
          }
        }, 120);
      }
      if (!willOpen) {
        closeGoalPicker();
        if (highlighterRef) highlighterRef.classList.remove('is-visible');
        panelsRef.querySelectorAll('.is-active-guide-task').forEach(el => el.classList.remove('is-active-guide-task'));
        window.dispatchEvent(new CustomEvent('guide:task-deactivate', { bubbles: true, composed: true }));
        try { window.dispatchEvent(new CustomEvent('guide:close', { bubbles: true, composed: true })); } catch {}
      } else {
        try { window.dispatchEvent(new CustomEvent('guide:open', { bubbles: true, composed: true })); } catch {}
      }
      try {
        window.__guideDebug = Object.assign({}, window.__guideDebug || {}, {
          lastToggle: { open: willOpen, at: Date.now() },
        });
      } catch {}
      guideInfoLog('[guide] toggle', { open: willOpen, goalCount: Number(hostRef.dataset.goalCount || 0) });
    });
    toggleRef.__guideBound = true;

    try { if (isPlaceAToyIntroActive(api || lastApi)) addGuidePulse(); else removeGuidePulse(); } catch {}
  }

  if (!hostRef.isConnected) {
    panelsRef.style.display = 'none';
    document.body.appendChild(hostRef);
  }
  if (moreGoalsButtonRef && !moreGoalsButtonRef.__guideBound) {
    moreGoalsButtonRef.__guideBound = true;
    moreGoalsButtonRef.addEventListener('click', () => {
      try {
        window.dispatchEvent(new CustomEvent('guide:open-goal-picker', { bubbles: true, composed: true }));
      } catch {}
    });
  }
  return hostRef;
}

function getFirstGoalFirstTaskId() {
  try {
    const goals = lastGuideContext?.goals || lastApi?.getGoals?.() || [];
    if (!Array.isArray(goals) || goals.length === 0) return null;
    const firstGoal = goals[0];
    const firstTask = Array.isArray(firstGoal?.tasks) ? firstGoal.tasks[0] : null;
    return firstTask?.id || null;
  } catch {
    return null;
  }
}

function closeGuide() {
  if (!hostRef) hostRef = document.querySelector(`.${GUIDE_TOGGLE_CLASS}`) || hostRef;
  if (!panelsRef) panelsRef = document.querySelector('.guide-panels-container') || panelsRef;
  if (!hostRef || !panelsRef) return;
  if (guideTaskSwapTimer) { clearTimeout(guideTaskSwapTimer); guideTaskSwapTimer = 0; }
  guideTaskSwapInProgress = false;
  pendingGuideRender = null;
  if (highlighterRef) highlighterRef.classList.remove('is-visible');
  hostRef.classList.remove(GUIDE_OPEN_CLASS);
  panelsRef.style.display = 'none';
  panelsRef.classList.remove('is-visible');
  panelsRef.querySelectorAll('.is-active-guide-task').forEach((taskEl) => {
    taskEl.classList.remove('is-active-guide-task');
  });
  lastActiveTaskSelectionId = null;
  try {
    window.dispatchEvent(new CustomEvent('guide:task-deactivate', { bubbles: true, composed: true }));
  } catch {}
}

function clearPanels() {
  if (!panelsRef) return;
  while (panelsRef.firstChild) panelsRef.removeChild(panelsRef.firstChild);
}


function buildGuideProgressSummary(collectedRewards, totalRewards) {
  const summary = document.createElement('div');
  summary.className = 'guide-progress-summary';
  summary.innerHTML = `
    <span class="guide-progress-summary__stars">
      <img src="./assets/UI/T_Star.png" alt="Stars" />
      ${collectedRewards}/${totalRewards}
    </span>
  `;
  return summary;
}function renderGuide(api, { source = 'unknown', skipSwap = false } = {}) {
  ensureStyles();
  ensureHost();
  if (api) lastApi = api;

  const guideOpen = hostRef && hostRef.classList.contains(GUIDE_OPEN_CLASS);
  if (!guideOpen && guideTaskSwapInProgress) {
    if (guideTaskSwapTimer) { clearTimeout(guideTaskSwapTimer); guideTaskSwapTimer = 0; }
    guideTaskSwapInProgress = false;
    pendingGuideRender = null;
  }
  if (guideTaskSwapInProgress && !skipSwap) {
    pendingGuideRender = { api, source };
    return;
  }

  const stamp = Date.now();
  let goals = [];
  if (api) {
    try {
      goals = api.getGoals?.() || [];
    } catch (err) {
      console.warn('[guide] getGoals threw', err);
    }
  }
  if (!Array.isArray(goals)) goals = [];
  const hasGoals = goals.length > 0;
  const toSet = (value) => (value instanceof Set ? new Set(value) : new Set(Array.isArray(value) ? value : []));
  const progress = api?.getGuideProgress?.() || {};
  const completedTasks = toSet(progress.completedTasks || []);
  const completedGoals = toSet(progress.completedGoals || []);
  const claimedRewards = toSet(progress.claimedRewards || []);
  const totalRewards = goals.length;
  const collectedRewards = claimedRewards.size;
  const prevCollectedRewards = Number.isFinite(lastCollectedRewards) ? lastCollectedRewards : null;
  const shouldBumpProgress = prevCollectedRewards !== null && collectedRewards > prevCollectedRewards;
  const pendingRewards = new Set([...completedGoals].filter((id) => !claimedRewards.has(id)));
  const replayTasksRaw = (typeof window !== 'undefined' && window.__guideReplayTasks) || [];
  const replayTasks = new Map(
    Array.isArray(replayTasksRaw)
      ? replayTasksRaw.map(([g, list]) => [g, new Set(list || [])])
      : []
  );
  lastGuideContext = { goals, api, completedTasks, completedGoals, claimedRewards, pendingRewards };

  if (userSelectedGoalId && !goals.some((goal) => goal && goal.id === userSelectedGoalId)) {
    userSelectedGoalId = null;
  }

  const allGoalsComplete = hasGoals && goals.every((goal) => goal && goal.id && completedGoals.has(goal.id));
  const showAllGoalsComplete = allGoalsComplete && pendingRewards.size === 0 && !userSelectedGoalId;

  const resolveGoalState = (goal) => {
    const goalId = goal?.id;
    const goalTasks = Array.isArray(goal?.tasks) ? goal.tasks : [];
    const replaySession = claimedRewards.has(goalId) && goalId === activeGoalId;
    let panelCompletedTasks = completedTasks;
    if (replaySession) {
      const sessionSet = replayTasks.get(goalId);
      panelCompletedTasks = sessionSet instanceof Set ? new Set(sessionSet) : new Set();
    }
    const isPendingReward = pendingRewards.has(goalId);
    const hideTaskList = isPendingReward && completedGoals.has(goalId) && !replaySession;
    let activeTaskId = null;
    let activeTaskIndex = 0;
    for (let i = 0; i < goalTasks.length; i += 1) {
      const taskId = goalTasks[i]?.id;
      if (!taskId) continue;
      if (!panelCompletedTasks.has(taskId)) {
        activeTaskId = taskId;
        activeTaskIndex = i;
        break;
      }
    }
    if (!hideTaskList && !replaySession && (completedGoals.has(goalId) || claimedRewards.has(goalId)) && goalTasks.length) {
      activeTaskId = goalTasks[0]?.id || activeTaskId;
      activeTaskIndex = 0;
    }
    if (hideTaskList) {
      activeTaskId = null;
      activeTaskIndex = goalTasks.length;
    }
    const replayComplete = replaySession && goalTasks.every(
      (task) => !task?.id || panelCompletedTasks.has(task.id)
    );
    return { goalTasks, replaySession, panelCompletedTasks, activeTaskId, activeTaskIndex, replayComplete, hideTaskList, isPendingReward };
  };

  const selectedGoal = userSelectedGoalId
    ? goals.find((goal) => goal && goal.id === userSelectedGoalId)
    : null;
  const visibleGoal = showAllGoalsComplete
    ? (goals[0] || null)
    : (selectedGoal || getActiveGoal(goals, { completedGoals, claimedRewards }));
  const visibleGoalId = visibleGoal?.id || null;
  const visibleState = (!showAllGoalsComplete && visibleGoal) ? resolveGoalState(visibleGoal) : null;
  const nextTaskId = visibleState?.activeTaskId || null;
  const nextTaskIndex = Number.isFinite(visibleState?.activeTaskIndex) ? visibleState.activeTaskIndex : 0;
  const goalPendingReward = !!visibleState?.isPendingReward;
  const shouldSwap =
    lastRenderedGuideTaskId &&
    ((nextTaskId && nextTaskId !== lastRenderedGuideTaskId) || (!nextTaskId && goalPendingReward));

  if (visibleGoalId && lastRenderedGuideGoalId && visibleGoalId !== lastRenderedGuideGoalId) {
    lastRenderedGuideTaskId = null;
    lastRenderedGuideTaskIndex = 0;
  }

  if (
    guideOpen &&
    !skipSwap &&
    !guideTaskSwapInProgress &&
    !showAllGoalsComplete &&
    visibleGoalId &&
    lastRenderedGuideGoalId === visibleGoalId &&
    shouldSwap
  ) {
    const currentTaskEl = panelsRef?.querySelector('.guide-goals-panel .goal-task.is-active')
      || panelsRef?.querySelector('.guide-goals-panel .goal-task');
    if (currentTaskEl) {
      guideTaskSwapInProgress = true;
      const isBacktrack = nextTaskId && nextTaskIndex < lastRenderedGuideTaskIndex;
      const useBacktrack = isBacktrack && !goalPendingReward;
      currentTaskEl.classList.remove('is-exiting-complete', 'is-exiting-backtrack');
      void currentTaskEl.offsetWidth;
      currentTaskEl.classList.add(useBacktrack ? 'is-exiting-backtrack' : 'is-exiting-complete');
      if (guideTaskSwapTimer) clearTimeout(guideTaskSwapTimer);
      guideTaskSwapTimer = setTimeout(() => {
        guideTaskSwapInProgress = false;
        guideTaskSwapTimer = 0;
        const pending = pendingGuideRender;
        pendingGuideRender = null;
        if (pending) {
          renderGuide(pending.api, { source: pending.source, skipSwap: true });
        } else {
          renderGuide(api, { source: 'task-swap', skipSwap: true });
        }
      }, 420);
      pendingGuideRender = { api, source };
      return;
    }
  }

  hostRef.dataset.guideState = hasGoals ? 'has-goals' : 'no-goals';
  hostRef.dataset.goalCount = String(goals.length);

  clearPanels();

  if (hasGoals && api?.createPanel) {
    const activePanels = [];
    const panelMeta = [];
    let expandedCount = 0;

    if (showAllGoalsComplete) {
      if (activeGoalId) setActiveGoal(null);
    } else if (visibleGoal && visibleGoal.id && activeGoalId !== visibleGoal.id) {
      setActiveGoal(visibleGoal.id);
    } else if (!visibleGoal && activeGoalId) {
      setActiveGoal(null);
    }

    const buildGoalPanel = (goal, index, { forceExpanded = false, lockCollapsed = false } = {}) => {
      const panel = api.createPanel?.();
      if (!panel) {
        console.warn('[guide] createPanel returned no panel', { index, goal });
        return null;
      }
      const goalId = goal?.id;
      const willBeFirstActive = activePanels.length === 0;
      panel.classList.add('guide-goals-panel');
      panel.removeAttribute('id');

      const { goalTasks, replaySession, panelCompletedTasks, activeTaskId, replayComplete, hideTaskList } = resolveGoalState(goal);
      const activeTaskIdForPanel = showAllGoalsComplete ? null : activeTaskId;
      try {
        api.populatePanel?.(panel, goal, {
          taskIndex: 0,
          showClaimButton: true,
          activeTaskId: activeTaskIdForPanel,
          completedTaskIds: panelCompletedTasks,
          completedGoals,
          claimedRewards,
          pendingRewards,
          replaySession,
          replayComplete,
          allGoalsComplete: showAllGoalsComplete,
          hideTaskList,
        });
      } catch (err) {
        console.warn('[guide] populatePanel failed', err);
      }

      if (replaySession) {
        const rewardEl = panel.querySelector('.tutorial-goals-reward');
        if (rewardEl) {
          // Hide reward UI but keep the claim/complete button visible
          rewardEl.querySelectorAll('.goal-reward-label, .goal-reward-description, .goal-reward-icons, .tutorial-goals-reward-claimed').forEach((el) => {
            el.style.display = 'none';
          });
          rewardEl.style.display = '';
        }
      }

      const claimBtn = panel.querySelector('.tutorial-claim-btn');
      if (claimBtn && !claimBtn.__guideBound) {
        claimBtn.__guideBound = true;
        claimBtn.addEventListener('click', () => {
          const targetGoalId = claimBtn.dataset.goalId || goal.id;
          openFirstGoalNextRender = true;
          window.dispatchEvent(new CustomEvent('guide:task-deactivate', { bubbles: true, composed: true }));
          const alreadyClaimed = claimedRewards.has(targetGoalId);
          if (alreadyClaimed) {
            // Replay mode: no reward, just refresh panel
            setActiveGoal(null);
            userSelectedGoalId = null;
            renderGuide(api, { source: 'replay-complete' });
            return;
          }
          setActiveGoal(null);
          userSelectedGoalId = null;
          if (typeof api.claimReward === 'function') {
            api.claimReward(targetGoalId);
          }
        });
      }
      if (claimBtn) {
        if (showAllGoalsComplete) {
          claimBtn.style.display = 'none';
          claimBtn.classList.remove('is-visible');
          claimBtn.disabled = true;
        } else {
          const alreadyClaimed = claimedRewards.has(goalId);
          const allDone = replaySession
            ? replayComplete
            : goalTasks.every(task => !task?.id || panelCompletedTasks.has(task.id));
          const showClaim = allDone;
          claimBtn.textContent = replaySession
            ? 'Complete'
            : (alreadyClaimed ? 'Complete' : 'Collect Your Reward');
          claimBtn.style.display = showClaim ? '' : 'none';
          claimBtn.classList.toggle('is-visible', showClaim);
          claimBtn.disabled = !showClaim;
        }
      }

      if (claimedRewards.has(goalId) && !pendingRewards.has(goalId)) {
        const rewardEl = panel.querySelector('.tutorial-goals-reward');
        if (rewardEl) {
          let claimedMsg = rewardEl.querySelector('.tutorial-goals-reward-claimed');
          if (!claimedMsg) {
            claimedMsg = document.createElement('div');
            claimedMsg.className = 'tutorial-goals-reward-claimed';
            rewardEl.prepend(claimedMsg);
          }
          claimedMsg.textContent = 'Reward already claimed';
        }

        const tasksEl = panel.querySelectorAll('.goal-task');
        tasksEl.forEach((task) => {
          // For *non-active* goals, keep them visually done.
          // For the active replay session, let the per-session completion state drive styles.
          if (replaySession && goal.id === goalId) {
            task.classList.remove('goal-task-claimed');
          } else {
            task.classList.add('goal-task-claimed');
          }
        });
      } else if (!replaySession) {
        const rewardEl = panel.querySelector('.tutorial-goals-reward');
        const desc = rewardEl?.querySelector('.goal-reward-description');
        if (desc) desc.textContent = 'A Star. A symbol of Achievement.';
      }

      panel.querySelectorAll('.goal-task').forEach((taskEl) => {
        taskEl.style.cursor = 'pointer';
        taskEl.addEventListener('click', () => {
          if (highlighterRef) highlighterRef.classList.remove('is-visible');
          const isActive = taskEl.classList.contains('is-active-guide-task');
          if (isActive) {
            taskEl.classList.remove('is-active-guide-task');
            lastActiveTaskSelectionId = null;
            window.dispatchEvent(new CustomEvent('guide:task-deactivate', { bubbles: true, composed: true }));
          } else {
            const currentActive = panel.querySelector('.is-active-guide-task');
            if (currentActive) {
              currentActive.classList.remove('is-active-guide-task');
              window.dispatchEvent(new CustomEvent('guide:task-deactivate', { bubbles: true, composed: true }));
            }
            taskEl.classList.add('is-active-guide-task');
            const taskId = taskEl.dataset.taskId;
            if (taskId) {
              lastActiveTaskSelectionId = taskId;
              window.dispatchEvent(new CustomEvent('guide:task-click', {
                detail: { taskId, taskElement: taskEl },
                bubbles: true,
                composed: true,
              }));
            }
          }
        });
      });

      const restoreActiveTaskSelection = () => {
        if (!lastActiveTaskSelectionId) return;
        const el = panel.querySelector(`.goal-task[data-task-id="${lastActiveTaskSelectionId}"]`);
        if (!el) return;
        el.classList.add('is-active-guide-task');
        try {
          window.dispatchEvent(new CustomEvent('guide:task-click', {
            detail: { taskId: lastActiveTaskSelectionId, taskElement: el },
            bubbles: true,
            composed: true,
          }));
        } catch {}
      };

      const header = panel.querySelector('.tutorial-goals-header');
      const tasks = panel.querySelector('.tutorial-goals-tasks');
      const progress = panel.querySelector('.tutorial-goals-progress');
      const reward = panel.querySelector('.tutorial-goals-reward');

      if (header && (tasks || progress || reward)) {
        const bodyContent = [tasks, progress, reward].filter(Boolean);
        const bodyWrapper = document.createElement('div');
        bodyWrapper.className = 'goal-body-wrapper';
        bodyWrapper.style.background = 'rgba(0,0,0,0.2)';
        bodyWrapper.style.padding = '10px';
        bodyWrapper.style.borderRadius = '8px';
        bodyContent.forEach((el) => bodyWrapper.appendChild(el));
        panel.appendChild(bodyWrapper);

        const stateKey = goalId || `__index_${index}`;
        const storedExpanded = stateKey ? goalExpansionState.get(stateKey) : undefined;
        const shouldExpand = forceExpanded ? true : (storedExpanded !== undefined ? !!storedExpanded : willBeFirstActive);
        if (shouldExpand) expandedCount += 1;
        if (stateKey) goalExpansionState.set(stateKey, shouldExpand);

        header.style.cursor = lockCollapsed ? 'default' : 'pointer';
        panel.classList.toggle('is-collapsed', !shouldExpand);
        bodyWrapper.style.display = shouldExpand ? '' : 'none';
        panelMeta.push({ panel, bodyWrapper, stateKey });

        if (!lockCollapsed) {
          header.addEventListener('click', () => {
            const isCollapsed = panel.classList.contains('is-collapsed');
            panel.classList.toggle('is-collapsed', !isCollapsed);
            const nowCollapsed = panel.classList.contains('is-collapsed');
            bodyWrapper.style.display = nowCollapsed ? 'none' : '';
            if (nowCollapsed) {
              if (expandedCount > 0) expandedCount -= 1;
            } else {
              expandedCount += 1;
            }
            if (stateKey) goalExpansionState.set(stateKey, !nowCollapsed);
            if (nowCollapsed) {
              panel.querySelectorAll('.is-active-guide-task').forEach(task => task.classList.remove('is-active-guide-task'));
              window.dispatchEvent(new CustomEvent('guide:task-deactivate', { bubbles: true, composed: true }));
            }
          });
        }
      }

      return panel;
    };

    if (visibleGoal) {
      const panel = buildGoalPanel(visibleGoal, 0, { forceExpanded: true });
      if (panel) activePanels.push(panel);
    }

    const orderedPanels = [...activePanels];
    orderedPanels.forEach(panel => panelsRef.appendChild(panel));

    if (totalRewards > 0) {
      const summary = buildGuideProgressSummary(collectedRewards, totalRewards);
      panelsRef.appendChild(summary);
      if (shouldBumpProgress) {
        requestAnimationFrame(() => summary.classList.add('is-bump'));
      }
    }

    if (openFirstGoalNextRender && orderedPanels.length > 0) {
      const targetPanel = orderedPanels[0];
      const meta = panelMeta.find(entry => entry.panel === targetPanel);
      if (meta && meta.bodyWrapper) {
        const wasCollapsed = targetPanel.classList.contains('is-collapsed');
        targetPanel.classList.remove('is-collapsed');
        meta.bodyWrapper.style.display = '';
        if (wasCollapsed) expandedCount += 1;
        if (meta.stateKey) goalExpansionState.set(meta.stateKey, true);
        openFirstGoalNextRender = false;
      }
    }

    if (expandedCount === 0 && orderedPanels.length > 0) {
      const targetPanel = orderedPanels[0];
      const meta = panelMeta.find(entry => entry.panel === targetPanel);
      if (meta && meta.bodyWrapper) {
        targetPanel.classList.remove('is-collapsed');
        meta.bodyWrapper.style.display = '';
        expandedCount = 1;
        if (meta.stateKey) goalExpansionState.set(meta.stateKey, true);
      }
    }

    // Restore previously active task highlight after render
    if (lastActiveTaskSelectionId && orderedPanels.length > 0) {
      const el = orderedPanels[0].querySelector(`.goal-task[data-task-id="${lastActiveTaskSelectionId}"]`);
      if (el) {
        el.classList.add('is-active-guide-task');
        try {
          window.dispatchEvent(new CustomEvent('guide:task-click', {
            detail: { taskId: lastActiveTaskSelectionId, taskElement: el },
            bubbles: true,
            composed: true,
          }));
        } catch {}
      }
    }
    if (showAllGoalsComplete || !visibleGoalId) {
      lastRenderedGuideTaskId = null;
      lastRenderedGuideTaskIndex = 0;
      lastRenderedGuideGoalId = null;
    } else {
      lastRenderedGuideTaskId = nextTaskId;
      lastRenderedGuideTaskIndex = nextTaskIndex;
      lastRenderedGuideGoalId = visibleGoalId;
    }

  } else {
    const empty = document.createElement('div');
    empty.className = 'guide-empty-state';
    empty.textContent = 'Guide will unlock once tutorial goals are available.';
    panelsRef.appendChild(empty);
    lastRenderedGuideTaskId = null;
    lastRenderedGuideTaskIndex = 0;
    lastRenderedGuideGoalId = null;
  }

  const open = hostRef.classList.contains(GUIDE_OPEN_CLASS);
  panelsRef.style.display = open ? 'block' : 'none';
  panelsRef.classList.toggle('is-visible', open);
  const multipleGoals = goals.length > 1;
  if (moreGoalsButtonRef) {
    moreGoalsButtonRef.style.display = open && multipleGoals ? '' : 'none';
    moreGoalsButtonRef.disabled = !multipleGoals;
  }

  try {
    if (isPlaceAToyIntroActive(api)) addGuidePulse(); else removeGuidePulse();
  } catch {
    removeGuidePulse();
  }
  lastCollectedRewards = hasGoals ? collectedRewards : null;

  try {
    window.__guideDebug = Object.assign({}, window.__guideDebug || {}, {
      lastRender: stamp,
      goalCount: goals.length,
      source,
      host: hostRef,
    });
  } catch {}

  //guideInfoLog('[guide] render', { source, goals: goals.length });
}

window.addEventListener('guide:progress-update', () => {
  if (lastApi) {
    renderGuide(lastApi, { source: 'progress-update' });
  }
  if (!shouldShowGuideTapHighlighter() && !shouldShowTaskTapHighlighter() && highlighterRef) {
    highlighterRef.classList.remove('is-visible');
    highlightNextTask = false;
  }
});

window.addEventListener('guide:open', () => {
  setGuideButtonAcknowledged(true);
  updateHighlighterTapState();
  if (highlighterRef && !shouldShowGuideTapHighlighter() && !shouldShowTaskTapHighlighter()) {
    highlighterRef.classList.remove('is-visible');
  }
});

window.addEventListener('guide:clear-active-task', () => {
  lastActiveTaskSelectionId = null;
  if (panelsRef) {
    panelsRef.querySelectorAll('.is-active-guide-task').forEach((taskEl) => {
      taskEl.classList.remove('is-active-guide-task');
    });
  }
});

window.addEventListener('scene:new', () => {
  try {
    const api = window.TutorialGoalsAPI || lastApi;
    if (isPlaceAToyIntroActive(api)) addGuidePulse(); else removeGuidePulse();
  } catch {
    addGuidePulse();
  }
  goalExpansionState.clear();
  setActiveGoal(null);
  userSelectedGoalId = null;
  lastRenderedGuideTaskId = null;
  lastRenderedGuideTaskIndex = 0;
  lastRenderedGuideGoalId = null;
  if (guideTaskSwapTimer) { clearTimeout(guideTaskSwapTimer); guideTaskSwapTimer = 0; }
  guideTaskSwapInProgress = false;
  pendingGuideRender = null;
  openFirstGoalNextRender = true;
  highlightNextTask = true;
  requestAnimationFrame(() => {
    if (!showHighlighterForGuide() && highlighterRef) highlighterRef.classList.remove('is-visible');
  });
  if (lastApi || window.TutorialGoalsAPI) {
    const api = lastApi || window.TutorialGoalsAPI;
    renderGuide(api, { source: 'scene-new' });
  }
}, { passive: true });

window.addEventListener('tutorial:goals-updated', () => {
  try {
    const api = window.TutorialGoalsAPI || lastApi;
    if (isPlaceAToyIntroActive(api)) addGuidePulse(); else removeGuidePulse();
  } catch {
    removeGuidePulse();
  }
}, { passive: true });

window.addEventListener('guide:close', () => closeGuide());
window.addEventListener('guide:highlight-next-task', () => {
  highlightNextTask = true;
  const guideOpen = hostRef && hostRef.classList.contains(GUIDE_OPEN_CLASS);
  if (guideOpen && panelsRef) {
    if (showHighlighterForFirstTask()) {
      highlightNextTask = false;
    } else if (highlighterRef) {
      highlighterRef.classList.remove('is-visible');
      highlightNextTask = false;
    }
  } else if (!showHighlighterForGuide() && highlighterRef) {
    highlighterRef.classList.remove('is-visible');
  }
});

window.addEventListener('guide:highlight-hide', () => {
  highlightNextTask = false;
  if (highlighterRef) highlighterRef.classList.remove('is-visible');
});

let highlighterRefreshRaf = 0;
let highlighterRefreshTimer = 0;
let highlighterObserver = null;

function runHighlighterRefresh() {
  if (!highlighterRef || !highlighterTarget) return;
  if (!highlighterRef.classList.contains('is-visible')) return;
  if (!highlighterTarget.isConnected) return;
  showHighlighterForElement(highlighterTarget);
}

function scheduleHighlighterRefresh() {
  if (!highlighterRefreshRaf) {
    highlighterRefreshRaf = requestAnimationFrame(() => {
      highlighterRefreshRaf = 0;
      runHighlighterRefresh();
    });
  }
  if (highlighterRefreshTimer) clearTimeout(highlighterRefreshTimer);
  highlighterRefreshTimer = setTimeout(() => {
    highlighterRefreshTimer = 0;
    runHighlighterRefresh();
  }, 140);
}

function watchUiScaleChanges() {
  if (highlighterObserver) return;
  if (typeof MutationObserver === 'undefined') return;
  highlighterObserver = new MutationObserver(() => scheduleHighlighterRefresh());
  highlighterObserver.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['style', 'class'],
  });
}

window.addEventListener('resize', scheduleHighlighterRefresh);
window.addEventListener('orientationchange', scheduleHighlighterRefresh);
if (window.visualViewport) {
  window.visualViewport.addEventListener('resize', scheduleHighlighterRefresh);
}
watchUiScaleChanges();

window.addEventListener('guide:open-goal-picker', () => {
  openGoalPicker();
});

function startWhenReady() {
  renderGuide(null, { source: 'bootstrap-placeholder' });

  if (window.TutorialGoalsAPI) {
    guideInfoLog('[guide] TutorialGoalsAPI available on load');
    renderGuide(window.TutorialGoalsAPI, { source: 'direct' });
    return;
  }

  guideInfoLog('[guide] waiting for tutorial:goals-ready event');
  try { window.__guideDebug = Object.assign({}, window.__guideDebug || {}, { waiting: true }); } catch {}

  let fallbackTimer = setTimeout(() => {
    console.warn('[guide] tutorial API not ready after delay, keeping placeholder');
    try { window.__guideDebug = Object.assign({}, window.__guideDebug || {}, { fallbackAt: Date.now() }); } catch {}
  }, 2500);

  window.addEventListener('tutorial:goals-ready', (event) => {
    guideInfoLog('[guide] tutorial:goals-ready received');
    if (fallbackTimer) {
      clearTimeout(fallbackTimer);
      fallbackTimer = null;
    }
    const api = event?.detail || window.TutorialGoalsAPI;
    renderGuide(api, { source: 'event' });
    try { window.__guideDebug = Object.assign({}, window.__guideDebug || {}, { waiting: false }); } catch {}
  }, { once: true });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', startWhenReady, { once: true });
} else {
  startWhenReady();
}






if (typeof window !== 'undefined') {
  window.addEventListener('guide:task-tapped', () => {
    setGuideTaskAcknowledged(true);
    updateHighlighterTapState();
    if (highlighterRef) highlighterRef.classList.remove('is-visible');
    highlightNextTask = false;
  });
  window.addEventListener('scene:new', () => {
    setGuideTaskAcknowledged(false);
    setGuideButtonAcknowledged(false);
    updateHighlighterTapState();
  });
}

window.addEventListener('drawgrid:update', (e) => {
  const { activityOnly } = e.detail || {};
  if (!activityOnly) {
    window.dispatchEvent(new Event('guide:progress-update'));
  }
});

window.addEventListener('drawgrid:activity', (e) => {
  // no pulse; optional: a very lightweight guide refresh without glow
  // renderGuide(lastApi, { source: 'drawgrid-activity', pulse:false });
});




