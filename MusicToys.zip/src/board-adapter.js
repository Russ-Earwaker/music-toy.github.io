// src/board-adapter.js
import { initDragBoard, organizeBoard } from './board.js';
window.initDragBoard = initDragBoard;
window.organizeBoard = organizeBoard;
