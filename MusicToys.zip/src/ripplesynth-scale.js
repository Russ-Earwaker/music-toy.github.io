export const PENTATONIC_OFFSETS = [0,3,5,7,10]; // minor pentatonic, 1 octave
