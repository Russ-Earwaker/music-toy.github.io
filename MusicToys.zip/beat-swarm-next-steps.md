## Beat Swarm next task list

### 1. Protect foundation even when player activity is heavy

The latest run is still showing **high player masking**, **heavily ducked foundation**, and bass moving from **stable** to **at_risk** later in the session. That means the bass is still not being protected enough when the action gets dense.  

**Task**

* Strengthen the rule that foundation/bass has first claim on audibility.
* On player-heavy steps, prefer dropping or downgrading non-foundation enemy notes before reducing bass prominence.
* Add a hard rule: if a foundation hit exists for a step, it should usually remain foreground unless a very explicit exception applies.

**Goal**

* Bass should stay musically readable throughout the run, not just technically present.

---

### 2. Add a true final-stage foreground arbitration pass

The lab now shows **audibleForegroundLaneCount** sitting around **1.69–1.74** in the later run, while readability is marked **busy**. That suggests too many things are still trying to act like foreground material at once.  

**Task**

* Add one final pass just before playback that decides:

  * what is the foreground idea this step
  * what is support
  * what is dropped
* Enforce simple lane budgets such as:

  * 1 foundation voice
  * 1 loop lead voice
  * 0–1 accent voice
  * optional player voice on top

**Goal**

* The system should sound selected and arranged, not accumulated.

---

### 3. Reduce player masking specifically against important musical material

In the older run, player masking late in the session was around **0.51**, while now it’s more like **0.63–0.65**. That is a big regression in practical readability.  

**Task**

* Split masking policy by role:

  * player can mask sparkle/accent
  * player should not easily mask foundation
  * player should not bury a newly introduced loop
* Add explicit priority rules for overlap resolution.

**Goal**

* Weapons still feel punchy, but they stop bulldozing the song.

---

### 4. Add “new loop establishment protection”

The lab now tracks **barsSinceNewForegroundIdea**, and the later run shows very long stretches like **57, 73, 81, 89** bars since a new foreground idea, while readability stays **busy**. That suggests loops are not being admitted and established clearly enough, or foreground ownership is stagnating instead of being managed deliberately.  

**Task**

* When a new loop/riff is admitted, mark it as “establishing.”
* For its first 2 bars:

  * keep it audible
  * resist replacing it
  * resist downgrading it to trace/background immediately
* After establishment, it can move to support or be retired normally.

**Goal**

* New loop ideas should actually be heard and understood by the player.

---

### 5. Stop foreground ownership from going stale

Very high **barsSinceNewForegroundIdea** combined with **busy** readability is a bad combo: it suggests the system is crowded without actually introducing a clear new lead idea. 

**Task**

* Add a foreground lifecycle:

  * introduced
  * establishing
  * established
  * background support
  * retired
* Add controlled rotation rules so the system can intentionally introduce a new foreground idea after enough time has passed.

**Goal**

* Avoid “same soup forever” while still keeping continuity.

---

### 6. Improve call-and-response / conversational structure

The latest run’s **responseRate** is around **0.16–0.18**, while the earlier run was around **0.40–0.48**. That is a major drop, and it fits the feeling that the music is less conversational and more cluttered.  

**Task**

* Add explicit call-and-response rules between roles:

  * if one layer states a phrase, another should often leave space
  * avoid letting all systems answer at once
* Consider bar-level alternation where loops, accents, and enemy reactions take turns more deliberately.

**Goal**

* The music should feel like interlocking phrases, not simultaneous chatter.

---

### 7. Keep motif reuse, but stop it becoming stagnant clutter

The latest run has strong **motifReuseRate** around **0.90–0.92+**, which is good for continuity, but because readability is still **busy**, reuse alone is not solving the musical problem.  

**Task**

* Keep reuse, but pair it with role clarity:

  * reused motif as foreground
  * reused motif as support
  * reused motif suppressed when it would clutter a stronger idea
* Prevent multiple reused motifs from all trying to speak at once.

**Goal**

* Repetition should feel like identity, not congestion.

---

### 8. Add collision metrics for actual musical pileups

The current lab is good, but it still does not directly tell us enough about the exact pileup problem you’re hearing.

**Task**
Add these metrics to Music Lab:

* same-step note count by role
* same-step same-pitch collisions
* same-step same-register collisions
* suppressed-by-arbitration counts
* suppressed-because-player-masking counts
* new-loop establishment success rate
* loop heard-duration after admission
* foreground ownership changes per 8 bars

**Goal**

* Let us see exactly why a moment sounded bad instead of inferring it.

---

### 9. Add explicit pass/fail checks for arrangement quality

Right now the lab reports useful metrics, but Codex needs clearer musical targets.

**Task**
Add high-level checks such as:

* fail if foundationProminence is `heavily_ducked` for too many consecutive windows
* fail if playerMaskingRate stays above a threshold for too long
* fail if responseRate drops below a minimum for too long
* fail if audibleForegroundLaneCount stays too high while readability is `busy`
* fail if bassFoundation becomes `at_risk` too often after mid-run

**Goal**

* Give Codex objective warning lights for musical regressions.

---

### 10. Tune for “clear loop + clear bass + clear weapons” as the intended mix

The latest run is still telling the same basic story: **beat delivery stable**, **spawner feedback consistent**, but **bass at risk** and **readability busy**. 

**Task**

* Rebalance the arrangement around three things being clearly perceivable:

  * bass/foundation
  * one active loop/riff
  * player weapon layer
* Everything else should compete for leftovers, not equal status.

**Goal**

* The mix should feel like a song with action on top, not action with music buried underneath.

---

## Acceptance criteria for Codex

Use this as the success target:

* Foundation should rarely become `heavily_ducked` for sustained stretches.
* Bass should remain `stable` most of the run, not drift into `at_risk` once action density rises.
* Player masking should come down meaningfully from the current ~0.63–0.65 late-run range. 
* Response rate should recover noticeably from the current ~0.16–0.18 range. 
* A new loop should be clearly audible when introduced.
* Foreground lane pressure should reduce, and readability should stop sitting in `busy` so persistently. 

## One-line brief for Codex

**The lab now shows that scheduling is stable, but arrangement is still too player-masked, too foreground-crowded, and too weak at protecting foundation and establishing loops; implement stronger final-stage musical arbitration and better loop/foundation protection.**