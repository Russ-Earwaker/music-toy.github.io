## Codex task list

### 1. Replace the current “foundation owner” concept with persistent musical lanes

Create explicit long-lived music lanes, not just event roles:

* `foundationLane`
* `primaryLoopLane`
* `secondaryLoopLane`
* `sparkleLane`

Each lane should own:

* lane id
* phrase id
* instrument id
* colour id
* register/range
* variation policy
* admission rules
* minimum lifetime
* transfer rules

Important rule:

* **lanes persist even when actors die**
* actors are only temporary performers for a lane
* lane state must not be rebuilt from scratch when an enemy changes

Implementation goal:

* treat the battlefield like a song with tracks
* actors are performers on tracks, not the tracks themselves

### 2. Make foundation a true protected lane

Foundation must become a privileged lane with harder rules than every other layer.

Add these rules:

* only 1 foundation lane at a time
* minimum lifetime: at least 16 bars once established
* no phrase reset during section unless an explicit musical transition says so
* no instrument change during section
* no colour change during section
* actor handoff must preserve phrase step, bar offset, and continuity id
* if no valid actor exists briefly, use lane ghost playback / invisible keeper until a new actor takes over

Success target:

* `bassPhraseResets` near 0 during normal play
* `bassHandoffContinuityRate` above 0.85
* `instrumentChangesPerEnemy = 0`
* `colourChangesPerEnemy = 0`

### 3. Split foundation reliability from foundation phrasing

Keep the bass reliable, but stop making it musically flat.

Create a small authored phrase library for foundation, for example:

* `foundation_phrase_A`: strong downbeats with one rest
* `foundation_phrase_B`: downbeat + held gap + late accent
* `foundation_phrase_C`: syncopated variant with one offbeat
* `foundation_phrase_D`: sparse bar-end pickup

Rules:

* choose one phrase and keep it for a meaningful duration
* minimum 4 bars before variation
* variation can only occur on bar boundaries
* use phrase families, not per-beat randomness
* allow silence/rest steps
* allow occasional offbeats
* never randomise individual beats independently

Important:

* do **not** solve this with probability on every step
* solve it with stable phrase clips / patterns

### 4. Slow the whole arranger down

Admission of new ideas is still too fast.

Change rules so that:

* no new foreground lane enters until current foreground lane has completed at least 2 full cycles
* minimum spacing between important new ideas: 4 bars
* after any section change, add a lockout window before another major musical idea can appear
* “main_low” should still feel sparse and readable, not busy

Suggested defaults:

* `loopRegistrationCycles = 2`
* `minLayerSpacingBars = 4`
* `sectionChangeIdeaLockBars = 2`
* `themeMinLifetimeBars = 8`

### 5. Limit the number of readable musical ideas on screen

Make the arranger optimise for player comprehension, not density.

Hard caps:

* foundation lanes audible: 1
* primary theme lanes audible: 1
* secondary theme lanes audible: 0 or 1 only when battlefield load is low
* sparkle lanes: many events allowed, but only 1 foreground sparkle voice at a time

If extra events want to play:

* demote them to support pulses
* or mute them visually/audio-wise
* or queue them for later

Principle:

* the player should be able to point at the screen and say “that orange enemy is the bass,” “that green group is the melody,” etc.

### 6. Decouple lane identity from enemy spawning churn

At the moment, enemies are still too tightly coupled to the musical state.

Implement:

* lane owns `instrumentId`
* lane owns `roleColor`
* enemy receives those on spawn from the lane
* enemy cannot mutate them later
* if performer changes, new performer inherits the lane identity exactly

Add hard guards:

* if any code tries to rewrite `musicInstrumentId` or `enemyRoleColor` after assignment, log a warning and reject the change unless it is part of an explicit cross-section reorchestration event

### 7. Add a real onboarding/readability policy

The first 20–24 bars should be treated as onboarding, not ordinary reactive play.

Suggested structure:

* bars 0–3: player solo / minimal punctuation
* bars 4–11: foundation only, readable and stable
* bars 12–19: introduce one primary theme
* bars 20–27: allow one response/secondary line only if readability is still high
* sparkle remains subordinate until later

During onboarding:

* prefer repeated enemy performers over churn
* avoid rapid musical handoffs
* avoid adding new colours too quickly
* avoid dense projectile-linked accents

### 8. Rework handoff so phrase inheritance is default, not exception

Your current lab result shows reset-heavy handoffs, which is the opposite of what you want. 

Change handoff rules:

* inherit phrase step by default
* inherit continuity id by default
* inherit loop cycle count by default
* reset only if:

  * section changed intentionally
  * phrase reached a real cadence endpoint
  * lane explicitly requests re-orchestration

Add a `handoffReason` enum:

* `performer_death_inherit`
* `performer_out_of_range_inherit`
* `section_reorchestrate_reset`
* `cadence_resolve_reset`

Then audit every reset path and remove accidental resets.

### 9. Add authored lane behaviours instead of generic per-role logic

Move away from “bass role,” “lead role,” “accent role” as mostly generic behaviour buckets.

Create lane profiles such as:

* `ground_bass`
* `steady_mid_riff`
* `call_response_lead`
* `ornament_sparkle`
* `weapon_anchor`

Each profile should define:

* phrase length
* allowed syncopation
* rest density
* offbeat allowance
* bar-boundary variation policy
* handoff policy
* colour family
* enemy behaviour preference

This will make the system feel composed instead of procedurally scrambled.

### 10. Make sparkle obey the arrangement instead of competing with it

Sparkle should be punctuation, not a second melody system.

Rules:

* sparkle must duck when a new theme enters
* sparkle cannot trigger if readability is below threshold
* sparkle cannot create a new perceived foreground identity
* sparkle density should scale down when the battlefield already has 2 strong audible lanes

### 11. Add the missing metrics that match the design goals

The current metrics are useful, but not yet the ones that answer your exact musical questions.

Add:

* `foundationCycleCount`
* `foundationContinuityRate`
* `foundationPhraseResets`
* `themeCycleCount`
* `themePersistenceRate`
* `themeReturnRate`
* `sparkleDensity`
* `sparkleForegroundShare`
* `laneReassignmentRate`
* `laneLifetimeBars`
* `barsSinceNewForegroundIdea`
* `audibleForegroundLaneCount`
* `enemyColourMutationCount`
* `enemyInstrumentMutationCount`

Also add a derived readability score:

* penalise frequent new colours
* penalise rapid lane changes
* penalise more than 2 simultaneous foreground identities
* penalise phrase resets before 2 cycles complete

### 12. Add a “musical boringness” metric for the bass

Since the intro bass is now too rigid, add diagnostics for that too.

Examples:

* `foundationRestShare`
* `foundationOffbeatShare`
* `foundationUniquePatternCount`
* `foundationPatternChangeRate`
* `foundationConsecutiveOnBeatHits`

Target:

* not random
* but not “every beat forever”

### 13. Build one explicit first-minute arrangement and make the director respect it

For now, stop asking the system to invent the whole song live.

Create a fixed arrangement plan for the first minute:

* phase A: intro solo
* phase B: foundation enters
* phase C: foundation repeats unchanged long enough to register
* phase D: one theme layer enters
* phase E: one response/support layer enters only if readability remains good

Then let reactive systems decorate around that plan instead of replacing it.

This is the fastest way to make the game sound intentional.

## Implementation priority order

Tell Codex to do it in this order:

1. persistent lane model
2. protected foundation lane
3. handoff inheritance by default
4. slower idea admission / foreground caps
5. bass phrase library with rests/offbeats
6. hard identity lock for colour/instrument
7. sparkle suppression
8. new metrics and lab reporting
9. first-minute authored arrangement plan

## One-line brief for Codex

Build Beat Swarm as a **track-based arranger**, not a reactive note cloud: persistent music lanes, protected foundation, slow readable layering, identity-stable enemies, phrase inheritance across actor changes, and authored bass phrases with controlled rests/offbeats.
