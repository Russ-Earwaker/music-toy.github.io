# Beat Swarm Next Steps

## Current State

Performance is no longer the main blocker.

Latest run:
- [music-lab-results-2026-03-20T00-03-22-545Z.json](/d:/Desktop/music-toy/music-toy.github.io/resources/music-lab-results/music-lab-results-2026-03-20T00-03-22-545Z.json)
- `avgFrameMs ~= 4.37`
- `maintainSpawners ~= 0.16 ms`
- `pickupsCombat ~= 0.90 ms`
- `starfield ~= 0.90 ms`

So the project should shift back to musical control, clarity, and intention.

## Already Landed

### 1. Intro loop structure

Done enough for now:
- player-only opening is preserved
- intro foundation window is stable
- intro loop ownership is established instead of collapsing immediately

### 2. Role-based instrument rotation

Done enough for now:
- bass / lead / accent pools exist
- lane assignment no longer gets stuck on one sound forever

### 3. Global gain staging

Done enough for now:
- per-step gain scaling exists
- synths now respect mix gain correctly

### 4. Early loop ownership

Done enough for now:
- one stable foundation owner
- one stable primary loop owner
- early sections are much more intentional than before

## Active Priorities

### 1. Snap all gameplay-triggered sounds to grid

Task:
- quantize player and gameplay-triggered sounds to the beat grid
- prefer slightly late over off-grid
- make the music system authoritative for when sounds happen

Goal:
- restore groove and rhythmic lock immediately

Why this is next:
- performance is healthy now
- timing authority is the biggest audible win still missing

### 2. Add per-role note limits

Hard caps per step:
- 1 bass
- 1 loop
- 1 accent
- optional player layer

Everything else:
- dropped
- deferred
- or backgrounded intentionally

Goal:
- immediate clarity improvement
- less mush when multiple systems fire at once

### 3. Fix spawner identity and dedupe

Task:
- keep one musical pattern per spawner identity
- reject or mutate near-duplicates
- verify created vs actually triggered behavior per spawner

Goal:
- stop duplicate loop voices
- make the arrangement easier to read

### 4. Fix death accents

Task:
- max 1 death accent per step
- vary pitch or instrument
- downgrade most accents to background support

Goal:
- eliminate repeated accent spam

### 5. Add musical sanity checks to Music Lab

Add metrics for:
- same-note collisions per step
- off-grid event count
- instrument repetition rate
- loop ownership changes
- per-step sound count

Goal:
- make musical failures visible automatically

## Lower Priority

### Separate music timing from game timing

Still correct architecturally, but larger than the items above.

Do this after:
- gameplay quantization
- note caps
- spawner dedupe

### More loop-ownership refinement

Return to this only if later sections still feel too diffuse after timing and note-limit work.

## Acceptance Criteria

Beat Swarm should aim for:
- intro clearly sounds like a repeatable musical idea
- bass is audible and consistent
- player shots feel locked to rhythm
- no obvious volume spikes
- sounds change over time
- no obvious duplicate loop voices
- no accent spam
- at any moment, you can answer: "what is the main musical idea right now?"

## Immediate Direction

Next implementation target:
- snap gameplay-triggered sounds to the grid

After that:
1. per-role note limits
2. spawner dedupe
3. death-accent cleanup
4. Music Lab sanity metrics
