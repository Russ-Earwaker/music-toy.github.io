Beat Swarm — Next Steps for Codex
Purpose

This document lists future architectural improvements for Beat Swarm that should be implemented later.
It focuses on improving:

musical coherence

pacing

enemy structure

sound identity

maintainability

These are not urgent changes, but the intended long-term direction.

1. Fully Remove Generic Musical Enemies
Current State

Generic enemies still exist through:

maintainEnemyPopulation()
maxFallbackEnemies

These enemies do not belong to groups and weaken musical structure.

Goal

Convert all enemies into Enemy Groups.

Even a single enemy should be treated as:

Group size = 1
Benefits

consistent motif ownership

easier call-and-response

cleaner pacing control

simpler code paths

Target structure
EnemyGroup
  id
  role
  size
  motif
  performers
  threatLevel
2. Improve Death Sound Families
Current State

All death sounds use:

Gaming Bling
Goal

Create three real families:

deathSmall
deathMedium
deathLarge
Requirements

All must feel like game deaths, not instruments.

Acceptable structure:

noise burst
+ tonal pop
+ short pitch drop

Examples:

Enemy class	Sound
small	arcade pop
medium	crunchy burst
large	heavy explosion

Death sounds may follow pitch rules but must not become melodic leads.

3. Expand Palette Evolution System
Current State

Palettes persist ~48–72 bars.

Improvement

Allow controlled evolution inside a palette.

Examples:

bass distortion increase
lead brightness increase
accent sharpness increase
motion density increase

Do NOT swap unrelated instrument families.

Goal:

soundtrack evolves like one track gaining layers.

4. Introduce Motif Locking

Problem:
procedural systems tend to wander.

Solution:
add motif locking.

Example:

lock 3–5 note phrase for 8 bars
reuse across drawsnakes/groups

This creates a recognizable hook.

5. Improve Call-and-Response

Current response logic works but is shallow.

Future improvements:

assign groups to lanes

enforce response timing windows

prefer alternating groups

Example:

Group A → call
Group B → response
Group A → variation

Goal: readable musical dialogue.

6. Improve Beam Weapon Behaviour

Beam weapons require special treatment.

Requirements:

beam starts on beat

beam pitch follows note

beam sustain respects sequence silence

beam sound does not dominate the mix

Check for:

beam sustain spam
beam masking other sounds
7. Director-Driven Arrangement

The Director should eventually control:

energy state
spawn pacing
note density
palette
phrase complexity

Energy states already exist but can be extended.

Future additions:

build_up
mini_break
boss_phase
swarm_chaos
8. Threat Budget Refinement

Per beat budgets should be clearer.

Example:

maxFullThreats
maxLightThreats
maxCosmetic

Goal:

everyone can participate, not everyone can be dangerous.

9. Reduce beat-swarm-mode.js Responsibility

Current file size:

~10k lines

Future refactor targets:

Move logic to modules:

beat-swarm-pacing.js
beat-swarm-palette.js
beat-swarm-groups.js
beat-swarm-music-lab.js
beat-swarm-director.js

Keep beat-swarm-mode.js as orchestrator.

10. Improve Theme → Palette Relationship

Final hierarchy should be:

Theme (UI selected)
  ↓
Palette (runtime musical arrangement)
  ↓
Roles
  ↓
Sound events

Themes should not change during a run.

Palettes may evolve.

Success Criteria

The system is working when:

soundtrack feels like one evolving track

enemies feel coordinated rather than random

player weapon remains readable

palette changes feel natural

pacing feels intentional