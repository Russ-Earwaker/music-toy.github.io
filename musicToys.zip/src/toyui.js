// src/toyui.js — ES module with named export + global auto-init fallback
// Builds header (title, Advanced, Random, Clear, Instrument) and a volume bar.
// Instrument selector is hidden in standard view and shown only in Advanced.

import { getInstrumentNames } from './audio-samples.js';
import { zoomInPanel, zoomOutPanel } from './zoom-overlay.js';

function stopHeaderLeak(el){
  ['pointerdown','mousedown','touchstart','click'].forEach(evt => {
    el.addEventListener(evt, e => e.stopPropagation(), { capture:true });
  });
}

export function initToyUI(panel, {
  toyName = 'Toy',
  defaultInstrument = 'tone',
  onRandom = null,
  onReset = null
} = {}){
  const idBase = (panel?.dataset?.toy || panel?.dataset?.toyid || toyName || 'toy').toLowerCase();
  const getToyId = ()=> idBase;
  panel.dataset.toy = getToyId();
  panel.dataset.toyid = panel.dataset.toy;

  // Header container
  let header = panel.querySelector('.toy-header');
  if (header) header.textContent = '';
  if (!header){
    header = document.createElement('div');
    header.className = 'toy-header';
    Object.assign(header.style, {
      display:'flex', alignItems:'center', justifyContent:'space-between',
      gap:'10px', padding:'8px 10px'
    });
    header.style.position = 'relative'; header.style.zIndex = '6';
    panel.prepend(header);
  }

  // Button helper
  const makeBtn = (label, title)=>{
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'toy-btn';
    b.title = title || label;
    Object.assign(b.style, {
      padding:'6px 10px', border:'1px solid #252b36', borderRadius:'10px',
      background:'#0d1117', color:'#e6e8ef', cursor:'pointer'
    });
    b.textContent = label;
    stopHeaderLeak(b);
    return b;
  };

  // Left side: Title + Advanced
  const left = document.createElement('div');
  Object.assign(left.style, { display:'flex', alignItems:'center', gap:'8px' });
  const titleEl = document.createElement('div');
  titleEl.style.pointerEvents = 'auto';
  titleEl.textContent = toyName;
  Object.assign(titleEl.style, { fontWeight:'600', color:'#e6e8ef' });
  const advBtn = makeBtn('Advanced', 'Open advanced edit');
  advBtn.addEventListener('click', ()=>{
    zoomInPanel(panel, ()=>{
      try{ zoomOutPanel(panel); }catch{}
    });
  });
  left.append(titleEl, advBtn);
  header.appendChild(left);

  // Right side: Random / Clear / Instrument (instrument only in Advanced)
  const right = document.createElement('div');
  Object.assign(right.style, { display:'flex', alignItems:'center', gap:'8px' });

  const randBtn  = makeBtn('Random', 'Randomize pattern');
  const clearBtn = makeBtn('Clear',  'Clear pattern');
  randBtn.addEventListener('click', (e)=>{
    e.stopPropagation();
    if (typeof onRandom === 'function'){ try{ onRandom(); }catch{} }
    try{ panel.dispatchEvent(new CustomEvent('toy-random', { bubbles:true })); }catch{}
  });
  clearBtn.addEventListener('click', (e)=>{
    e.stopPropagation();
    if (typeof onReset === 'function'){ try{ onReset(); }catch{} }
    try{ panel.dispatchEvent(new CustomEvent('toy-reset', { bubbles:true })); }catch{}
  });

  const instWrap = document.createElement('div');
  Object.assign(instWrap.style, { display:'none', alignItems:'center', gap:'6px' }); // hidden until Advanced
  const instSel = document.createElement('select');
  instSel.className = 'toy-instrument';
  Object.assign(instSel.style, { background:'#0d1117', color:'#e6e8ef', border:'1px solid #252b36', borderRadius:'8px', padding:'4px 6px' });
  stopHeaderLeak(instSel);

  try {
    const names = (getInstrumentNames && getInstrumentNames()) || [];
    names.forEach(n => { const opt = document.createElement('option'); opt.value = n; opt.textContent = n; instSel.appendChild(opt); });
  } catch {}
  instSel.value = defaultInstrument;
  instSel.addEventListener('change', ()=>{
    try{ panel.dispatchEvent(new CustomEvent('toy-instrument', { detail:{ value: instSel.value }, bubbles:true })); }catch{}
  });

  instWrap.appendChild(instSel);
  right.append(randBtn, clearBtn, instWrap);
  header.appendChild(right);

  // Volume (absolute, positioned under the .toy-body, inside panel)
  let volWrap = panel.querySelector('.toy-volwrap');
  if (!volWrap){ volWrap = document.createElement('div'); volWrap.className = 'toy-volwrap'; panel.appendChild(volWrap); }
  Object.assign(volWrap.style, {
    position:'absolute', zIndex:'5', pointerEvents:'auto',
    display:'flex', alignItems:'center', gap:'10px',
    left:'0', right:'0', top:'0',
    padding:'8px 10px',
    background:'rgba(13,17,23,0.92)', border:'1px solid #252b36', borderRadius:'12px',
    boxShadow:'0 10px 24px rgba(0,0,0,0.35)', backdropFilter:'blur(6px)',
    userSelect:'none'
  });
  // Clear/ensure contents
  volWrap.innerHTML = '';

  const muteBtn = document.createElement('button');
  muteBtn.type = 'button';
  muteBtn.title = 'Mute';
  muteBtn.innerHTML = "<svg viewBox='0 0 24 24' width='18' height='18' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M11 5L6 9H3v6h3l5 4V5z'/><path d='M23 9l-6 6M17 9l6 6'/></svg>";
  Object.assign(muteBtn.style, { width:'32px', height:'32px', display:'grid', placeItems:'center', background:'transparent', color:'#e6e8ef', border:'none', borderRadius:'8px', cursor:'pointer' });

  const vol = document.createElement('input');
  vol.type = 'range'; vol.min = '0'; vol.max = '100'; vol.step = '1'; vol.value = '100';
  Object.assign(vol.style, { flex:'1', height:'8px', borderRadius:'999px', appearance:'none', background:'#394150' });

  function updateVolBg(){
    const pct = Math.max(0, Math.min(100, (parseInt(vol.value,10)||0)));
    vol.style.background = `linear-gradient(to right, #6adf7a 0% ${pct}%, #394150 ${pct}% 100%)`;
  }
  vol.addEventListener('input', ()=>{
    const v = Math.max(0, Math.min(1, (parseInt(vol.value,10)||0)/100));
    updateVolBg();
    try{ panel.dispatchEvent(new CustomEvent('toy-volume', { detail: { toyId: getToyId(), value: v } })); }catch{}
  });
  updateVolBg();

  function positionVolume(){
    try{
      const header = panel.querySelector('.toy-header');
      const hh = header ? header.getBoundingClientRect().height : 0;
      const bodyEl = panel.querySelector('.toy-body') || panel;
      const pr = panel.getBoundingClientRect();
      const br = bodyEl.getBoundingClientRect();
      let top = Math.round((br.top - pr.top) + br.height);
      if (!isFinite(top) || top <= 0){ top = hh; }
      volWrap.style.top = Math.max(hh, top) + 'px';
      volWrap.style.left = '0';
      volWrap.style.right = '0';
      // enable pointer events only when clearly below header
      volWrap.style.pointerEvents = (Math.max(hh, top) > hh + 4) ? 'auto' : 'none';
    }catch{}
  }
  positionVolume();
  window.addEventListener('resize', positionVolume);
  try{ panel.addEventListener('toy-zoom', positionVolume); }catch{}

  volWrap.append(muteBtn, vol);

  // Show/hide instrument in Advanced only
  function syncAdvancedUI(){
    const zoomed = panel.classList.contains('toy-zoomed');
    instWrap.style.display = zoomed ? 'flex' : 'none';
  }
  syncAdvancedUI();
  try {
    panel.addEventListener('toy-zoom', (e)=>{
      const z = !!(e?.detail?.zoomed);
      panel.classList.toggle('toy-zoomed', z);
      syncAdvancedUI();
      positionVolume();
    });
  } catch {}

  return {
    setInstrument: (name)=>{ instSel.value = name; },
    get instrument(){ return instSel.value; }
  };
}

// Auto-initialize headers for panels that didn't call initToyUI themselves
function __autoInitToyUI(){
  try{
    const panels = document.querySelectorAll('.toy-panel');
    panels.forEach(p => {
      if (!p.querySelector('.toy-header')){
        const name = p.dataset.toyid || p.dataset.toy || 'Toy';
        const instr = p.dataset.instrument || 'tone';
        try { initToyUI(p, { toyName: name, defaultInstrument: instr }); } catch {}
      }
    });
  }catch{}
}

try{
  if (typeof window !== 'undefined'){
    // Export on window as well
    window.initToyUI = initToyUI;
    if (document.readyState === 'loading'){
      document.addEventListener('DOMContentLoaded', __autoInitToyUI);
    } else {
      __autoInitToyUI();
    }
    // Retry once to catch panels created during boot
    setTimeout(__autoInitToyUI, 200);
  }
}catch{}
