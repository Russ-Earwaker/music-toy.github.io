// src/ripplesynth.js
// Shim to use the solidified core implementation.
// This keeps main.js imports unchanged.
export { createRippleSynth } from './ripplesynth-core.js';
