export const PENTATONIC_OFFSETS = [0,2,4,7,9,12,14,16]; // C D E G A C D E
