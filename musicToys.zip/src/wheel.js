// src/wheel.js
// Wheel toy v2 (clean rebuild) — 16 spokes (16th notes), zero or one handle per spoke.
// - No outer progress ring.
// - Higher pitch = farther from center (12 semitones per spoke).
// - Starts empty (no notes).
// - Click on a spoke: add a handle near click (if none at that spoke).
// - Click on a handle: delete it (if you don't drag).
// - Drag: move the NEAREST existing handle (global).
// - Header: title + Random + Clear buttons (consistent with other toys).

import { resizeCanvasForDPR, clamp, randInt } from './utils.js';
// Fallback in case utils.randInt is absent
function _randInt(min, max){ min|=0; max|=0; if (max<min) [min,max]=[max,min]; return Math.floor(Math.random()*(max-min+1))+min; }
const RINT = (typeof randInt === 'function') ? randInt : _randInt;
import { initToySizing } from './toyhelpers-sizing.js';

const NOTE_NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
function midiName(m){ const n = m % 12, o = Math.floor(m/12) - 1; return NOTE_NAMES[n] + o; }

export function buildWheel(panel, deps = {}){
  // Header with title + buttons (matches other toys style)
  let header = panel.querySelector('.toy-header');
  if (!header){
    header = document.createElement('div');
    header.className = 'toy-header';
    const title = document.createElement('div');
    title.className = 'toy-title';
    title.textContent = 'Wheel';
    header.appendChild(title);
    panel.insertBefore(header, panel.firstChild);
  }
  // Ensure buttons container
  let btns = header.querySelector('.toy-buttons');
  if (!btns){
    btns = document.createElement('div');
    btns.className = 'toy-buttons';
    header.appendChild(btns);
  }
  // Ensure Random/Clear buttons
  let _btnRandInit = btns.querySelector('[data-action="random"]');
  if (!_btnRandInit){
    _btnRandInit = document.createElement('button');
    _btnRandInit.className = 'toy-btn';
    _btnRandInit.dataset.action = 'random';
    _btnRandInit.textContent = 'Random';
    btns.appendChild(_btnRandInit);
  }
  let _btnClearInit = btns.querySelector('[data-action="clear"]');
  if (!_btnClearInit){
    _btnClearInit = document.createElement('button');
    _btnClearInit.className = 'toy-btn';
    _btnClearInit.dataset.action = 'clear';
    _btnClearInit.textContent = 'Clear';
    btns.appendChild(_btnClearInit);
  }

  // Body + canvas
  let body = panel.querySelector('.toy-body');
  if (!body){ body = document.createElement('div'); body.className = 'toy-body'; panel.appendChild(body); }
  const canvas = document.createElement('canvas'); const ctx = canvas.getContext('2d');
  body.appendChild(canvas);

  // Sizing (square)
  const { setZoom } = initToySizing(panel, canvas, ctx, { squareFromWidth: true, minH: 180 });

  // Model
  const STEPS = 16, SEMIS = 12;
  const handles = new Array(STEPS).fill(null); // null = no note; otherwise 0..11 (outer = higher)
  let baseMidi = 60; // C4
  let playing = true;
  let step = 0;
  let lastTime = performance.now();
  let phase = 0;

  // Geometry
  function WH(){ return [canvas.clientWidth||canvas.width||300, canvas.clientHeight||canvas.height||300]; }
  function radii(){
    const [w,h] = WH(); const s = Math.min(w,h);
    return { cx: w/2, cy: h/2, Rmin: s*0.18, Rmax: s*0.44, Rout: s*0.46 };
  }
  function spokeAngle(i){ return -Math.PI/2 + (i/STEPS)*Math.PI*2; } // 0 at top, clockwise

  // Map screen angle (atan2 with dy down) -> spoke index
  function angleToSpokeFromAtan(ang){
    const TWO = Math.PI*2;
    // normalize ang to [0, 2π)
    while (ang < 0) ang += TWO;
    while (ang >= TWO) ang -= TWO;
    // diff from top (-π/2)
    let diff = ang + Math.PI/2;
    if (diff >= TWO) diff -= TWO;
    const idx = Math.round((diff / TWO) * STEPS) % STEPS;
    return idx;
  }

  function handlePos(i){
    const val = handles[i];
    if (val == null) return null;
    const { cx, cy, Rmin, Rmax } = radii();
    const t = val / (SEMIS - 1);
    const r = Rmin + t*(Rmax - Rmin);
    const a = spokeAngle(i);
    return { x: cx + Math.cos(a)*r, y: cy + Math.sin(a)*r, r, a };
  }

  function nearestHandle(x, y, maxPx=18){
    let best = null, bestD = maxPx;
    for (let i=0;i<STEPS;i++){
      const p = handlePos(i); if (!p) continue;
      const d = Math.hypot(p.x - x, p.y - y);
      if (d < bestD){ bestD = d; best = { spoke: i, ...p, d }; }
    }
    return best;
  }

  function posToSpokeSemi(x, y){
    const { cx, cy, Rmin, Rmax } = radii();
    const dx = x - cx, dy = y - cy;
    const ang = Math.atan2(dy, dx); // dy is screen-down; matches draw angles
    const spoke = angleToSpokeFromAtan(ang);
    const dist = Math.hypot(dx, dy);
    const t = clamp((dist - Rmin)/(Rmax - Rmin), 0, 1);
    const semi = Math.round(t * (SEMIS-1)); // outer = higher
    return { spoke, semi, dist };
  }

  // Interaction
  let dragging = null; // { startX, startY, wasOnHandle, moved }
  canvas.addEventListener('pointerdown', (e)=>{
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left, y = e.clientY - rect.top;
    const near = nearestHandle(x, y, 16);
    if (near){
      dragging = { startX: x, startY: y, wasOnHandle: true, moved: false };
    } else {
      // add if within ring
      const { cx, cy, Rmin, Rmax } = radii();
      const dist = Math.hypot(x - cx, y - cy);
      if (dist >= Rmin - 6 && dist <= Rmax + 6){
        const { spoke, semi } = posToSpokeSemi(x, y);
        handles[spoke] = semi;
        dragging = { startX: x, startY: y, wasOnHandle: false, moved: false };
      } else {
        dragging = null;
      }
    }
    if (dragging){ canvas.setPointerCapture?.(e.pointerId); e.preventDefault(); }
  });
  window.addEventListener('pointermove', (e)=>{
    if (!dragging) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left, y = e.clientY - rect.top;
    if (Math.abs(x - dragging.startX) > 2 || Math.abs(y - dragging.startY) > 2) dragging.moved = true;
    // Move nearest existing handle (global)
    const near = nearestHandle(x, y, 64);
    if (near){
      const { semi } = posToSpokeSemi(x, y);
      handles[near.spoke] = semi;
    }
  }, true);
  window.addEventListener('pointerup', (e)=>{
    if (!dragging) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left, y = e.clientY - rect.top;
    if (dragging.wasOnHandle && !dragging.moved){
      const near = nearestHandle(x, y, 18);
      if (near) handles[near.spoke] = null;
    }
    dragging = null;
    canvas.releasePointerCapture?.(e.pointerId);
  }, true);
  window.addEventListener('pointercancel', ()=>{ dragging = null; }, true);

    // Random/Clear helpers (idempotent)
function doRandom(){
  const minC = Math.ceil(STEPS*0.5), maxC = Math.floor(STEPS*0.75);
  const count = RINT(minC, maxC);
  const idxs = Array.from({length:STEPS}, (_,i)=>i);
  for (let i=idxs.length-1;i>0;i--){ const j = RINT(0,i); [idxs[i], idxs[j]] = [idxs[j], idxs[i]]; }
  handles.fill(null);
  for (let i=0;i<count;i++){ handles[idxs[i]] = RINT(0, SEMIS-1); }
}
function doClear(){ for (let i=0;i<STEPS;i++) handles[i] = null; }
// Buttons
const btnRand = panel.querySelector('.toy-header .toy-buttons [data-action="random"]');
const btnClear = panel.querySelector('.toy-header .toy-buttons [data-action="clear"]');
btnRand?.addEventListener('click', doRandom);
btnClear?.addEventListener('click', doClear);

// Event delegation (works with generic headers)
panel.addEventListener('click', (e)=>{
  const b = e.target.closest && e.target.closest('.toy-btn');
  if (!b) return;
  const label = (b.dataset.action || b.getAttribute('data-action') || b.textContent || '').trim().toLowerCase();
  if (label.startsWith('random')) doRandom();
  else if (label.startsWith('clear')) doClear();
}, true);

// Generic wrapper custom events support
panel.addEventListener('toy-random', doRandom);
panel.addEventListener('toy-clear', doClear);

// Draw

  function draw(){
    const [w,h] = WH();
    resizeCanvasForDPR(canvas, ctx);
    ctx.clearRect(0,0,canvas.width,canvas.height);
    const { cx, cy, Rmin, Rout } = radii();

    // bg
    ctx.fillStyle = '#0d1117'; ctx.fillRect(0,0,w,h);

    // spokes
    ctx.strokeStyle = '#252b36'; ctx.lineWidth = 2;
    for (let i=0;i<STEPS;i++){
      const a = spokeAngle(i);
      const x1 = cx + Math.cos(a)*Rmin, y1 = cy + Math.sin(a)*Rmin;
      const x2 = cx + Math.cos(a)*Rout, y2 = cy + Math.sin(a)*Rout;
      ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke();
    }

    // connection line among active handles (closed loop if >1)
    const pts = [];
    for (let i=0;i<STEPS;i++){ const p = handlePos(i); if (p) pts.push({i, x:p.x, y:p.y}); }
    if (pts.length > 1){
      ctx.strokeStyle = '#394150'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(pts[0].x, pts[0].y);
      for (let k=1;k<pts.length;k++){ ctx.lineTo(pts[k].x, pts[k].y); }
      ctx.lineTo(pts[0].x, pts[0].y);
      ctx.stroke();
    }

    // handles
    for (let i=0;i<STEPS;i++){
      const p = handlePos(i); if (!p) continue;
      const isNow = (i === step);
      ctx.fillStyle = isNow ? '#f4932f' : '#e6e8ef';
      ctx.beginPath(); ctx.arc(p.x, p.y, isNow? 7 : 5, 0, Math.PI*2); ctx.fill();
      ctx.strokeStyle = '#11151d'; ctx.lineWidth = 1; ctx.stroke();
    }
  }

  // Timing
  const onNote = (typeof deps.onNote === 'function') ? deps.onNote : null;
  const getBpm = (typeof deps.getBpm === 'function') ? deps.getBpm : (()=> (window.musictoyBpm || 120));
  function tick(dt){
    const bpm = getBpm();
    const stepDur = (60/bpm)/4; phase += dt/1000/stepDur;
    while (phase >= 1){
      phase -= 1;
      const semi = handles[step];
      if (semi != null){
        const midi = baseMidi + semi;
        const name = midiName(midi);
        const vel = 0.9;
        panel.dispatchEvent(new CustomEvent('wheel-note', { detail: { step, midi, name, velocity: vel } }));
        if (onNote) try { onNote(midi, name, vel); } catch {}
      }
      step = (step + 1) % STEPS;
    }
  }
  function loop(now){
    const dt = Math.min(100, now - lastTime); lastTime = now;
    if (playing) tick(dt);
    draw(); requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  // Zoom + keys
  panel.dataset.toy = 'wheel';
  panel.addEventListener('toy-zoom', (e)=> setZoom(e.detail?.zoomed));
  panel.tabIndex = 0;
  panel.addEventListener('keydown', (e)=>{
    if (e.key === 'ArrowUp'){ baseMidi += 12; e.preventDefault(); }
    else if (e.key === 'ArrowDown'){ baseMidi -= 12; e.preventDefault(); }
  });

  return { setPlaying(v){ playing = !!v; }, setBaseMidi(m){ baseMidi = m|0; } };
}
