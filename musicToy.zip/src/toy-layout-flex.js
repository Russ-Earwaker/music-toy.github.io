// src/toy-layout-flex.js
// Stable layout fix for zoom scaling (no flicker, no loops):
// 1) Inject minimal CSS so .toy-panel lays out as column: header/controls on top, visual window fills the rest.
// 2) If a toy lacks .toy-body, create it and move its canvas/SVG into it (no other DOM changes).
// 3) Make canvas/SVG fill the body; keep canvas backing store sharp with a throttled ResizeObserver.
// Works for wheel, rippler, bouncer, grid. <300 lines.
(function(){
  // ---- Inject CSS once ----
  const STYLE_ID = "toy-layout-flex-style";
  if (!document.getElementById(STYLE_ID)){
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .toy-panel { min-height: 0; }
      /* Column layout: header/controls stack naturally; body fills leftover */
      [data-toy] { display: flex; flex-direction: column; min-height: 0; }
      [data-toy] .toy-header, [data-toy] .toy-controls { flex: 0 0 auto; }
      [data-toy] .toy-body { flex: 1 1 auto; min-height: 0; position: relative; }
      [data-toy] .toy-body canvas, [data-toy] .toy-body svg { width: 100% !important; height: 100% !important; display: block; }
    `;
    document.head.appendChild(style);
  }

  const DPR = ()=> window.devicePixelRatio || 1;

  function pickVisual(panel){
    return panel.querySelector(".wheel-canvas, .grid-canvas, .rippler-canvas, .bouncer-canvas, canvas, svg");
  }

  function ensureBody(panel){
    let body = panel.querySelector(".toy-body");
    if (!body){
      body = document.createElement("div");
      body.className = "toy-body";
      // place body right before the first visual and move the visual inside
      const vis = pickVisual(panel);
      if (vis && vis.parentNode){
        vis.parentNode.insertBefore(body, vis);
        body.appendChild(vis);
      } else {
        // fallback: append at end; later visual observer will move it in
        panel.appendChild(body);
      }
    }
    return body;
  }

  function wirePanel(panel){
    const body = ensureBody(panel);
    const visual = pickVisual(panel);
    if (visual && visual.parentElement !== body) body.appendChild(visual);

    // Keep canvas/SVG pixel buffer matched to body size (no CSS size changes here)
    const resize = ()=>{
      const w = Math.max(1, Math.round(body.clientWidth));
      const h = Math.max(1, Math.round(body.clientHeight));
      if (visual && visual.tagName === "CANVAS"){
        const pxW = Math.max(1, Math.round(w * DPR()));
        const pxH = Math.max(1, Math.round(h * DPR()));
        if (visual.width !== pxW) visual.width = pxW;
        if (visual.height !== pxH) visual.height = pxH;
      } else if (visual && visual.tagName === "SVG"){
        visual.setAttribute("viewBox", `0 0 ${w} ${h}`);
        visual.setAttribute("preserveAspectRatio", "none");
      }
    };
    resize();
    let raf = 0;
    const ro = new ResizeObserver(()=>{
      if (raf) return;
      raf = requestAnimationFrame(()=>{ raf = 0; resize(); });
    });
    ro.observe(body);
  }

  function boot(){
    document.querySelectorAll(".toy-panel").forEach(wirePanel);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  // Handle toys added later
  const root = document.getElementById("board") || document.body;
  const mo = new MutationObserver((muts)=>{
    for (const m of muts){
      (m.addedNodes||[]).forEach(n=>{
        if (n.nodeType===1 && n.classList?.contains("toy-panel")) wirePanel(n);
      });
    }
  });
  mo.observe(root, { childList:true, subtree:true });
})();