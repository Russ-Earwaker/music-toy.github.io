// src/toy-visual-css.js
// Injects tiny CSS rules at runtime — no external .css file needed.
// Square toys (wheel/rippler/bouncer): canvas/SVG fills width and stays square.
// Grid: canvas fills both width and height of its toy body.
(function(){
  const id = "toy-visual-css-style";
  if (document.getElementById(id)) return;
  const css = `
  [data-toy="wheel"] canvas, [data-toy="wheel"] svg,
  [data-toy="rippler"] canvas, [data-toy="rippler"] svg,
  [data-toy="bouncer"] canvas, [data-toy="bouncer"] svg {
    width: 100% !important;
    height: auto !important;
    aspect-ratio: 1 / 1;
    display: block;
  }

  [data-toy="grid"] .toy-body canvas, [data-toy="grid"] .toy-body svg,
  [data-toy^="loopgrid"] .toy-body canvas, [data-toy^="loopgrid"] .toy-body svg {
    width: 100% !important;
    height: 100% !important;
    display: block;
  }`;
  const style = document.createElement("style");
  style.id = id;
  style.textContent = css;
  document.head.appendChild(style);
})();