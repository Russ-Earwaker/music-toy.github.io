// src/ripplesynth-utils.js — pure helpers (math/geometry/quantize) for RippleSynth
// TODO: migrate pure helper functions that don't touch DOM or audio here.
// Export nothing for now to avoid breaking imports. Add functions as we refactor.
