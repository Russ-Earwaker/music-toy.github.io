// src/toy-zoom-forcefill.js
// FORCE-FILL v3 (flicker-safe):
// - No aspect-ratio hacks
// - No MutationObserver on styles (avoids oscillation)
// - One-time CSS fill + ResizeObserver (throttled with rAF) to keep canvas backing store crisp
// - Handles toys instantiated after load
(function(){
  const DPR = ()=> window.devicePixelRatio || 1;

  function primaryVisual(panel){
    const body = panel.querySelector(".toy-body") || panel;
    // Prefer common classes; fallback to first canvas/svg
    let v = body.querySelector(".wheel-canvas, .grid-canvas, .rippler-canvas, .bouncer-canvas");
    if (!v) v = body.querySelector("canvas, svg");
    return { body, visual: v };
  }

  function ensureRelative(el){
    if (!el) return;
    const cs = getComputedStyle(el);
    if (cs.position === "static") el.style.position = "relative";
  }

  function fillOnce(visual){
    if (!visual) return;
    visual.style.setProperty("width","100%","important");
    visual.style.setProperty("height","100%","important");
    visual.style.display = "block";
    visual.style.removeProperty("max-width");
  }

  function wire(panel){
    const { body, visual } = primaryVisual(panel);
    if (!body || !visual) return;
    ensureRelative(body);
    fillOnce(visual);

    // Throttled resize to keep backing store in sync; does not touch CSS sizes
    let raf = 0;
    const onResize = ()=>{
      if (raf) return;
      raf = requestAnimationFrame(()=>{
        raf = 0;
        if (visual.tagName === "CANVAS"){
          const w = Math.max(1, Math.round(body.clientWidth));
          const h = Math.max(1, Math.round(body.clientHeight));
          const pxW = Math.max(1, Math.round(w * DPR()));
          const pxH = Math.max(1, Math.round(h * DPR()));
          if (visual.width !== pxW) visual.width = pxW;
          if (visual.height !== pxH) visual.height = pxH;
        } else if (visual.tagName === "SVG"){
          const w = Math.max(1, Math.round(body.clientWidth));
          const h = Math.max(1, Math.round(body.clientHeight));
          visual.setAttribute("viewBox", `0 0 ${w} ${h}`);
          visual.setAttribute("preserveAspectRatio", "none");
        }
      });
    };
    const ro = new ResizeObserver(onResize);
    ro.observe(body);
    onResize(); // initial
  }

  function scanAll(){
    document.querySelectorAll(".toy-panel").forEach(wire);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", scanAll);
  else scanAll();

  // Handle toys added later
  const root = document.getElementById("board") || document.body;
  const mo = new MutationObserver((muts)=>{
    for (const m of muts){
      (m.addedNodes||[]).forEach(n=>{
        if (n.nodeType!==1) return;
        if (n.classList?.contains("toy-panel")) wire(n);
        n.querySelectorAll?.(".toy-panel").forEach(wire);
      });
    }
  });
  mo.observe(root, { childList:true, subtree:true });
})();