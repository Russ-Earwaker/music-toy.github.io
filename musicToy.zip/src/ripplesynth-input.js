// src/ripplesynth-input.js (generic-UI only)
export function makePointerHandlers(cfg) {
  const { canvas, vw, vh, EDGE, blocks, ripples, generatorRef, clamp, getCanvasPos } = cfg;
  let capturedId = null;

  function hitBlockAt(pos) {
    for (let i = blocks.length - 1; i >= 0; i--) {
      const b = blocks[i];
      if (pos.x >= b.x && pos.x <= b.x + b.w && pos.y >= b.y && pos.y <= b.y + b.h) {
        return { b, i };
      }
    }
    return null;
  }

  function addRippleAt(x, y) {
    const t0 = performance.now() * 0.001;
    ripples.push({ x, y, t0, kind: 'primary' });
    if (ripples.length > 128) ripples.splice(0, ripples.length - 128);
    ripples.push({ x, y, t0: t0 + 0.50, kind: 'secondary' });
    ripples.push({ x, y, t0: t0 + 1.00, kind: 'tertiary' });
  }

  function pointerDown(e) {
    try { canvas.setPointerCapture && canvas.setPointerCapture(e.pointerId); capturedId = e.pointerId; } catch {}
    const pos = getCanvasPos(e);

    const hit = hitBlockAt(pos);
    if (hit) {
      cfg.state.draggingBlock = hit.b;
      cfg.state.dragOff = { x: pos.x - hit.b.x, y: pos.y - hit.b.y };
    } else {
      generatorRef.value = { x: pos.x, y: pos.y };
      addRippleAt(pos.x, pos.y);
    }
  }

  function pointerMove(e) {
    if (!cfg.state.draggingBlock) return;
    const pos = getCanvasPos(e);
    const b = cfg.state.draggingBlock;
    b.x = clamp(pos.x - cfg.state.dragOff.x, EDGE, vw() - EDGE - b.w);
    b.y = clamp(pos.y - cfg.state.dragOff.y, EDGE, vh() - EDGE - b.h);
  }

  function pointerUp(e) {
    cfg.state.draggingBlock = null;
    try {
      if (capturedId != null && canvas.hasPointerCapture && canvas.hasPointerCapture(capturedId)) {
        canvas.releasePointerCapture(capturedId);
      }
    } catch {}
    capturedId = null;
  }

  return { pointerDown, pointerMove, pointerUp };
}
