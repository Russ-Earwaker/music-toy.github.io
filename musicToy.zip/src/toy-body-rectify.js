// src/toy-body-rectify.js
// Create a proper visual window for each toy and ensure its canvas/SVG fills it.
// - Adds a .toy-body when missing (wheel/rippler/bouncer lacked one in your logs)
// - Makes square toys' bodies square (aspect-ratio: 1/1) WITHOUT observers on styles
// - Sets visual width/height:100% (no positioning hacks)
// - Keeps canvas/SVG backing store in sync via a throttled ResizeObserver (no flicker)
(function(){
  const SQUARE = new Set(["wheel","rippler","bouncer"]);
  const DPR = ()=> window.devicePixelRatio || 1;

  function findVisual(panel){
    // Prefer known classes, then fallback
    return panel.querySelector(".wheel-canvas, .rippler-canvas, .bouncer-canvas, .grid-canvas, canvas, svg");
  }

  function ensureBody(panel){
    let body = panel.querySelector(".toy-body");
    if (!body){
      body = document.createElement("div");
      body.className = "toy-body";
      // place before first visual; move visual inside to avoid reflow surprises
      const vis = findVisual(panel);
      if (vis && vis.parentNode){
        vis.parentNode.insertBefore(body, vis);
        body.appendChild(vis);
      } else {
        panel.appendChild(body);
      }
    }
    // base styles (no absolute positioning)
    body.style.position = "relative";
    body.style.width = "100%";
    body.style.minHeight = "0";
    return body;
  }

  function fillVisual(body, visual){
    if (!visual) return;
    visual.style.setProperty("width","100%","important");
    visual.style.setProperty("height","100%","important");
    visual.style.display = "block"; // avoid baseline gap

    // Keep pixel buffer sized to body
    let raf = 0;
    const onResize = ()=>{
      if (raf) return;
      raf = requestAnimationFrame(()=>{
        raf = 0;
        const w = Math.max(1, Math.round(body.clientWidth));
        const h = Math.max(1, Math.round(body.clientHeight));
        if (visual.tagName === "CANVAS"){
          const pxW = Math.max(1, Math.round(w * DPR()));
          const pxH = Math.max(1, Math.round(h * DPR()));
          if (visual.width !== pxW) visual.width = pxW;
          if (visual.height !== pxH) visual.height = pxH;
        } else if (visual.tagName === "SVG"){
          visual.setAttribute("viewBox", `0 0 ${w} ${h}`);
          visual.setAttribute("preserveAspectRatio", "none");
        }
      });
    };
    const ro = new ResizeObserver(onResize);
    ro.observe(body);
    onResize();
  }

  function process(panel){
    const kind = (panel.getAttribute("data-toy")||"").toLowerCase();
    const body = ensureBody(panel);
    if (SQUARE.has(kind)){
      // Static aspect ratio; no observers -> avoids flicker
      body.style.aspectRatio = "1 / 1";
      body.style.height = "auto";
    }
    const visual = findVisual(panel) || body.querySelector("canvas,svg");
    if (visual) fillVisual(body, visual);
  }

  function boot(){
    document.querySelectorAll(".toy-panel").forEach(process);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  // Handle toys added later
  const root = document.getElementById("board") || document.body;
  const mo = new MutationObserver((muts)=>{
    for (const m of muts){
      (m.addedNodes||[]).forEach(n=>{
        if (n.nodeType===1 && n.classList?.contains("toy-panel")) process(n);
      });
    }
  });
  mo.observe(root, { childList:true, subtree:true });
})();