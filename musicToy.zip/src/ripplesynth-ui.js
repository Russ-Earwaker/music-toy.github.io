// src/ripplesynth-ui.js — UI-specific helpers for RippleSynth
// TODO: progressively migrate pointer handlers, drawing, and layout logic here.
// Export nothing for now to avoid breaking imports. Add functions as we refactor.
