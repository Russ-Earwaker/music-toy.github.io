// src/grid-zoom-override.js
// Grid-only safety shim: make the grid's canvas fill its toy body and keep backing store sharp.
(function(){
  const DPR = ()=> window.devicePixelRatio || 1;
  function wire(panel){
    const body = panel.querySelector(".toy-body") || panel;
    const canvas = body.querySelector(".grid-canvas") || body.querySelector("canvas");
    if (!canvas) return;
    canvas.style.setProperty("width","100%","important");
    canvas.style.setProperty("height","100%","important");
    canvas.style.display = "block";
    let raf = 0;
    const resize = ()=>{
      if (raf) return;
      raf = requestAnimationFrame(()=>{
        raf = 0;
        const w = Math.max(1, Math.round(body.clientWidth));
        const h = Math.max(1, Math.round(body.clientHeight));
        const pxW = Math.max(1, Math.round(w * DPR()));
        const pxH = Math.max(1, Math.round(h * DPR()));
        if (canvas.width !== pxW) canvas.width = pxW;
        if (canvas.height !== pxH) canvas.height = pxH;
      });
    };
    const ro = new ResizeObserver(resize);
    ro.observe(body);
    resize();
  }
  function boot(){
    document.querySelectorAll('[data-toy^="loopgrid"],[data-toy="grid"]').forEach(wire);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();