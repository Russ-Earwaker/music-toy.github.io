// src/toy-square-once.js
// Make square-visual toys (wheel, rippler, bouncer) use a square toy-body once at boot.
// We set height = current width in CSS pixels, then leave it alone (no observers) to avoid flicker.
// This is conservative and shouldn't fight existing sizing logic.
(function(){
  function squareBody(panel){
    const body = panel.querySelector('.toy-body') || panel;
    const w = Math.max(1, Math.round(body.clientWidth));
    body.style.height = w + 'px';
  }
  function boot(){
    document.querySelectorAll('[data-toy="wheel"],[data-toy="rippler"],[data-toy="bouncer"]').forEach(squareBody);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  // Optional: re-square on window resize (not on board zoom, since that's a transform)
  let t = 0;
  window.addEventListener('resize', ()=>{
    cancelAnimationFrame(t);
    t = requestAnimationFrame(boot);
  });
})();