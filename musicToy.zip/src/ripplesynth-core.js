// src/ripplesynth-core.js (generic-UI only)
import { initToySizing, randomizeRects, clamp } from './toyhelpers.js';
import { drawWaves } from './ripplesynth-waves.js';
import { drawBlocksSection } from './ripplesynth-blocks.js';
import { initParticles, drawParticles } from './ripplesynth-particles.js';
import { makePointerHandlers } from './ripplesynth-input.js';

const EDGE = 10;
const NUM_STEPS = 16;
const LOOP_SECONDS = 4;
const stepSeconds = () => LOOP_SECONDS / NUM_STEPS;

function resizeCanvasForDPR(canvas, ctx) {
  const dpr = window.devicePixelRatio || 1;
  const w = Math.max(1, Math.round((canvas.clientWidth || 0) * dpr));
  const h = Math.max(1, Math.round((canvas.clientHeight || 0) * dpr));
  if (canvas.width !== w || canvas.height !== h) {
    canvas.width = w; canvas.height = h;
    ctx.imageSmoothingEnabled = false;
  }
}
function drawFrame(ctx, w, h) {
  ctx.save();
  ctx.lineWidth = 2;
  ctx.strokeStyle = 'rgba(255,255,255,0.25)';
  ctx.strokeRect(1, 1, w - 2, h - 2);
  ctx.restore();
}

export function createRippleSynth(panel, rect) {
  // STRICT: use existing generic UI only (no fallback). Find the canvas the same way other toys do.
  const canvas = panel.querySelector('.toy-body canvas, canvas');
  if (!canvas) {
    console.warn('[rippler] generic UI expected: missing <canvas> in panel.');
    return;
  }
  const container = panel;
  canvas.style.touchAction = 'none';
  canvas.tabIndex = canvas.tabIndex || 0;

  const ctx = canvas.getContext('2d', { alpha: false });

  try { initToySizing(container, canvas, ctx, { squareFromWidth: true, minH: 120 }); } catch {}

  const layout = () => resizeCanvasForDPR(canvas, ctx);
  layout();
  new ResizeObserver(layout).observe(container);

  const vw = () => canvas.width;
  const vh = () => canvas.height;

  function getCanvasPos(evt) {
    const r = canvas.getBoundingClientRect();
    const sx = canvas.width / Math.max(1, r.width);
    const sy = canvas.height / Math.max(1, r.height);
    return { x: (evt.clientX - r.left) * sx, y: (evt.clientY - r.top) * sy };
  }

  // ---- state ----
  let blocks = makeBlocks(5);
  randomizeRects(blocks, vw(), vh(), EDGE);

  initParticles(vw, vh, EDGE, 56);

  let generator = null;
  const ripples = [];
  const state = { draggingGen: false, draggingBlock: null, dragOff: { x: 0, y: 0 } };
  const enrolled = new Set();
  const rejoinNextLoop = new Set();

  // ---- input handlers ----
  const { pointerDown, pointerMove, pointerUp } = makePointerHandlers({
    canvas, vw, vh, EDGE,
    blocks, ripples,
    generatorRef: {
      get value() { return generator; },
      set value(v) { generator = v; }
    },
    clamp, getCanvasPos,
    ensureAudioContext: () => {}, quantizeNextStep: (t) => t,
    recalcBlockPhases: (b) => b, NUM_STEPS, stepSeconds,
    enrolled, rejoinNextLoop, state,
  });

  canvas.addEventListener('pointerdown', pointerDown);
  canvas.addEventListener('pointermove', pointerMove);
  window.addEventListener('pointerup', pointerUp);
  window.addEventListener('pointercancel', pointerUp);
  window.addEventListener('blur', pointerUp);

  // ---- hook standard controls already in the generic header ----
  const btnRandom = panel.querySelector('[data-action="random"]');
  const btnClear  = panel.querySelector('[data-action="clear"]');
  const btnZoom   = panel.querySelector('[data-action="zoom"]');

  let zoomScale = 1.0;
  function applyZoom() {
    canvas.style.transformOrigin = 'top left';
    canvas.style.transform = `scale(${zoomScale})`;
    layout();
    randomizeRects(blocks, vw(), vh(), EDGE);
  }
  btnRandom && btnRandom.addEventListener('click', () => {
    randomizeRects(blocks, vw(), vh(), EDGE);
  });
  btnClear && btnClear.addEventListener('click', () => {
    ripples.length = 0;
    generator = null;
  });
  btnZoom && btnZoom.addEventListener('click', () => {
    zoomScale = (zoomScale === 1 ? 1.15 : 1.0);
    applyZoom();
  });

  // ---- draw loop ----
  function draw() {
    const now = performance.now() * 0.001;
    const w = vw(), h = vh();
    if (w === 0 || h === 0) { requestAnimationFrame(draw); return; }

    const cx = w * 0.5, cy = h * 0.5;
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, '#0a0a0a'); grad.addColorStop(1, '#000');
    ctx.fillStyle = grad; ctx.fillRect(0, 0, w, h);

    drawFrame(ctx, w, h);
    drawWaves(ctx, { now, cx, cy, ripples, w, h });
    try { drawParticles(ctx, now); } catch {}

    drawBlocksSection(ctx, blocks, cx, cy, ripples, 1.0, null, { scale: 1.0 }, null, null, now);
    requestAnimationFrame(draw);
  }
  requestAnimationFrame(draw);
}

function makeBlocks(n) {
  const arr = [];
  for (let i = 0; i < n; i++) {
    arr.push({ x: 0, y: 0, w: 40, h: 40, vx: 0, vy: 0, rippleAge: 999, rippleMax: 0.9 });
  }
  return arr;
}
